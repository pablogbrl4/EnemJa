﻿using CursoVideo.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Xml.Linq;

namespace CursoVideo.Model
{
    class ModelXML
    {
        // Retorna os dados contidos no xml 
        public List<PergDTO> xmlP()
        {
            var xml = XDocument.Load("C:\\Program Files (x86)\\Franco Desenvolvimentos\\Enem Já\\Model\\Perguntas.xml");

            List<PergDTO> pergun = xml.Root.Elements("pergunta").Select(q => new PergDTO
            {
                materia = (string)q.Attribute("materia"),
                tema = (string)q.Attribute("tema"),
                per = (string)q.Attribute("per"),
                Pergunta = q.Elements("p").
                Select(s => (string)s).ToList(),
                A = q.Elements("a").
                Select(s => (string)s).ToList(),
                B = q.Elements("b").
                Select(s => (string)s).ToList(),
                C = q.Elements("c").
                Select(s => (string)s).ToList(),
                D = q.Elements("d").
                Select(s => (string)s).ToList(),
                R = q.Elements("r").
                Select(s => (string)s).ToList(),
            }).ToList();
            return pergun;
        }

        public string Cadastrar(PergDTO dto)
        {
            try
            {
                XElement x = new XElement("pergunta");
                x.Add(new XAttribute("materia", dto.materia));
                x.Add(new XAttribute("tema", dto.tema));
                x.Add(new XAttribute("per", dto.per));

                x.Add(new XElement("p", dto.Perguntas));
                x.Add(new XElement("a", dto.a));
                x.Add(new XElement("b", dto.b));
                x.Add(new XElement("c", dto.c));
                x.Add(new XElement("d", dto.d));
                x.Add(new XElement("r", dto.r));


                //XElement xml = XElement.Load("../../Perguntas.xml");
                //xml.Add(x);
                //xml.Save("../../Perguntas.xml");

                XElement xml = XElement.Load("C:\\Program Files (x86)\\Franco Desenvolvimentos\\Enem Já\\Model\\Perguntas.xml");
                xml.Add(x);
                xml.Save("C:\\Program Files (x86)\\Franco Desenvolvimentos\\Enem Já\\Model\\Perguntas.xml");

                return "0";
            }
            catch (Exception ex)
            {
                return "Não foi possivel cadastrar " + ex;
            }

        }

        public string Editar(PergDTO dto)
        {
            try
            {
                Excluir(dto);

                Cadastrar(dto);

                return "0";
            }
            catch (Exception ex)
            {
                return "Não foi possivel cadastrar" + ex;
            }

        }

        public string Excluir(PergDTO excluir)
        {
            try
            {
                XElement xml = XElement.Load("C:\\Program Files (x86)\\Franco Desenvolvimentos\\Enem Já\\Model\\Perguntas.xml");
                XElement x = xml.Elements().Where(p => p.Attribute("materia").Value.Equals(excluir.materia.ToString()))
                    .Where(p => p.Attribute("tema").Value.Equals(excluir.tema.ToString()))
                    .Where(p => p.Attribute("per").Value.Equals(excluir.per.ToString())).First();

                if (x != null)
                {
                    x.Remove();
                }
                xml.Save("C:\\Program Files (x86)\\Franco Desenvolvimentos\\Enem Já\\Model\\Perguntas.xml");
                return "0";
            }
            catch (Exception ex)
            {
                return "Não foi possivel detectar o banco de dados " + ex;
            }
        }
    }

}