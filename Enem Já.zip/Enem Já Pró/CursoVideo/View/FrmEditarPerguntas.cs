﻿using CursoVideo.DTO;
using CursoVideo.Model;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace CursoVideo.View
{
    public partial class FrmEditarPerguntas : Form
    {
        public FrmEditarPerguntas()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
        }

        private void refresh()
        {
            // Uma lista do que vem do xml
            dto = xml.xmlP();

            int contar = dto.Count;

            var materia = dtoMateria.materia = dto[0].materia;
            cbxMateria.Items.Add(materia);

            // Preenche comboBox
            for (int j = 1; j < contar; j++)
            {
                var materias = dtoMateria.materia = dto[j].materia;

                int t = 0;

                foreach (string item in cbxMateria.Items)
                {
                    if (materias == item)
                    {
                        t = 1;
                    }
                }
                if (t != 1)
                {
                    cbxMateria.Items.Add(materias);
                }
            }
            cbxTema.Enabled = false;
            cbxNPerg.Enabled = false;

            txtPer.Text = "";
            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
            txtD.Text = "";

        }

        ModelXML xml = new ModelXML();
        List<PergDTO> dto = new List<PergDTO>();
        PergDTO dtoMateria = new PergDTO();

        private void FrmEditarPerguntas_Load(object sender, System.EventArgs e)
        {
            refresh();
        }

        private void cbxTema_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            cbxNPerg.Items.Clear();

            dto = xml.xmlP();

            int contar = dto.Count;

            for (int j = 0; j < contar; j++)
            {
                var materia = dtoMateria.materia = dto[j].materia;
                var tem = dtoMateria.materia = dto[j].tema;
                var per = dtoMateria.materia = dto[j].per;

                if (materia == cbxMateria.Text && tem == cbxTema.Text)
                {
                    cbxNPerg.Items.Add(per);
                }
            }

            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
            txtD.Text = "";
            txtPer.Text = "";

            cbxNPerg.Enabled = true;
        }

        private void cbxMateria_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            cbxNPerg.Items.Clear();
            cbxTema.Items.Clear();

            List<PergDTO> results = dto.Where(o => (o.materia == cbxMateria.Text)).Select(s => s).ToList();
            int contar = results.Count();

            cbxTema.Items.Add(results[0].tema);

            int t = 0;

            for (int con = 1; con < contar; con++)
            {
                foreach (string item in cbxTema.Items)
                {
                    if (results[con].tema != item)
                    {
                        t = 1;
                    }
                }
                if (t == 1)
                {
                    cbxTema.Items.Add(results[con].tema);
                    t = 0;
                }
            }
            cbxMateria.Enabled = true;
            cbxTema.Enabled = true;

            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
            txtD.Text = "";
            txtPer.Text = "";
        }

        private void cbxNPerg_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            List<PergDTO> results = dto.Where(o => (o.tema == cbxTema.Text && o.per == cbxNPerg.Text)).Select(s => s).ToList();

            txtPer.Text = results[0].Pergunta[0];

            txtA.Text = results[0].A[0];

            txtB.Text = results[0].B[0];

            txtC.Text = results[0].C[0];

            txtD.Text = results[0].D[0];

            if (results[0].A[0] == results[0].R[0])
            {
                cbxA.Checked = true;
            }
            else if (results[0].B[0] == results[0].R[0])
            {
                cbxB.Checked = true;
            }
            else if (results[0].C[0] == results[0].R[0])
            {
                cbxC.Checked = true;
            }
            else if (results[0].D[0] == results[0].R[0])
            {
                cbxD.Checked = true;
            }
        }

        private void btnStart_Click(object sender, System.EventArgs e)
        {
            dto = xml.xmlP();

            dtoMateria.materia = cbxMateria.Text;
            dtoMateria.tema = cbxTema.Text;
            dtoMateria.per = cbxNPerg.Text;

            dtoMateria.Perguntas = txtPer.Text;
            dtoMateria.a = txtA.Text;
            dtoMateria.b = txtB.Text;
            dtoMateria.c = txtC.Text;
            dtoMateria.d = txtD.Text;

            if (cbxA.Checked == true)
            {
                dtoMateria.r = txtA.Text;
            }
            else if (cbxB.Checked == true)
            {
                dtoMateria.r = txtB.Text;
            }
            else if (cbxC.Checked == true)
            {
                dtoMateria.r = txtC.Text;
            }
            else if (cbxD.Checked == true)
            {
                dtoMateria.r = txtD.Text;
            }

            if (cbxMateria.Text != "" && cbxTema.Text != "" && cbxTema.Text != "" && txtPer.Text != ""
                && txtA.Text != "" && txtB.Text != "" && txtC.Text != "" && txtD.Text != "")
            {
                xml.Editar(dtoMateria);
                MessageBox.Show("Alterado com sucesso");
                refresh();
            }
            else
            {
                MessageBox.Show("Preencha Todos os Campos", "Erro",
                MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void cbxA_CheckedChanged(object sender, System.EventArgs e)
        {
            if (cbxA.Checked == true)
            {
                cbxB.Checked = false;
                cbxC.Checked = false;
                cbxD.Checked = false;
            }
        }

        private void cbxB_CheckedChanged(object sender, System.EventArgs e)
        {
            if (cbxB.Checked == true)
            {
                cbxA.Checked = false;
                cbxC.Checked = false;
                cbxD.Checked = false;
            }
        }

        private void cbxC_CheckedChanged(object sender, System.EventArgs e)
        {
            if (cbxC.Checked == true)
            {
                cbxB.Checked = false;
                cbxA.Checked = false;
                cbxD.Checked = false;
            }
        }

        private void cbxD_CheckedChanged(object sender, System.EventArgs e)
        {
            if (cbxD.Checked == true)
            {
                cbxB.Checked = false;
                cbxA.Checked = false;
                cbxC.Checked = false;
            }
        }
    }
}