﻿using CursoVideo.View.Videos;
using System;
using System.IO;
using System.Windows.Forms;
using System.Xml;
namespace CursoVideo.View
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

            //this.Height = Screen.PrimaryScreen.Bounds.Height;

            //this.Width = Screen.PrimaryScreen.Bounds.Width;

            //this.TopMost = true;

        }

        public void FecharCLasseFilha()
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {

                if (Application.OpenForms[i].IsMdiChild)
                {
                    Application.OpenForms[i].Close();
                }
            }
        }

        private void CSharpMenuItem1_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmMat frm = new FrmMat();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void JavaMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmPort frm = new FrmPort();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void MySqlMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmGeo frm = new FrmGeo();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void PhpMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmBiologia frm = new FrmBiologia();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void HtmlMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmFilo frm = new FrmFilo();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void CssMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmFisica frm = new FrmFisica();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void JavaScriptMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmQui frm = new FrmQui();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void SobreMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmSobre frm = new FrmSobre();
            frm.MdiParent = this;
            frm.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            Application.Exit();
        }

        private void sociologiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmSocio frm = new FrmSocio();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void historiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmHist frm = new FrmHist();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void cadastrarPerguntasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmAddPeguntas frm = new FrmAddPeguntas();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void editarPerguntasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FecharCLasseFilha();
            FrmEditarPerguntas frm = new FrmEditarPerguntas();
            frm.MdiParent = this;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }
    }
}