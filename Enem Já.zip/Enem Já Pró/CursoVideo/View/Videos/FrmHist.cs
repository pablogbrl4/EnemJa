﻿using CursoVideo.DTO;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmHist : Form
    {
        public FrmHist()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }

        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }

        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }

        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "História";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void linhaDoTempoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=o7DGlQXNvag&index=1");
        }

        private void préHistóriaDefiniçãoEEstudoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {     
            LeitorCodigo("https://www.youtube.com/watch?v=djMzV_7oc8w");
            
        }

        private void mesopotâmiaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZclCE5ajfpA");
        }

        private void gréciaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OZgWoAGjKJQ");
        }

        private void romaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=kf251mBiTBM");
        }

        private void impérioBizantinoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cPBonGqr2ok");
            
        }

        private void impérioDosFrancosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nkw0wJZDP2o&index=7");
        }

        private void civilizaçãoIslâmicaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9Tvxebthvaw");
        }

        private void feudalismoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5YA1cjTtYhc&index=9");
        }

        private void cruzadasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6aJBVG0oizw");
        }

        private void renascimentoComercialEUrbanoFatoresToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            
            LeitorCodigo("https://www.youtube.com/watch?v=F6L1Brc8F_4&index=11");
        }

        private void pesteNegraToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-5Uw1UV1LRo");
        }

        private void monarquiasNacionaisToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HNSjRodb2wY&index=13");
        }

        private void igrejaMedievalInquisiçãoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SklpsO0RthI&index=14");      
        }

        private void renascimentoCulturalToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JyWR0towU_M");
        }

        private void reformaProtestanteToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=G9ItjdhCMVo");
        }

        private void absolutismoEMercantilismoIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8zKp6kYOjFA");
        }

        private void absolutismoEMercantilismoIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qoKgqddKnqM&index=15");
        }

        private void expansãoMarítimaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jmNwJfe6HiI");
        }

        private void aConquistaDaAméricaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Dp3aV0jMGS8");
            
        }

        private void iluminismoToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-bjlVI-dejk");
        }

        private void séculoXVIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=07UztpQgiPI&index=2");
        }

        private void dinastiaStuartToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JTlLlASZSto");
            
        }

        private void absolutismoNaInglaterraToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cHZ9OS0ATGo&index=4");
            
        }

        private void visãoAlémDoAlcanceToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qJL8Xyoi4Vs&index=5");
        }

        private void economiaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0YDrZ_oKSoU");
            
        }

        private void anglicanosEPuritanosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HYmHKwY6gtg");
        }

        private void reiXParlamentoEAGuerraCivilToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EDWJ9CCZ2OM");
            
        }

        private void repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=O915MpVRQGQ&index=9");
        }

        private void revoluçãoFrancesaIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4nkwvmBKxek");
        }

        private void revoluçãoFrancesaIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=A53u4uTXnSo&index=42");
        }

        private void períodoNapoleônicoIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=uzMxCOJh-VQ");
        }

        private void períodoNapoleônicoIiToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=by_x9m5qWgA&index=60");
            
        }

        private void primeiraFaseToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=93mDyfFtmOE");
        }

        private void doutrinasDoSéculoXIXToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZcjAg0evm_o");
        }

        private void revoluçõesLiberaisToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=T7SA3vBYXLU");
            
        }

        private void segundaRevoluçãoIndustrialToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=twO0Btr15rg");
        }

        private void imperialismoNeocolonialismoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=a5gWLE2AuDk");
            
        }

        private void áfricaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NAG06-UXMKM");
        }

        private void eurocentrismoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VXkpfS3eOvI");
        }

        private void primeiraGuerraMundialToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=12NpjZ6jUYs&index=49");
            
        }

        private void primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HlLe4goIjSs&index=50");
        }

        private void introduçãoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ucoGWZGez_8");
            
        }

        private void tratadoDeVersalhesToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=m80izp_dptA");
        }

        private void revoluçãoRussaIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=loaAUmIdDKI");
        }

        private void revoluçãoRussaIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=DGlcHxuZ4qI");
           
        }

        private void trotskyXStalinToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XOcmWoE666k");
        }

        private void criseDe1929ToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=lRAut1YeGxo");
        }

        private void regimesTotalitáriosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=UQwlmhHvV3M");
            
        }

        private void fascismoItalianoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=RH3pNWNCbrU");
        }

        private void históriaNazismoAlemãoIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Sr7VRIal204");
        }

        private void históriaNazismoAlemãoIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VZ0lSaPhmKo");
            
        }

        private void parteIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BzQ8rw4_SD8");
        }

        private void parteIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6E1guWs5cPU");
        }

        private void introduçãoÀGuerraFriaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OkLhhBvElQE");
        }

        private void conflitosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XGjpztzhvHA");
        }

        private void oBrasilNaGuerraFriaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JssJ_9gLBdQ");
        }

        private void descolonizaçãoDaÁfricaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PB56pGosugE");
        }

        private void uRSSESeusEstadistasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=IWVJBHwxGxg");
        }

        private void quedaDoMuroDeBerlimToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EYeppe9Ncw0");
           
        }

        private void quedaDaURSSToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wMfIY0IbH8A");
        }

        private void conflitosNoOrienteMédioToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Zk_PmAyCOOY");
        }

        private void guerrasDaCoreiaEVietnãToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=a6OWsYw_cHc");
            
        }

        private void revoluçãoChinesaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=hbH6r0wYdCg");
        }

        private void direitosHumanosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6LRcLc9CBuQ");         
        }

        private void mundoAtualToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gDc1M7WNLp0");
        }

        private void expansãoMarítimaEComercialEuropeiaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?time_continue=566&v=jmNwJfe6HiI");
        }

        private void conquistaDaAméricaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Dp3aV0jMGS8");
        }

        private void maiasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=30dvMIKsddo&index=19");
        }

        private void aSTECASToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NnoVCqhVFZg");
        }

        private void incasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-5sImPo4EFU");
        }

        private void colonizaçãoEspanholaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ivB-9IfznMA");
        }

        private void colonizaçãoInglesaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nZCywrs7pg4");
        }

        private void revoluçãoAmericanaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6H-48sZdcCw");
        }

        private void expansãoDosEUAToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NfwoahDwOno");
        }

        private void criseDe1929ToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6H-48sZdcCw");
            
        }

        private void guerraDeSecessãoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=S93movjyiNI");
        }

        private void estadosUnidosNoSéculoXIXToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=IynV4kC0YF4");
        }

        private void aRevoluçãoMexicanaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pSfGhsHl0ac&index=29"); 
        }

        private void aRevoluçãoCubanaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=W2POTEUVYqs");
        }

        private void ditadurasDaAMÉRICALATINAToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=IN68Z3Evt-g");
            
        }

        private void revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qFb_5SAwO3w");
        }

        private void independênciaDaAméricaLatinaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SNjmC4uqwx0");
        }

        private void formaçãoDosEstadosNacionaisIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ECWHVW5ces0");
        }

        private void formaçãoDosEstadosNacionaisIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=utiI69PUl8A");
        }

        private void populismoNaAméricaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YZT8fAi81zs");
            
        }

        private void descobrimentoDoBrasilToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZF6DBvQSpks");
        }

        private void préHistóriaNoBrasilToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BIKzkXX6pOg&index=27");
        }

        private void períodoPréColonialToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=iP99XK83Kzk");
        }

        private void ciclosEconômicosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nDiHb5Hq-MY");
            
        }

        private void capitaniasHereditáriasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=S5FHYQkXPB8");
        }

        private void governosGeraisToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=i9xcx3OwW78");
        }

        private void economiaDoAçúcarColonialToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=O1oWKSIRNVc");
            
        }

        private void uniãoIbéricaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=s_9IuYALEPs");
        }

        private void presençaHolandesaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=fDs3l1ForjI");
        }

        private void economiaMineradoraToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=WGhHSrV2azg");
        }

        private void escravidãoNoBrasilToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=aNs0eL_NlQ4");
        }

        private void sociedadesQuilombolasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=o24c0P1Iiqo");
        }

        private void bandeirantismoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=kfdutBAl6r0");
        }

        private void criseDoSistemaColonialToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=F_D-zd0vpFk");
        }

        private void inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jm_EJ4ze8Tk");
        }

        private void inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=X8Ai93bZhJ8");
            
        }

        private void revisãoDoPeríodoColonialToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2ttIGdy53d8");
        }

        private void períodoJoaninoIToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8ORC7KppGGg");
        }

        private void períodoJoaninoIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=QlpXiIy-kIo");
        }

        private void independênciaDoBrasilToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JZ_2SYIIBGA");          
        }

        private void primeiroReinadoToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=J7O6ltcXWpo");
        }

        private void períodoRegencialParteIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nSxnDu1bQfI");
        }

        private void períodoRegencialParteIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cL2inxGpzYI");           
        }

        private void revoltaRegenciaisToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Xpf3Tvd2spI");
        }

        private void segundoReinadoParteIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=KJ10qRZNAm0");
        }

        private void segundoReinadoParteIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xpyJHWFVL80");           
        }

        private void guerrasDoPrataToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Yb2xM_IChJE");
        }

        private void osPartidosPoliticosNoBrasilImpérioToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HBRmWz3ch38");
        }

        private void leisAbolicionistasToolStripMenuItem_Click_1(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=I0sPEjByvAg");
            
        }

        private void oProcessoDeIndependênciaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Pm57QgqdSgY");
        }

        private void introduçãoToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9Pha84rmgi8");
        }

        private void repúblicaDaEspadaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2wAXGcewduo");
        }

        private void repúblicaOligárquicaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Iwf8a0gBy9U");
        }

        private void movimentosERevoltasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yGUpoSnFUzI");
        }

        private void revoltaDaArmadaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=p6T4dVNYn_g");
            
        }

        private void revoltaFederalistaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=08E2_C1Y7oI");
        }

        private void revoltaDeCanudosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=U-bHD2dXs30");
        }

        private void revoltaDaVacinaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GNLW3AiDpNI");
            
        }

        private void revoltaDaChibataToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gcp8IlnPLmw");
        }

        private void revoltaDeJuazeiroToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=aR0Hs99KKlA");
        }

        private void revoltaContestadoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=39lBQECa68Y");
            
        }

        private void revoluçãoDe1923ToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=DRrOwTOyLWE");
        }

        private void movimentoOperárioToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oCaqW8sQVQY");
        }

        private void revoluçãoDe1930ToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=sfIWJpoljM8");
        }

        private void introduçãoToolStripMenuItem2_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VbchuOcfZGY");
            
        }

        private void eraVargasIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=O_R3nD5nGYM");
        }

        private void eraVargasIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=B1NSr6-J-xU");
        }

        private void populismoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=t5BFcu1ykQM");
            
        }

        private void eríodoDemocráticoPopulistaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=tpQtAxTh_6Y");
        }

        private void governoDutraToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3JG78gq42eY");
        }

        private void governoVargasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=iwSN5Tl8m1c");
            
        }

        private void aMorteDeVargasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2oh6xw22BUc");
            
        }

        private void transiçãoDeVargasParaJKToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7b3zuLgJ9JY");
        }

        private void governoJKToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2EdriUSgzI0");
            
        }

        private void governoJânioQuadrosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VfKxl5GjNwg");
        }

        private void governoJoãoGoulartToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=i-QgVj9RBj0");
        }

        private void movimentoDaLegalidadeToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xjsvT-UrIxE");
           
        }

        private void golpeDe1964ToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=47kChOVCi1U");
        }

        private void governoCasteloBrancoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1s3bOTdR5nM");
        }

        private void governoCostaESilvaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=L82filNctL4");
           
        }

        private void governoMédiciToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1RqdZbePqK8");
        }

        private void governoGeiselToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jU6NQ6OjNo8");
        }

        private void governoFigueiredoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=t_Lwh-DJnGk");
        }

        private void aNovaReplúblicaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=krFZkhvHXBI");
            LeitorCodigo("");
        }

        private void diretasJáToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=_tsx1SwMgTY");
        }

        private void toolStripMenuItem8_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem8.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem9_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem9.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem10_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem10.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem12_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem12.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem13_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem13.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem14_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem14.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem15_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem15.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem17_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem17.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem18_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem18.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem19_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem19.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem20_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem20.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem22_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem22.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem23_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem23.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem24_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem24.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem26_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem26.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem28_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem29_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem29.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem32_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem32.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem33_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem33.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem36_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem36.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem39_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem39.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem42_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem42.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem43_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem43.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem45_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem45.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem47_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem47.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem48_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem48.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem49_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem49.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem51_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem51.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem52_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem52.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem53_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem53.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem54_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem54.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem55_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem55.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem58_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem58.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem59_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem59.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem61_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem61.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem62_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem62.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem63_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem63.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem64_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem64.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem65_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem65.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem67_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem67.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem71_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem71.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem72_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem72.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem73_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem73.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem74_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem74.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem75_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem75.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem76_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem76.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem77_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem77.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem79_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem79.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem80_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem80.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem82_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem82.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem84_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem84.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem86_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem86.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem87_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem87.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem88_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem88.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem89_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem89.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem90_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem90.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem91_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem91.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem93_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem93.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem94_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem94.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem95_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem95.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem98_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem98.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem99_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem99.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem101_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem101.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem102_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem102.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem103_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem103.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem104_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem104.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem105_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem105.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem106_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem106.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem109_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem109.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem110_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem110.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem112_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem112.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem114_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem114.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem115_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem115.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem117_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem117.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem118_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem118.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem120_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem120.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem121_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem121.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem122_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem122.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem123_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem123.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem124_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem124.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem125_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem125.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem126_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem126.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem128_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem128.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem129_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem129.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem131_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem131.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem132_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem132.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem136_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem136.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem137_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem137.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem139_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem139.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem141_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem141.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem143_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem143.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem145_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem145.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem147_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem147.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem148_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem148.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem149_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem149.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem152_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem152.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem153_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem153.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem155_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem155.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem156_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem156.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem157_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem157.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem158_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem158.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem159_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem159.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem160_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem160.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem161_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem161.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem162_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem162.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem163_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem163.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem164_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem164.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem166_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem166.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem169_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem169.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem172_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem172.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem174_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem174.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem175_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem175.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem176_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem176.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem178_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem178.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem179_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem179.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem180_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem180.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem181_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem181.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem183_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem183.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem185_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem185.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem186_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem186.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem187_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem187.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem188_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem188.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem190_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem190.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem191_Click(object sender, System.EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem191.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
             MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }
    }
}
