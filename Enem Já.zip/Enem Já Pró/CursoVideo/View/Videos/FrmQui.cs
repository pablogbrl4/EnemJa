﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmQui : Form
    {
        public FrmQui()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }

        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }

        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }

        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Química";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void substânciasEFenômenosToolStripMenuItem_Click(object sender, EventArgs e)
        {
              LeitorCodigo("https://www.youtube.com/watch?v=5PH5dNDomts");
        }

        private void estadosDeAgregaçãoDaMateriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nOaBWbs53IY");
            
        }

        private void mudançasDeEstadosFísicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nZkzTPfNpBI");
        }

        private void misturasHomogêneasEHeterogêneasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=hCYGjcQAZhs&index=4"); 
        }

        private void métodosDeSeparaçãoDeMisturasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=WJOB0iHCFhc");
        }

        private void substânciasPurasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=D8GbFmfdWA0&index=2");
        }

        private void estruturaAtômicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void metaisELigasMetálicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZFnEdCpEU6E");
        }

        private void ligaçõesQuímicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=DJCEuoBQV_M");
        }

        private void ligaçõesMetálicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EZGH-OqweF4");
        }

        private void propriedadesDosCompostosIônicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void ligaçãoCovalenteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=aozGe-jsLwM");
        }

        private void molENúmeroDeAvogadroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=dqG6Wi9KnWw"); 
        }

        private void molXMassamassaMolarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void volumeMolarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GPWGAgPuFHw");
        }

        private void massaAtômicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-AL-ei6yBdc");
        }

        private void tiposDeReaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YbE9nRP9IGs");
        }

        private void reaçãoDeSínteseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=p6vdxuIbiRA");
        }

        private void reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=24rNaviB6JQ");
        }

        private void outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-fjXlwTgYI0");
        }

        private void fundamentosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HWBAjQw7I2o");
        }

        private void purezaDeReagentesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pnvodFo6Gg8");
        }

        private void rendimentoDeReaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8rtvKmoR3f4");
        }

        private void reagentesEmExcessoELimitanteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3qzmmz9IkwU");
        }

        private void soluçõesIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yjyjfn-C1Ho");
        }

        private void soluçõesIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=QxTnijixXZ8&index=48");
            
        }

        private void classificaçõesEPropriedadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=e0NTLPi5hWM");
        }

        private void fórmulasENomenclaturasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nbdgttl_9zQ");
        }

        private void definiçãoClassificaçõesEPropriedadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8Bi0qQuzTC8");
        }

        private void fórmulasENomenclaturasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=v5TFgEPrZHo");
        }

        private void definiçãoClassificaçõesEPropriedadesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=tQckji7lGQs&index=80");
        }

        private void fórmulasENomenclaturasToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=h7cKOgRof9c");
        }

        private void definiçãoClassificaçõesEPropriedadesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1qUTk4f6MoY&index=82");
        }

        private void fórmulasENomenclaturasToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=AQWecwtGjDQ");
        }

        private void principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void conceitoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Jp3k9qrnlgQ");
        }

        private void fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qXEYZzMv3os");
        }

        private void ordemDeReaçãoglobalEEspecíficaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Ge83MQsJpfI");
        }

        private void leiDaVelocidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=fg8K4w-Psec");
        }

        private void cinéticaQuímicaECotidianoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xlWiYLTE-h8");
        }

        private void caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HxOUKFp6afY");
        }

        private void fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Xc9UolJbab4");
        }

        private void produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JFBBa5-lNpg");
        }

        private void pHEPOHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pIPoybIkzvk");
        }

        private void oEquilíbrioQuímicoEOCotidianoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=uEXjRU_8JdI");
        }

        private void químicaOrgânicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=i2FN-PRrBfw");
        }

        private void nomenclaturaBásicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6dPDZLttpM0");
        }

        private void formasERepresentaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=lxocZhg6JJM");
        }

        private void ligaçõesSigmaEPiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7E4UNmCkJ0Q");
        }

        private void hibridizaçãoDoCarbonoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=rAIwys5ZcN8&index=8");
        }

        private void classificaçãoDosCarbonosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oouLr2tkXXs");
        }

        private void abertasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wsCmNaiZorY");
        }

        private void fechadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GmG6BeMDeLM&index=12");
            
        }

        private void hidrocarbonetosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=rV_E_Kp43xo");
        }

        private void hidrocarbonetosRamificadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CCorvpFnvBo");
        }

        private void haletosOrgânicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7hLZl1kfFyg");
        }

        private void isomeriaPlanaDePosiçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TyFUinQc4uk");
        }

        private void isomeriaDeCadeiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=C6yx2TfwswA");
        }

        private void isomeriaDeFunçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gVrDzZE_CfU");
        }

        private void isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gSdV_CpfpZA");
        }

        private void isomeriaDinâmicaOuTautomeriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4mAaC7IyrbY");
        }

        private void álcoolToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GgFiCViMi0Y");
        }

        private void aldeídosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Re_KYYGpP6Y");
        }

        private void cetonasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=UCXWtRUXco4");
        }

        private void ácidosCarboxílicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=uQXaLv3xzCw");
        }

        private void éteresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=mEkaZS_NzQk");
        }

        private void ésteresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9mgTTHLBpYI");
        }

        private void aminaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=KZ95q9pUTXM");
        }

        private void amidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=n_CShp3ZW6M");
        }

        private void nitrocompostoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SX9U359CNGQ");
        }

        private void nitrilaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void polímerosNaturaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=KBHSjuEGRxA");
        }

        private void polímerosArtificiaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Lt_UMgN6pXM");
        }

        private void massaMolecularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1J_kb3vxSiE&index=24");
        }

        private void balanceamentoDeEquaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qjjpmI2MTfA&index=27");
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem3.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem4.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem5.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem6.Text;
            ChamarQuiz(); 
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem7.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem8.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem10.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem17.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem18.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem19.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem21_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem21.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem22_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem22.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem25_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem25.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem26_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem26.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem28_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem29_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem29.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem30_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem30.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem31_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem31.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem33_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem33.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem34_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem34.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem35_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem35.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem36_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem36.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem37_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem37.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem40_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem40.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem41_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem41.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem42_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem42.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem44_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem44.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem47_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem47.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem49_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem49.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem50_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem50.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem52_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem52.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem53_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem53.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem55_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem55.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem58_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem58.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem61_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem61.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem64_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem64.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem67_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem67.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem69_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem69.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem74_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem74.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem75_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem75.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem76_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem76.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem78_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem78.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem79_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem79.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem80_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem80.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem82_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem82.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem87_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem87.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem91_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem91.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem92_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem92.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem93_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem93.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem95_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem95.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem96_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem96.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem97_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem97.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem98_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem98.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem99_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem99.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem100_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem100.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem102_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem102.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem103_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem103.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem104_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem104.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem111_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem111.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem112_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem112.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem113_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem113.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem114_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem114.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem115_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem115.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem116_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem116.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem117_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem117.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem118_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem118.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem120_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem120.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem121_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem121.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem122_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem122.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem123_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem123.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem124_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem124.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem125_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem125.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem127_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem127.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem128_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem128.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem129_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem129.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem130_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem130.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem132_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem132.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem133_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem133.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem134_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem134.Text;
            ChamarQuiz();
        }

        private void fecharMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
             MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }

        private void modelosAtômicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=MtBbVt7eInE");
        }

        private void regiõesDoÁtomoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gL5ytHCKBK4");
        }

        private void númeroAtômicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ggApleG67mk");
        }

        private void átomoNeutroEÍonsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=eCvrdGwQ1TI");
        }

        private void isótoposConceitoEAplicaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Nj3EmiWkC5M");
        }

        private void tabelaPeriódicaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=RII_OM56t8I");
            LeitorCodigo("");
        }

        private void ligaçãoIônicaToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EJmv1KE-Br0");
        }
    }
}
