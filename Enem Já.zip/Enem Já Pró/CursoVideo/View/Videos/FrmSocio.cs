﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmSocio : Form
    {
        public FrmSocio()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }
        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }
        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }
        private void fecharMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
              MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }
        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Sociologia";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }
        private void introduçãoÀSociologiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=M7s5ryIwi-M");
        }
        private void autoresClássicosDaSociologiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gUNmUPEuC4E&index=2");
        }

        private void emileDurkheimToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Qhg3GMHue-s");
        }

        private void maxWeberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=25NSWMwZV4o");
            
        }

        private void karlMarxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=lCcdXpNH4d4&index=12");
        }

        private void augusteComteEOPositivismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EHnMYR23nCI");
        }

        private void novasRelaçõesDeTrabalhoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=KKMDzlobmZ0");          
        }

        private void relaçãoEntreIndivíduoESociedadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LGkk_2a1n4Y");
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {           
            PergDTO.TEMA = "Autores Clássicos da Sociologia";
            ChamarQuiz();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Emile Durkheim";
            ChamarQuiz();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Auguste Comte e o Positivismo";
            ChamarQuiz();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Max Weber";
            ChamarQuiz();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Karl Marx";
            ChamarQuiz();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Novas Relações de Trabalho";
            ChamarQuiz();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Relação entre Indivíduo e Sociedade";
            ChamarQuiz();
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Democracia e direitos humanos";
            ChamarQuiz();
        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Sociedade midiática - Comunicação";
            ChamarQuiz();
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Sociedade de consumo";
            ChamarQuiz();
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Sociedade midiática - Linguagem";
            ChamarQuiz();
        }

        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Sociologia no Brasil";
            ChamarQuiz();
        }

        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Escola de Frankfurt";
            ChamarQuiz();
        }

        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Culturas contemporâneas";
            ChamarQuiz();
        }

        private void democraciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=zph2TwR05K0");
        }

        private void direitosHumanosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=hGKAaVoDlSs");
        }

        private void sociedadeMidiáticaComunicaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7XrAK5jqd9Y");
        }

        private void sociedadeDeConsumoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ni4Ya9fL1TQ");
        }

        private void sociedadeMidiáticaLinguagemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=P4tl7m8j4Uk");
        }

        private void sociologiaNoBrasilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=02ck6oRZnh8");
        }

        private void aDialéticaDoEsclarecimentoParteIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yJIF3QldGKk");
        }

        private void aDialéticaDoEsclarecimentoParteIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4MQ1aK2oiyE");
        }

        private void culturasContemporâneasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vSf36uCGI9E");
        }
    }
}
