﻿namespace CursoVideo.View.Videos
{
    partial class FrmQui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQui));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fecharMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cursoEmVídeoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.materiaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.substânciasEFenômenosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadosDeAgregaçãoDaMateriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mudançasDeEstadosFísicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.misturasHomogêneasEHeterogêneasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodosDeSeparaçãoDeMisturasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.substânciasPurasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estruturaAtômicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modelosAtômicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regiõesDoÁtomoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númeroAtômicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.átomoNeutroEÍonsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isótoposConceitoEAplicaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabelaPeriódicaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.metaisELigasMetálicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ligaçõesQuímicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ligaçõesMetálicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ligaçãoIônicaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.propriedadesDosCompostosIônicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ligaçãoCovalenteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.transformaçõesERepresentaçõesQuímicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.molToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.molENúmeroDeAvogadroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.molXMassamassaMolarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.volumeMolarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.massaAtômicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.massaMolecularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.balanceamentoDeEquaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gasesIdeaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reaçãoQuímicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposDeReaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reaçãoDeSínteseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.determinaçãoDeFórmulasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.estequiometriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fundamentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purezaDeReagentesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rendimentoDeReaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reagentesEmExcessoELimitanteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.soluçõesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.soluçõesIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.soluçõesIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.solubilidadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.concentraçãoDasSoluçõesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.concentraçãoComumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.concentraçãoMolarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propriedadesColigativasDasSoluçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crioscopiaEEbuliometriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tonoscopiaEOsmometriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçõesInorgânicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ácidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classificaçõesEPropriedadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fórmulasENomenclaturasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fórmulasENomenclaturasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fórmulasENomenclaturasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.óxidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.fórmulasENomenclaturasToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.transformaçõesQuímicasEEnergiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.termoquímicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diferentesTiposDeCaloresDeReaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leiDeHessToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eletroquímicaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pilhasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eletróliseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transformaçõesNuclearesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radioatividadeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fissãoEFusãoNuclearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desintegraçãoRadioativaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radioisótoposAplicaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dinâmicaDasTransformaçõesQuímicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cinéticaQuímicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordemDeReaçãoglobalEEspecíficaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leiDaVelocidadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cinéticaQuímicaECotidianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transformaçõesQuímicasEEquilíbrioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pHEPOHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oEquilíbrioQuímicoEOCotidianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compostosDeCarbonoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.químicaOrgânicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nomenclaturaBásicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formasERepresentaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ligaçõesSigmaEPiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hibridizaçãoDoCarbonoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classificaçãoDosCarbonosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classificaçãoDasCadeiasCarbônicasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.abertasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fechadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isomeriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isomeriaPlanaDePosiçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isomeriaDeCadeiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isomeriaDeFunçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isomeriaDinâmicaOuTautomeriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hidrocarbonetosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hidrocarbonetosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.alcanosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alcenosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alcinosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aromáticosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outrosHidrocarbonetosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hidrocarbonetosRamificadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.haletosOrgânicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçõesOrgânicasOxigenadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.álcoolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aldeídosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cetonasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ácidosCarboxílicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.éteresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ésteresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçõesOrgânicasNitrogenadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aminaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.amidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nitrocompostoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nitrilaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polímerosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polímerosNaturaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polímerosArtificiaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.energiasQuímicasNoCotidianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.petróleoGásNaturalECarvãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.madeiraEHulhaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.biomassaEBiocombustíveisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem38 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem52 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem53 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem55 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem58 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem61 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem68 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem69 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem73 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem74 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem75 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem76 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem77 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem78 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem79 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem80 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem81 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem82 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem87 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem88 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem91 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem92 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem93 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem94 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem95 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem96 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem97 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem98 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem99 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem100 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem101 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem102 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem103 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem104 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem110 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem111 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem112 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem113 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem114 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem115 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem116 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem117 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem118 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem119 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem120 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem121 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem122 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem123 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem124 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem125 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem126 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem127 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem128 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem129 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem130 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem131 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem132 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem133 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem134 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharMenuItem,
            this.cursoEmVídeoToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(122, 612);
            this.menuStrip1.TabIndex = 39;
            // 
            // fecharMenuItem
            // 
            this.fecharMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.fecharMenuItem.BackColor = System.Drawing.SystemColors.ControlLight;
            this.fecharMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharMenuItem.Image")));
            this.fecharMenuItem.Name = "fecharMenuItem";
            this.fecharMenuItem.Size = new System.Drawing.Size(109, 39);
            this.fecharMenuItem.Text = "FECHAR";
            this.fecharMenuItem.Click += new System.EventHandler(this.fecharMenuItem_Click);
            // 
            // cursoEmVídeoToolStripMenuItem
            // 
            this.cursoEmVídeoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.materiaisToolStripMenuItem,
            this.transformaçõesERepresentaçõesQuímicasToolStripMenuItem,
            this.soluçõesToolStripMenuItem1,
            this.funçõesInorgânicasToolStripMenuItem,
            this.transformaçõesQuímicasEEnergiaToolStripMenuItem,
            this.dinâmicaDasTransformaçõesQuímicasToolStripMenuItem,
            this.transformaçõesQuímicasEEquilíbrioToolStripMenuItem,
            this.compostosDeCarbonoToolStripMenuItem,
            this.energiasQuímicasNoCotidianoToolStripMenuItem});
            this.cursoEmVídeoToolStripMenuItem.Name = "cursoEmVídeoToolStripMenuItem";
            this.cursoEmVídeoToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.cursoEmVídeoToolStripMenuItem.Text = "Química";
            // 
            // materiaisToolStripMenuItem
            // 
            this.materiaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.substânciasEFenômenosToolStripMenuItem,
            this.estadosDeAgregaçãoDaMateriaToolStripMenuItem,
            this.mudançasDeEstadosFísicosToolStripMenuItem,
            this.misturasHomogêneasEHeterogêneasToolStripMenuItem,
            this.métodosDeSeparaçãoDeMisturasToolStripMenuItem,
            this.substânciasPurasToolStripMenuItem,
            this.diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem,
            this.estruturaAtômicaToolStripMenuItem,
            this.metaisELigasMetálicasToolStripMenuItem,
            this.ligaçõesQuímicasToolStripMenuItem,
            this.ligaçõesMetálicasToolStripMenuItem,
            this.ligaçãoIônicaToolStripMenuItem2,
            this.ligaçãoCovalenteToolStripMenuItem1});
            this.materiaisToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.materiaisToolStripMenuItem.Name = "materiaisToolStripMenuItem";
            this.materiaisToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.materiaisToolStripMenuItem.Text = "Materiais";
            // 
            // substânciasEFenômenosToolStripMenuItem
            // 
            this.substânciasEFenômenosToolStripMenuItem.Name = "substânciasEFenômenosToolStripMenuItem";
            this.substânciasEFenômenosToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.substânciasEFenômenosToolStripMenuItem.Text = "Substâncias e fenômenos";
            this.substânciasEFenômenosToolStripMenuItem.Click += new System.EventHandler(this.substânciasEFenômenosToolStripMenuItem_Click);
            // 
            // estadosDeAgregaçãoDaMateriaToolStripMenuItem
            // 
            this.estadosDeAgregaçãoDaMateriaToolStripMenuItem.Name = "estadosDeAgregaçãoDaMateriaToolStripMenuItem";
            this.estadosDeAgregaçãoDaMateriaToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.estadosDeAgregaçãoDaMateriaToolStripMenuItem.Text = "Estados de agregação da materia";
            this.estadosDeAgregaçãoDaMateriaToolStripMenuItem.Click += new System.EventHandler(this.estadosDeAgregaçãoDaMateriaToolStripMenuItem_Click);
            // 
            // mudançasDeEstadosFísicosToolStripMenuItem
            // 
            this.mudançasDeEstadosFísicosToolStripMenuItem.Name = "mudançasDeEstadosFísicosToolStripMenuItem";
            this.mudançasDeEstadosFísicosToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.mudançasDeEstadosFísicosToolStripMenuItem.Text = "Mudanças de estados físicos";
            this.mudançasDeEstadosFísicosToolStripMenuItem.Click += new System.EventHandler(this.mudançasDeEstadosFísicosToolStripMenuItem_Click);
            // 
            // misturasHomogêneasEHeterogêneasToolStripMenuItem
            // 
            this.misturasHomogêneasEHeterogêneasToolStripMenuItem.Name = "misturasHomogêneasEHeterogêneasToolStripMenuItem";
            this.misturasHomogêneasEHeterogêneasToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.misturasHomogêneasEHeterogêneasToolStripMenuItem.Text = "Misturas homogêneas e heterogêneas";
            this.misturasHomogêneasEHeterogêneasToolStripMenuItem.Click += new System.EventHandler(this.misturasHomogêneasEHeterogêneasToolStripMenuItem_Click);
            // 
            // métodosDeSeparaçãoDeMisturasToolStripMenuItem
            // 
            this.métodosDeSeparaçãoDeMisturasToolStripMenuItem.Name = "métodosDeSeparaçãoDeMisturasToolStripMenuItem";
            this.métodosDeSeparaçãoDeMisturasToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.métodosDeSeparaçãoDeMisturasToolStripMenuItem.Text = "Métodos de separação de misturas";
            this.métodosDeSeparaçãoDeMisturasToolStripMenuItem.Click += new System.EventHandler(this.métodosDeSeparaçãoDeMisturasToolStripMenuItem_Click);
            // 
            // substânciasPurasToolStripMenuItem
            // 
            this.substânciasPurasToolStripMenuItem.Name = "substânciasPurasToolStripMenuItem";
            this.substânciasPurasToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.substânciasPurasToolStripMenuItem.Text = "Substâncias Puras";
            this.substânciasPurasToolStripMenuItem.Click += new System.EventHandler(this.substânciasPurasToolStripMenuItem_Click);
            // 
            // diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem
            // 
            this.diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem.Name = "diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem";
            this.diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem.Text = "Diagramas de mudança de estado de substâncias e misturas";
            this.diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem.Click += new System.EventHandler(this.diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem_Click);
            // 
            // estruturaAtômicaToolStripMenuItem
            // 
            this.estruturaAtômicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.modelosAtômicosToolStripMenuItem,
            this.regiõesDoÁtomoToolStripMenuItem,
            this.númeroAtômicoToolStripMenuItem,
            this.átomoNeutroEÍonsToolStripMenuItem,
            this.isótoposConceitoEAplicaçõesToolStripMenuItem,
            this.tabelaPeriódicaToolStripMenuItem1});
            this.estruturaAtômicaToolStripMenuItem.Name = "estruturaAtômicaToolStripMenuItem";
            this.estruturaAtômicaToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.estruturaAtômicaToolStripMenuItem.Text = "Estrutura atômica";
            this.estruturaAtômicaToolStripMenuItem.Click += new System.EventHandler(this.estruturaAtômicaToolStripMenuItem_Click);
            // 
            // modelosAtômicosToolStripMenuItem
            // 
            this.modelosAtômicosToolStripMenuItem.Name = "modelosAtômicosToolStripMenuItem";
            this.modelosAtômicosToolStripMenuItem.Size = new System.Drawing.Size(310, 26);
            this.modelosAtômicosToolStripMenuItem.Text = "Modelos atômicos";
            this.modelosAtômicosToolStripMenuItem.Click += new System.EventHandler(this.modelosAtômicosToolStripMenuItem_Click);
            // 
            // regiõesDoÁtomoToolStripMenuItem
            // 
            this.regiõesDoÁtomoToolStripMenuItem.Name = "regiõesDoÁtomoToolStripMenuItem";
            this.regiõesDoÁtomoToolStripMenuItem.Size = new System.Drawing.Size(310, 26);
            this.regiõesDoÁtomoToolStripMenuItem.Text = "Regiões do átomo";
            this.regiõesDoÁtomoToolStripMenuItem.Click += new System.EventHandler(this.regiõesDoÁtomoToolStripMenuItem_Click);
            // 
            // númeroAtômicoToolStripMenuItem
            // 
            this.númeroAtômicoToolStripMenuItem.Name = "númeroAtômicoToolStripMenuItem";
            this.númeroAtômicoToolStripMenuItem.Size = new System.Drawing.Size(310, 26);
            this.númeroAtômicoToolStripMenuItem.Text = "Número atômico";
            this.númeroAtômicoToolStripMenuItem.Click += new System.EventHandler(this.númeroAtômicoToolStripMenuItem_Click);
            // 
            // átomoNeutroEÍonsToolStripMenuItem
            // 
            this.átomoNeutroEÍonsToolStripMenuItem.Name = "átomoNeutroEÍonsToolStripMenuItem";
            this.átomoNeutroEÍonsToolStripMenuItem.Size = new System.Drawing.Size(310, 26);
            this.átomoNeutroEÍonsToolStripMenuItem.Text = "Átomo neutro e íons";
            this.átomoNeutroEÍonsToolStripMenuItem.Click += new System.EventHandler(this.átomoNeutroEÍonsToolStripMenuItem_Click);
            // 
            // isótoposConceitoEAplicaçõesToolStripMenuItem
            // 
            this.isótoposConceitoEAplicaçõesToolStripMenuItem.Name = "isótoposConceitoEAplicaçõesToolStripMenuItem";
            this.isótoposConceitoEAplicaçõesToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.isótoposConceitoEAplicaçõesToolStripMenuItem.Text = "ISÓTOPOS, ISÓBAROS E ISÓTONOS";
            this.isótoposConceitoEAplicaçõesToolStripMenuItem.Click += new System.EventHandler(this.isótoposConceitoEAplicaçõesToolStripMenuItem_Click);
            // 
            // tabelaPeriódicaToolStripMenuItem1
            // 
            this.tabelaPeriódicaToolStripMenuItem1.Name = "tabelaPeriódicaToolStripMenuItem1";
            this.tabelaPeriódicaToolStripMenuItem1.Size = new System.Drawing.Size(335, 26);
            this.tabelaPeriódicaToolStripMenuItem1.Text = "Tabela periódica";
            this.tabelaPeriódicaToolStripMenuItem1.Click += new System.EventHandler(this.tabelaPeriódicaToolStripMenuItem1_Click);
            // 
            // metaisELigasMetálicasToolStripMenuItem
            // 
            this.metaisELigasMetálicasToolStripMenuItem.Name = "metaisELigasMetálicasToolStripMenuItem";
            this.metaisELigasMetálicasToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.metaisELigasMetálicasToolStripMenuItem.Text = "Metais e ligas metálicas";
            this.metaisELigasMetálicasToolStripMenuItem.Click += new System.EventHandler(this.metaisELigasMetálicasToolStripMenuItem_Click);
            // 
            // ligaçõesQuímicasToolStripMenuItem
            // 
            this.ligaçõesQuímicasToolStripMenuItem.Name = "ligaçõesQuímicasToolStripMenuItem";
            this.ligaçõesQuímicasToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.ligaçõesQuímicasToolStripMenuItem.Text = "Ligações químicas";
            this.ligaçõesQuímicasToolStripMenuItem.Click += new System.EventHandler(this.ligaçõesQuímicasToolStripMenuItem_Click);
            // 
            // ligaçõesMetálicasToolStripMenuItem
            // 
            this.ligaçõesMetálicasToolStripMenuItem.Name = "ligaçõesMetálicasToolStripMenuItem";
            this.ligaçõesMetálicasToolStripMenuItem.Size = new System.Drawing.Size(514, 26);
            this.ligaçõesMetálicasToolStripMenuItem.Text = "Ligações metálicas";
            this.ligaçõesMetálicasToolStripMenuItem.Click += new System.EventHandler(this.ligaçõesMetálicasToolStripMenuItem_Click);
            // 
            // ligaçãoIônicaToolStripMenuItem2
            // 
            this.ligaçãoIônicaToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.propriedadesDosCompostosIônicosToolStripMenuItem});
            this.ligaçãoIônicaToolStripMenuItem2.Name = "ligaçãoIônicaToolStripMenuItem2";
            this.ligaçãoIônicaToolStripMenuItem2.Size = new System.Drawing.Size(514, 26);
            this.ligaçãoIônicaToolStripMenuItem2.Text = "Ligação iônica";
            this.ligaçãoIônicaToolStripMenuItem2.Click += new System.EventHandler(this.ligaçãoIônicaToolStripMenuItem2_Click);
            // 
            // propriedadesDosCompostosIônicosToolStripMenuItem
            // 
            this.propriedadesDosCompostosIônicosToolStripMenuItem.Name = "propriedadesDosCompostosIônicosToolStripMenuItem";
            this.propriedadesDosCompostosIônicosToolStripMenuItem.Size = new System.Drawing.Size(351, 26);
            this.propriedadesDosCompostosIônicosToolStripMenuItem.Text = "Propriedades dos compostos iônicos";
            this.propriedadesDosCompostosIônicosToolStripMenuItem.Click += new System.EventHandler(this.propriedadesDosCompostosIônicosToolStripMenuItem_Click);
            // 
            // ligaçãoCovalenteToolStripMenuItem1
            // 
            this.ligaçãoCovalenteToolStripMenuItem1.Name = "ligaçãoCovalenteToolStripMenuItem1";
            this.ligaçãoCovalenteToolStripMenuItem1.Size = new System.Drawing.Size(514, 26);
            this.ligaçãoCovalenteToolStripMenuItem1.Text = "Ligação covalente";
            this.ligaçãoCovalenteToolStripMenuItem1.Click += new System.EventHandler(this.ligaçãoCovalenteToolStripMenuItem1_Click);
            // 
            // transformaçõesERepresentaçõesQuímicasToolStripMenuItem
            // 
            this.transformaçõesERepresentaçõesQuímicasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.molToolStripMenuItem,
            this.massaAtômicaToolStripMenuItem,
            this.massaMolecularToolStripMenuItem,
            this.balanceamentoDeEquaçõesToolStripMenuItem,
            this.gasesIdeaisToolStripMenuItem,
            this.reaçãoQuímicaToolStripMenuItem,
            this.determinaçãoDeFórmulasToolStripMenuItem2,
            this.estequiometriaToolStripMenuItem});
            this.transformaçõesERepresentaçõesQuímicasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.transformaçõesERepresentaçõesQuímicasToolStripMenuItem.Name = "transformaçõesERepresentaçõesQuímicasToolStripMenuItem";
            this.transformaçõesERepresentaçõesQuímicasToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.transformaçõesERepresentaçõesQuímicasToolStripMenuItem.Text = "Transformações e representações químicas";
            // 
            // molToolStripMenuItem
            // 
            this.molToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.molENúmeroDeAvogadroToolStripMenuItem,
            this.molXMassamassaMolarToolStripMenuItem});
            this.molToolStripMenuItem.Name = "molToolStripMenuItem";
            this.molToolStripMenuItem.Size = new System.Drawing.Size(288, 26);
            this.molToolStripMenuItem.Text = "Mol";
            // 
            // molENúmeroDeAvogadroToolStripMenuItem
            // 
            this.molENúmeroDeAvogadroToolStripMenuItem.Name = "molENúmeroDeAvogadroToolStripMenuItem";
            this.molENúmeroDeAvogadroToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.molENúmeroDeAvogadroToolStripMenuItem.Text = "Mol e número de Avogadro";
            this.molENúmeroDeAvogadroToolStripMenuItem.Click += new System.EventHandler(this.molENúmeroDeAvogadroToolStripMenuItem_Click);
            // 
            // molXMassamassaMolarToolStripMenuItem
            // 
            this.molXMassamassaMolarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.volumeMolarToolStripMenuItem});
            this.molXMassamassaMolarToolStripMenuItem.Name = "molXMassamassaMolarToolStripMenuItem";
            this.molXMassamassaMolarToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.molXMassamassaMolarToolStripMenuItem.Text = "Mol x massa (massa molar)";
            this.molXMassamassaMolarToolStripMenuItem.Click += new System.EventHandler(this.molXMassamassaMolarToolStripMenuItem_Click);
            // 
            // volumeMolarToolStripMenuItem
            // 
            this.volumeMolarToolStripMenuItem.Name = "volumeMolarToolStripMenuItem";
            this.volumeMolarToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.volumeMolarToolStripMenuItem.Text = "Volume molar";
            this.volumeMolarToolStripMenuItem.Click += new System.EventHandler(this.volumeMolarToolStripMenuItem_Click);
            // 
            // massaAtômicaToolStripMenuItem
            // 
            this.massaAtômicaToolStripMenuItem.Name = "massaAtômicaToolStripMenuItem";
            this.massaAtômicaToolStripMenuItem.Size = new System.Drawing.Size(288, 26);
            this.massaAtômicaToolStripMenuItem.Text = "Massa Atômica";
            this.massaAtômicaToolStripMenuItem.Click += new System.EventHandler(this.massaAtômicaToolStripMenuItem_Click);
            // 
            // massaMolecularToolStripMenuItem
            // 
            this.massaMolecularToolStripMenuItem.Name = "massaMolecularToolStripMenuItem";
            this.massaMolecularToolStripMenuItem.Size = new System.Drawing.Size(288, 26);
            this.massaMolecularToolStripMenuItem.Text = "Massa Molecular";
            this.massaMolecularToolStripMenuItem.Click += new System.EventHandler(this.massaMolecularToolStripMenuItem_Click);
            // 
            // balanceamentoDeEquaçõesToolStripMenuItem
            // 
            this.balanceamentoDeEquaçõesToolStripMenuItem.Name = "balanceamentoDeEquaçõesToolStripMenuItem";
            this.balanceamentoDeEquaçõesToolStripMenuItem.Size = new System.Drawing.Size(288, 26);
            this.balanceamentoDeEquaçõesToolStripMenuItem.Text = "Balanceamento de Equações";
            this.balanceamentoDeEquaçõesToolStripMenuItem.Click += new System.EventHandler(this.balanceamentoDeEquaçõesToolStripMenuItem_Click);
            // 
            // gasesIdeaisToolStripMenuItem
            // 
            this.gasesIdeaisToolStripMenuItem.Name = "gasesIdeaisToolStripMenuItem";
            this.gasesIdeaisToolStripMenuItem.Size = new System.Drawing.Size(288, 26);
            this.gasesIdeaisToolStripMenuItem.Text = "Gases ideais";
            // 
            // reaçãoQuímicaToolStripMenuItem
            // 
            this.reaçãoQuímicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tiposDeReaçõesToolStripMenuItem,
            this.reaçãoDeSínteseToolStripMenuItem,
            this.reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem,
            this.outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem});
            this.reaçãoQuímicaToolStripMenuItem.Name = "reaçãoQuímicaToolStripMenuItem";
            this.reaçãoQuímicaToolStripMenuItem.Size = new System.Drawing.Size(288, 26);
            this.reaçãoQuímicaToolStripMenuItem.Text = "Reação química";
            // 
            // tiposDeReaçõesToolStripMenuItem
            // 
            this.tiposDeReaçõesToolStripMenuItem.Name = "tiposDeReaçõesToolStripMenuItem";
            this.tiposDeReaçõesToolStripMenuItem.Size = new System.Drawing.Size(566, 26);
            this.tiposDeReaçõesToolStripMenuItem.Text = "Tipos de reações";
            this.tiposDeReaçõesToolStripMenuItem.Click += new System.EventHandler(this.tiposDeReaçõesToolStripMenuItem_Click);
            // 
            // reaçãoDeSínteseToolStripMenuItem
            // 
            this.reaçãoDeSínteseToolStripMenuItem.Name = "reaçãoDeSínteseToolStripMenuItem";
            this.reaçãoDeSínteseToolStripMenuItem.Size = new System.Drawing.Size(566, 26);
            this.reaçãoDeSínteseToolStripMenuItem.Text = "Reação de síntese ";
            this.reaçãoDeSínteseToolStripMenuItem.Click += new System.EventHandler(this.reaçãoDeSínteseToolStripMenuItem_Click);
            // 
            // reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem
            // 
            this.reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem.Name = "reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem";
            this.reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem.Size = new System.Drawing.Size(566, 26);
            this.reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem.Text = "Reação de simples troca e reação de dupla troca";
            this.reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem.Click += new System.EventHandler(this.reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem_Click);
            // 
            // outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem
            // 
            this.outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem.Name = "outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem";
            this.outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem.Size = new System.Drawing.Size(566, 26);
            this.outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem.Text = "Outras reações: neutralização, combustão, hidrogenação, oxidação";
            this.outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem.Click += new System.EventHandler(this.outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem_Click);
            // 
            // determinaçãoDeFórmulasToolStripMenuItem2
            // 
            this.determinaçãoDeFórmulasToolStripMenuItem2.Name = "determinaçãoDeFórmulasToolStripMenuItem2";
            this.determinaçãoDeFórmulasToolStripMenuItem2.Size = new System.Drawing.Size(288, 26);
            this.determinaçãoDeFórmulasToolStripMenuItem2.Text = "Determinação de fórmulas";
            // 
            // estequiometriaToolStripMenuItem
            // 
            this.estequiometriaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fundamentosToolStripMenuItem,
            this.purezaDeReagentesToolStripMenuItem,
            this.rendimentoDeReaçãoToolStripMenuItem,
            this.reagentesEmExcessoELimitanteToolStripMenuItem});
            this.estequiometriaToolStripMenuItem.Name = "estequiometriaToolStripMenuItem";
            this.estequiometriaToolStripMenuItem.Size = new System.Drawing.Size(288, 26);
            this.estequiometriaToolStripMenuItem.Text = "Estequiometria";
            // 
            // fundamentosToolStripMenuItem
            // 
            this.fundamentosToolStripMenuItem.Name = "fundamentosToolStripMenuItem";
            this.fundamentosToolStripMenuItem.Size = new System.Drawing.Size(330, 26);
            this.fundamentosToolStripMenuItem.Text = "Fundamentos";
            this.fundamentosToolStripMenuItem.Click += new System.EventHandler(this.fundamentosToolStripMenuItem_Click);
            // 
            // purezaDeReagentesToolStripMenuItem
            // 
            this.purezaDeReagentesToolStripMenuItem.Name = "purezaDeReagentesToolStripMenuItem";
            this.purezaDeReagentesToolStripMenuItem.Size = new System.Drawing.Size(330, 26);
            this.purezaDeReagentesToolStripMenuItem.Text = "Pureza de reagentes";
            this.purezaDeReagentesToolStripMenuItem.Click += new System.EventHandler(this.purezaDeReagentesToolStripMenuItem_Click);
            // 
            // rendimentoDeReaçãoToolStripMenuItem
            // 
            this.rendimentoDeReaçãoToolStripMenuItem.Name = "rendimentoDeReaçãoToolStripMenuItem";
            this.rendimentoDeReaçãoToolStripMenuItem.Size = new System.Drawing.Size(330, 26);
            this.rendimentoDeReaçãoToolStripMenuItem.Text = "Rendimento de Reação";
            this.rendimentoDeReaçãoToolStripMenuItem.Click += new System.EventHandler(this.rendimentoDeReaçãoToolStripMenuItem_Click);
            // 
            // reagentesEmExcessoELimitanteToolStripMenuItem
            // 
            this.reagentesEmExcessoELimitanteToolStripMenuItem.Name = "reagentesEmExcessoELimitanteToolStripMenuItem";
            this.reagentesEmExcessoELimitanteToolStripMenuItem.Size = new System.Drawing.Size(330, 26);
            this.reagentesEmExcessoELimitanteToolStripMenuItem.Text = "Reagentes em Excesso e Limitante";
            this.reagentesEmExcessoELimitanteToolStripMenuItem.Click += new System.EventHandler(this.reagentesEmExcessoELimitanteToolStripMenuItem_Click);
            // 
            // soluçõesToolStripMenuItem1
            // 
            this.soluçõesToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem,
            this.solubilidadeToolStripMenuItem,
            this.concentraçãoDasSoluçõesToolStripMenuItem1,
            this.propriedadesColigativasDasSoluçõesToolStripMenuItem});
            this.soluçõesToolStripMenuItem1.Name = "soluçõesToolStripMenuItem1";
            this.soluçõesToolStripMenuItem1.Size = new System.Drawing.Size(394, 26);
            this.soluçõesToolStripMenuItem1.Text = "Soluções";
            // 
            // soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem
            // 
            this.soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.soluçõesIToolStripMenuItem,
            this.soluçõesIIToolStripMenuItem});
            this.soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem.Name = "soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem";
            this.soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem.Size = new System.Drawing.Size(406, 26);
            this.soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem.Text = "Soluções verdadeiras, suspensões e colóides";
            // 
            // soluçõesIToolStripMenuItem
            // 
            this.soluçõesIToolStripMenuItem.Name = "soluçõesIToolStripMenuItem";
            this.soluçõesIToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.soluçõesIToolStripMenuItem.Text = "Soluções I";
            this.soluçõesIToolStripMenuItem.Click += new System.EventHandler(this.soluçõesIToolStripMenuItem_Click);
            // 
            // soluçõesIIToolStripMenuItem
            // 
            this.soluçõesIIToolStripMenuItem.Name = "soluçõesIIToolStripMenuItem";
            this.soluçõesIIToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.soluçõesIIToolStripMenuItem.Text = "Soluções II";
            this.soluçõesIIToolStripMenuItem.Click += new System.EventHandler(this.soluçõesIIToolStripMenuItem_Click);
            // 
            // solubilidadeToolStripMenuItem
            // 
            this.solubilidadeToolStripMenuItem.Name = "solubilidadeToolStripMenuItem";
            this.solubilidadeToolStripMenuItem.Size = new System.Drawing.Size(406, 26);
            this.solubilidadeToolStripMenuItem.Text = "Solubilidade";
            // 
            // concentraçãoDasSoluçõesToolStripMenuItem1
            // 
            this.concentraçãoDasSoluçõesToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.concentraçãoComumToolStripMenuItem,
            this.concentraçãoMolarToolStripMenuItem});
            this.concentraçãoDasSoluçõesToolStripMenuItem1.Name = "concentraçãoDasSoluçõesToolStripMenuItem1";
            this.concentraçãoDasSoluçõesToolStripMenuItem1.Size = new System.Drawing.Size(406, 26);
            this.concentraçãoDasSoluçõesToolStripMenuItem1.Text = "Concentração das soluções";
            // 
            // concentraçãoComumToolStripMenuItem
            // 
            this.concentraçãoComumToolStripMenuItem.Name = "concentraçãoComumToolStripMenuItem";
            this.concentraçãoComumToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.concentraçãoComumToolStripMenuItem.Text = "Concentração comum";
            // 
            // concentraçãoMolarToolStripMenuItem
            // 
            this.concentraçãoMolarToolStripMenuItem.Name = "concentraçãoMolarToolStripMenuItem";
            this.concentraçãoMolarToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.concentraçãoMolarToolStripMenuItem.Text = "Concentração molar";
            // 
            // propriedadesColigativasDasSoluçõesToolStripMenuItem
            // 
            this.propriedadesColigativasDasSoluçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crioscopiaEEbuliometriaToolStripMenuItem,
            this.tonoscopiaEOsmometriaToolStripMenuItem});
            this.propriedadesColigativasDasSoluçõesToolStripMenuItem.Name = "propriedadesColigativasDasSoluçõesToolStripMenuItem";
            this.propriedadesColigativasDasSoluçõesToolStripMenuItem.Size = new System.Drawing.Size(406, 26);
            this.propriedadesColigativasDasSoluçõesToolStripMenuItem.Text = "Propriedades coligativas das soluções";
            // 
            // crioscopiaEEbuliometriaToolStripMenuItem
            // 
            this.crioscopiaEEbuliometriaToolStripMenuItem.Name = "crioscopiaEEbuliometriaToolStripMenuItem";
            this.crioscopiaEEbuliometriaToolStripMenuItem.Size = new System.Drawing.Size(268, 26);
            this.crioscopiaEEbuliometriaToolStripMenuItem.Text = "Crioscopia e ebuliometria";
            // 
            // tonoscopiaEOsmometriaToolStripMenuItem
            // 
            this.tonoscopiaEOsmometriaToolStripMenuItem.Name = "tonoscopiaEOsmometriaToolStripMenuItem";
            this.tonoscopiaEOsmometriaToolStripMenuItem.Size = new System.Drawing.Size(268, 26);
            this.tonoscopiaEOsmometriaToolStripMenuItem.Text = "Tonoscopia e osmometria";
            // 
            // funçõesInorgânicasToolStripMenuItem
            // 
            this.funçõesInorgânicasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ácidosToolStripMenuItem,
            this.basesToolStripMenuItem,
            this.saisToolStripMenuItem,
            this.óxidosToolStripMenuItem,
            this.principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1});
            this.funçõesInorgânicasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.funçõesInorgânicasToolStripMenuItem.Name = "funçõesInorgânicasToolStripMenuItem";
            this.funçõesInorgânicasToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.funçõesInorgânicasToolStripMenuItem.Text = "Funções inorgânicas";
            // 
            // ácidosToolStripMenuItem
            // 
            this.ácidosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classificaçõesEPropriedadesToolStripMenuItem,
            this.fórmulasENomenclaturasToolStripMenuItem});
            this.ácidosToolStripMenuItem.Name = "ácidosToolStripMenuItem";
            this.ácidosToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.ácidosToolStripMenuItem.Text = "Ácidos";
            // 
            // classificaçõesEPropriedadesToolStripMenuItem
            // 
            this.classificaçõesEPropriedadesToolStripMenuItem.Name = "classificaçõesEPropriedadesToolStripMenuItem";
            this.classificaçõesEPropriedadesToolStripMenuItem.Size = new System.Drawing.Size(296, 26);
            this.classificaçõesEPropriedadesToolStripMenuItem.Text = "Classificações e propriedades";
            this.classificaçõesEPropriedadesToolStripMenuItem.Click += new System.EventHandler(this.classificaçõesEPropriedadesToolStripMenuItem_Click);
            // 
            // fórmulasENomenclaturasToolStripMenuItem
            // 
            this.fórmulasENomenclaturasToolStripMenuItem.Name = "fórmulasENomenclaturasToolStripMenuItem";
            this.fórmulasENomenclaturasToolStripMenuItem.Size = new System.Drawing.Size(296, 26);
            this.fórmulasENomenclaturasToolStripMenuItem.Text = "Fórmulas e nomenclaturas";
            this.fórmulasENomenclaturasToolStripMenuItem.Click += new System.EventHandler(this.fórmulasENomenclaturasToolStripMenuItem_Click);
            // 
            // basesToolStripMenuItem
            // 
            this.basesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem,
            this.fórmulasENomenclaturasToolStripMenuItem1});
            this.basesToolStripMenuItem.Name = "basesToolStripMenuItem";
            this.basesToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.basesToolStripMenuItem.Text = "Bases";
            // 
            // definiçãoClassificaçõesEPropriedadesToolStripMenuItem
            // 
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem.Name = "definiçãoClassificaçõesEPropriedadesToolStripMenuItem";
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem.Size = new System.Drawing.Size(371, 26);
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem.Text = "Definição, classificações e propriedades";
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem.Click += new System.EventHandler(this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem_Click);
            // 
            // fórmulasENomenclaturasToolStripMenuItem1
            // 
            this.fórmulasENomenclaturasToolStripMenuItem1.Name = "fórmulasENomenclaturasToolStripMenuItem1";
            this.fórmulasENomenclaturasToolStripMenuItem1.Size = new System.Drawing.Size(371, 26);
            this.fórmulasENomenclaturasToolStripMenuItem1.Text = "Fórmulas e nomenclaturas";
            this.fórmulasENomenclaturasToolStripMenuItem1.Click += new System.EventHandler(this.fórmulasENomenclaturasToolStripMenuItem1_Click);
            // 
            // saisToolStripMenuItem
            // 
            this.saisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem1,
            this.fórmulasENomenclaturasToolStripMenuItem2});
            this.saisToolStripMenuItem.Name = "saisToolStripMenuItem";
            this.saisToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.saisToolStripMenuItem.Text = "Sais";
            // 
            // definiçãoClassificaçõesEPropriedadesToolStripMenuItem1
            // 
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem1.Name = "definiçãoClassificaçõesEPropriedadesToolStripMenuItem1";
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem1.Size = new System.Drawing.Size(371, 26);
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem1.Text = "Definição, classificações e propriedades";
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem1.Click += new System.EventHandler(this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem1_Click);
            // 
            // fórmulasENomenclaturasToolStripMenuItem2
            // 
            this.fórmulasENomenclaturasToolStripMenuItem2.Name = "fórmulasENomenclaturasToolStripMenuItem2";
            this.fórmulasENomenclaturasToolStripMenuItem2.Size = new System.Drawing.Size(371, 26);
            this.fórmulasENomenclaturasToolStripMenuItem2.Text = "Fórmulas e nomenclaturas";
            this.fórmulasENomenclaturasToolStripMenuItem2.Click += new System.EventHandler(this.fórmulasENomenclaturasToolStripMenuItem2_Click);
            // 
            // óxidosToolStripMenuItem
            // 
            this.óxidosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem2,
            this.fórmulasENomenclaturasToolStripMenuItem3});
            this.óxidosToolStripMenuItem.Name = "óxidosToolStripMenuItem";
            this.óxidosToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.óxidosToolStripMenuItem.Text = "Óxidos";
            // 
            // definiçãoClassificaçõesEPropriedadesToolStripMenuItem2
            // 
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem2.Name = "definiçãoClassificaçõesEPropriedadesToolStripMenuItem2";
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem2.Size = new System.Drawing.Size(371, 26);
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem2.Text = "Definição, classificações e propriedades";
            this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem2.Click += new System.EventHandler(this.definiçãoClassificaçõesEPropriedadesToolStripMenuItem2_Click);
            // 
            // fórmulasENomenclaturasToolStripMenuItem3
            // 
            this.fórmulasENomenclaturasToolStripMenuItem3.Name = "fórmulasENomenclaturasToolStripMenuItem3";
            this.fórmulasENomenclaturasToolStripMenuItem3.Size = new System.Drawing.Size(371, 26);
            this.fórmulasENomenclaturasToolStripMenuItem3.Text = "Fórmulas e nomenclaturas";
            this.fórmulasENomenclaturasToolStripMenuItem3.Click += new System.EventHandler(this.fórmulasENomenclaturasToolStripMenuItem3_Click);
            // 
            // principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1
            // 
            this.principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1.Name = "principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1";
            this.principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1.Size = new System.Drawing.Size(384, 26);
            this.principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1.Text = "Principais propriedades de ácidos e bases";
            this.principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1.Click += new System.EventHandler(this.principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1_Click);
            // 
            // transformaçõesQuímicasEEnergiaToolStripMenuItem
            // 
            this.transformaçõesQuímicasEEnergiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.termoquímicaToolStripMenuItem,
            this.eletroquímicaToolStripMenuItem1,
            this.transformaçõesNuclearesToolStripMenuItem,
            this.radioatividadeToolStripMenuItem1});
            this.transformaçõesQuímicasEEnergiaToolStripMenuItem.Name = "transformaçõesQuímicasEEnergiaToolStripMenuItem";
            this.transformaçõesQuímicasEEnergiaToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.transformaçõesQuímicasEEnergiaToolStripMenuItem.Text = "Transformações químicas e energia";
            // 
            // termoquímicaToolStripMenuItem
            // 
            this.termoquímicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem,
            this.diferentesTiposDeCaloresDeReaçãoToolStripMenuItem,
            this.leiDeHessToolStripMenuItem1});
            this.termoquímicaToolStripMenuItem.Name = "termoquímicaToolStripMenuItem";
            this.termoquímicaToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.termoquímicaToolStripMenuItem.Text = "Termoquímica";
            // 
            // equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem
            // 
            this.equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem.Name = "equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem";
            this.equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem.Size = new System.Drawing.Size(488, 26);
            this.equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem.Text = "Equações termoquímicas, delta H nas reações e gráficos";
            // 
            // diferentesTiposDeCaloresDeReaçãoToolStripMenuItem
            // 
            this.diferentesTiposDeCaloresDeReaçãoToolStripMenuItem.Name = "diferentesTiposDeCaloresDeReaçãoToolStripMenuItem";
            this.diferentesTiposDeCaloresDeReaçãoToolStripMenuItem.Size = new System.Drawing.Size(488, 26);
            this.diferentesTiposDeCaloresDeReaçãoToolStripMenuItem.Text = "Diferentes tipos de calores de reação";
            // 
            // leiDeHessToolStripMenuItem1
            // 
            this.leiDeHessToolStripMenuItem1.Name = "leiDeHessToolStripMenuItem1";
            this.leiDeHessToolStripMenuItem1.Size = new System.Drawing.Size(488, 26);
            this.leiDeHessToolStripMenuItem1.Text = "Lei de Hess";
            // 
            // eletroquímicaToolStripMenuItem1
            // 
            this.eletroquímicaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pilhasToolStripMenuItem,
            this.eletróliseToolStripMenuItem});
            this.eletroquímicaToolStripMenuItem1.Name = "eletroquímicaToolStripMenuItem1";
            this.eletroquímicaToolStripMenuItem1.Size = new System.Drawing.Size(269, 26);
            this.eletroquímicaToolStripMenuItem1.Text = "Eletroquímica";
            // 
            // pilhasToolStripMenuItem
            // 
            this.pilhasToolStripMenuItem.Name = "pilhasToolStripMenuItem";
            this.pilhasToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.pilhasToolStripMenuItem.Text = "Pilhas";
            // 
            // eletróliseToolStripMenuItem
            // 
            this.eletróliseToolStripMenuItem.Name = "eletróliseToolStripMenuItem";
            this.eletróliseToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.eletróliseToolStripMenuItem.Text = "Eletrólise";
            // 
            // transformaçõesNuclearesToolStripMenuItem
            // 
            this.transformaçõesNuclearesToolStripMenuItem.Name = "transformaçõesNuclearesToolStripMenuItem";
            this.transformaçõesNuclearesToolStripMenuItem.Size = new System.Drawing.Size(269, 26);
            this.transformaçõesNuclearesToolStripMenuItem.Text = "Transformações nucleares";
            // 
            // radioatividadeToolStripMenuItem1
            // 
            this.radioatividadeToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fissãoEFusãoNuclearToolStripMenuItem,
            this.desintegraçãoRadioativaToolStripMenuItem,
            this.radioisótoposAplicaçãoToolStripMenuItem});
            this.radioatividadeToolStripMenuItem1.Name = "radioatividadeToolStripMenuItem1";
            this.radioatividadeToolStripMenuItem1.Size = new System.Drawing.Size(269, 26);
            this.radioatividadeToolStripMenuItem1.Text = "Radioatividade";
            // 
            // fissãoEFusãoNuclearToolStripMenuItem
            // 
            this.fissãoEFusãoNuclearToolStripMenuItem.Name = "fissãoEFusãoNuclearToolStripMenuItem";
            this.fissãoEFusãoNuclearToolStripMenuItem.Size = new System.Drawing.Size(262, 26);
            this.fissãoEFusãoNuclearToolStripMenuItem.Text = "Fissão e fusão nuclear";
            // 
            // desintegraçãoRadioativaToolStripMenuItem
            // 
            this.desintegraçãoRadioativaToolStripMenuItem.Name = "desintegraçãoRadioativaToolStripMenuItem";
            this.desintegraçãoRadioativaToolStripMenuItem.Size = new System.Drawing.Size(262, 26);
            this.desintegraçãoRadioativaToolStripMenuItem.Text = "Desintegração radioativa";
            // 
            // radioisótoposAplicaçãoToolStripMenuItem
            // 
            this.radioisótoposAplicaçãoToolStripMenuItem.Name = "radioisótoposAplicaçãoToolStripMenuItem";
            this.radioisótoposAplicaçãoToolStripMenuItem.Size = new System.Drawing.Size(262, 26);
            this.radioisótoposAplicaçãoToolStripMenuItem.Text = "Radioisótopos: aplicação";
            // 
            // dinâmicaDasTransformaçõesQuímicasToolStripMenuItem
            // 
            this.dinâmicaDasTransformaçõesQuímicasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cinéticaQuímicaToolStripMenuItem,
            this.cinéticaQuímicaECotidianoToolStripMenuItem});
            this.dinâmicaDasTransformaçõesQuímicasToolStripMenuItem.Name = "dinâmicaDasTransformaçõesQuímicasToolStripMenuItem";
            this.dinâmicaDasTransformaçõesQuímicasToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.dinâmicaDasTransformaçõesQuímicasToolStripMenuItem.Text = "Dinâmica das transformações químicas";
            // 
            // cinéticaQuímicaToolStripMenuItem
            // 
            this.cinéticaQuímicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conceitoToolStripMenuItem,
            this.fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem,
            this.ordemDeReaçãoglobalEEspecíficaToolStripMenuItem,
            this.leiDaVelocidadeToolStripMenuItem});
            this.cinéticaQuímicaToolStripMenuItem.Name = "cinéticaQuímicaToolStripMenuItem";
            this.cinéticaQuímicaToolStripMenuItem.Size = new System.Drawing.Size(285, 26);
            this.cinéticaQuímicaToolStripMenuItem.Text = "Cinética química";
            // 
            // conceitoToolStripMenuItem
            // 
            this.conceitoToolStripMenuItem.Name = "conceitoToolStripMenuItem";
            this.conceitoToolStripMenuItem.Size = new System.Drawing.Size(410, 26);
            this.conceitoToolStripMenuItem.Text = "Conceito";
            this.conceitoToolStripMenuItem.Click += new System.EventHandler(this.conceitoToolStripMenuItem_Click);
            // 
            // fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem
            // 
            this.fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem.Name = "fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem";
            this.fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem.Size = new System.Drawing.Size(410, 26);
            this.fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem.Text = "Fatores que alteram a velocidade das reações";
            this.fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem.Click += new System.EventHandler(this.fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem_Click);
            // 
            // ordemDeReaçãoglobalEEspecíficaToolStripMenuItem
            // 
            this.ordemDeReaçãoglobalEEspecíficaToolStripMenuItem.Name = "ordemDeReaçãoglobalEEspecíficaToolStripMenuItem";
            this.ordemDeReaçãoglobalEEspecíficaToolStripMenuItem.Size = new System.Drawing.Size(410, 26);
            this.ordemDeReaçãoglobalEEspecíficaToolStripMenuItem.Text = "Ordem de reação (global e específica)";
            this.ordemDeReaçãoglobalEEspecíficaToolStripMenuItem.Click += new System.EventHandler(this.ordemDeReaçãoglobalEEspecíficaToolStripMenuItem_Click);
            // 
            // leiDaVelocidadeToolStripMenuItem
            // 
            this.leiDaVelocidadeToolStripMenuItem.Name = "leiDaVelocidadeToolStripMenuItem";
            this.leiDaVelocidadeToolStripMenuItem.Size = new System.Drawing.Size(410, 26);
            this.leiDaVelocidadeToolStripMenuItem.Text = "Lei da velocidade";
            this.leiDaVelocidadeToolStripMenuItem.Click += new System.EventHandler(this.leiDaVelocidadeToolStripMenuItem_Click);
            // 
            // cinéticaQuímicaECotidianoToolStripMenuItem
            // 
            this.cinéticaQuímicaECotidianoToolStripMenuItem.Name = "cinéticaQuímicaECotidianoToolStripMenuItem";
            this.cinéticaQuímicaECotidianoToolStripMenuItem.Size = new System.Drawing.Size(285, 26);
            this.cinéticaQuímicaECotidianoToolStripMenuItem.Text = "Cinética química e cotidiano";
            this.cinéticaQuímicaECotidianoToolStripMenuItem.Click += new System.EventHandler(this.cinéticaQuímicaECotidianoToolStripMenuItem_Click);
            // 
            // transformaçõesQuímicasEEquilíbrioToolStripMenuItem
            // 
            this.transformaçõesQuímicasEEquilíbrioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem,
            this.fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem,
            this.produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem,
            this.pHEPOHToolStripMenuItem,
            this.oEquilíbrioQuímicoEOCotidianoToolStripMenuItem});
            this.transformaçõesQuímicasEEquilíbrioToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.transformaçõesQuímicasEEquilíbrioToolStripMenuItem.Name = "transformaçõesQuímicasEEquilíbrioToolStripMenuItem";
            this.transformaçõesQuímicasEEquilíbrioToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.transformaçõesQuímicasEEquilíbrioToolStripMenuItem.Text = "Transformações químicas e equilíbrio";
            // 
            // caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem
            // 
            this.caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem.Name = "caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem";
            this.caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem.Text = "Caracterização de um sistema em equilíbrio";
            this.caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem.Click += new System.EventHandler(this.caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem_Click);
            // 
            // fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem
            // 
            this.fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem.Name = "fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem";
            this.fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem.Text = "Fatores que alteram o equilíbrio das reações";
            this.fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem.Click += new System.EventHandler(this.fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem_Click);
            // 
            // produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem
            // 
            this.produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem.Name = "produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem";
            this.produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem.Text = "Produto iônico da água, equilíbrio ácido-base e pH";
            this.produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem.Click += new System.EventHandler(this.produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem_Click);
            // 
            // pHEPOHToolStripMenuItem
            // 
            this.pHEPOHToolStripMenuItem.Name = "pHEPOHToolStripMenuItem";
            this.pHEPOHToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.pHEPOHToolStripMenuItem.Text = "pH e pOH";
            this.pHEPOHToolStripMenuItem.Click += new System.EventHandler(this.pHEPOHToolStripMenuItem_Click);
            // 
            // oEquilíbrioQuímicoEOCotidianoToolStripMenuItem
            // 
            this.oEquilíbrioQuímicoEOCotidianoToolStripMenuItem.Name = "oEquilíbrioQuímicoEOCotidianoToolStripMenuItem";
            this.oEquilíbrioQuímicoEOCotidianoToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.oEquilíbrioQuímicoEOCotidianoToolStripMenuItem.Text = "O equilíbrio químico e o cotidiano";
            this.oEquilíbrioQuímicoEOCotidianoToolStripMenuItem.Click += new System.EventHandler(this.oEquilíbrioQuímicoEOCotidianoToolStripMenuItem_Click);
            // 
            // compostosDeCarbonoToolStripMenuItem
            // 
            this.compostosDeCarbonoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.químicaOrgânicaToolStripMenuItem,
            this.nomenclaturaBásicaToolStripMenuItem,
            this.formasERepresentaçõesToolStripMenuItem,
            this.ligaçõesSigmaEPiToolStripMenuItem,
            this.hibridizaçãoDoCarbonoToolStripMenuItem,
            this.classificaçãoDosCarbonosToolStripMenuItem,
            this.classificaçãoDasCadeiasCarbônicasToolStripMenuItem1,
            this.isomeriaToolStripMenuItem,
            this.hidrocarbonetosToolStripMenuItem,
            this.funçõesOrgânicasOxigenadasToolStripMenuItem,
            this.funçõesOrgânicasNitrogenadasToolStripMenuItem,
            this.polímerosToolStripMenuItem});
            this.compostosDeCarbonoToolStripMenuItem.Name = "compostosDeCarbonoToolStripMenuItem";
            this.compostosDeCarbonoToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.compostosDeCarbonoToolStripMenuItem.Text = "Compostos de Carbono";
            // 
            // químicaOrgânicaToolStripMenuItem
            // 
            this.químicaOrgânicaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.químicaOrgânicaToolStripMenuItem.Name = "químicaOrgânicaToolStripMenuItem";
            this.químicaOrgânicaToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.químicaOrgânicaToolStripMenuItem.Text = "Química Orgânica";
            this.químicaOrgânicaToolStripMenuItem.Click += new System.EventHandler(this.químicaOrgânicaToolStripMenuItem_Click);
            // 
            // nomenclaturaBásicaToolStripMenuItem
            // 
            this.nomenclaturaBásicaToolStripMenuItem.Name = "nomenclaturaBásicaToolStripMenuItem";
            this.nomenclaturaBásicaToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.nomenclaturaBásicaToolStripMenuItem.Text = "Nomenclatura básica";
            this.nomenclaturaBásicaToolStripMenuItem.Click += new System.EventHandler(this.nomenclaturaBásicaToolStripMenuItem_Click);
            // 
            // formasERepresentaçõesToolStripMenuItem
            // 
            this.formasERepresentaçõesToolStripMenuItem.Name = "formasERepresentaçõesToolStripMenuItem";
            this.formasERepresentaçõesToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.formasERepresentaçõesToolStripMenuItem.Text = "Formas e representações";
            this.formasERepresentaçõesToolStripMenuItem.Click += new System.EventHandler(this.formasERepresentaçõesToolStripMenuItem_Click);
            // 
            // ligaçõesSigmaEPiToolStripMenuItem
            // 
            this.ligaçõesSigmaEPiToolStripMenuItem.Name = "ligaçõesSigmaEPiToolStripMenuItem";
            this.ligaçõesSigmaEPiToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.ligaçõesSigmaEPiToolStripMenuItem.Text = "Ligações sigma e pi";
            this.ligaçõesSigmaEPiToolStripMenuItem.Click += new System.EventHandler(this.ligaçõesSigmaEPiToolStripMenuItem_Click);
            // 
            // hibridizaçãoDoCarbonoToolStripMenuItem
            // 
            this.hibridizaçãoDoCarbonoToolStripMenuItem.Name = "hibridizaçãoDoCarbonoToolStripMenuItem";
            this.hibridizaçãoDoCarbonoToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.hibridizaçãoDoCarbonoToolStripMenuItem.Text = "Hibridização do carbono";
            this.hibridizaçãoDoCarbonoToolStripMenuItem.Click += new System.EventHandler(this.hibridizaçãoDoCarbonoToolStripMenuItem_Click);
            // 
            // classificaçãoDosCarbonosToolStripMenuItem
            // 
            this.classificaçãoDosCarbonosToolStripMenuItem.Name = "classificaçãoDosCarbonosToolStripMenuItem";
            this.classificaçãoDosCarbonosToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.classificaçãoDosCarbonosToolStripMenuItem.Text = "Classificação dos carbonos";
            this.classificaçãoDosCarbonosToolStripMenuItem.Click += new System.EventHandler(this.classificaçãoDosCarbonosToolStripMenuItem_Click);
            // 
            // classificaçãoDasCadeiasCarbônicasToolStripMenuItem1
            // 
            this.classificaçãoDasCadeiasCarbônicasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abertasToolStripMenuItem,
            this.fechadasToolStripMenuItem});
            this.classificaçãoDasCadeiasCarbônicasToolStripMenuItem1.Name = "classificaçãoDasCadeiasCarbônicasToolStripMenuItem1";
            this.classificaçãoDasCadeiasCarbônicasToolStripMenuItem1.Size = new System.Drawing.Size(341, 26);
            this.classificaçãoDasCadeiasCarbônicasToolStripMenuItem1.Text = "Classificação das cadeias carbônicas";
            // 
            // abertasToolStripMenuItem
            // 
            this.abertasToolStripMenuItem.Name = "abertasToolStripMenuItem";
            this.abertasToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.abertasToolStripMenuItem.Text = "Abertas";
            this.abertasToolStripMenuItem.Click += new System.EventHandler(this.abertasToolStripMenuItem_Click);
            // 
            // fechadasToolStripMenuItem
            // 
            this.fechadasToolStripMenuItem.Name = "fechadasToolStripMenuItem";
            this.fechadasToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.fechadasToolStripMenuItem.Text = "Fechadas";
            this.fechadasToolStripMenuItem.Click += new System.EventHandler(this.fechadasToolStripMenuItem_Click);
            // 
            // isomeriaToolStripMenuItem
            // 
            this.isomeriaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.isomeriaPlanaDePosiçãoToolStripMenuItem,
            this.isomeriaDeCadeiaToolStripMenuItem,
            this.isomeriaDeFunçãoToolStripMenuItem,
            this.isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem,
            this.isomeriaDinâmicaOuTautomeriaToolStripMenuItem});
            this.isomeriaToolStripMenuItem.Name = "isomeriaToolStripMenuItem";
            this.isomeriaToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.isomeriaToolStripMenuItem.Text = "Isomeria";
            // 
            // isomeriaPlanaDePosiçãoToolStripMenuItem
            // 
            this.isomeriaPlanaDePosiçãoToolStripMenuItem.Name = "isomeriaPlanaDePosiçãoToolStripMenuItem";
            this.isomeriaPlanaDePosiçãoToolStripMenuItem.Size = new System.Drawing.Size(379, 26);
            this.isomeriaPlanaDePosiçãoToolStripMenuItem.Text = "Isomeria plana de posição";
            this.isomeriaPlanaDePosiçãoToolStripMenuItem.Click += new System.EventHandler(this.isomeriaPlanaDePosiçãoToolStripMenuItem_Click);
            // 
            // isomeriaDeCadeiaToolStripMenuItem
            // 
            this.isomeriaDeCadeiaToolStripMenuItem.Name = "isomeriaDeCadeiaToolStripMenuItem";
            this.isomeriaDeCadeiaToolStripMenuItem.Size = new System.Drawing.Size(379, 26);
            this.isomeriaDeCadeiaToolStripMenuItem.Text = "Isomeria de cadeia";
            this.isomeriaDeCadeiaToolStripMenuItem.Click += new System.EventHandler(this.isomeriaDeCadeiaToolStripMenuItem_Click);
            // 
            // isomeriaDeFunçãoToolStripMenuItem
            // 
            this.isomeriaDeFunçãoToolStripMenuItem.Name = "isomeriaDeFunçãoToolStripMenuItem";
            this.isomeriaDeFunçãoToolStripMenuItem.Size = new System.Drawing.Size(379, 26);
            this.isomeriaDeFunçãoToolStripMenuItem.Text = "Isomeria de Função";
            this.isomeriaDeFunçãoToolStripMenuItem.Click += new System.EventHandler(this.isomeriaDeFunçãoToolStripMenuItem_Click);
            // 
            // isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem
            // 
            this.isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem.Name = "isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem";
            this.isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem.Size = new System.Drawing.Size(379, 26);
            this.isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem.Text = "Isomeria de Compensação ou Metameria";
            this.isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem.Click += new System.EventHandler(this.isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem_Click);
            // 
            // isomeriaDinâmicaOuTautomeriaToolStripMenuItem
            // 
            this.isomeriaDinâmicaOuTautomeriaToolStripMenuItem.Name = "isomeriaDinâmicaOuTautomeriaToolStripMenuItem";
            this.isomeriaDinâmicaOuTautomeriaToolStripMenuItem.Size = new System.Drawing.Size(379, 26);
            this.isomeriaDinâmicaOuTautomeriaToolStripMenuItem.Text = "Isomeria Dinâmica ou Tautomeria";
            this.isomeriaDinâmicaOuTautomeriaToolStripMenuItem.Click += new System.EventHandler(this.isomeriaDinâmicaOuTautomeriaToolStripMenuItem_Click);
            // 
            // hidrocarbonetosToolStripMenuItem
            // 
            this.hidrocarbonetosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hidrocarbonetosToolStripMenuItem1,
            this.alcanosToolStripMenuItem,
            this.alcenosToolStripMenuItem,
            this.alcinosToolStripMenuItem,
            this.aromáticosToolStripMenuItem,
            this.outrosHidrocarbonetosToolStripMenuItem,
            this.hidrocarbonetosRamificadosToolStripMenuItem,
            this.haletosOrgânicosToolStripMenuItem});
            this.hidrocarbonetosToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.hidrocarbonetosToolStripMenuItem.Name = "hidrocarbonetosToolStripMenuItem";
            this.hidrocarbonetosToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.hidrocarbonetosToolStripMenuItem.Text = "Hidrocarbonetos";
            // 
            // hidrocarbonetosToolStripMenuItem1
            // 
            this.hidrocarbonetosToolStripMenuItem1.Name = "hidrocarbonetosToolStripMenuItem1";
            this.hidrocarbonetosToolStripMenuItem1.Size = new System.Drawing.Size(298, 26);
            this.hidrocarbonetosToolStripMenuItem1.Text = "Hidrocarbonetos";
            this.hidrocarbonetosToolStripMenuItem1.Click += new System.EventHandler(this.hidrocarbonetosToolStripMenuItem1_Click);
            // 
            // alcanosToolStripMenuItem
            // 
            this.alcanosToolStripMenuItem.Name = "alcanosToolStripMenuItem";
            this.alcanosToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.alcanosToolStripMenuItem.Text = "Alcanos";
            // 
            // alcenosToolStripMenuItem
            // 
            this.alcenosToolStripMenuItem.Name = "alcenosToolStripMenuItem";
            this.alcenosToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.alcenosToolStripMenuItem.Text = "Alcenos";
            // 
            // alcinosToolStripMenuItem
            // 
            this.alcinosToolStripMenuItem.Name = "alcinosToolStripMenuItem";
            this.alcinosToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.alcinosToolStripMenuItem.Text = "Alcinos";
            // 
            // aromáticosToolStripMenuItem
            // 
            this.aromáticosToolStripMenuItem.Name = "aromáticosToolStripMenuItem";
            this.aromáticosToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.aromáticosToolStripMenuItem.Text = "Aromáticos";
            // 
            // outrosHidrocarbonetosToolStripMenuItem
            // 
            this.outrosHidrocarbonetosToolStripMenuItem.Name = "outrosHidrocarbonetosToolStripMenuItem";
            this.outrosHidrocarbonetosToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.outrosHidrocarbonetosToolStripMenuItem.Text = "Outros hidrocarbonetos";
            // 
            // hidrocarbonetosRamificadosToolStripMenuItem
            // 
            this.hidrocarbonetosRamificadosToolStripMenuItem.Name = "hidrocarbonetosRamificadosToolStripMenuItem";
            this.hidrocarbonetosRamificadosToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.hidrocarbonetosRamificadosToolStripMenuItem.Text = "Hidrocarbonetos Ramificados";
            this.hidrocarbonetosRamificadosToolStripMenuItem.Click += new System.EventHandler(this.hidrocarbonetosRamificadosToolStripMenuItem_Click);
            // 
            // haletosOrgânicosToolStripMenuItem
            // 
            this.haletosOrgânicosToolStripMenuItem.Name = "haletosOrgânicosToolStripMenuItem";
            this.haletosOrgânicosToolStripMenuItem.Size = new System.Drawing.Size(298, 26);
            this.haletosOrgânicosToolStripMenuItem.Text = "Haletos Orgânicos";
            this.haletosOrgânicosToolStripMenuItem.Click += new System.EventHandler(this.haletosOrgânicosToolStripMenuItem_Click);
            // 
            // funçõesOrgânicasOxigenadasToolStripMenuItem
            // 
            this.funçõesOrgânicasOxigenadasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.álcoolToolStripMenuItem,
            this.aldeídosToolStripMenuItem,
            this.cetonasToolStripMenuItem,
            this.ácidosCarboxílicosToolStripMenuItem,
            this.éteresToolStripMenuItem,
            this.ésteresToolStripMenuItem});
            this.funçõesOrgânicasOxigenadasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.funçõesOrgânicasOxigenadasToolStripMenuItem.Name = "funçõesOrgânicasOxigenadasToolStripMenuItem";
            this.funçõesOrgânicasOxigenadasToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.funçõesOrgânicasOxigenadasToolStripMenuItem.Text = "Funções orgânicas oxigenadas";
            // 
            // álcoolToolStripMenuItem
            // 
            this.álcoolToolStripMenuItem.Name = "álcoolToolStripMenuItem";
            this.álcoolToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.álcoolToolStripMenuItem.Text = "Álcool, Fenol e Enol";
            this.álcoolToolStripMenuItem.Click += new System.EventHandler(this.álcoolToolStripMenuItem_Click);
            // 
            // aldeídosToolStripMenuItem
            // 
            this.aldeídosToolStripMenuItem.Name = "aldeídosToolStripMenuItem";
            this.aldeídosToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.aldeídosToolStripMenuItem.Text = "Aldeídos";
            this.aldeídosToolStripMenuItem.Click += new System.EventHandler(this.aldeídosToolStripMenuItem_Click);
            // 
            // cetonasToolStripMenuItem
            // 
            this.cetonasToolStripMenuItem.Name = "cetonasToolStripMenuItem";
            this.cetonasToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.cetonasToolStripMenuItem.Text = "Cetonas";
            this.cetonasToolStripMenuItem.Click += new System.EventHandler(this.cetonasToolStripMenuItem_Click);
            // 
            // ácidosCarboxílicosToolStripMenuItem
            // 
            this.ácidosCarboxílicosToolStripMenuItem.Name = "ácidosCarboxílicosToolStripMenuItem";
            this.ácidosCarboxílicosToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.ácidosCarboxílicosToolStripMenuItem.Text = "Ácidos carboxílicos";
            this.ácidosCarboxílicosToolStripMenuItem.Click += new System.EventHandler(this.ácidosCarboxílicosToolStripMenuItem_Click);
            // 
            // éteresToolStripMenuItem
            // 
            this.éteresToolStripMenuItem.Name = "éteresToolStripMenuItem";
            this.éteresToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.éteresToolStripMenuItem.Text = "Éteres";
            this.éteresToolStripMenuItem.Click += new System.EventHandler(this.éteresToolStripMenuItem_Click);
            // 
            // ésteresToolStripMenuItem
            // 
            this.ésteresToolStripMenuItem.Name = "ésteresToolStripMenuItem";
            this.ésteresToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.ésteresToolStripMenuItem.Text = "Ésteres";
            this.ésteresToolStripMenuItem.Click += new System.EventHandler(this.ésteresToolStripMenuItem_Click);
            // 
            // funçõesOrgânicasNitrogenadasToolStripMenuItem
            // 
            this.funçõesOrgânicasNitrogenadasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aminaToolStripMenuItem,
            this.amidaToolStripMenuItem,
            this.nitrocompostoToolStripMenuItem,
            this.nitrilaToolStripMenuItem});
            this.funçõesOrgânicasNitrogenadasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.funçõesOrgânicasNitrogenadasToolStripMenuItem.Name = "funçõesOrgânicasNitrogenadasToolStripMenuItem";
            this.funçõesOrgânicasNitrogenadasToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.funçõesOrgânicasNitrogenadasToolStripMenuItem.Text = "Funções orgânicas nitrogenadas";
            // 
            // aminaToolStripMenuItem
            // 
            this.aminaToolStripMenuItem.Name = "aminaToolStripMenuItem";
            this.aminaToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.aminaToolStripMenuItem.Text = "Amina";
            this.aminaToolStripMenuItem.Click += new System.EventHandler(this.aminaToolStripMenuItem_Click);
            // 
            // amidaToolStripMenuItem
            // 
            this.amidaToolStripMenuItem.Name = "amidaToolStripMenuItem";
            this.amidaToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.amidaToolStripMenuItem.Text = "Amida";
            this.amidaToolStripMenuItem.Click += new System.EventHandler(this.amidaToolStripMenuItem_Click);
            // 
            // nitrocompostoToolStripMenuItem
            // 
            this.nitrocompostoToolStripMenuItem.Name = "nitrocompostoToolStripMenuItem";
            this.nitrocompostoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.nitrocompostoToolStripMenuItem.Text = "Nitrocomposto";
            this.nitrocompostoToolStripMenuItem.Click += new System.EventHandler(this.nitrocompostoToolStripMenuItem_Click);
            // 
            // nitrilaToolStripMenuItem
            // 
            this.nitrilaToolStripMenuItem.Name = "nitrilaToolStripMenuItem";
            this.nitrilaToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.nitrilaToolStripMenuItem.Text = "Nitrila";
            this.nitrilaToolStripMenuItem.Click += new System.EventHandler(this.nitrilaToolStripMenuItem_Click);
            // 
            // polímerosToolStripMenuItem
            // 
            this.polímerosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.polímerosNaturaisToolStripMenuItem,
            this.polímerosArtificiaisToolStripMenuItem});
            this.polímerosToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.polímerosToolStripMenuItem.Name = "polímerosToolStripMenuItem";
            this.polímerosToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.polímerosToolStripMenuItem.Text = "Polímeros";
            // 
            // polímerosNaturaisToolStripMenuItem
            // 
            this.polímerosNaturaisToolStripMenuItem.Name = "polímerosNaturaisToolStripMenuItem";
            this.polímerosNaturaisToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.polímerosNaturaisToolStripMenuItem.Text = "Polímeros naturais";
            this.polímerosNaturaisToolStripMenuItem.Click += new System.EventHandler(this.polímerosNaturaisToolStripMenuItem_Click);
            // 
            // polímerosArtificiaisToolStripMenuItem
            // 
            this.polímerosArtificiaisToolStripMenuItem.Name = "polímerosArtificiaisToolStripMenuItem";
            this.polímerosArtificiaisToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.polímerosArtificiaisToolStripMenuItem.Text = "Polímeros artificiais";
            this.polímerosArtificiaisToolStripMenuItem.Click += new System.EventHandler(this.polímerosArtificiaisToolStripMenuItem_Click);
            // 
            // energiasQuímicasNoCotidianoToolStripMenuItem
            // 
            this.energiasQuímicasNoCotidianoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.petróleoGásNaturalECarvãoToolStripMenuItem,
            this.madeiraEHulhaToolStripMenuItem,
            this.biomassaEBiocombustíveisToolStripMenuItem,
            this.energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem});
            this.energiasQuímicasNoCotidianoToolStripMenuItem.Name = "energiasQuímicasNoCotidianoToolStripMenuItem";
            this.energiasQuímicasNoCotidianoToolStripMenuItem.Size = new System.Drawing.Size(394, 26);
            this.energiasQuímicasNoCotidianoToolStripMenuItem.Text = "Energias químicas no cotidiano";
            // 
            // petróleoGásNaturalECarvãoToolStripMenuItem
            // 
            this.petróleoGásNaturalECarvãoToolStripMenuItem.Name = "petróleoGásNaturalECarvãoToolStripMenuItem";
            this.petróleoGásNaturalECarvãoToolStripMenuItem.Size = new System.Drawing.Size(482, 26);
            this.petróleoGásNaturalECarvãoToolStripMenuItem.Text = "Petróleo, gás natural e carvão";
            // 
            // madeiraEHulhaToolStripMenuItem
            // 
            this.madeiraEHulhaToolStripMenuItem.Name = "madeiraEHulhaToolStripMenuItem";
            this.madeiraEHulhaToolStripMenuItem.Size = new System.Drawing.Size(482, 26);
            this.madeiraEHulhaToolStripMenuItem.Text = "Madeira e hulha";
            // 
            // biomassaEBiocombustíveisToolStripMenuItem
            // 
            this.biomassaEBiocombustíveisToolStripMenuItem.Name = "biomassaEBiocombustíveisToolStripMenuItem";
            this.biomassaEBiocombustíveisToolStripMenuItem.Size = new System.Drawing.Size(482, 26);
            this.biomassaEBiocombustíveisToolStripMenuItem.Text = "Biomassa e biocombustíveis";
            // 
            // energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem
            // 
            this.energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem});
            this.energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem.Name = "energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem";
            this.energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem.Size = new System.Drawing.Size(482, 26);
            this.energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem.Text = "Energia nuclear: vantagens, desvantagens e lixo nuclear";
            // 
            // fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem
            // 
            this.fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem.Name = "fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem";
            this.fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem.Text = "Fenômenos físicos e químicos que acontecem nas usinas nucleares";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.Tomato;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem23,
            this.toolStripMenuItem43,
            this.toolStripMenuItem54,
            this.toolStripMenuItem68,
            this.toolStripMenuItem81,
            this.toolStripMenuItem88,
            this.toolStripMenuItem94,
            this.toolStripMenuItem134});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(109, 25);
            this.toolStripMenuItem1.Text = "Perguntas";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem10,
            this.toolStripMenuItem17,
            this.toolStripMenuItem18,
            this.toolStripMenuItem19,
            this.toolStripMenuItem20,
            this.toolStripMenuItem22});
            this.toolStripMenuItem2.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem2.Text = "Materiais";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem3.Text = "Substâncias e fenômenos";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem4.Text = "Estados de agregação da materia";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem5.Text = "Mudanças de estados físicos";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem6.Text = "Misturas homogêneas e heterogêneas";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem7.Text = "Métodos de separação de misturas";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem8.Text = "Substâncias Puras";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem10.Text = "Estrutura atômica";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem17.Text = "Metais e ligas metálicas";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem18.Text = "Ligações químicas";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem19.Text = "Ligações metálicas";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem21});
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem20.Text = "Ligação iônica";
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(351, 26);
            this.toolStripMenuItem21.Text = "Propriedades dos compostos iônicos";
            this.toolStripMenuItem21.Click += new System.EventHandler(this.toolStripMenuItem21_Click);
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem22.Text = "Ligação covalente";
            this.toolStripMenuItem22.Click += new System.EventHandler(this.toolStripMenuItem22_Click);
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem24,
            this.toolStripMenuItem28,
            this.toolStripMenuItem29,
            this.toolStripMenuItem30,
            this.toolStripMenuItem31,
            this.toolStripMenuItem32,
            this.toolStripMenuItem37,
            this.toolStripMenuItem38});
            this.toolStripMenuItem23.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem23.Text = "Transformações e representações químicas";
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem25,
            this.toolStripMenuItem26});
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem24.Text = "Mol";
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(283, 26);
            this.toolStripMenuItem25.Text = "Mol e número de Avogadro";
            this.toolStripMenuItem25.Click += new System.EventHandler(this.toolStripMenuItem25_Click);
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem27});
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(283, 26);
            this.toolStripMenuItem26.Text = "Mol x massa (massa molar)";
            this.toolStripMenuItem26.Click += new System.EventHandler(this.toolStripMenuItem26_Click);
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(181, 26);
            this.toolStripMenuItem27.Text = "Volume molar";
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem28.Text = "Massa Atômica";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.toolStripMenuItem28_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem29.Text = "Massa Molecular";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem30.Text = "Balanceamento de Equações";
            this.toolStripMenuItem30.Click += new System.EventHandler(this.toolStripMenuItem30_Click);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem31.Text = "Gases ideais";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.toolStripMenuItem31_Click);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem33,
            this.toolStripMenuItem34,
            this.toolStripMenuItem35,
            this.toolStripMenuItem36});
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem32.Text = "Reação química";
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(566, 26);
            this.toolStripMenuItem33.Text = "Tipos de reações";
            this.toolStripMenuItem33.Click += new System.EventHandler(this.toolStripMenuItem33_Click);
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(566, 26);
            this.toolStripMenuItem34.Text = "Reação de síntese ";
            this.toolStripMenuItem34.Click += new System.EventHandler(this.toolStripMenuItem34_Click);
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(566, 26);
            this.toolStripMenuItem35.Text = "Reação de simples troca e reação de dupla troca";
            this.toolStripMenuItem35.Click += new System.EventHandler(this.toolStripMenuItem35_Click);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(566, 26);
            this.toolStripMenuItem36.Text = "Outras reações: neutralização, combustão, hidrogenação, oxidação";
            this.toolStripMenuItem36.Click += new System.EventHandler(this.toolStripMenuItem36_Click);
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem37.Text = "Determinação de fórmulas";
            this.toolStripMenuItem37.Click += new System.EventHandler(this.toolStripMenuItem37_Click);
            // 
            // toolStripMenuItem38
            // 
            this.toolStripMenuItem38.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem40,
            this.toolStripMenuItem41,
            this.toolStripMenuItem42});
            this.toolStripMenuItem38.Name = "toolStripMenuItem38";
            this.toolStripMenuItem38.Size = new System.Drawing.Size(288, 26);
            this.toolStripMenuItem38.Text = "Estequiometria";
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(330, 26);
            this.toolStripMenuItem40.Text = "Pureza de reagentes";
            this.toolStripMenuItem40.Click += new System.EventHandler(this.toolStripMenuItem40_Click);
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(330, 26);
            this.toolStripMenuItem41.Text = "Rendimento de Reação";
            this.toolStripMenuItem41.Click += new System.EventHandler(this.toolStripMenuItem41_Click);
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(330, 26);
            this.toolStripMenuItem42.Text = "Reagentes em Excesso e Limitante";
            this.toolStripMenuItem42.Click += new System.EventHandler(this.toolStripMenuItem42_Click);
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem44,
            this.toolStripMenuItem47,
            this.toolStripMenuItem48,
            this.toolStripMenuItem51});
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem43.Text = "Soluções";
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(406, 26);
            this.toolStripMenuItem44.Text = "Soluções verdadeiras, suspensões e colóides";
            this.toolStripMenuItem44.Click += new System.EventHandler(this.toolStripMenuItem44_Click);
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(406, 26);
            this.toolStripMenuItem47.Text = "Solubilidade";
            this.toolStripMenuItem47.Click += new System.EventHandler(this.toolStripMenuItem47_Click);
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem49,
            this.toolStripMenuItem50});
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(406, 26);
            this.toolStripMenuItem48.Text = "Concentração das soluções";
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(240, 26);
            this.toolStripMenuItem49.Text = "Concentração comum";
            this.toolStripMenuItem49.Click += new System.EventHandler(this.toolStripMenuItem49_Click);
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(240, 26);
            this.toolStripMenuItem50.Text = "Concentração molar";
            this.toolStripMenuItem50.Click += new System.EventHandler(this.toolStripMenuItem50_Click);
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem52,
            this.toolStripMenuItem53});
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(406, 26);
            this.toolStripMenuItem51.Text = "Propriedades coligativas das soluções";
            // 
            // toolStripMenuItem52
            // 
            this.toolStripMenuItem52.Name = "toolStripMenuItem52";
            this.toolStripMenuItem52.Size = new System.Drawing.Size(268, 26);
            this.toolStripMenuItem52.Text = "Crioscopia e ebuliometria";
            this.toolStripMenuItem52.Click += new System.EventHandler(this.toolStripMenuItem52_Click);
            // 
            // toolStripMenuItem53
            // 
            this.toolStripMenuItem53.Name = "toolStripMenuItem53";
            this.toolStripMenuItem53.Size = new System.Drawing.Size(268, 26);
            this.toolStripMenuItem53.Text = "Tonoscopia e osmometria";
            this.toolStripMenuItem53.Click += new System.EventHandler(this.toolStripMenuItem53_Click);
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem55,
            this.toolStripMenuItem58,
            this.toolStripMenuItem61,
            this.toolStripMenuItem64,
            this.toolStripMenuItem67});
            this.toolStripMenuItem54.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem54.Text = "Funções inorgânicas";
            // 
            // toolStripMenuItem55
            // 
            this.toolStripMenuItem55.Name = "toolStripMenuItem55";
            this.toolStripMenuItem55.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem55.Text = "Ácidos";
            this.toolStripMenuItem55.Click += new System.EventHandler(this.toolStripMenuItem55_Click);
            // 
            // toolStripMenuItem58
            // 
            this.toolStripMenuItem58.Name = "toolStripMenuItem58";
            this.toolStripMenuItem58.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem58.Text = "Bases";
            this.toolStripMenuItem58.Click += new System.EventHandler(this.toolStripMenuItem58_Click);
            // 
            // toolStripMenuItem61
            // 
            this.toolStripMenuItem61.Name = "toolStripMenuItem61";
            this.toolStripMenuItem61.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem61.Text = "Sais";
            this.toolStripMenuItem61.Click += new System.EventHandler(this.toolStripMenuItem61_Click);
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem64.Text = "Óxidos";
            this.toolStripMenuItem64.Click += new System.EventHandler(this.toolStripMenuItem64_Click);
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem67.Text = "Principais propriedades de ácidos e bases";
            this.toolStripMenuItem67.Click += new System.EventHandler(this.toolStripMenuItem67_Click);
            // 
            // toolStripMenuItem68
            // 
            this.toolStripMenuItem68.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem69,
            this.toolStripMenuItem73,
            this.toolStripMenuItem76,
            this.toolStripMenuItem77});
            this.toolStripMenuItem68.Name = "toolStripMenuItem68";
            this.toolStripMenuItem68.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem68.Text = "Transformações químicas e energia";
            // 
            // toolStripMenuItem69
            // 
            this.toolStripMenuItem69.Name = "toolStripMenuItem69";
            this.toolStripMenuItem69.Size = new System.Drawing.Size(269, 26);
            this.toolStripMenuItem69.Text = "Termoquímica";
            this.toolStripMenuItem69.Click += new System.EventHandler(this.toolStripMenuItem69_Click);
            // 
            // toolStripMenuItem73
            // 
            this.toolStripMenuItem73.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem74,
            this.toolStripMenuItem75});
            this.toolStripMenuItem73.Name = "toolStripMenuItem73";
            this.toolStripMenuItem73.Size = new System.Drawing.Size(269, 26);
            this.toolStripMenuItem73.Text = "Eletroquímica";
            // 
            // toolStripMenuItem74
            // 
            this.toolStripMenuItem74.Name = "toolStripMenuItem74";
            this.toolStripMenuItem74.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem74.Text = "Pilhas";
            this.toolStripMenuItem74.Click += new System.EventHandler(this.toolStripMenuItem74_Click);
            // 
            // toolStripMenuItem75
            // 
            this.toolStripMenuItem75.Name = "toolStripMenuItem75";
            this.toolStripMenuItem75.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem75.Text = "Eletrólise";
            this.toolStripMenuItem75.Click += new System.EventHandler(this.toolStripMenuItem75_Click);
            // 
            // toolStripMenuItem76
            // 
            this.toolStripMenuItem76.Name = "toolStripMenuItem76";
            this.toolStripMenuItem76.Size = new System.Drawing.Size(269, 26);
            this.toolStripMenuItem76.Text = "Transformações nucleares";
            this.toolStripMenuItem76.Click += new System.EventHandler(this.toolStripMenuItem76_Click);
            // 
            // toolStripMenuItem77
            // 
            this.toolStripMenuItem77.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem78,
            this.toolStripMenuItem79,
            this.toolStripMenuItem80});
            this.toolStripMenuItem77.Name = "toolStripMenuItem77";
            this.toolStripMenuItem77.Size = new System.Drawing.Size(269, 26);
            this.toolStripMenuItem77.Text = "Radioatividade";
            // 
            // toolStripMenuItem78
            // 
            this.toolStripMenuItem78.Name = "toolStripMenuItem78";
            this.toolStripMenuItem78.Size = new System.Drawing.Size(262, 26);
            this.toolStripMenuItem78.Text = "Fissão e fusão nuclear";
            this.toolStripMenuItem78.Click += new System.EventHandler(this.toolStripMenuItem78_Click);
            // 
            // toolStripMenuItem79
            // 
            this.toolStripMenuItem79.Name = "toolStripMenuItem79";
            this.toolStripMenuItem79.Size = new System.Drawing.Size(262, 26);
            this.toolStripMenuItem79.Text = "Desintegração radioativa";
            this.toolStripMenuItem79.Click += new System.EventHandler(this.toolStripMenuItem79_Click);
            // 
            // toolStripMenuItem80
            // 
            this.toolStripMenuItem80.Name = "toolStripMenuItem80";
            this.toolStripMenuItem80.Size = new System.Drawing.Size(262, 26);
            this.toolStripMenuItem80.Text = "Radioisótopos: aplicação";
            this.toolStripMenuItem80.Click += new System.EventHandler(this.toolStripMenuItem80_Click);
            // 
            // toolStripMenuItem81
            // 
            this.toolStripMenuItem81.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem82,
            this.toolStripMenuItem87});
            this.toolStripMenuItem81.Name = "toolStripMenuItem81";
            this.toolStripMenuItem81.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem81.Text = "Dinâmica das transformações químicas";
            // 
            // toolStripMenuItem82
            // 
            this.toolStripMenuItem82.Name = "toolStripMenuItem82";
            this.toolStripMenuItem82.Size = new System.Drawing.Size(285, 26);
            this.toolStripMenuItem82.Text = "Cinética química";
            this.toolStripMenuItem82.Click += new System.EventHandler(this.toolStripMenuItem82_Click);
            // 
            // toolStripMenuItem87
            // 
            this.toolStripMenuItem87.Name = "toolStripMenuItem87";
            this.toolStripMenuItem87.Size = new System.Drawing.Size(285, 26);
            this.toolStripMenuItem87.Text = "Cinética química e cotidiano";
            this.toolStripMenuItem87.Click += new System.EventHandler(this.toolStripMenuItem87_Click);
            // 
            // toolStripMenuItem88
            // 
            this.toolStripMenuItem88.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem91,
            this.toolStripMenuItem92,
            this.toolStripMenuItem93});
            this.toolStripMenuItem88.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem88.Name = "toolStripMenuItem88";
            this.toolStripMenuItem88.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem88.Text = "Transformações químicas e equilíbrio";
            // 
            // toolStripMenuItem91
            // 
            this.toolStripMenuItem91.Name = "toolStripMenuItem91";
            this.toolStripMenuItem91.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem91.Text = "Produto iônico da água, equilíbrio ácido-base e pH";
            this.toolStripMenuItem91.Click += new System.EventHandler(this.toolStripMenuItem91_Click);
            // 
            // toolStripMenuItem92
            // 
            this.toolStripMenuItem92.Name = "toolStripMenuItem92";
            this.toolStripMenuItem92.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem92.Text = "pH e pOH";
            this.toolStripMenuItem92.Click += new System.EventHandler(this.toolStripMenuItem92_Click);
            // 
            // toolStripMenuItem93
            // 
            this.toolStripMenuItem93.Name = "toolStripMenuItem93";
            this.toolStripMenuItem93.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem93.Text = "O equilíbrio químico e o cotidiano";
            this.toolStripMenuItem93.Click += new System.EventHandler(this.toolStripMenuItem93_Click);
            // 
            // toolStripMenuItem94
            // 
            this.toolStripMenuItem94.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem95,
            this.toolStripMenuItem96,
            this.toolStripMenuItem97,
            this.toolStripMenuItem98,
            this.toolStripMenuItem99,
            this.toolStripMenuItem100,
            this.toolStripMenuItem101,
            this.toolStripMenuItem104,
            this.toolStripMenuItem110,
            this.toolStripMenuItem119,
            this.toolStripMenuItem126,
            this.toolStripMenuItem131});
            this.toolStripMenuItem94.Name = "toolStripMenuItem94";
            this.toolStripMenuItem94.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem94.Text = "Compostos de Carbono";
            // 
            // toolStripMenuItem95
            // 
            this.toolStripMenuItem95.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem95.Name = "toolStripMenuItem95";
            this.toolStripMenuItem95.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem95.Text = "Química Orgânica";
            this.toolStripMenuItem95.Click += new System.EventHandler(this.toolStripMenuItem95_Click);
            // 
            // toolStripMenuItem96
            // 
            this.toolStripMenuItem96.Name = "toolStripMenuItem96";
            this.toolStripMenuItem96.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem96.Text = "Nomenclatura básica";
            this.toolStripMenuItem96.Click += new System.EventHandler(this.toolStripMenuItem96_Click);
            // 
            // toolStripMenuItem97
            // 
            this.toolStripMenuItem97.Name = "toolStripMenuItem97";
            this.toolStripMenuItem97.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem97.Text = "Formas e representações";
            this.toolStripMenuItem97.Click += new System.EventHandler(this.toolStripMenuItem97_Click);
            // 
            // toolStripMenuItem98
            // 
            this.toolStripMenuItem98.Name = "toolStripMenuItem98";
            this.toolStripMenuItem98.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem98.Text = "Ligações sigma e pi";
            this.toolStripMenuItem98.Click += new System.EventHandler(this.toolStripMenuItem98_Click);
            // 
            // toolStripMenuItem99
            // 
            this.toolStripMenuItem99.Name = "toolStripMenuItem99";
            this.toolStripMenuItem99.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem99.Text = "Hibridização do carbono";
            this.toolStripMenuItem99.Click += new System.EventHandler(this.toolStripMenuItem99_Click);
            // 
            // toolStripMenuItem100
            // 
            this.toolStripMenuItem100.Name = "toolStripMenuItem100";
            this.toolStripMenuItem100.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem100.Text = "Classificação dos carbonos";
            this.toolStripMenuItem100.Click += new System.EventHandler(this.toolStripMenuItem100_Click);
            // 
            // toolStripMenuItem101
            // 
            this.toolStripMenuItem101.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem102,
            this.toolStripMenuItem103});
            this.toolStripMenuItem101.Name = "toolStripMenuItem101";
            this.toolStripMenuItem101.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem101.Text = "Classificação das cadeias carbônicas";
            // 
            // toolStripMenuItem102
            // 
            this.toolStripMenuItem102.Name = "toolStripMenuItem102";
            this.toolStripMenuItem102.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem102.Text = "Abertas";
            this.toolStripMenuItem102.Click += new System.EventHandler(this.toolStripMenuItem102_Click);
            // 
            // toolStripMenuItem103
            // 
            this.toolStripMenuItem103.Name = "toolStripMenuItem103";
            this.toolStripMenuItem103.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem103.Text = "Fechadas";
            this.toolStripMenuItem103.Click += new System.EventHandler(this.toolStripMenuItem103_Click);
            // 
            // toolStripMenuItem104
            // 
            this.toolStripMenuItem104.Name = "toolStripMenuItem104";
            this.toolStripMenuItem104.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem104.Text = "Isomeria";
            this.toolStripMenuItem104.Click += new System.EventHandler(this.toolStripMenuItem104_Click);
            // 
            // toolStripMenuItem110
            // 
            this.toolStripMenuItem110.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem111,
            this.toolStripMenuItem112,
            this.toolStripMenuItem113,
            this.toolStripMenuItem114,
            this.toolStripMenuItem115,
            this.toolStripMenuItem116,
            this.toolStripMenuItem117,
            this.toolStripMenuItem118});
            this.toolStripMenuItem110.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem110.Name = "toolStripMenuItem110";
            this.toolStripMenuItem110.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem110.Text = "Hidrocarbonetos";
            // 
            // toolStripMenuItem111
            // 
            this.toolStripMenuItem111.Name = "toolStripMenuItem111";
            this.toolStripMenuItem111.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem111.Text = "Hidrocarbonetos";
            this.toolStripMenuItem111.Click += new System.EventHandler(this.toolStripMenuItem111_Click);
            // 
            // toolStripMenuItem112
            // 
            this.toolStripMenuItem112.Name = "toolStripMenuItem112";
            this.toolStripMenuItem112.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem112.Text = "Alcanos";
            this.toolStripMenuItem112.Click += new System.EventHandler(this.toolStripMenuItem112_Click);
            // 
            // toolStripMenuItem113
            // 
            this.toolStripMenuItem113.Name = "toolStripMenuItem113";
            this.toolStripMenuItem113.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem113.Text = "Alcenos";
            this.toolStripMenuItem113.Click += new System.EventHandler(this.toolStripMenuItem113_Click);
            // 
            // toolStripMenuItem114
            // 
            this.toolStripMenuItem114.Name = "toolStripMenuItem114";
            this.toolStripMenuItem114.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem114.Text = "Alcinos";
            this.toolStripMenuItem114.Click += new System.EventHandler(this.toolStripMenuItem114_Click);
            // 
            // toolStripMenuItem115
            // 
            this.toolStripMenuItem115.Name = "toolStripMenuItem115";
            this.toolStripMenuItem115.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem115.Text = "Aromáticos";
            this.toolStripMenuItem115.Click += new System.EventHandler(this.toolStripMenuItem115_Click);
            // 
            // toolStripMenuItem116
            // 
            this.toolStripMenuItem116.Name = "toolStripMenuItem116";
            this.toolStripMenuItem116.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem116.Text = "Outros hidrocarbonetos";
            this.toolStripMenuItem116.Click += new System.EventHandler(this.toolStripMenuItem116_Click);
            // 
            // toolStripMenuItem117
            // 
            this.toolStripMenuItem117.Name = "toolStripMenuItem117";
            this.toolStripMenuItem117.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem117.Text = "Hidrocarbonetos Ramificados";
            this.toolStripMenuItem117.Click += new System.EventHandler(this.toolStripMenuItem117_Click);
            // 
            // toolStripMenuItem118
            // 
            this.toolStripMenuItem118.Name = "toolStripMenuItem118";
            this.toolStripMenuItem118.Size = new System.Drawing.Size(298, 26);
            this.toolStripMenuItem118.Text = "Haletos Orgânicos";
            this.toolStripMenuItem118.Click += new System.EventHandler(this.toolStripMenuItem118_Click);
            // 
            // toolStripMenuItem119
            // 
            this.toolStripMenuItem119.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem120,
            this.toolStripMenuItem121,
            this.toolStripMenuItem122,
            this.toolStripMenuItem123,
            this.toolStripMenuItem124,
            this.toolStripMenuItem125});
            this.toolStripMenuItem119.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem119.Name = "toolStripMenuItem119";
            this.toolStripMenuItem119.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem119.Text = "Funções orgânicas oxigenadas";
            // 
            // toolStripMenuItem120
            // 
            this.toolStripMenuItem120.Name = "toolStripMenuItem120";
            this.toolStripMenuItem120.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem120.Text = "Álcool, Fenol e Enol";
            this.toolStripMenuItem120.Click += new System.EventHandler(this.toolStripMenuItem120_Click);
            // 
            // toolStripMenuItem121
            // 
            this.toolStripMenuItem121.Name = "toolStripMenuItem121";
            this.toolStripMenuItem121.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem121.Text = "Aldeídos";
            this.toolStripMenuItem121.Click += new System.EventHandler(this.toolStripMenuItem121_Click);
            // 
            // toolStripMenuItem122
            // 
            this.toolStripMenuItem122.Name = "toolStripMenuItem122";
            this.toolStripMenuItem122.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem122.Text = "Cetonas";
            this.toolStripMenuItem122.Click += new System.EventHandler(this.toolStripMenuItem122_Click);
            // 
            // toolStripMenuItem123
            // 
            this.toolStripMenuItem123.Name = "toolStripMenuItem123";
            this.toolStripMenuItem123.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem123.Text = "Ácidos carboxílicos";
            this.toolStripMenuItem123.Click += new System.EventHandler(this.toolStripMenuItem123_Click);
            // 
            // toolStripMenuItem124
            // 
            this.toolStripMenuItem124.Name = "toolStripMenuItem124";
            this.toolStripMenuItem124.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem124.Text = "Éteres";
            this.toolStripMenuItem124.Click += new System.EventHandler(this.toolStripMenuItem124_Click);
            // 
            // toolStripMenuItem125
            // 
            this.toolStripMenuItem125.Name = "toolStripMenuItem125";
            this.toolStripMenuItem125.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem125.Text = "Ésteres";
            this.toolStripMenuItem125.Click += new System.EventHandler(this.toolStripMenuItem125_Click);
            // 
            // toolStripMenuItem126
            // 
            this.toolStripMenuItem126.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem127,
            this.toolStripMenuItem128,
            this.toolStripMenuItem129,
            this.toolStripMenuItem130});
            this.toolStripMenuItem126.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem126.Name = "toolStripMenuItem126";
            this.toolStripMenuItem126.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem126.Text = "Funções orgânicas nitrogenadas";
            // 
            // toolStripMenuItem127
            // 
            this.toolStripMenuItem127.Name = "toolStripMenuItem127";
            this.toolStripMenuItem127.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem127.Text = "Amina";
            this.toolStripMenuItem127.Click += new System.EventHandler(this.toolStripMenuItem127_Click);
            // 
            // toolStripMenuItem128
            // 
            this.toolStripMenuItem128.Name = "toolStripMenuItem128";
            this.toolStripMenuItem128.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem128.Text = "Amida";
            this.toolStripMenuItem128.Click += new System.EventHandler(this.toolStripMenuItem128_Click);
            // 
            // toolStripMenuItem129
            // 
            this.toolStripMenuItem129.Name = "toolStripMenuItem129";
            this.toolStripMenuItem129.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem129.Text = "Nitrocomposto";
            this.toolStripMenuItem129.Click += new System.EventHandler(this.toolStripMenuItem129_Click);
            // 
            // toolStripMenuItem130
            // 
            this.toolStripMenuItem130.Name = "toolStripMenuItem130";
            this.toolStripMenuItem130.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem130.Text = "Nitrila";
            this.toolStripMenuItem130.Click += new System.EventHandler(this.toolStripMenuItem130_Click);
            // 
            // toolStripMenuItem131
            // 
            this.toolStripMenuItem131.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem132,
            this.toolStripMenuItem133});
            this.toolStripMenuItem131.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem131.Name = "toolStripMenuItem131";
            this.toolStripMenuItem131.Size = new System.Drawing.Size(341, 26);
            this.toolStripMenuItem131.Text = "Polímeros";
            // 
            // toolStripMenuItem132
            // 
            this.toolStripMenuItem132.Name = "toolStripMenuItem132";
            this.toolStripMenuItem132.Size = new System.Drawing.Size(221, 26);
            this.toolStripMenuItem132.Text = "Polímeros naturais";
            this.toolStripMenuItem132.Click += new System.EventHandler(this.toolStripMenuItem132_Click);
            // 
            // toolStripMenuItem133
            // 
            this.toolStripMenuItem133.Name = "toolStripMenuItem133";
            this.toolStripMenuItem133.Size = new System.Drawing.Size(221, 26);
            this.toolStripMenuItem133.Text = "Polímeros artificiais";
            this.toolStripMenuItem133.Click += new System.EventHandler(this.toolStripMenuItem133_Click);
            // 
            // toolStripMenuItem134
            // 
            this.toolStripMenuItem134.Name = "toolStripMenuItem134";
            this.toolStripMenuItem134.Size = new System.Drawing.Size(394, 26);
            this.toolStripMenuItem134.Text = "Energias químicas no cotidiano";
            this.toolStripMenuItem134.Click += new System.EventHandler(this.toolStripMenuItem134_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(914, 612);
            this.sfoPlayer.TabIndex = 41;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(914, 612);
            this.PictureCSharp.TabIndex = 42;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(914, 612);
            this.panelQuiz.TabIndex = 65;
            // 
            // FrmQui
            // 
            this.AccessibleDescription = "FrmQuimica";
            this.AccessibleName = "FrmQuimica";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmQui";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmQuimica";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fecharMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cursoEmVídeoToolStripMenuItem;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.ToolStripMenuItem materiaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem substânciasEFenômenosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estadosDeAgregaçãoDaMateriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mudançasDeEstadosFísicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem misturasHomogêneasEHeterogêneasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodosDeSeparaçãoDeMisturasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem substânciasPurasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diagramasDeMudançaDeEstadoDeSubstânciasEMisturasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estruturaAtômicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modelosAtômicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regiõesDoÁtomoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númeroAtômicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem átomoNeutroEÍonsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isótoposConceitoEAplicaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabelaPeriódicaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem metaisELigasMetálicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ligaçõesQuímicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ligaçõesMetálicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ligaçãoIônicaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem propriedadesDosCompostosIônicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ligaçãoCovalenteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem transformaçõesERepresentaçõesQuímicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem molToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem molENúmeroDeAvogadroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem molXMassamassaMolarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem volumeMolarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem massaAtômicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gasesIdeaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reaçãoQuímicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem determinaçãoDeFórmulasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem estequiometriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem soluçõesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem soluçõesVerdadeirasSuspensõesEColóidesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem solubilidadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem concentraçãoDasSoluçõesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem concentraçãoComumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem concentraçãoMolarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propriedadesColigativasDasSoluçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crioscopiaEEbuliometriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tonoscopiaEOsmometriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçõesInorgânicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transformaçõesQuímicasEEnergiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem termoquímicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesTermoquímicasDeltaHNasReaçõesEGráficosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diferentesTiposDeCaloresDeReaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leiDeHessToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eletroquímicaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pilhasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eletróliseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transformaçõesNuclearesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem radioatividadeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fissãoEFusãoNuclearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desintegraçãoRadioativaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem radioisótoposAplicaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dinâmicaDasTransformaçõesQuímicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cinéticaQuímicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoresQueAlteramAVelocidadeDasReaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordemDeReaçãoglobalEEspecíficaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leiDaVelocidadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cinéticaQuímicaECotidianoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transformaçõesQuímicasEEquilíbrioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem caracterizaçãoDeUmSistemaEmEquilíbrioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoresQueAlteramOEquilíbrioDasReaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtoIônicoDaÁguaEquilíbrioÁcidobaseEPHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHEPOHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oEquilíbrioQuímicoEOCotidianoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem compostosDeCarbonoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem químicaOrgânicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nomenclaturaBásicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formasERepresentaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ligaçõesSigmaEPiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hibridizaçãoDoCarbonoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classificaçãoDosCarbonosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classificaçãoDasCadeiasCarbônicasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem abertasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fechadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isomeriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isomeriaPlanaDePosiçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isomeriaDeCadeiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isomeriaDeFunçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isomeriaDeCompensaçãoOuMetameriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isomeriaDinâmicaOuTautomeriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hidrocarbonetosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alcanosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alcenosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alcinosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aromáticosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outrosHidrocarbonetosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hidrocarbonetosRamificadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem haletosOrgânicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçõesOrgânicasOxigenadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem álcoolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aldeídosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cetonasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ácidosCarboxílicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem éteresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ésteresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçõesOrgânicasNitrogenadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aminaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem amidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nitrocompostoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nitrilaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polímerosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polímerosNaturaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polímerosArtificiaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem energiasQuímicasNoCotidianoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem petróleoGásNaturalECarvãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem madeiraEHulhaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biomassaEBiocombustíveisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem energiaNuclearVantagensDesvantagensELixoNuclearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fenômenosFísicosEQuímicosQueAcontecemNasUsinasNuclearesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposDeReaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reaçãoDeSínteseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reaçãoDeSimplesTrocaEReaçãoDeDuplaTrocaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outrasReaçõesNeutralizaçãoCombustãoHidrogenaçãoOxidaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fundamentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purezaDeReagentesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rendimentoDeReaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reagentesEmExcessoELimitanteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem soluçõesIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem soluçõesIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ácidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classificaçõesEPropriedadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fórmulasENomenclaturasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem definiçãoClassificaçõesEPropriedadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fórmulasENomenclaturasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem definiçãoClassificaçõesEPropriedadesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fórmulasENomenclaturasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem óxidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem definiçãoClassificaçõesEPropriedadesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem fórmulasENomenclaturasToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem principaisPropriedadesDeÁcidosEBasesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hidrocarbonetosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem massaMolecularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem balanceamentoDeEquaçõesToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem53;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem58;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem61;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem68;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem69;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem73;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem74;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem75;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem76;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem77;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem78;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem79;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem80;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem81;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem82;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem87;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem88;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem91;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem92;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem93;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem94;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem95;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem96;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem97;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem98;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem99;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem100;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem101;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem102;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem103;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem104;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem110;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem111;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem112;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem113;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem114;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem115;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem116;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem117;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem118;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem119;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem120;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem121;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem122;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem123;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem124;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem125;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem126;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem127;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem128;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem129;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem130;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem131;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem132;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem133;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem134;
    }
}