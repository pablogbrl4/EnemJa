﻿namespace CursoVideo.View.Videos
{
    partial class FrmMat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMat));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fecharMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cursoEmVídeoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matemáticaBásicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expressõesNuméricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.critériosDeDivisibilidadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númerosPrimosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoraçãoDeNúmerosInteirosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.divisoresDeUmNúmeroInteiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mínimoMúltiploComumMMCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.máximoDivisorComumMDCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fraçõesparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fraçõesparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númerosDecimaisparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númerosDecimaisparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potenciaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potênciaDeDezENotaçãoCientíficaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radiciaçãoparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radiciaçãoparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosNotáveisparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosNotáveisparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fraçõesAlgébricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.racionalizaçãoDeDenominadoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.razãoEProporçãoparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.razãoEProporçãoparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regraDeTrêsSimplesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regraDeTrêsCompostaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porcentagemparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.porcentagemparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jurosSimplesparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jurosSimplesparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jurosCompostosparte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jurosCompostosparte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaMétricoDecimalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.médiaAritméticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.médiaPonderadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.médiaGeométricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.médiaHarmônicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçãoDo1GrauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçãoDo2GrauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesIrracionaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesBiquadradasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conjuntosNuméricosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númerosNaturaisEInteirosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númerosRacionaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númerosIrracionaisEReaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.intervalosReaisOperaçõesEPropriedadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conjuntosNuméricosNívelBásicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conjuntosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.subconjuntosEConjuntoDasPartesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uniãoEIntersecçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diferençaEComplementarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasConjuntosNívelBásicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasConjuntosNívelAvançadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçõesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.noçõesBásicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.domínioContradomínioEConjuntoImagemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudoDoDomínioDasFunçõesReaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noçõesBásicasDePlanoCartesianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.construçãoDeGráficosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.domínioEImagemAtravésDoGráficoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reconhecendoUmaFunçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.analisandoOGráficoDeFunçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasAnáliseDeGráficosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoParEFunçãoÍmparToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoInjetoraFunçãoInjetivaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoBijetoraFunçãoBijetivaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoCompostaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoInversaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasFunçãoInversaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitosIniciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.determinandoAFunçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coeficienteAngularECoeficienteLinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.casosParticularesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zeroOuRaizDaFunçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudoDoSinalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçãoDoPrimeiroGrauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitosIniciaisToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçõesSimultâneasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçãoProdutoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçãoQuocienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitosIniciaisToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quantidadeDeRaízesReaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoParábolaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoParábolaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosSobreGráficoParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosSobreGráficoParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudoDoSinalGráficoParábolaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte2ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçãoDoSegundoGrauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitosIniciaisToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçõesSimultâneasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçãoProdutoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçãoQuocienteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoModularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.móduloDeUmNúmeroRealToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.propriedadesDoMóduloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesModularesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçõesModularesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasFunçãoModularParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasFunçãoModularParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoExponencialToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.revisãoDePotenciaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficoParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesExponenciaisParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesExponenciaisParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçõesExponenciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte1ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte2ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.QuartoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.progressãoAritméticaPAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.termoGeralToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.termoGeralExercíciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notaçõesEspeciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interpolaçãoDeMeiosAritméticosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.somaDosTermosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.progressãoGeométricaPGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.termoGeralToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.termoGeralExercíciosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.notaçõesEspeciaisToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.interpolaçãoDeMeiosGeométricosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.somaDosTermosDeUmaPGFinitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.somaDosTermosDeUmaPGInfinitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosDePAEPGSimultaneamenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.questõesComentadasParte2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.geometriaPlanaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoÂngulosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paralelismoEntreRetasNoPlanoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polígonosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polígonosRegularesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoAosTriângulosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classificaçãoDosTriângulosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pontosNotáveisDoTriânguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.áreaDeTriângulosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.semelhançaDeTriângulosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.triânguloRetânguloRelaçõesMétricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.triânguloRetânguloExercíciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.triânguloEquiláteroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teoremaDeTalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quadriláterosParalelogramoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quadriláterosRetânguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.quadriláterosLosangoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quadriláterosQuadradoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quadriláterosTrapézioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hexágonoRegularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circunferênciaConceitosIniciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relaçõesMétricasNaCircunferênciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circunferênciaPotênciaDePontoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ângulosNaCircunferênciaParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ângulosNaCircunferênciaParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comprimentoDaCircunferênciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.áreaDoCírculoESetorCircularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.áreaDeSegmentoECoroaCircularesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.áreasSemelhantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trigonometriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.triânguloRetânguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trigonometriaNoTriânguloRetânguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.triânguloQualquerLeiDosSenosECossenosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leiDosSenosECossenosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cicloTrigonométricoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosResolvidosCicloTrigonométricoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relaçõesTrigonométricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operaçõesComArcosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosResolvidosOperaçõesComArcosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesTrigonométricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçõesTrigonométricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoSenoECossenoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoTgCotgSecECossecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geometriaEspacialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tetraedroEOctaedroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prismasIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prismasIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pirâmidesIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pirâmidesIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cilindroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.esferaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.troncosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosIIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosIVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geometriaAnalíticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distânciaEntre2PontosEPontoMédioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.baricentroEÁreaDeTriânguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudoDaRetaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudoDaRetaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercícioEstudoDaRetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudoDaCircunferênciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudoDaCircunferênciaExercícioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númerosComplexosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unidadeImagináriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaAlgébricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operaçõesNaFormaAlgébricaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operaçõesNaFormaAlgébricaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potênciasDaUnidadeImagináriaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polinômiosEEquaçõesPolinomiaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polinômiosIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polinômiosIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TerceiroMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.binômioDeNewtonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coeficientesBinomiaisETriânguloDePascalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SegundoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.princípioFundamentalDaContagemToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatorialEPermutaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.permutaçãoNaVideolocadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arranjoECombinaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitoDeCombinaçãoEArranjoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.análiseCombinatóriaquestãoFácilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.análiseCombinatóriacomPegadinhaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.probabilidadeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte2ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logaritmoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.condiçãoDeExistênciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consequênciasDaDefiniçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propriedadesOperatóriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propriedadesOperatóriasExercíciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cálculoDeLogaritmosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mudançaDeBaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logaritmoEAsEquaçõesExponenciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aplicaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoLogarítmicaEGráficoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesLogarítmicasParte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesLogarítmicasParte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inequaçõesLogarítmicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logaritmoQuestõesComentadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funçãoLogarítmicaQuestõesComentadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem52 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem56 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem65 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem83 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem95 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem101 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem113 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem119 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem127 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem137 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem138 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem147 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem158 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem159 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem162 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem163 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem167 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem168 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem169 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem171 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem172 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem173 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem174 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem175 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem176 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem177 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem178 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem179 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem180 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem183 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem185 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem189 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem190 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem192 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem194 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem196 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem197 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem199 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem200 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem201 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem202 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem204 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem205 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem206 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem207 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem210 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem213 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem214 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem215 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem216 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem220 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem221 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem222 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem225 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem228 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem230 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem231 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem232 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem233 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem235 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem236 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem239 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem240 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem241 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem242 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem245 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem247 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem252 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem259 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharMenuItem,
            this.cursoEmVídeoToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(122, 612);
            this.menuStrip1.TabIndex = 39;
            // 
            // fecharMenuItem
            // 
            this.fecharMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.fecharMenuItem.BackColor = System.Drawing.SystemColors.ControlLight;
            this.fecharMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharMenuItem.Image")));
            this.fecharMenuItem.Name = "fecharMenuItem";
            this.fecharMenuItem.Size = new System.Drawing.Size(109, 39);
            this.fecharMenuItem.Text = "FECHAR";
            this.fecharMenuItem.Click += new System.EventHandler(this.fecharMenuItem_Click);
            // 
            // cursoEmVídeoToolStripMenuItem
            // 
            this.cursoEmVídeoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.matemáticaBásicaToolStripMenuItem,
            this.conjuntosNuméricosToolStripMenuItem,
            this.conjuntosToolStripMenuItem,
            this.funçõesToolStripMenuItem,
            this.QuartoMenuItem,
            this.geometriaPlanaToolStripMenuItem,
            this.trigonometriaToolStripMenuItem,
            this.geometriaEspacialToolStripMenuItem,
            this.geometriaAnalíticaToolStripMenuItem,
            this.númerosComplexosToolStripMenuItem,
            this.polinômiosEEquaçõesPolinomiaisToolStripMenuItem,
            this.TerceiroMenuItem,
            this.SegundoMenuItem,
            this.probabilidadeToolStripMenuItem1,
            this.logaritmoToolStripMenuItem});
            this.cursoEmVídeoToolStripMenuItem.Name = "cursoEmVídeoToolStripMenuItem";
            this.cursoEmVídeoToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.cursoEmVídeoToolStripMenuItem.Text = "Matemática";
            // 
            // matemáticaBásicaToolStripMenuItem
            // 
            this.matemáticaBásicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte1ToolStripMenuItem,
            this.parte2ToolStripMenuItem});
            this.matemáticaBásicaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.matemáticaBásicaToolStripMenuItem.Name = "matemáticaBásicaToolStripMenuItem";
            this.matemáticaBásicaToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.matemáticaBásicaToolStripMenuItem.Text = "Matemática Básica ";
            // 
            // parte1ToolStripMenuItem
            // 
            this.parte1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expressõesNuméricasToolStripMenuItem,
            this.critériosDeDivisibilidadeToolStripMenuItem,
            this.númerosPrimosToolStripMenuItem,
            this.fatoraçãoDeNúmerosInteirosToolStripMenuItem,
            this.quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem,
            this.divisoresDeUmNúmeroInteiroToolStripMenuItem,
            this.mínimoMúltiploComumMMCToolStripMenuItem,
            this.máximoDivisorComumMDCToolStripMenuItem,
            this.fraçõesparte1ToolStripMenuItem,
            this.fraçõesparte2ToolStripMenuItem,
            this.númerosDecimaisparte1ToolStripMenuItem,
            this.númerosDecimaisparte2ToolStripMenuItem,
            this.dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem,
            this.potenciaçãoToolStripMenuItem,
            this.potênciaDeDezENotaçãoCientíficaToolStripMenuItem,
            this.sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem,
            this.radiciaçãoparte1ToolStripMenuItem,
            this.radiciaçãoparte2ToolStripMenuItem,
            this.produtosNotáveisparte1ToolStripMenuItem,
            this.produtosNotáveisparte2ToolStripMenuItem});
            this.parte1ToolStripMenuItem.Name = "parte1ToolStripMenuItem";
            this.parte1ToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.parte1ToolStripMenuItem.Text = "Parte 1";
            // 
            // expressõesNuméricasToolStripMenuItem
            // 
            this.expressõesNuméricasToolStripMenuItem.Name = "expressõesNuméricasToolStripMenuItem";
            this.expressõesNuméricasToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.expressõesNuméricasToolStripMenuItem.Text = "Expressões numéricas";
            this.expressõesNuméricasToolStripMenuItem.Click += new System.EventHandler(this.expressõesNuméricasToolStripMenuItem_Click);
            // 
            // critériosDeDivisibilidadeToolStripMenuItem
            // 
            this.critériosDeDivisibilidadeToolStripMenuItem.Name = "critériosDeDivisibilidadeToolStripMenuItem";
            this.critériosDeDivisibilidadeToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.critériosDeDivisibilidadeToolStripMenuItem.Text = "Critérios de divisibilidade";
            this.critériosDeDivisibilidadeToolStripMenuItem.Click += new System.EventHandler(this.critériosDeDivisibilidadeToolStripMenuItem_Click);
            // 
            // númerosPrimosToolStripMenuItem
            // 
            this.númerosPrimosToolStripMenuItem.Name = "númerosPrimosToolStripMenuItem";
            this.númerosPrimosToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.númerosPrimosToolStripMenuItem.Text = "Números primos";
            this.númerosPrimosToolStripMenuItem.Click += new System.EventHandler(this.númerosPrimosToolStripMenuItem_Click);
            // 
            // fatoraçãoDeNúmerosInteirosToolStripMenuItem
            // 
            this.fatoraçãoDeNúmerosInteirosToolStripMenuItem.Name = "fatoraçãoDeNúmerosInteirosToolStripMenuItem";
            this.fatoraçãoDeNúmerosInteirosToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.fatoraçãoDeNúmerosInteirosToolStripMenuItem.Text = "Fatoração de números inteiros";
            this.fatoraçãoDeNúmerosInteirosToolStripMenuItem.Click += new System.EventHandler(this.fatoraçãoDeNúmerosInteirosToolStripMenuItem_Click);
            // 
            // quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem
            // 
            this.quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem.Name = "quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem";
            this.quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem.Text = "Quantidade de divisores de um número inteiro";
            this.quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem.Click += new System.EventHandler(this.quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem_Click);
            // 
            // divisoresDeUmNúmeroInteiroToolStripMenuItem
            // 
            this.divisoresDeUmNúmeroInteiroToolStripMenuItem.Name = "divisoresDeUmNúmeroInteiroToolStripMenuItem";
            this.divisoresDeUmNúmeroInteiroToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.divisoresDeUmNúmeroInteiroToolStripMenuItem.Text = "Divisores de um número inteiro";
            this.divisoresDeUmNúmeroInteiroToolStripMenuItem.Click += new System.EventHandler(this.divisoresDeUmNúmeroInteiroToolStripMenuItem_Click);
            // 
            // mínimoMúltiploComumMMCToolStripMenuItem
            // 
            this.mínimoMúltiploComumMMCToolStripMenuItem.Name = "mínimoMúltiploComumMMCToolStripMenuItem";
            this.mínimoMúltiploComumMMCToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.mínimoMúltiploComumMMCToolStripMenuItem.Text = "Mínimo múltiplo comum - MMC";
            this.mínimoMúltiploComumMMCToolStripMenuItem.Click += new System.EventHandler(this.mínimoMúltiploComumMMCToolStripMenuItem_Click);
            // 
            // máximoDivisorComumMDCToolStripMenuItem
            // 
            this.máximoDivisorComumMDCToolStripMenuItem.Name = "máximoDivisorComumMDCToolStripMenuItem";
            this.máximoDivisorComumMDCToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.máximoDivisorComumMDCToolStripMenuItem.Text = "Máximo divisor comum - MDC";
            this.máximoDivisorComumMDCToolStripMenuItem.Click += new System.EventHandler(this.máximoDivisorComumMDCToolStripMenuItem_Click);
            // 
            // fraçõesparte1ToolStripMenuItem
            // 
            this.fraçõesparte1ToolStripMenuItem.Name = "fraçõesparte1ToolStripMenuItem";
            this.fraçõesparte1ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.fraçõesparte1ToolStripMenuItem.Text = "Frações (parte 1)";
            this.fraçõesparte1ToolStripMenuItem.Click += new System.EventHandler(this.fraçõesparte1ToolStripMenuItem_Click);
            // 
            // fraçõesparte2ToolStripMenuItem
            // 
            this.fraçõesparte2ToolStripMenuItem.Name = "fraçõesparte2ToolStripMenuItem";
            this.fraçõesparte2ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.fraçõesparte2ToolStripMenuItem.Text = "Frações (parte 2)";
            this.fraçõesparte2ToolStripMenuItem.Click += new System.EventHandler(this.fraçõesparte2ToolStripMenuItem_Click);
            // 
            // númerosDecimaisparte1ToolStripMenuItem
            // 
            this.númerosDecimaisparte1ToolStripMenuItem.Name = "númerosDecimaisparte1ToolStripMenuItem";
            this.númerosDecimaisparte1ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.númerosDecimaisparte1ToolStripMenuItem.Text = "Números decimais (parte 1)";
            this.númerosDecimaisparte1ToolStripMenuItem.Click += new System.EventHandler(this.númerosDecimaisparte1ToolStripMenuItem_Click);
            // 
            // númerosDecimaisparte2ToolStripMenuItem
            // 
            this.númerosDecimaisparte2ToolStripMenuItem.Name = "númerosDecimaisparte2ToolStripMenuItem";
            this.númerosDecimaisparte2ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.númerosDecimaisparte2ToolStripMenuItem.Text = "Números decimais (parte 2)";
            this.númerosDecimaisparte2ToolStripMenuItem.Click += new System.EventHandler(this.númerosDecimaisparte2ToolStripMenuItem_Click);
            // 
            // dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem
            // 
            this.dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem.Name = "dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem";
            this.dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem.Text = "Dízimas periódicas (decimais periódicos)";
            this.dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem.Click += new System.EventHandler(this.dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem_Click);
            // 
            // potenciaçãoToolStripMenuItem
            // 
            this.potenciaçãoToolStripMenuItem.Name = "potenciaçãoToolStripMenuItem";
            this.potenciaçãoToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.potenciaçãoToolStripMenuItem.Text = "Potenciação";
            this.potenciaçãoToolStripMenuItem.Click += new System.EventHandler(this.potenciaçãoToolStripMenuItem_Click);
            // 
            // potênciaDeDezENotaçãoCientíficaToolStripMenuItem
            // 
            this.potênciaDeDezENotaçãoCientíficaToolStripMenuItem.Name = "potênciaDeDezENotaçãoCientíficaToolStripMenuItem";
            this.potênciaDeDezENotaçãoCientíficaToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.potênciaDeDezENotaçãoCientíficaToolStripMenuItem.Text = "Potência de dez e notação científica";
            this.potênciaDeDezENotaçãoCientíficaToolStripMenuItem.Click += new System.EventHandler(this.potênciaDeDezENotaçãoCientíficaToolStripMenuItem_Click);
            // 
            // sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem
            // 
            this.sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem.Name = "sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem";
            this.sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem.Text = "Sistema de numeração decimal ou base dez";
            this.sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem.Click += new System.EventHandler(this.sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem_Click);
            // 
            // radiciaçãoparte1ToolStripMenuItem
            // 
            this.radiciaçãoparte1ToolStripMenuItem.Name = "radiciaçãoparte1ToolStripMenuItem";
            this.radiciaçãoparte1ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.radiciaçãoparte1ToolStripMenuItem.Text = "Radiciação (parte 1)";
            this.radiciaçãoparte1ToolStripMenuItem.Click += new System.EventHandler(this.radiciaçãoparte1ToolStripMenuItem_Click);
            // 
            // radiciaçãoparte2ToolStripMenuItem
            // 
            this.radiciaçãoparte2ToolStripMenuItem.Name = "radiciaçãoparte2ToolStripMenuItem";
            this.radiciaçãoparte2ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.radiciaçãoparte2ToolStripMenuItem.Text = "Radiciação (parte 2)";
            this.radiciaçãoparte2ToolStripMenuItem.Click += new System.EventHandler(this.radiciaçãoparte2ToolStripMenuItem_Click);
            // 
            // produtosNotáveisparte1ToolStripMenuItem
            // 
            this.produtosNotáveisparte1ToolStripMenuItem.Name = "produtosNotáveisparte1ToolStripMenuItem";
            this.produtosNotáveisparte1ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.produtosNotáveisparte1ToolStripMenuItem.Text = "Produtos notáveis (parte 1)";
            this.produtosNotáveisparte1ToolStripMenuItem.Click += new System.EventHandler(this.produtosNotáveisparte1ToolStripMenuItem_Click);
            // 
            // produtosNotáveisparte2ToolStripMenuItem
            // 
            this.produtosNotáveisparte2ToolStripMenuItem.Name = "produtosNotáveisparte2ToolStripMenuItem";
            this.produtosNotáveisparte2ToolStripMenuItem.Size = new System.Drawing.Size(420, 26);
            this.produtosNotáveisparte2ToolStripMenuItem.Text = "Produtos notáveis (parte 2)";
            this.produtosNotáveisparte2ToolStripMenuItem.Click += new System.EventHandler(this.produtosNotáveisparte2ToolStripMenuItem_Click);
            // 
            // parte2ToolStripMenuItem
            // 
            this.parte2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem,
            this.fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem,
            this.fraçõesAlgébricasToolStripMenuItem,
            this.racionalizaçãoDeDenominadoresToolStripMenuItem,
            this.razãoEProporçãoparte1ToolStripMenuItem,
            this.razãoEProporçãoparte2ToolStripMenuItem,
            this.regraDeTrêsSimplesToolStripMenuItem,
            this.regraDeTrêsCompostaToolStripMenuItem,
            this.porcentagemparte1ToolStripMenuItem,
            this.porcentagemparte2ToolStripMenuItem,
            this.jurosSimplesparte1ToolStripMenuItem,
            this.jurosSimplesparte2ToolStripMenuItem,
            this.jurosCompostosparte1ToolStripMenuItem,
            this.jurosCompostosparte2ToolStripMenuItem,
            this.sistemaMétricoDecimalToolStripMenuItem,
            this.médiaAritméticaToolStripMenuItem,
            this.médiaPonderadaToolStripMenuItem,
            this.médiaGeométricaToolStripMenuItem,
            this.médiaHarmônicaToolStripMenuItem,
            this.equaçãoDo1GrauToolStripMenuItem,
            this.equaçãoDo2GrauToolStripMenuItem,
            this.equaçõesIrracionaisToolStripMenuItem,
            this.equaçõesBiquadradasToolStripMenuItem});
            this.parte2ToolStripMenuItem.Name = "parte2ToolStripMenuItem";
            this.parte2ToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.parte2ToolStripMenuItem.Text = "Parte 2";
            // 
            // fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem
            // 
            this.fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem.Name = "fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem";
            this.fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem.Text = "Fatoração de expressões algébricas (parte 1)";
            this.fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem.Click += new System.EventHandler(this.fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem_Click);
            // 
            // fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem
            // 
            this.fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem.Name = "fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem";
            this.fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem.Text = "Fatoração de expressões algébricas (parte 2)";
            this.fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem.Click += new System.EventHandler(this.fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem_Click);
            // 
            // fraçõesAlgébricasToolStripMenuItem
            // 
            this.fraçõesAlgébricasToolStripMenuItem.Name = "fraçõesAlgébricasToolStripMenuItem";
            this.fraçõesAlgébricasToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.fraçõesAlgébricasToolStripMenuItem.Text = "Frações Algébricas";
            this.fraçõesAlgébricasToolStripMenuItem.Click += new System.EventHandler(this.fraçõesAlgébricasToolStripMenuItem_Click);
            // 
            // racionalizaçãoDeDenominadoresToolStripMenuItem
            // 
            this.racionalizaçãoDeDenominadoresToolStripMenuItem.Name = "racionalizaçãoDeDenominadoresToolStripMenuItem";
            this.racionalizaçãoDeDenominadoresToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.racionalizaçãoDeDenominadoresToolStripMenuItem.Text = "Racionalização de denominadores";
            this.racionalizaçãoDeDenominadoresToolStripMenuItem.Click += new System.EventHandler(this.racionalizaçãoDeDenominadoresToolStripMenuItem_Click);
            // 
            // razãoEProporçãoparte1ToolStripMenuItem
            // 
            this.razãoEProporçãoparte1ToolStripMenuItem.Name = "razãoEProporçãoparte1ToolStripMenuItem";
            this.razãoEProporçãoparte1ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.razãoEProporçãoparte1ToolStripMenuItem.Text = "Razão e Proporção (parte 1)";
            this.razãoEProporçãoparte1ToolStripMenuItem.Click += new System.EventHandler(this.razãoEProporçãoparte1ToolStripMenuItem_Click);
            // 
            // razãoEProporçãoparte2ToolStripMenuItem
            // 
            this.razãoEProporçãoparte2ToolStripMenuItem.Name = "razãoEProporçãoparte2ToolStripMenuItem";
            this.razãoEProporçãoparte2ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.razãoEProporçãoparte2ToolStripMenuItem.Text = "Razão e Proporção (parte 2)";
            this.razãoEProporçãoparte2ToolStripMenuItem.Click += new System.EventHandler(this.razãoEProporçãoparte2ToolStripMenuItem_Click);
            // 
            // regraDeTrêsSimplesToolStripMenuItem
            // 
            this.regraDeTrêsSimplesToolStripMenuItem.Name = "regraDeTrêsSimplesToolStripMenuItem";
            this.regraDeTrêsSimplesToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.regraDeTrêsSimplesToolStripMenuItem.Text = "Regra de Três Simples";
            this.regraDeTrêsSimplesToolStripMenuItem.Click += new System.EventHandler(this.regraDeTrêsSimplesToolStripMenuItem_Click);
            // 
            // regraDeTrêsCompostaToolStripMenuItem
            // 
            this.regraDeTrêsCompostaToolStripMenuItem.Name = "regraDeTrêsCompostaToolStripMenuItem";
            this.regraDeTrêsCompostaToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.regraDeTrêsCompostaToolStripMenuItem.Text = "Regra de Três Composta";
            this.regraDeTrêsCompostaToolStripMenuItem.Click += new System.EventHandler(this.regraDeTrêsCompostaToolStripMenuItem_Click);
            // 
            // porcentagemparte1ToolStripMenuItem
            // 
            this.porcentagemparte1ToolStripMenuItem.Name = "porcentagemparte1ToolStripMenuItem";
            this.porcentagemparte1ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.porcentagemparte1ToolStripMenuItem.Text = "Porcentagem (parte 1)";
            this.porcentagemparte1ToolStripMenuItem.Click += new System.EventHandler(this.porcentagemparte1ToolStripMenuItem_Click);
            // 
            // porcentagemparte2ToolStripMenuItem
            // 
            this.porcentagemparte2ToolStripMenuItem.Name = "porcentagemparte2ToolStripMenuItem";
            this.porcentagemparte2ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.porcentagemparte2ToolStripMenuItem.Text = "Porcentagem (parte 2)";
            this.porcentagemparte2ToolStripMenuItem.Click += new System.EventHandler(this.porcentagemparte2ToolStripMenuItem_Click);
            // 
            // jurosSimplesparte1ToolStripMenuItem
            // 
            this.jurosSimplesparte1ToolStripMenuItem.Name = "jurosSimplesparte1ToolStripMenuItem";
            this.jurosSimplesparte1ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.jurosSimplesparte1ToolStripMenuItem.Text = "Juros Simples (parte 1)";
            this.jurosSimplesparte1ToolStripMenuItem.Click += new System.EventHandler(this.jurosSimplesparte1ToolStripMenuItem_Click);
            // 
            // jurosSimplesparte2ToolStripMenuItem
            // 
            this.jurosSimplesparte2ToolStripMenuItem.Name = "jurosSimplesparte2ToolStripMenuItem";
            this.jurosSimplesparte2ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.jurosSimplesparte2ToolStripMenuItem.Text = "Juros Simples (parte 2)";
            this.jurosSimplesparte2ToolStripMenuItem.Click += new System.EventHandler(this.jurosSimplesparte2ToolStripMenuItem_Click);
            // 
            // jurosCompostosparte1ToolStripMenuItem
            // 
            this.jurosCompostosparte1ToolStripMenuItem.Name = "jurosCompostosparte1ToolStripMenuItem";
            this.jurosCompostosparte1ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.jurosCompostosparte1ToolStripMenuItem.Text = "Juros Compostos (parte 1)";
            this.jurosCompostosparte1ToolStripMenuItem.Click += new System.EventHandler(this.jurosCompostosparte1ToolStripMenuItem_Click);
            // 
            // jurosCompostosparte2ToolStripMenuItem
            // 
            this.jurosCompostosparte2ToolStripMenuItem.Name = "jurosCompostosparte2ToolStripMenuItem";
            this.jurosCompostosparte2ToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.jurosCompostosparte2ToolStripMenuItem.Text = "Juros Compostos (parte 2)";
            this.jurosCompostosparte2ToolStripMenuItem.Click += new System.EventHandler(this.jurosCompostosparte2ToolStripMenuItem_Click);
            // 
            // sistemaMétricoDecimalToolStripMenuItem
            // 
            this.sistemaMétricoDecimalToolStripMenuItem.Name = "sistemaMétricoDecimalToolStripMenuItem";
            this.sistemaMétricoDecimalToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.sistemaMétricoDecimalToolStripMenuItem.Text = "Sistema Métrico Decimal";
            this.sistemaMétricoDecimalToolStripMenuItem.Click += new System.EventHandler(this.sistemaMétricoDecimalToolStripMenuItem_Click);
            // 
            // médiaAritméticaToolStripMenuItem
            // 
            this.médiaAritméticaToolStripMenuItem.Name = "médiaAritméticaToolStripMenuItem";
            this.médiaAritméticaToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.médiaAritméticaToolStripMenuItem.Text = "Média Aritmética";
            this.médiaAritméticaToolStripMenuItem.Click += new System.EventHandler(this.médiaAritméticaToolStripMenuItem_Click);
            // 
            // médiaPonderadaToolStripMenuItem
            // 
            this.médiaPonderadaToolStripMenuItem.Name = "médiaPonderadaToolStripMenuItem";
            this.médiaPonderadaToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.médiaPonderadaToolStripMenuItem.Text = "Média Ponderada";
            this.médiaPonderadaToolStripMenuItem.Click += new System.EventHandler(this.médiaPonderadaToolStripMenuItem_Click);
            // 
            // médiaGeométricaToolStripMenuItem
            // 
            this.médiaGeométricaToolStripMenuItem.Name = "médiaGeométricaToolStripMenuItem";
            this.médiaGeométricaToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.médiaGeométricaToolStripMenuItem.Text = "Média Geométrica";
            this.médiaGeométricaToolStripMenuItem.Click += new System.EventHandler(this.médiaGeométricaToolStripMenuItem_Click);
            // 
            // médiaHarmônicaToolStripMenuItem
            // 
            this.médiaHarmônicaToolStripMenuItem.Name = "médiaHarmônicaToolStripMenuItem";
            this.médiaHarmônicaToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.médiaHarmônicaToolStripMenuItem.Text = "Média Harmônica";
            this.médiaHarmônicaToolStripMenuItem.Click += new System.EventHandler(this.médiaHarmônicaToolStripMenuItem_Click);
            // 
            // equaçãoDo1GrauToolStripMenuItem
            // 
            this.equaçãoDo1GrauToolStripMenuItem.Name = "equaçãoDo1GrauToolStripMenuItem";
            this.equaçãoDo1GrauToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.equaçãoDo1GrauToolStripMenuItem.Text = "Equação do 1° Grau";
            this.equaçãoDo1GrauToolStripMenuItem.Click += new System.EventHandler(this.equaçãoDo1GrauToolStripMenuItem_Click);
            // 
            // equaçãoDo2GrauToolStripMenuItem
            // 
            this.equaçãoDo2GrauToolStripMenuItem.Name = "equaçãoDo2GrauToolStripMenuItem";
            this.equaçãoDo2GrauToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.equaçãoDo2GrauToolStripMenuItem.Text = "Equação do 2° Grau";
            this.equaçãoDo2GrauToolStripMenuItem.Click += new System.EventHandler(this.equaçãoDo2GrauToolStripMenuItem_Click);
            // 
            // equaçõesIrracionaisToolStripMenuItem
            // 
            this.equaçõesIrracionaisToolStripMenuItem.Name = "equaçõesIrracionaisToolStripMenuItem";
            this.equaçõesIrracionaisToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.equaçõesIrracionaisToolStripMenuItem.Text = "Equações Irracionais";
            this.equaçõesIrracionaisToolStripMenuItem.Click += new System.EventHandler(this.equaçõesIrracionaisToolStripMenuItem_Click);
            // 
            // equaçõesBiquadradasToolStripMenuItem
            // 
            this.equaçõesBiquadradasToolStripMenuItem.Name = "equaçõesBiquadradasToolStripMenuItem";
            this.equaçõesBiquadradasToolStripMenuItem.Size = new System.Drawing.Size(404, 26);
            this.equaçõesBiquadradasToolStripMenuItem.Text = "Equações Biquadradas";
            this.equaçõesBiquadradasToolStripMenuItem.Click += new System.EventHandler(this.equaçõesBiquadradasToolStripMenuItem_Click);
            // 
            // conjuntosNuméricosToolStripMenuItem
            // 
            this.conjuntosNuméricosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.númerosNaturaisEInteirosToolStripMenuItem,
            this.númerosRacionaisToolStripMenuItem,
            this.númerosIrracionaisEReaisToolStripMenuItem,
            this.intervalosReaisOperaçõesEPropriedadesToolStripMenuItem,
            this.conjuntosNuméricosNívelBásicoToolStripMenuItem,
            this.questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem,
            this.questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem});
            this.conjuntosNuméricosToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.conjuntosNuméricosToolStripMenuItem.Name = "conjuntosNuméricosToolStripMenuItem";
            this.conjuntosNuméricosToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.conjuntosNuméricosToolStripMenuItem.Text = "Conjuntos Numéricos";
            // 
            // númerosNaturaisEInteirosToolStripMenuItem
            // 
            this.númerosNaturaisEInteirosToolStripMenuItem.Name = "númerosNaturaisEInteirosToolStripMenuItem";
            this.númerosNaturaisEInteirosToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.númerosNaturaisEInteirosToolStripMenuItem.Text = "Números Naturais e Inteiros";
            this.númerosNaturaisEInteirosToolStripMenuItem.Click += new System.EventHandler(this.númerosNaturaisEInteirosToolStripMenuItem_Click);
            // 
            // númerosRacionaisToolStripMenuItem
            // 
            this.númerosRacionaisToolStripMenuItem.Name = "númerosRacionaisToolStripMenuItem";
            this.númerosRacionaisToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.númerosRacionaisToolStripMenuItem.Text = "Números Racionais";
            this.númerosRacionaisToolStripMenuItem.Click += new System.EventHandler(this.númerosRacionaisToolStripMenuItem_Click);
            // 
            // númerosIrracionaisEReaisToolStripMenuItem
            // 
            this.númerosIrracionaisEReaisToolStripMenuItem.Name = "númerosIrracionaisEReaisToolStripMenuItem";
            this.númerosIrracionaisEReaisToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.númerosIrracionaisEReaisToolStripMenuItem.Text = "Números Irracionais e Reais";
            this.númerosIrracionaisEReaisToolStripMenuItem.Click += new System.EventHandler(this.númerosIrracionaisEReaisToolStripMenuItem_Click);
            // 
            // intervalosReaisOperaçõesEPropriedadesToolStripMenuItem
            // 
            this.intervalosReaisOperaçõesEPropriedadesToolStripMenuItem.Name = "intervalosReaisOperaçõesEPropriedadesToolStripMenuItem";
            this.intervalosReaisOperaçõesEPropriedadesToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.intervalosReaisOperaçõesEPropriedadesToolStripMenuItem.Text = "Intervalos Reais, Operações e Propriedades";
            this.intervalosReaisOperaçõesEPropriedadesToolStripMenuItem.Click += new System.EventHandler(this.intervalosReaisOperaçõesEPropriedadesToolStripMenuItem_Click);
            // 
            // conjuntosNuméricosNívelBásicoToolStripMenuItem
            // 
            this.conjuntosNuméricosNívelBásicoToolStripMenuItem.Name = "conjuntosNuméricosNívelBásicoToolStripMenuItem";
            this.conjuntosNuméricosNívelBásicoToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.conjuntosNuméricosNívelBásicoToolStripMenuItem.Text = "Questões Comentadas: Conjuntos Numéricos - Nível Básico";
            this.conjuntosNuméricosNívelBásicoToolStripMenuItem.Click += new System.EventHandler(this.conjuntosNuméricosNívelBásicoToolStripMenuItem_Click);
            // 
            // questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem
            // 
            this.questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem.Name = "questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem";
            this.questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem.Text = "Questões Comentadas: Conjuntos Numéricos - Nível Intermediário";
            this.questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem_Click);
            // 
            // questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem
            // 
            this.questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem.Name = "questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem";
            this.questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem.Size = new System.Drawing.Size(564, 26);
            this.questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem.Text = "Questões Comentadas: Conjuntos Numéricos - Nível Avançado";
            this.questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem_Click);
            // 
            // conjuntosToolStripMenuItem
            // 
            this.conjuntosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem2,
            this.subconjuntosEConjuntoDasPartesToolStripMenuItem,
            this.uniãoEIntersecçãoToolStripMenuItem,
            this.diferençaEComplementarToolStripMenuItem,
            this.questõesComentadasConjuntosNívelBásicoToolStripMenuItem,
            this.questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem,
            this.questõesComentadasConjuntosNívelAvançadoToolStripMenuItem});
            this.conjuntosToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.conjuntosToolStripMenuItem.Name = "conjuntosToolStripMenuItem";
            this.conjuntosToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.conjuntosToolStripMenuItem.Text = "Conjuntos";
            // 
            // introduçãoToolStripMenuItem2
            // 
            this.introduçãoToolStripMenuItem2.Name = "introduçãoToolStripMenuItem2";
            this.introduçãoToolStripMenuItem2.Size = new System.Drawing.Size(481, 26);
            this.introduçãoToolStripMenuItem2.Text = "Introdução";
            this.introduçãoToolStripMenuItem2.Click += new System.EventHandler(this.introduçãoToolStripMenuItem2_Click);
            // 
            // subconjuntosEConjuntoDasPartesToolStripMenuItem
            // 
            this.subconjuntosEConjuntoDasPartesToolStripMenuItem.Name = "subconjuntosEConjuntoDasPartesToolStripMenuItem";
            this.subconjuntosEConjuntoDasPartesToolStripMenuItem.Size = new System.Drawing.Size(481, 26);
            this.subconjuntosEConjuntoDasPartesToolStripMenuItem.Text = "Subconjuntos e Conjunto das Partes";
            this.subconjuntosEConjuntoDasPartesToolStripMenuItem.Click += new System.EventHandler(this.subconjuntosEConjuntoDasPartesToolStripMenuItem_Click);
            // 
            // uniãoEIntersecçãoToolStripMenuItem
            // 
            this.uniãoEIntersecçãoToolStripMenuItem.Name = "uniãoEIntersecçãoToolStripMenuItem";
            this.uniãoEIntersecçãoToolStripMenuItem.Size = new System.Drawing.Size(481, 26);
            this.uniãoEIntersecçãoToolStripMenuItem.Text = "União e Intersecção";
            this.uniãoEIntersecçãoToolStripMenuItem.Click += new System.EventHandler(this.uniãoEIntersecçãoToolStripMenuItem_Click);
            // 
            // diferençaEComplementarToolStripMenuItem
            // 
            this.diferençaEComplementarToolStripMenuItem.Name = "diferençaEComplementarToolStripMenuItem";
            this.diferençaEComplementarToolStripMenuItem.Size = new System.Drawing.Size(481, 26);
            this.diferençaEComplementarToolStripMenuItem.Text = "Diferença e Complementar";
            this.diferençaEComplementarToolStripMenuItem.Click += new System.EventHandler(this.diferençaEComplementarToolStripMenuItem_Click);
            // 
            // questõesComentadasConjuntosNívelBásicoToolStripMenuItem
            // 
            this.questõesComentadasConjuntosNívelBásicoToolStripMenuItem.Name = "questõesComentadasConjuntosNívelBásicoToolStripMenuItem";
            this.questõesComentadasConjuntosNívelBásicoToolStripMenuItem.Size = new System.Drawing.Size(481, 26);
            this.questõesComentadasConjuntosNívelBásicoToolStripMenuItem.Text = "Questões Comentadas: Conjuntos - Nível Básico";
            this.questõesComentadasConjuntosNívelBásicoToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasConjuntosNívelBásicoToolStripMenuItem_Click);
            // 
            // questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem
            // 
            this.questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem.Name = "questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem";
            this.questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem.Size = new System.Drawing.Size(481, 26);
            this.questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem.Text = "Questões Comentadas: Conjuntos - Nível Intermediário";
            this.questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem_Click);
            // 
            // questõesComentadasConjuntosNívelAvançadoToolStripMenuItem
            // 
            this.questõesComentadasConjuntosNívelAvançadoToolStripMenuItem.Name = "questõesComentadasConjuntosNívelAvançadoToolStripMenuItem";
            this.questõesComentadasConjuntosNívelAvançadoToolStripMenuItem.Size = new System.Drawing.Size(481, 26);
            this.questõesComentadasConjuntosNívelAvançadoToolStripMenuItem.Text = "Questões Comentadas: Conjuntos - Nível Avançado";
            this.questõesComentadasConjuntosNívelAvançadoToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasConjuntosNívelAvançadoToolStripMenuItem_Click);
            // 
            // funçõesToolStripMenuItem
            // 
            this.funçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.funçõesToolStripMenuItem1,
            this.funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem,
            this.inequaçãoDoPrimeiroGrauToolStripMenuItem,
            this.funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem,
            this.inequaçãoDoSegundoGrauToolStripMenuItem,
            this.funçãoModularToolStripMenuItem,
            this.funçãoExponencialToolStripMenuItem1});
            this.funçõesToolStripMenuItem.Name = "funçõesToolStripMenuItem";
            this.funçõesToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.funçõesToolStripMenuItem.Text = "Funções";
            // 
            // funçõesToolStripMenuItem1
            // 
            this.funçõesToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noçõesBásicasToolStripMenuItem,
            this.domínioContradomínioEConjuntoImagemToolStripMenuItem,
            this.estudoDoDomínioDasFunçõesReaisToolStripMenuItem,
            this.noçõesBásicasDePlanoCartesianoToolStripMenuItem,
            this.construçãoDeGráficosToolStripMenuItem,
            this.domínioEImagemAtravésDoGráficoToolStripMenuItem,
            this.reconhecendoUmaFunçãoToolStripMenuItem,
            this.analisandoOGráficoDeFunçõesToolStripMenuItem,
            this.questõesComentadasAnáliseDeGráficosToolStripMenuItem,
            this.funçãoParEFunçãoÍmparToolStripMenuItem,
            this.funçãoInjetoraFunçãoInjetivaToolStripMenuItem,
            this.funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem,
            this.funçãoBijetoraFunçãoBijetivaToolStripMenuItem,
            this.funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem,
            this.funçãoCompostaToolStripMenuItem,
            this.funçãoInversaToolStripMenuItem,
            this.questõesComentadasFunçãoInversaToolStripMenuItem});
            this.funçõesToolStripMenuItem1.ForeColor = System.Drawing.Color.Red;
            this.funçõesToolStripMenuItem1.Name = "funçõesToolStripMenuItem1";
            this.funçõesToolStripMenuItem1.Size = new System.Drawing.Size(418, 26);
            this.funçõesToolStripMenuItem1.Text = "Funções";
            // 
            // noçõesBásicasToolStripMenuItem
            // 
            this.noçõesBásicasToolStripMenuItem.Name = "noçõesBásicasToolStripMenuItem";
            this.noçõesBásicasToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.noçõesBásicasToolStripMenuItem.Text = "Noções Básicas";
            this.noçõesBásicasToolStripMenuItem.Click += new System.EventHandler(this.noçõesBásicasToolStripMenuItem_Click_1);
            // 
            // domínioContradomínioEConjuntoImagemToolStripMenuItem
            // 
            this.domínioContradomínioEConjuntoImagemToolStripMenuItem.Name = "domínioContradomínioEConjuntoImagemToolStripMenuItem";
            this.domínioContradomínioEConjuntoImagemToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.domínioContradomínioEConjuntoImagemToolStripMenuItem.Text = "Domínio, Contradomínio e Conjunto Imagem";
            this.domínioContradomínioEConjuntoImagemToolStripMenuItem.Click += new System.EventHandler(this.domínioContradomínioEConjuntoImagemToolStripMenuItem_Click);
            // 
            // estudoDoDomínioDasFunçõesReaisToolStripMenuItem
            // 
            this.estudoDoDomínioDasFunçõesReaisToolStripMenuItem.Name = "estudoDoDomínioDasFunçõesReaisToolStripMenuItem";
            this.estudoDoDomínioDasFunçõesReaisToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.estudoDoDomínioDasFunçõesReaisToolStripMenuItem.Text = "Estudo do Domínio das Funções Reais";
            this.estudoDoDomínioDasFunçõesReaisToolStripMenuItem.Click += new System.EventHandler(this.estudoDoDomínioDasFunçõesReaisToolStripMenuItem_Click);
            // 
            // noçõesBásicasDePlanoCartesianoToolStripMenuItem
            // 
            this.noçõesBásicasDePlanoCartesianoToolStripMenuItem.Name = "noçõesBásicasDePlanoCartesianoToolStripMenuItem";
            this.noçõesBásicasDePlanoCartesianoToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.noçõesBásicasDePlanoCartesianoToolStripMenuItem.Text = "Noções Básicas de Plano Cartesiano";
            this.noçõesBásicasDePlanoCartesianoToolStripMenuItem.Click += new System.EventHandler(this.noçõesBásicasDePlanoCartesianoToolStripMenuItem_Click);
            // 
            // construçãoDeGráficosToolStripMenuItem
            // 
            this.construçãoDeGráficosToolStripMenuItem.Name = "construçãoDeGráficosToolStripMenuItem";
            this.construçãoDeGráficosToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.construçãoDeGráficosToolStripMenuItem.Text = "Construção de Gráficos";
            this.construçãoDeGráficosToolStripMenuItem.Click += new System.EventHandler(this.construçãoDeGráficosToolStripMenuItem_Click);
            // 
            // domínioEImagemAtravésDoGráficoToolStripMenuItem
            // 
            this.domínioEImagemAtravésDoGráficoToolStripMenuItem.Name = "domínioEImagemAtravésDoGráficoToolStripMenuItem";
            this.domínioEImagemAtravésDoGráficoToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.domínioEImagemAtravésDoGráficoToolStripMenuItem.Text = "Domínio e Imagem Através do Gráfico";
            this.domínioEImagemAtravésDoGráficoToolStripMenuItem.Click += new System.EventHandler(this.domínioEImagemAtravésDoGráficoToolStripMenuItem_Click);
            // 
            // reconhecendoUmaFunçãoToolStripMenuItem
            // 
            this.reconhecendoUmaFunçãoToolStripMenuItem.Name = "reconhecendoUmaFunçãoToolStripMenuItem";
            this.reconhecendoUmaFunçãoToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.reconhecendoUmaFunçãoToolStripMenuItem.Text = "Reconhecendo uma Função";
            this.reconhecendoUmaFunçãoToolStripMenuItem.Click += new System.EventHandler(this.reconhecendoUmaFunçãoToolStripMenuItem_Click);
            // 
            // analisandoOGráficoDeFunçõesToolStripMenuItem
            // 
            this.analisandoOGráficoDeFunçõesToolStripMenuItem.Name = "analisandoOGráficoDeFunçõesToolStripMenuItem";
            this.analisandoOGráficoDeFunçõesToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.analisandoOGráficoDeFunçõesToolStripMenuItem.Text = "Analisando o Gráfico de Funções";
            this.analisandoOGráficoDeFunçõesToolStripMenuItem.Click += new System.EventHandler(this.analisandoOGráficoDeFunçõesToolStripMenuItem_Click);
            // 
            // questõesComentadasAnáliseDeGráficosToolStripMenuItem
            // 
            this.questõesComentadasAnáliseDeGráficosToolStripMenuItem.Name = "questõesComentadasAnáliseDeGráficosToolStripMenuItem";
            this.questõesComentadasAnáliseDeGráficosToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.questõesComentadasAnáliseDeGráficosToolStripMenuItem.Text = "Questões Comentadas: Análise de Gráficos";
            this.questõesComentadasAnáliseDeGráficosToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasAnáliseDeGráficosToolStripMenuItem_Click);
            // 
            // funçãoParEFunçãoÍmparToolStripMenuItem
            // 
            this.funçãoParEFunçãoÍmparToolStripMenuItem.Name = "funçãoParEFunçãoÍmparToolStripMenuItem";
            this.funçãoParEFunçãoÍmparToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.funçãoParEFunçãoÍmparToolStripMenuItem.Text = "Função Par e Função Ímpar";
            this.funçãoParEFunçãoÍmparToolStripMenuItem.Click += new System.EventHandler(this.funçãoParEFunçãoÍmparToolStripMenuItem_Click);
            // 
            // funçãoInjetoraFunçãoInjetivaToolStripMenuItem
            // 
            this.funçãoInjetoraFunçãoInjetivaToolStripMenuItem.Name = "funçãoInjetoraFunçãoInjetivaToolStripMenuItem";
            this.funçãoInjetoraFunçãoInjetivaToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.funçãoInjetoraFunçãoInjetivaToolStripMenuItem.Text = "Função Injetora (Função Injetiva)";
            this.funçãoInjetoraFunçãoInjetivaToolStripMenuItem.Click += new System.EventHandler(this.funçãoInjetoraFunçãoInjetivaToolStripMenuItem_Click);
            // 
            // funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem
            // 
            this.funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem.Name = "funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem";
            this.funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem.Text = "Função Sobrejetora (Função Sobrejetiva)";
            this.funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem.Click += new System.EventHandler(this.funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem_Click);
            // 
            // funçãoBijetoraFunçãoBijetivaToolStripMenuItem
            // 
            this.funçãoBijetoraFunçãoBijetivaToolStripMenuItem.Name = "funçãoBijetoraFunçãoBijetivaToolStripMenuItem";
            this.funçãoBijetoraFunçãoBijetivaToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.funçãoBijetoraFunçãoBijetivaToolStripMenuItem.Text = "Função Bijetora (Função Bijetiva)";
            this.funçãoBijetoraFunçãoBijetivaToolStripMenuItem.Click += new System.EventHandler(this.funçãoBijetoraFunçãoBijetivaToolStripMenuItem_Click);
            // 
            // funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem
            // 
            this.funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem.Name = "funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem";
            this.funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem.Text = "Função Composta (Composição de Funções) ";
            this.funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem.Click += new System.EventHandler(this.funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem_Click);
            // 
            // funçãoCompostaToolStripMenuItem
            // 
            this.funçãoCompostaToolStripMenuItem.Name = "funçãoCompostaToolStripMenuItem";
            this.funçãoCompostaToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.funçãoCompostaToolStripMenuItem.Text = "Questões Comentadas: Função Composta";
            this.funçãoCompostaToolStripMenuItem.Click += new System.EventHandler(this.funçãoCompostaToolStripMenuItem_Click);
            // 
            // funçãoInversaToolStripMenuItem
            // 
            this.funçãoInversaToolStripMenuItem.Name = "funçãoInversaToolStripMenuItem";
            this.funçãoInversaToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.funçãoInversaToolStripMenuItem.Text = "Função Inversa";
            this.funçãoInversaToolStripMenuItem.Click += new System.EventHandler(this.funçãoInversaToolStripMenuItem_Click);
            // 
            // questõesComentadasFunçãoInversaToolStripMenuItem
            // 
            this.questõesComentadasFunçãoInversaToolStripMenuItem.Name = "questõesComentadasFunçãoInversaToolStripMenuItem";
            this.questõesComentadasFunçãoInversaToolStripMenuItem.Size = new System.Drawing.Size(408, 26);
            this.questõesComentadasFunçãoInversaToolStripMenuItem.Text = "Questões Comentadas: Função Inversa";
            this.questõesComentadasFunçãoInversaToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasFunçãoInversaToolStripMenuItem_Click);
            // 
            // funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem
            // 
            this.funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conceitosIniciaisToolStripMenuItem,
            this.determinandoAFunçãoToolStripMenuItem,
            this.exercíciosToolStripMenuItem,
            this.gráficoToolStripMenuItem,
            this.coeficienteAngularECoeficienteLinearToolStripMenuItem,
            this.exercíciosToolStripMenuItem1,
            this.casosParticularesToolStripMenuItem,
            this.zeroOuRaizDaFunçãoToolStripMenuItem,
            this.estudoDoSinalToolStripMenuItem,
            this.questõesComentadasToolStripMenuItem,
            this.questõesComentadasToolStripMenuItem1});
            this.funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem.Name = "funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem";
            this.funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem.Text = "Função 1º Grau (Função Afim)";
            // 
            // conceitosIniciaisToolStripMenuItem
            // 
            this.conceitosIniciaisToolStripMenuItem.Name = "conceitosIniciaisToolStripMenuItem";
            this.conceitosIniciaisToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.conceitosIniciaisToolStripMenuItem.Text = "Conceitos Iniciais";
            this.conceitosIniciaisToolStripMenuItem.Click += new System.EventHandler(this.conceitosIniciaisToolStripMenuItem_Click);
            // 
            // determinandoAFunçãoToolStripMenuItem
            // 
            this.determinandoAFunçãoToolStripMenuItem.Name = "determinandoAFunçãoToolStripMenuItem";
            this.determinandoAFunçãoToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.determinandoAFunçãoToolStripMenuItem.Text = "Determinando a Função";
            this.determinandoAFunçãoToolStripMenuItem.Click += new System.EventHandler(this.determinandoAFunçãoToolStripMenuItem_Click);
            // 
            // exercíciosToolStripMenuItem
            // 
            this.exercíciosToolStripMenuItem.Name = "exercíciosToolStripMenuItem";
            this.exercíciosToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.exercíciosToolStripMenuItem.Text = "Exercícios";
            this.exercíciosToolStripMenuItem.Click += new System.EventHandler(this.exercíciosToolStripMenuItem_Click);
            // 
            // gráficoToolStripMenuItem
            // 
            this.gráficoToolStripMenuItem.Name = "gráficoToolStripMenuItem";
            this.gráficoToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.gráficoToolStripMenuItem.Text = "Gráfico";
            this.gráficoToolStripMenuItem.Click += new System.EventHandler(this.gráficoToolStripMenuItem_Click);
            // 
            // coeficienteAngularECoeficienteLinearToolStripMenuItem
            // 
            this.coeficienteAngularECoeficienteLinearToolStripMenuItem.Name = "coeficienteAngularECoeficienteLinearToolStripMenuItem";
            this.coeficienteAngularECoeficienteLinearToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.coeficienteAngularECoeficienteLinearToolStripMenuItem.Text = "Coeficiente Angular e Coeficiente Linear";
            this.coeficienteAngularECoeficienteLinearToolStripMenuItem.Click += new System.EventHandler(this.coeficienteAngularECoeficienteLinearToolStripMenuItem_Click);
            // 
            // exercíciosToolStripMenuItem1
            // 
            this.exercíciosToolStripMenuItem1.Name = "exercíciosToolStripMenuItem1";
            this.exercíciosToolStripMenuItem1.Size = new System.Drawing.Size(374, 26);
            this.exercíciosToolStripMenuItem1.Text = "Exercícios";
            this.exercíciosToolStripMenuItem1.Click += new System.EventHandler(this.exercíciosToolStripMenuItem1_Click);
            // 
            // casosParticularesToolStripMenuItem
            // 
            this.casosParticularesToolStripMenuItem.Name = "casosParticularesToolStripMenuItem";
            this.casosParticularesToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.casosParticularesToolStripMenuItem.Text = "Casos Particulares";
            this.casosParticularesToolStripMenuItem.Click += new System.EventHandler(this.casosParticularesToolStripMenuItem_Click);
            // 
            // zeroOuRaizDaFunçãoToolStripMenuItem
            // 
            this.zeroOuRaizDaFunçãoToolStripMenuItem.Name = "zeroOuRaizDaFunçãoToolStripMenuItem";
            this.zeroOuRaizDaFunçãoToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.zeroOuRaizDaFunçãoToolStripMenuItem.Text = "Zero ou Raiz da Função";
            this.zeroOuRaizDaFunçãoToolStripMenuItem.Click += new System.EventHandler(this.zeroOuRaizDaFunçãoToolStripMenuItem_Click);
            // 
            // estudoDoSinalToolStripMenuItem
            // 
            this.estudoDoSinalToolStripMenuItem.Name = "estudoDoSinalToolStripMenuItem";
            this.estudoDoSinalToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.estudoDoSinalToolStripMenuItem.Text = "Estudo do Sinal";
            this.estudoDoSinalToolStripMenuItem.Click += new System.EventHandler(this.estudoDoSinalToolStripMenuItem_Click);
            // 
            // questõesComentadasToolStripMenuItem
            // 
            this.questõesComentadasToolStripMenuItem.Name = "questõesComentadasToolStripMenuItem";
            this.questõesComentadasToolStripMenuItem.Size = new System.Drawing.Size(374, 26);
            this.questõesComentadasToolStripMenuItem.Text = "Questões Comentadas Parte 1";
            this.questõesComentadasToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasToolStripMenuItem_Click);
            // 
            // questõesComentadasToolStripMenuItem1
            // 
            this.questõesComentadasToolStripMenuItem1.Name = "questõesComentadasToolStripMenuItem1";
            this.questõesComentadasToolStripMenuItem1.Size = new System.Drawing.Size(374, 26);
            this.questõesComentadasToolStripMenuItem1.Text = "Questões Comentadas Parte 2";
            this.questõesComentadasToolStripMenuItem1.Click += new System.EventHandler(this.questõesComentadasToolStripMenuItem1_Click);
            // 
            // inequaçãoDoPrimeiroGrauToolStripMenuItem
            // 
            this.inequaçãoDoPrimeiroGrauToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conceitosIniciaisToolStripMenuItem2,
            this.inequaçõesSimultâneasToolStripMenuItem,
            this.inequaçãoProdutoToolStripMenuItem,
            this.inequaçãoQuocienteToolStripMenuItem,
            this.questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem});
            this.inequaçãoDoPrimeiroGrauToolStripMenuItem.Name = "inequaçãoDoPrimeiroGrauToolStripMenuItem";
            this.inequaçãoDoPrimeiroGrauToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.inequaçãoDoPrimeiroGrauToolStripMenuItem.Text = "Inequação do Primeiro Grau";
            // 
            // conceitosIniciaisToolStripMenuItem2
            // 
            this.conceitosIniciaisToolStripMenuItem2.Name = "conceitosIniciaisToolStripMenuItem2";
            this.conceitosIniciaisToolStripMenuItem2.Size = new System.Drawing.Size(456, 26);
            this.conceitosIniciaisToolStripMenuItem2.Text = "Conceitos Iniciais";
            this.conceitosIniciaisToolStripMenuItem2.Click += new System.EventHandler(this.conceitosIniciaisToolStripMenuItem2_Click);
            // 
            // inequaçõesSimultâneasToolStripMenuItem
            // 
            this.inequaçõesSimultâneasToolStripMenuItem.Name = "inequaçõesSimultâneasToolStripMenuItem";
            this.inequaçõesSimultâneasToolStripMenuItem.Size = new System.Drawing.Size(456, 26);
            this.inequaçõesSimultâneasToolStripMenuItem.Text = "Inequações Simultâneas";
            this.inequaçõesSimultâneasToolStripMenuItem.Click += new System.EventHandler(this.inequaçõesSimultâneasToolStripMenuItem_Click);
            // 
            // inequaçãoProdutoToolStripMenuItem
            // 
            this.inequaçãoProdutoToolStripMenuItem.Name = "inequaçãoProdutoToolStripMenuItem";
            this.inequaçãoProdutoToolStripMenuItem.Size = new System.Drawing.Size(456, 26);
            this.inequaçãoProdutoToolStripMenuItem.Text = "Inequação Produto";
            this.inequaçãoProdutoToolStripMenuItem.Click += new System.EventHandler(this.inequaçãoProdutoToolStripMenuItem_Click);
            // 
            // inequaçãoQuocienteToolStripMenuItem
            // 
            this.inequaçãoQuocienteToolStripMenuItem.Name = "inequaçãoQuocienteToolStripMenuItem";
            this.inequaçãoQuocienteToolStripMenuItem.Size = new System.Drawing.Size(456, 26);
            this.inequaçãoQuocienteToolStripMenuItem.Text = "Inequação Quociente";
            this.inequaçãoQuocienteToolStripMenuItem.Click += new System.EventHandler(this.inequaçãoQuocienteToolStripMenuItem_Click);
            // 
            // questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem
            // 
            this.questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem.Name = "questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem";
            this.questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem.Size = new System.Drawing.Size(456, 26);
            this.questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem.Text = "Questões Comentadas: Inequação do Primeiro Grau";
            this.questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem_Click);
            // 
            // funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem
            // 
            this.funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conceitosIniciaisToolStripMenuItem1,
            this.zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem,
            this.quantidadeDeRaízesReaisToolStripMenuItem,
            this.exercíciosToolStripMenuItem2,
            this.gráficoParábolaToolStripMenuItem,
            this.gráficoParábolaIIToolStripMenuItem,
            this.exercíciosSobreGráficoParte1ToolStripMenuItem,
            this.exercíciosSobreGráficoParte2ToolStripMenuItem,
            this.estudoDoSinalGráficoParábolaToolStripMenuItem,
            this.questõesComentadasParte1ToolStripMenuItem2,
            this.questõesComentadasParte2ToolStripMenuItem2});
            this.funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem.Name = "funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem";
            this.funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem.Text = "Função Polinomial 2º Grau (Função Quadrática)";
            // 
            // conceitosIniciaisToolStripMenuItem1
            // 
            this.conceitosIniciaisToolStripMenuItem1.Name = "conceitosIniciaisToolStripMenuItem1";
            this.conceitosIniciaisToolStripMenuItem1.Size = new System.Drawing.Size(341, 26);
            this.conceitosIniciaisToolStripMenuItem1.Text = "Conceitos Iniciais";
            this.conceitosIniciaisToolStripMenuItem1.Click += new System.EventHandler(this.conceitosIniciaisToolStripMenuItem1_Click);
            // 
            // zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem
            // 
            this.zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem.Name = "zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem";
            this.zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem.Text = "Zeros, Raízes e Fórmula de Bhaskara";
            this.zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem.Click += new System.EventHandler(this.zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem_Click);
            // 
            // quantidadeDeRaízesReaisToolStripMenuItem
            // 
            this.quantidadeDeRaízesReaisToolStripMenuItem.Name = "quantidadeDeRaízesReaisToolStripMenuItem";
            this.quantidadeDeRaízesReaisToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.quantidadeDeRaízesReaisToolStripMenuItem.Text = "Quantidade de Raízes Reais";
            this.quantidadeDeRaízesReaisToolStripMenuItem.Click += new System.EventHandler(this.quantidadeDeRaízesReaisToolStripMenuItem_Click);
            // 
            // exercíciosToolStripMenuItem2
            // 
            this.exercíciosToolStripMenuItem2.Name = "exercíciosToolStripMenuItem2";
            this.exercíciosToolStripMenuItem2.Size = new System.Drawing.Size(341, 26);
            this.exercíciosToolStripMenuItem2.Text = "Exercícios";
            this.exercíciosToolStripMenuItem2.Click += new System.EventHandler(this.exercíciosToolStripMenuItem2_Click);
            // 
            // gráficoParábolaToolStripMenuItem
            // 
            this.gráficoParábolaToolStripMenuItem.Name = "gráficoParábolaToolStripMenuItem";
            this.gráficoParábolaToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.gráficoParábolaToolStripMenuItem.Text = "Gráfico Parábola";
            this.gráficoParábolaToolStripMenuItem.Click += new System.EventHandler(this.gráficoParábolaToolStripMenuItem_Click);
            // 
            // gráficoParábolaIIToolStripMenuItem
            // 
            this.gráficoParábolaIIToolStripMenuItem.Name = "gráficoParábolaIIToolStripMenuItem";
            this.gráficoParábolaIIToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.gráficoParábolaIIToolStripMenuItem.Text = "Gráfico Parábola II";
            this.gráficoParábolaIIToolStripMenuItem.Click += new System.EventHandler(this.gráficoParábolaIIToolStripMenuItem_Click);
            // 
            // exercíciosSobreGráficoParte1ToolStripMenuItem
            // 
            this.exercíciosSobreGráficoParte1ToolStripMenuItem.Name = "exercíciosSobreGráficoParte1ToolStripMenuItem";
            this.exercíciosSobreGráficoParte1ToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.exercíciosSobreGráficoParte1ToolStripMenuItem.Text = "Exercícios sobre Gráfico - Parte 1";
            this.exercíciosSobreGráficoParte1ToolStripMenuItem.Click += new System.EventHandler(this.exercíciosSobreGráficoParte1ToolStripMenuItem_Click);
            // 
            // exercíciosSobreGráficoParte2ToolStripMenuItem
            // 
            this.exercíciosSobreGráficoParte2ToolStripMenuItem.Name = "exercíciosSobreGráficoParte2ToolStripMenuItem";
            this.exercíciosSobreGráficoParte2ToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.exercíciosSobreGráficoParte2ToolStripMenuItem.Text = "Exercícios sobre Gráfico - Parte 2";
            this.exercíciosSobreGráficoParte2ToolStripMenuItem.Click += new System.EventHandler(this.exercíciosSobreGráficoParte2ToolStripMenuItem_Click);
            // 
            // estudoDoSinalGráficoParábolaToolStripMenuItem
            // 
            this.estudoDoSinalGráficoParábolaToolStripMenuItem.Name = "estudoDoSinalGráficoParábolaToolStripMenuItem";
            this.estudoDoSinalGráficoParábolaToolStripMenuItem.Size = new System.Drawing.Size(341, 26);
            this.estudoDoSinalGráficoParábolaToolStripMenuItem.Text = "Estudo do Sinal Gráfico Parábola";
            this.estudoDoSinalGráficoParábolaToolStripMenuItem.Click += new System.EventHandler(this.estudoDoSinalGráficoParábolaToolStripMenuItem_Click);
            // 
            // questõesComentadasParte1ToolStripMenuItem2
            // 
            this.questõesComentadasParte1ToolStripMenuItem2.Name = "questõesComentadasParte1ToolStripMenuItem2";
            this.questõesComentadasParte1ToolStripMenuItem2.Size = new System.Drawing.Size(341, 26);
            this.questõesComentadasParte1ToolStripMenuItem2.Text = "Questões Comentadas Parte 1";
            this.questõesComentadasParte1ToolStripMenuItem2.Click += new System.EventHandler(this.questõesComentadasParte1ToolStripMenuItem2_Click);
            // 
            // questõesComentadasParte2ToolStripMenuItem2
            // 
            this.questõesComentadasParte2ToolStripMenuItem2.Name = "questõesComentadasParte2ToolStripMenuItem2";
            this.questõesComentadasParte2ToolStripMenuItem2.Size = new System.Drawing.Size(341, 26);
            this.questõesComentadasParte2ToolStripMenuItem2.Text = "Questões Comentadas Parte 2";
            this.questõesComentadasParte2ToolStripMenuItem2.Click += new System.EventHandler(this.questõesComentadasParte2ToolStripMenuItem2_Click);
            // 
            // inequaçãoDoSegundoGrauToolStripMenuItem
            // 
            this.inequaçãoDoSegundoGrauToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conceitosIniciaisToolStripMenuItem3,
            this.inequaçõesSimultâneasToolStripMenuItem1,
            this.inequaçãoProdutoToolStripMenuItem1,
            this.inequaçãoQuocienteToolStripMenuItem1,
            this.questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem});
            this.inequaçãoDoSegundoGrauToolStripMenuItem.Name = "inequaçãoDoSegundoGrauToolStripMenuItem";
            this.inequaçãoDoSegundoGrauToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.inequaçãoDoSegundoGrauToolStripMenuItem.Text = "Inequação do Segundo Grau";
            // 
            // conceitosIniciaisToolStripMenuItem3
            // 
            this.conceitosIniciaisToolStripMenuItem3.Name = "conceitosIniciaisToolStripMenuItem3";
            this.conceitosIniciaisToolStripMenuItem3.Size = new System.Drawing.Size(460, 26);
            this.conceitosIniciaisToolStripMenuItem3.Text = "Conceitos Iniciais";
            this.conceitosIniciaisToolStripMenuItem3.Click += new System.EventHandler(this.conceitosIniciaisToolStripMenuItem3_Click);
            // 
            // inequaçõesSimultâneasToolStripMenuItem1
            // 
            this.inequaçõesSimultâneasToolStripMenuItem1.Name = "inequaçõesSimultâneasToolStripMenuItem1";
            this.inequaçõesSimultâneasToolStripMenuItem1.Size = new System.Drawing.Size(460, 26);
            this.inequaçõesSimultâneasToolStripMenuItem1.Text = "Inequações Simultâneas";
            this.inequaçõesSimultâneasToolStripMenuItem1.Click += new System.EventHandler(this.inequaçõesSimultâneasToolStripMenuItem1_Click);
            // 
            // inequaçãoProdutoToolStripMenuItem1
            // 
            this.inequaçãoProdutoToolStripMenuItem1.Name = "inequaçãoProdutoToolStripMenuItem1";
            this.inequaçãoProdutoToolStripMenuItem1.Size = new System.Drawing.Size(460, 26);
            this.inequaçãoProdutoToolStripMenuItem1.Text = "Inequação Produto";
            this.inequaçãoProdutoToolStripMenuItem1.Click += new System.EventHandler(this.inequaçãoProdutoToolStripMenuItem1_Click);
            // 
            // inequaçãoQuocienteToolStripMenuItem1
            // 
            this.inequaçãoQuocienteToolStripMenuItem1.Name = "inequaçãoQuocienteToolStripMenuItem1";
            this.inequaçãoQuocienteToolStripMenuItem1.Size = new System.Drawing.Size(460, 26);
            this.inequaçãoQuocienteToolStripMenuItem1.Text = "Inequação Quociente";
            this.inequaçãoQuocienteToolStripMenuItem1.Click += new System.EventHandler(this.inequaçãoQuocienteToolStripMenuItem1_Click);
            // 
            // questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem
            // 
            this.questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem.Name = "questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem";
            this.questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem.Size = new System.Drawing.Size(460, 26);
            this.questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem.Text = "Questões Comentadas: Inequação do Segundo Grau";
            this.questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem_Click);
            // 
            // funçãoModularToolStripMenuItem
            // 
            this.funçãoModularToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.móduloDeUmNúmeroRealToolStripMenuItem1,
            this.propriedadesDoMóduloToolStripMenuItem,
            this.gráficoToolStripMenuItem1,
            this.equaçõesModularesToolStripMenuItem,
            this.inequaçõesModularesToolStripMenuItem,
            this.questõesComentadasFunçãoModularParte1ToolStripMenuItem,
            this.questõesComentadasFunçãoModularParte2ToolStripMenuItem});
            this.funçãoModularToolStripMenuItem.Name = "funçãoModularToolStripMenuItem";
            this.funçãoModularToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.funçãoModularToolStripMenuItem.Text = "Função Modular";
            // 
            // móduloDeUmNúmeroRealToolStripMenuItem1
            // 
            this.móduloDeUmNúmeroRealToolStripMenuItem1.Name = "móduloDeUmNúmeroRealToolStripMenuItem1";
            this.móduloDeUmNúmeroRealToolStripMenuItem1.Size = new System.Drawing.Size(435, 26);
            this.móduloDeUmNúmeroRealToolStripMenuItem1.Text = "Módulo de um Número Real";
            this.móduloDeUmNúmeroRealToolStripMenuItem1.Click += new System.EventHandler(this.móduloDeUmNúmeroRealToolStripMenuItem1_Click);
            // 
            // propriedadesDoMóduloToolStripMenuItem
            // 
            this.propriedadesDoMóduloToolStripMenuItem.Name = "propriedadesDoMóduloToolStripMenuItem";
            this.propriedadesDoMóduloToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.propriedadesDoMóduloToolStripMenuItem.Text = "Propriedades do Módulo";
            this.propriedadesDoMóduloToolStripMenuItem.Click += new System.EventHandler(this.propriedadesDoMóduloToolStripMenuItem_Click);
            // 
            // gráficoToolStripMenuItem1
            // 
            this.gráficoToolStripMenuItem1.Name = "gráficoToolStripMenuItem1";
            this.gráficoToolStripMenuItem1.Size = new System.Drawing.Size(435, 26);
            this.gráficoToolStripMenuItem1.Text = "Gráfico";
            this.gráficoToolStripMenuItem1.Click += new System.EventHandler(this.gráficoToolStripMenuItem1_Click);
            // 
            // equaçõesModularesToolStripMenuItem
            // 
            this.equaçõesModularesToolStripMenuItem.Name = "equaçõesModularesToolStripMenuItem";
            this.equaçõesModularesToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.equaçõesModularesToolStripMenuItem.Text = "Equações Modulares";
            this.equaçõesModularesToolStripMenuItem.Click += new System.EventHandler(this.equaçõesModularesToolStripMenuItem_Click);
            // 
            // inequaçõesModularesToolStripMenuItem
            // 
            this.inequaçõesModularesToolStripMenuItem.Name = "inequaçõesModularesToolStripMenuItem";
            this.inequaçõesModularesToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.inequaçõesModularesToolStripMenuItem.Text = "Inequações Modulares";
            this.inequaçõesModularesToolStripMenuItem.Click += new System.EventHandler(this.inequaçõesModularesToolStripMenuItem_Click);
            // 
            // questõesComentadasFunçãoModularParte1ToolStripMenuItem
            // 
            this.questõesComentadasFunçãoModularParte1ToolStripMenuItem.Name = "questõesComentadasFunçãoModularParte1ToolStripMenuItem";
            this.questõesComentadasFunçãoModularParte1ToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.questõesComentadasFunçãoModularParte1ToolStripMenuItem.Text = "Questões Comentadas: Função Modular - Parte 1";
            this.questõesComentadasFunçãoModularParte1ToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasFunçãoModularParte1ToolStripMenuItem_Click);
            // 
            // questõesComentadasFunçãoModularParte2ToolStripMenuItem
            // 
            this.questõesComentadasFunçãoModularParte2ToolStripMenuItem.Name = "questõesComentadasFunçãoModularParte2ToolStripMenuItem";
            this.questõesComentadasFunçãoModularParte2ToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.questõesComentadasFunçãoModularParte2ToolStripMenuItem.Text = "Questões Comentadas: Função Modular - Parte 2";
            this.questõesComentadasFunçãoModularParte2ToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasFunçãoModularParte2ToolStripMenuItem_Click);
            // 
            // funçãoExponencialToolStripMenuItem1
            // 
            this.funçãoExponencialToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revisãoDePotenciaçãoToolStripMenuItem,
            this.introduçãoToolStripMenuItem3,
            this.gráficoParte1ToolStripMenuItem,
            this.gráficoParte2ToolStripMenuItem,
            this.equaçõesExponenciaisParte1ToolStripMenuItem,
            this.equaçõesExponenciaisParte2ToolStripMenuItem,
            this.inequaçõesExponenciaisToolStripMenuItem,
            this.questõesComentadasParte1ToolStripMenuItem3,
            this.questõesComentadasParte2ToolStripMenuItem3});
            this.funçãoExponencialToolStripMenuItem1.Name = "funçãoExponencialToolStripMenuItem1";
            this.funçãoExponencialToolStripMenuItem1.Size = new System.Drawing.Size(418, 26);
            this.funçãoExponencialToolStripMenuItem1.Text = "Função Exponencial";
            // 
            // revisãoDePotenciaçãoToolStripMenuItem
            // 
            this.revisãoDePotenciaçãoToolStripMenuItem.Name = "revisãoDePotenciaçãoToolStripMenuItem";
            this.revisãoDePotenciaçãoToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.revisãoDePotenciaçãoToolStripMenuItem.Text = "Revisão de Potenciação ";
            this.revisãoDePotenciaçãoToolStripMenuItem.Click += new System.EventHandler(this.revisãoDePotenciaçãoToolStripMenuItem_Click);
            // 
            // introduçãoToolStripMenuItem3
            // 
            this.introduçãoToolStripMenuItem3.Name = "introduçãoToolStripMenuItem3";
            this.introduçãoToolStripMenuItem3.Size = new System.Drawing.Size(312, 26);
            this.introduçãoToolStripMenuItem3.Text = "Introdução";
            this.introduçãoToolStripMenuItem3.Click += new System.EventHandler(this.introduçãoToolStripMenuItem3_Click);
            // 
            // gráficoParte1ToolStripMenuItem
            // 
            this.gráficoParte1ToolStripMenuItem.Name = "gráficoParte1ToolStripMenuItem";
            this.gráficoParte1ToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.gráficoParte1ToolStripMenuItem.Text = "Gráfico - Parte 1";
            this.gráficoParte1ToolStripMenuItem.Click += new System.EventHandler(this.gráficoParte1ToolStripMenuItem_Click);
            // 
            // gráficoParte2ToolStripMenuItem
            // 
            this.gráficoParte2ToolStripMenuItem.Name = "gráficoParte2ToolStripMenuItem";
            this.gráficoParte2ToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.gráficoParte2ToolStripMenuItem.Text = "Gráfico - Parte 2";
            this.gráficoParte2ToolStripMenuItem.Click += new System.EventHandler(this.gráficoParte2ToolStripMenuItem_Click);
            // 
            // equaçõesExponenciaisParte1ToolStripMenuItem
            // 
            this.equaçõesExponenciaisParte1ToolStripMenuItem.Name = "equaçõesExponenciaisParte1ToolStripMenuItem";
            this.equaçõesExponenciaisParte1ToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.equaçõesExponenciaisParte1ToolStripMenuItem.Text = "Equações Exponenciais - Parte 1";
            this.equaçõesExponenciaisParte1ToolStripMenuItem.Click += new System.EventHandler(this.equaçõesExponenciaisParte1ToolStripMenuItem_Click);
            // 
            // equaçõesExponenciaisParte2ToolStripMenuItem
            // 
            this.equaçõesExponenciaisParte2ToolStripMenuItem.Name = "equaçõesExponenciaisParte2ToolStripMenuItem";
            this.equaçõesExponenciaisParte2ToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.equaçõesExponenciaisParte2ToolStripMenuItem.Text = "Equações Exponenciais - Parte 2";
            this.equaçõesExponenciaisParte2ToolStripMenuItem.Click += new System.EventHandler(this.equaçõesExponenciaisParte2ToolStripMenuItem_Click);
            // 
            // inequaçõesExponenciaisToolStripMenuItem
            // 
            this.inequaçõesExponenciaisToolStripMenuItem.Name = "inequaçõesExponenciaisToolStripMenuItem";
            this.inequaçõesExponenciaisToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.inequaçõesExponenciaisToolStripMenuItem.Text = "Inequações Exponenciais";
            this.inequaçõesExponenciaisToolStripMenuItem.Click += new System.EventHandler(this.inequaçõesExponenciaisToolStripMenuItem_Click);
            // 
            // questõesComentadasParte1ToolStripMenuItem3
            // 
            this.questõesComentadasParte1ToolStripMenuItem3.Name = "questõesComentadasParte1ToolStripMenuItem3";
            this.questõesComentadasParte1ToolStripMenuItem3.Size = new System.Drawing.Size(312, 26);
            this.questõesComentadasParte1ToolStripMenuItem3.Text = "Questões Comentadas - Parte 1";
            this.questõesComentadasParte1ToolStripMenuItem3.Click += new System.EventHandler(this.questõesComentadasParte1ToolStripMenuItem3_Click);
            // 
            // questõesComentadasParte2ToolStripMenuItem3
            // 
            this.questõesComentadasParte2ToolStripMenuItem3.Name = "questõesComentadasParte2ToolStripMenuItem3";
            this.questõesComentadasParte2ToolStripMenuItem3.Size = new System.Drawing.Size(312, 26);
            this.questõesComentadasParte2ToolStripMenuItem3.Text = "Questões Comentadas - Parte 2";
            this.questõesComentadasParte2ToolStripMenuItem3.Click += new System.EventHandler(this.questõesComentadasParte2ToolStripMenuItem3_Click);
            // 
            // QuartoMenuItem
            // 
            this.QuartoMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.progressãoAritméticaPAToolStripMenuItem,
            this.progressãoGeométricaPGToolStripMenuItem});
            this.QuartoMenuItem.ForeColor = System.Drawing.Color.Red;
            this.QuartoMenuItem.Name = "QuartoMenuItem";
            this.QuartoMenuItem.Size = new System.Drawing.Size(332, 26);
            this.QuartoMenuItem.Text = "Sequências";
            // 
            // progressãoAritméticaPAToolStripMenuItem
            // 
            this.progressãoAritméticaPAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem,
            this.termoGeralToolStripMenuItem,
            this.termoGeralExercíciosToolStripMenuItem,
            this.notaçõesEspeciaisToolStripMenuItem,
            this.interpolaçãoDeMeiosAritméticosToolStripMenuItem,
            this.somaDosTermosToolStripMenuItem,
            this.questõesComentadasParte1ToolStripMenuItem,
            this.questõesComentadasParte2ToolStripMenuItem});
            this.progressãoAritméticaPAToolStripMenuItem.Name = "progressãoAritméticaPAToolStripMenuItem";
            this.progressãoAritméticaPAToolStripMenuItem.Size = new System.Drawing.Size(291, 26);
            this.progressãoAritméticaPAToolStripMenuItem.Text = "Progressão Aritmética (P.A.)";
            // 
            // introduçãoToolStripMenuItem
            // 
            this.introduçãoToolStripMenuItem.Name = "introduçãoToolStripMenuItem";
            this.introduçãoToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.introduçãoToolStripMenuItem.Text = "Introdução";
            this.introduçãoToolStripMenuItem.Click += new System.EventHandler(this.introduçãoToolStripMenuItem_Click);
            // 
            // termoGeralToolStripMenuItem
            // 
            this.termoGeralToolStripMenuItem.Name = "termoGeralToolStripMenuItem";
            this.termoGeralToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.termoGeralToolStripMenuItem.Text = "Termo Geral";
            this.termoGeralToolStripMenuItem.Click += new System.EventHandler(this.termoGeralToolStripMenuItem_Click);
            // 
            // termoGeralExercíciosToolStripMenuItem
            // 
            this.termoGeralExercíciosToolStripMenuItem.Name = "termoGeralExercíciosToolStripMenuItem";
            this.termoGeralExercíciosToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.termoGeralExercíciosToolStripMenuItem.Text = "Termo Geral - Exercícios";
            this.termoGeralExercíciosToolStripMenuItem.Click += new System.EventHandler(this.termoGeralExercíciosToolStripMenuItem_Click);
            // 
            // notaçõesEspeciaisToolStripMenuItem
            // 
            this.notaçõesEspeciaisToolStripMenuItem.Name = "notaçõesEspeciaisToolStripMenuItem";
            this.notaçõesEspeciaisToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.notaçõesEspeciaisToolStripMenuItem.Text = "Notações Especiais";
            this.notaçõesEspeciaisToolStripMenuItem.Click += new System.EventHandler(this.notaçõesEspeciaisToolStripMenuItem_Click);
            // 
            // interpolaçãoDeMeiosAritméticosToolStripMenuItem
            // 
            this.interpolaçãoDeMeiosAritméticosToolStripMenuItem.Name = "interpolaçãoDeMeiosAritméticosToolStripMenuItem";
            this.interpolaçãoDeMeiosAritméticosToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.interpolaçãoDeMeiosAritméticosToolStripMenuItem.Text = "Interpolação de Meios Aritméticos";
            this.interpolaçãoDeMeiosAritméticosToolStripMenuItem.Click += new System.EventHandler(this.interpolaçãoDeMeiosAritméticosToolStripMenuItem_Click);
            // 
            // somaDosTermosToolStripMenuItem
            // 
            this.somaDosTermosToolStripMenuItem.Name = "somaDosTermosToolStripMenuItem";
            this.somaDosTermosToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.somaDosTermosToolStripMenuItem.Text = "Soma dos Termos";
            this.somaDosTermosToolStripMenuItem.Click += new System.EventHandler(this.somaDosTermosToolStripMenuItem_Click);
            // 
            // questõesComentadasParte1ToolStripMenuItem
            // 
            this.questõesComentadasParte1ToolStripMenuItem.Name = "questõesComentadasParte1ToolStripMenuItem";
            this.questõesComentadasParte1ToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.questõesComentadasParte1ToolStripMenuItem.Text = "Questões Comentadas - Parte 1";
            this.questõesComentadasParte1ToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasParte1ToolStripMenuItem_Click);
            // 
            // questõesComentadasParte2ToolStripMenuItem
            // 
            this.questõesComentadasParte2ToolStripMenuItem.Name = "questõesComentadasParte2ToolStripMenuItem";
            this.questõesComentadasParte2ToolStripMenuItem.Size = new System.Drawing.Size(334, 26);
            this.questõesComentadasParte2ToolStripMenuItem.Text = "Questões Comentadas - Parte 2";
            this.questõesComentadasParte2ToolStripMenuItem.Click += new System.EventHandler(this.questõesComentadasParte2ToolStripMenuItem_Click);
            // 
            // progressãoGeométricaPGToolStripMenuItem
            // 
            this.progressãoGeométricaPGToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem1,
            this.termoGeralToolStripMenuItem1,
            this.termoGeralExercíciosToolStripMenuItem1,
            this.notaçõesEspeciaisToolStripMenuItem1,
            this.interpolaçãoDeMeiosGeométricosToolStripMenuItem,
            this.somaDosTermosDeUmaPGFinitaToolStripMenuItem,
            this.somaDosTermosDeUmaPGInfinitaToolStripMenuItem,
            this.exercíciosDePAEPGSimultaneamenteToolStripMenuItem,
            this.questõesComentadasParte1ToolStripMenuItem1,
            this.questõesComentadasParte2ToolStripMenuItem1});
            this.progressãoGeométricaPGToolStripMenuItem.Name = "progressãoGeométricaPGToolStripMenuItem";
            this.progressãoGeométricaPGToolStripMenuItem.Size = new System.Drawing.Size(291, 26);
            this.progressãoGeométricaPGToolStripMenuItem.Text = "Progressão Geométrica (P.G.)";
            // 
            // introduçãoToolStripMenuItem1
            // 
            this.introduçãoToolStripMenuItem1.Name = "introduçãoToolStripMenuItem1";
            this.introduçãoToolStripMenuItem1.Size = new System.Drawing.Size(366, 26);
            this.introduçãoToolStripMenuItem1.Text = "Introdução ";
            this.introduçãoToolStripMenuItem1.Click += new System.EventHandler(this.introduçãoToolStripMenuItem1_Click);
            // 
            // termoGeralToolStripMenuItem1
            // 
            this.termoGeralToolStripMenuItem1.Name = "termoGeralToolStripMenuItem1";
            this.termoGeralToolStripMenuItem1.Size = new System.Drawing.Size(366, 26);
            this.termoGeralToolStripMenuItem1.Text = "Termo Geral";
            this.termoGeralToolStripMenuItem1.Click += new System.EventHandler(this.termoGeralToolStripMenuItem1_Click);
            // 
            // termoGeralExercíciosToolStripMenuItem1
            // 
            this.termoGeralExercíciosToolStripMenuItem1.Name = "termoGeralExercíciosToolStripMenuItem1";
            this.termoGeralExercíciosToolStripMenuItem1.Size = new System.Drawing.Size(366, 26);
            this.termoGeralExercíciosToolStripMenuItem1.Text = "Termo Geral - Exercícios";
            this.termoGeralExercíciosToolStripMenuItem1.Click += new System.EventHandler(this.termoGeralExercíciosToolStripMenuItem1_Click);
            // 
            // notaçõesEspeciaisToolStripMenuItem1
            // 
            this.notaçõesEspeciaisToolStripMenuItem1.Name = "notaçõesEspeciaisToolStripMenuItem1";
            this.notaçõesEspeciaisToolStripMenuItem1.Size = new System.Drawing.Size(366, 26);
            this.notaçõesEspeciaisToolStripMenuItem1.Text = "Notações Especiais";
            this.notaçõesEspeciaisToolStripMenuItem1.Click += new System.EventHandler(this.notaçõesEspeciaisToolStripMenuItem1_Click);
            // 
            // interpolaçãoDeMeiosGeométricosToolStripMenuItem
            // 
            this.interpolaçãoDeMeiosGeométricosToolStripMenuItem.Name = "interpolaçãoDeMeiosGeométricosToolStripMenuItem";
            this.interpolaçãoDeMeiosGeométricosToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.interpolaçãoDeMeiosGeométricosToolStripMenuItem.Text = "Interpolação de Meios Geométricos";
            this.interpolaçãoDeMeiosGeométricosToolStripMenuItem.Click += new System.EventHandler(this.interpolaçãoDeMeiosGeométricosToolStripMenuItem_Click);
            // 
            // somaDosTermosDeUmaPGFinitaToolStripMenuItem
            // 
            this.somaDosTermosDeUmaPGFinitaToolStripMenuItem.Name = "somaDosTermosDeUmaPGFinitaToolStripMenuItem";
            this.somaDosTermosDeUmaPGFinitaToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.somaDosTermosDeUmaPGFinitaToolStripMenuItem.Text = "Soma dos Termos de uma PG Finita";
            this.somaDosTermosDeUmaPGFinitaToolStripMenuItem.Click += new System.EventHandler(this.somaDosTermosDeUmaPGFinitaToolStripMenuItem_Click);
            // 
            // somaDosTermosDeUmaPGInfinitaToolStripMenuItem
            // 
            this.somaDosTermosDeUmaPGInfinitaToolStripMenuItem.Name = "somaDosTermosDeUmaPGInfinitaToolStripMenuItem";
            this.somaDosTermosDeUmaPGInfinitaToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.somaDosTermosDeUmaPGInfinitaToolStripMenuItem.Text = "Soma dos Termos de uma PG Infinita";
            this.somaDosTermosDeUmaPGInfinitaToolStripMenuItem.Click += new System.EventHandler(this.somaDosTermosDeUmaPGInfinitaToolStripMenuItem_Click);
            // 
            // exercíciosDePAEPGSimultaneamenteToolStripMenuItem
            // 
            this.exercíciosDePAEPGSimultaneamenteToolStripMenuItem.Name = "exercíciosDePAEPGSimultaneamenteToolStripMenuItem";
            this.exercíciosDePAEPGSimultaneamenteToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.exercíciosDePAEPGSimultaneamenteToolStripMenuItem.Text = "Exercícios de PA e PG Simultaneamente";
            this.exercíciosDePAEPGSimultaneamenteToolStripMenuItem.Click += new System.EventHandler(this.exercíciosDePAEPGSimultaneamenteToolStripMenuItem_Click);
            // 
            // questõesComentadasParte1ToolStripMenuItem1
            // 
            this.questõesComentadasParte1ToolStripMenuItem1.Name = "questõesComentadasParte1ToolStripMenuItem1";
            this.questõesComentadasParte1ToolStripMenuItem1.Size = new System.Drawing.Size(366, 26);
            this.questõesComentadasParte1ToolStripMenuItem1.Text = "Questões Comentadas - Parte 1";
            this.questõesComentadasParte1ToolStripMenuItem1.Click += new System.EventHandler(this.questõesComentadasParte1ToolStripMenuItem1_Click);
            // 
            // questõesComentadasParte2ToolStripMenuItem1
            // 
            this.questõesComentadasParte2ToolStripMenuItem1.Name = "questõesComentadasParte2ToolStripMenuItem1";
            this.questõesComentadasParte2ToolStripMenuItem1.Size = new System.Drawing.Size(366, 26);
            this.questõesComentadasParte2ToolStripMenuItem1.Text = "Questões Comentadas - Parte 2";
            this.questõesComentadasParte2ToolStripMenuItem1.Click += new System.EventHandler(this.questõesComentadasParte2ToolStripMenuItem1_Click);
            // 
            // geometriaPlanaToolStripMenuItem
            // 
            this.geometriaPlanaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte1ToolStripMenuItem1,
            this.parte2ToolStripMenuItem1});
            this.geometriaPlanaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.geometriaPlanaToolStripMenuItem.Name = "geometriaPlanaToolStripMenuItem";
            this.geometriaPlanaToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.geometriaPlanaToolStripMenuItem.Text = "Geometria Plana ";
            // 
            // parte1ToolStripMenuItem1
            // 
            this.parte1ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoÂngulosToolStripMenuItem,
            this.paralelismoEntreRetasNoPlanoToolStripMenuItem,
            this.polígonosToolStripMenuItem,
            this.polígonosRegularesToolStripMenuItem,
            this.introduçãoAosTriângulosToolStripMenuItem,
            this.classificaçãoDosTriângulosToolStripMenuItem,
            this.pontosNotáveisDoTriânguloToolStripMenuItem,
            this.áreaDeTriângulosToolStripMenuItem,
            this.semelhançaDeTriângulosToolStripMenuItem,
            this.triânguloRetânguloRelaçõesMétricasToolStripMenuItem,
            this.triânguloRetânguloExercíciosToolStripMenuItem,
            this.triânguloEquiláteroToolStripMenuItem,
            this.teoremaDeTalesToolStripMenuItem,
            this.quadriláterosParalelogramoToolStripMenuItem,
            this.quadriláterosRetânguloToolStripMenuItem});
            this.parte1ToolStripMenuItem1.Name = "parte1ToolStripMenuItem1";
            this.parte1ToolStripMenuItem1.Size = new System.Drawing.Size(152, 26);
            this.parte1ToolStripMenuItem1.Text = "Parte 1";
            // 
            // introduçãoÂngulosToolStripMenuItem
            // 
            this.introduçãoÂngulosToolStripMenuItem.Name = "introduçãoÂngulosToolStripMenuItem";
            this.introduçãoÂngulosToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.introduçãoÂngulosToolStripMenuItem.Text = "Introdução - Ângulos";
            this.introduçãoÂngulosToolStripMenuItem.Click += new System.EventHandler(this.introduçãoÂngulosToolStripMenuItem_Click);
            // 
            // paralelismoEntreRetasNoPlanoToolStripMenuItem
            // 
            this.paralelismoEntreRetasNoPlanoToolStripMenuItem.Name = "paralelismoEntreRetasNoPlanoToolStripMenuItem";
            this.paralelismoEntreRetasNoPlanoToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.paralelismoEntreRetasNoPlanoToolStripMenuItem.Text = "Paralelismo Entre Retas no Plano";
            this.paralelismoEntreRetasNoPlanoToolStripMenuItem.Click += new System.EventHandler(this.paralelismoEntreRetasNoPlanoToolStripMenuItem_Click);
            // 
            // polígonosToolStripMenuItem
            // 
            this.polígonosToolStripMenuItem.Name = "polígonosToolStripMenuItem";
            this.polígonosToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.polígonosToolStripMenuItem.Text = "Polígonos";
            this.polígonosToolStripMenuItem.Click += new System.EventHandler(this.polígonosToolStripMenuItem_Click);
            // 
            // polígonosRegularesToolStripMenuItem
            // 
            this.polígonosRegularesToolStripMenuItem.Name = "polígonosRegularesToolStripMenuItem";
            this.polígonosRegularesToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.polígonosRegularesToolStripMenuItem.Text = "Polígonos Regulares";
            this.polígonosRegularesToolStripMenuItem.Click += new System.EventHandler(this.polígonosRegularesToolStripMenuItem_Click);
            // 
            // introduçãoAosTriângulosToolStripMenuItem
            // 
            this.introduçãoAosTriângulosToolStripMenuItem.Name = "introduçãoAosTriângulosToolStripMenuItem";
            this.introduçãoAosTriângulosToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.introduçãoAosTriângulosToolStripMenuItem.Text = "Introdução aos Triângulos";
            this.introduçãoAosTriângulosToolStripMenuItem.Click += new System.EventHandler(this.introduçãoAosTriângulosToolStripMenuItem_Click);
            // 
            // classificaçãoDosTriângulosToolStripMenuItem
            // 
            this.classificaçãoDosTriângulosToolStripMenuItem.Name = "classificaçãoDosTriângulosToolStripMenuItem";
            this.classificaçãoDosTriângulosToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.classificaçãoDosTriângulosToolStripMenuItem.Text = "Classificação dos Triângulos";
            this.classificaçãoDosTriângulosToolStripMenuItem.Click += new System.EventHandler(this.classificaçãoDosTriângulosToolStripMenuItem_Click);
            // 
            // pontosNotáveisDoTriânguloToolStripMenuItem
            // 
            this.pontosNotáveisDoTriânguloToolStripMenuItem.Name = "pontosNotáveisDoTriânguloToolStripMenuItem";
            this.pontosNotáveisDoTriânguloToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.pontosNotáveisDoTriânguloToolStripMenuItem.Text = "Pontos Notáveis do Triângulo";
            this.pontosNotáveisDoTriânguloToolStripMenuItem.Click += new System.EventHandler(this.pontosNotáveisDoTriânguloToolStripMenuItem_Click);
            // 
            // áreaDeTriângulosToolStripMenuItem
            // 
            this.áreaDeTriângulosToolStripMenuItem.Name = "áreaDeTriângulosToolStripMenuItem";
            this.áreaDeTriângulosToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.áreaDeTriângulosToolStripMenuItem.Text = "Área de Triângulos";
            this.áreaDeTriângulosToolStripMenuItem.Click += new System.EventHandler(this.áreaDeTriângulosToolStripMenuItem_Click);
            // 
            // semelhançaDeTriângulosToolStripMenuItem
            // 
            this.semelhançaDeTriângulosToolStripMenuItem.Name = "semelhançaDeTriângulosToolStripMenuItem";
            this.semelhançaDeTriângulosToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.semelhançaDeTriângulosToolStripMenuItem.Text = "Semelhança de Triângulos";
            this.semelhançaDeTriângulosToolStripMenuItem.Click += new System.EventHandler(this.semelhançaDeTriângulosToolStripMenuItem_Click);
            // 
            // triânguloRetânguloRelaçõesMétricasToolStripMenuItem
            // 
            this.triânguloRetânguloRelaçõesMétricasToolStripMenuItem.Name = "triânguloRetânguloRelaçõesMétricasToolStripMenuItem";
            this.triânguloRetânguloRelaçõesMétricasToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.triânguloRetânguloRelaçõesMétricasToolStripMenuItem.Text = "Triângulo Retângulo - Relações Métricas";
            this.triânguloRetânguloRelaçõesMétricasToolStripMenuItem.Click += new System.EventHandler(this.triânguloRetânguloRelaçõesMétricasToolStripMenuItem_Click);
            // 
            // triânguloRetânguloExercíciosToolStripMenuItem
            // 
            this.triânguloRetânguloExercíciosToolStripMenuItem.Name = "triânguloRetânguloExercíciosToolStripMenuItem";
            this.triânguloRetânguloExercíciosToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.triânguloRetânguloExercíciosToolStripMenuItem.Text = "Triângulo Retângulo - Exercícios";
            this.triânguloRetânguloExercíciosToolStripMenuItem.Click += new System.EventHandler(this.triânguloRetânguloExercíciosToolStripMenuItem_Click);
            // 
            // triânguloEquiláteroToolStripMenuItem
            // 
            this.triânguloEquiláteroToolStripMenuItem.Name = "triânguloEquiláteroToolStripMenuItem";
            this.triânguloEquiláteroToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.triânguloEquiláteroToolStripMenuItem.Text = "Triângulo Equilátero";
            this.triânguloEquiláteroToolStripMenuItem.Click += new System.EventHandler(this.triânguloEquiláteroToolStripMenuItem_Click);
            // 
            // teoremaDeTalesToolStripMenuItem
            // 
            this.teoremaDeTalesToolStripMenuItem.Name = "teoremaDeTalesToolStripMenuItem";
            this.teoremaDeTalesToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.teoremaDeTalesToolStripMenuItem.Text = "Teorema de Tales";
            this.teoremaDeTalesToolStripMenuItem.Click += new System.EventHandler(this.teoremaDeTalesToolStripMenuItem_Click);
            // 
            // quadriláterosParalelogramoToolStripMenuItem
            // 
            this.quadriláterosParalelogramoToolStripMenuItem.Name = "quadriláterosParalelogramoToolStripMenuItem";
            this.quadriláterosParalelogramoToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.quadriláterosParalelogramoToolStripMenuItem.Text = "Quadriláteros - Paralelogramo";
            this.quadriláterosParalelogramoToolStripMenuItem.Click += new System.EventHandler(this.quadriláterosParalelogramoToolStripMenuItem_Click);
            // 
            // quadriláterosRetânguloToolStripMenuItem
            // 
            this.quadriláterosRetânguloToolStripMenuItem.Name = "quadriláterosRetânguloToolStripMenuItem";
            this.quadriláterosRetânguloToolStripMenuItem.Size = new System.Drawing.Size(373, 26);
            this.quadriláterosRetânguloToolStripMenuItem.Text = "Quadriláteros - Retângulo";
            this.quadriláterosRetânguloToolStripMenuItem.Click += new System.EventHandler(this.quadriláterosRetânguloToolStripMenuItem_Click);
            // 
            // parte2ToolStripMenuItem1
            // 
            this.parte2ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quadriláterosLosangoToolStripMenuItem,
            this.quadriláterosQuadradoToolStripMenuItem,
            this.quadriláterosTrapézioToolStripMenuItem,
            this.hexágonoRegularToolStripMenuItem,
            this.circunferênciaConceitosIniciaisToolStripMenuItem,
            this.relaçõesMétricasNaCircunferênciaToolStripMenuItem,
            this.circunferênciaPotênciaDePontoToolStripMenuItem,
            this.ângulosNaCircunferênciaParte1ToolStripMenuItem,
            this.ângulosNaCircunferênciaParte2ToolStripMenuItem,
            this.comprimentoDaCircunferênciaToolStripMenuItem,
            this.áreaDoCírculoESetorCircularToolStripMenuItem,
            this.áreaDeSegmentoECoroaCircularesToolStripMenuItem,
            this.áreasSemelhantesToolStripMenuItem});
            this.parte2ToolStripMenuItem1.Name = "parte2ToolStripMenuItem1";
            this.parte2ToolStripMenuItem1.Size = new System.Drawing.Size(152, 26);
            this.parte2ToolStripMenuItem1.Text = "Parte 2";
            // 
            // quadriláterosLosangoToolStripMenuItem
            // 
            this.quadriláterosLosangoToolStripMenuItem.Name = "quadriláterosLosangoToolStripMenuItem";
            this.quadriláterosLosangoToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.quadriláterosLosangoToolStripMenuItem.Text = "Quadriláteros - Losango";
            this.quadriláterosLosangoToolStripMenuItem.Click += new System.EventHandler(this.quadriláterosLosangoToolStripMenuItem_Click);
            // 
            // quadriláterosQuadradoToolStripMenuItem
            // 
            this.quadriláterosQuadradoToolStripMenuItem.Name = "quadriláterosQuadradoToolStripMenuItem";
            this.quadriláterosQuadradoToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.quadriláterosQuadradoToolStripMenuItem.Text = "Quadriláteros - Quadrado";
            this.quadriláterosQuadradoToolStripMenuItem.Click += new System.EventHandler(this.quadriláterosQuadradoToolStripMenuItem_Click);
            // 
            // quadriláterosTrapézioToolStripMenuItem
            // 
            this.quadriláterosTrapézioToolStripMenuItem.Name = "quadriláterosTrapézioToolStripMenuItem";
            this.quadriláterosTrapézioToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.quadriláterosTrapézioToolStripMenuItem.Text = "Quadriláteros Trapézio";
            this.quadriláterosTrapézioToolStripMenuItem.Click += new System.EventHandler(this.quadriláterosTrapézioToolStripMenuItem_Click);
            // 
            // hexágonoRegularToolStripMenuItem
            // 
            this.hexágonoRegularToolStripMenuItem.Name = "hexágonoRegularToolStripMenuItem";
            this.hexágonoRegularToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.hexágonoRegularToolStripMenuItem.Text = "Hexágono Regular";
            this.hexágonoRegularToolStripMenuItem.Click += new System.EventHandler(this.hexágonoRegularToolStripMenuItem_Click);
            // 
            // circunferênciaConceitosIniciaisToolStripMenuItem
            // 
            this.circunferênciaConceitosIniciaisToolStripMenuItem.Name = "circunferênciaConceitosIniciaisToolStripMenuItem";
            this.circunferênciaConceitosIniciaisToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.circunferênciaConceitosIniciaisToolStripMenuItem.Text = "Circunferência - Conceitos Iniciais";
            this.circunferênciaConceitosIniciaisToolStripMenuItem.Click += new System.EventHandler(this.circunferênciaConceitosIniciaisToolStripMenuItem_Click);
            // 
            // relaçõesMétricasNaCircunferênciaToolStripMenuItem
            // 
            this.relaçõesMétricasNaCircunferênciaToolStripMenuItem.Name = "relaçõesMétricasNaCircunferênciaToolStripMenuItem";
            this.relaçõesMétricasNaCircunferênciaToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.relaçõesMétricasNaCircunferênciaToolStripMenuItem.Text = "Relações Métricas na Circunferência";
            this.relaçõesMétricasNaCircunferênciaToolStripMenuItem.Click += new System.EventHandler(this.relaçõesMétricasNaCircunferênciaToolStripMenuItem_Click);
            // 
            // circunferênciaPotênciaDePontoToolStripMenuItem
            // 
            this.circunferênciaPotênciaDePontoToolStripMenuItem.Name = "circunferênciaPotênciaDePontoToolStripMenuItem";
            this.circunferênciaPotênciaDePontoToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.circunferênciaPotênciaDePontoToolStripMenuItem.Text = "Circunferência - Potência de Ponto";
            this.circunferênciaPotênciaDePontoToolStripMenuItem.Click += new System.EventHandler(this.circunferênciaPotênciaDePontoToolStripMenuItem_Click);
            // 
            // ângulosNaCircunferênciaParte1ToolStripMenuItem
            // 
            this.ângulosNaCircunferênciaParte1ToolStripMenuItem.Name = "ângulosNaCircunferênciaParte1ToolStripMenuItem";
            this.ângulosNaCircunferênciaParte1ToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.ângulosNaCircunferênciaParte1ToolStripMenuItem.Text = "Ângulos na Circunferência - Parte 1";
            this.ângulosNaCircunferênciaParte1ToolStripMenuItem.Click += new System.EventHandler(this.ângulosNaCircunferênciaParte1ToolStripMenuItem_Click);
            // 
            // ângulosNaCircunferênciaParte2ToolStripMenuItem
            // 
            this.ângulosNaCircunferênciaParte2ToolStripMenuItem.Name = "ângulosNaCircunferênciaParte2ToolStripMenuItem";
            this.ângulosNaCircunferênciaParte2ToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.ângulosNaCircunferênciaParte2ToolStripMenuItem.Text = "Ângulos na Circunferência - Parte 2";
            this.ângulosNaCircunferênciaParte2ToolStripMenuItem.Click += new System.EventHandler(this.ângulosNaCircunferênciaParte2ToolStripMenuItem_Click);
            // 
            // comprimentoDaCircunferênciaToolStripMenuItem
            // 
            this.comprimentoDaCircunferênciaToolStripMenuItem.Name = "comprimentoDaCircunferênciaToolStripMenuItem";
            this.comprimentoDaCircunferênciaToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.comprimentoDaCircunferênciaToolStripMenuItem.Text = "Comprimento da Circunferência";
            this.comprimentoDaCircunferênciaToolStripMenuItem.Click += new System.EventHandler(this.comprimentoDaCircunferênciaToolStripMenuItem_Click);
            // 
            // áreaDoCírculoESetorCircularToolStripMenuItem
            // 
            this.áreaDoCírculoESetorCircularToolStripMenuItem.Name = "áreaDoCírculoESetorCircularToolStripMenuItem";
            this.áreaDoCírculoESetorCircularToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.áreaDoCírculoESetorCircularToolStripMenuItem.Text = "Área do Círculo e Setor Circular";
            this.áreaDoCírculoESetorCircularToolStripMenuItem.Click += new System.EventHandler(this.áreaDoCírculoESetorCircularToolStripMenuItem_Click);
            // 
            // áreaDeSegmentoECoroaCircularesToolStripMenuItem
            // 
            this.áreaDeSegmentoECoroaCircularesToolStripMenuItem.Name = "áreaDeSegmentoECoroaCircularesToolStripMenuItem";
            this.áreaDeSegmentoECoroaCircularesToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.áreaDeSegmentoECoroaCircularesToolStripMenuItem.Text = "Área de Segmento e Coroa Circulares";
            this.áreaDeSegmentoECoroaCircularesToolStripMenuItem.Click += new System.EventHandler(this.áreaDeSegmentoECoroaCircularesToolStripMenuItem_Click);
            // 
            // áreasSemelhantesToolStripMenuItem
            // 
            this.áreasSemelhantesToolStripMenuItem.Name = "áreasSemelhantesToolStripMenuItem";
            this.áreasSemelhantesToolStripMenuItem.Size = new System.Drawing.Size(353, 26);
            this.áreasSemelhantesToolStripMenuItem.Text = "Áreas Semelhantes";
            this.áreasSemelhantesToolStripMenuItem.Click += new System.EventHandler(this.áreasSemelhantesToolStripMenuItem_Click);
            // 
            // trigonometriaToolStripMenuItem
            // 
            this.trigonometriaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.triânguloRetânguloToolStripMenuItem,
            this.trigonometriaNoTriânguloRetânguloToolStripMenuItem,
            this.triânguloQualquerLeiDosSenosECossenosToolStripMenuItem,
            this.leiDosSenosECossenosToolStripMenuItem,
            this.cicloTrigonométricoToolStripMenuItem,
            this.exercíciosResolvidosCicloTrigonométricoToolStripMenuItem,
            this.relaçõesTrigonométricasToolStripMenuItem,
            this.operaçõesComArcosToolStripMenuItem,
            this.exercíciosResolvidosOperaçõesComArcosToolStripMenuItem,
            this.equaçõesTrigonométricasToolStripMenuItem,
            this.inequaçõesTrigonométricasToolStripMenuItem,
            this.funçãoSenoECossenoToolStripMenuItem,
            this.funçãoTgCotgSecECossecToolStripMenuItem,
            this.exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem});
            this.trigonometriaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.trigonometriaToolStripMenuItem.Name = "trigonometriaToolStripMenuItem";
            this.trigonometriaToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.trigonometriaToolStripMenuItem.Text = "Trigonometria ";
            // 
            // triânguloRetânguloToolStripMenuItem
            // 
            this.triânguloRetânguloToolStripMenuItem.Name = "triânguloRetânguloToolStripMenuItem";
            this.triânguloRetânguloToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.triânguloRetânguloToolStripMenuItem.Text = "Triângulo Retângulo";
            this.triânguloRetânguloToolStripMenuItem.Click += new System.EventHandler(this.triânguloRetânguloToolStripMenuItem_Click);
            // 
            // trigonometriaNoTriânguloRetânguloToolStripMenuItem
            // 
            this.trigonometriaNoTriânguloRetânguloToolStripMenuItem.Name = "trigonometriaNoTriânguloRetânguloToolStripMenuItem";
            this.trigonometriaNoTriânguloRetânguloToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.trigonometriaNoTriânguloRetânguloToolStripMenuItem.Text = "Trigonometria no Triângulo Retângulo";
            this.trigonometriaNoTriânguloRetânguloToolStripMenuItem.Click += new System.EventHandler(this.trigonometriaNoTriânguloRetânguloToolStripMenuItem_Click);
            // 
            // triânguloQualquerLeiDosSenosECossenosToolStripMenuItem
            // 
            this.triânguloQualquerLeiDosSenosECossenosToolStripMenuItem.Name = "triânguloQualquerLeiDosSenosECossenosToolStripMenuItem";
            this.triânguloQualquerLeiDosSenosECossenosToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.triânguloQualquerLeiDosSenosECossenosToolStripMenuItem.Text = "Triângulo Qualquer (Lei dos Senos e Cossenos)";
            this.triânguloQualquerLeiDosSenosECossenosToolStripMenuItem.Click += new System.EventHandler(this.triânguloQualquerLeiDosSenosECossenosToolStripMenuItem_Click);
            // 
            // leiDosSenosECossenosToolStripMenuItem
            // 
            this.leiDosSenosECossenosToolStripMenuItem.Name = "leiDosSenosECossenosToolStripMenuItem";
            this.leiDosSenosECossenosToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.leiDosSenosECossenosToolStripMenuItem.Text = "Exercícios Resolvidos - Lei dos Senos e Cossenos";
            this.leiDosSenosECossenosToolStripMenuItem.Click += new System.EventHandler(this.leiDosSenosECossenosToolStripMenuItem_Click);
            // 
            // cicloTrigonométricoToolStripMenuItem
            // 
            this.cicloTrigonométricoToolStripMenuItem.Name = "cicloTrigonométricoToolStripMenuItem";
            this.cicloTrigonométricoToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.cicloTrigonométricoToolStripMenuItem.Text = "Ciclo Trigonométrico";
            this.cicloTrigonométricoToolStripMenuItem.Click += new System.EventHandler(this.cicloTrigonométricoToolStripMenuItem_Click);
            // 
            // exercíciosResolvidosCicloTrigonométricoToolStripMenuItem
            // 
            this.exercíciosResolvidosCicloTrigonométricoToolStripMenuItem.Name = "exercíciosResolvidosCicloTrigonométricoToolStripMenuItem";
            this.exercíciosResolvidosCicloTrigonométricoToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.exercíciosResolvidosCicloTrigonométricoToolStripMenuItem.Text = "Exercícios Resolvidos - Ciclo Trigonométrico";
            this.exercíciosResolvidosCicloTrigonométricoToolStripMenuItem.Click += new System.EventHandler(this.exercíciosResolvidosCicloTrigonométricoToolStripMenuItem_Click);
            // 
            // relaçõesTrigonométricasToolStripMenuItem
            // 
            this.relaçõesTrigonométricasToolStripMenuItem.Name = "relaçõesTrigonométricasToolStripMenuItem";
            this.relaçõesTrigonométricasToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.relaçõesTrigonométricasToolStripMenuItem.Text = "Relações Trigonométricas";
            this.relaçõesTrigonométricasToolStripMenuItem.Click += new System.EventHandler(this.relaçõesTrigonométricasToolStripMenuItem_Click);
            // 
            // operaçõesComArcosToolStripMenuItem
            // 
            this.operaçõesComArcosToolStripMenuItem.Name = "operaçõesComArcosToolStripMenuItem";
            this.operaçõesComArcosToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.operaçõesComArcosToolStripMenuItem.Text = "Operações com Arcos";
            this.operaçõesComArcosToolStripMenuItem.Click += new System.EventHandler(this.operaçõesComArcosToolStripMenuItem_Click);
            // 
            // exercíciosResolvidosOperaçõesComArcosToolStripMenuItem
            // 
            this.exercíciosResolvidosOperaçõesComArcosToolStripMenuItem.Name = "exercíciosResolvidosOperaçõesComArcosToolStripMenuItem";
            this.exercíciosResolvidosOperaçõesComArcosToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.exercíciosResolvidosOperaçõesComArcosToolStripMenuItem.Text = "Exercícios Resolvidos - Operações com Arcos";
            this.exercíciosResolvidosOperaçõesComArcosToolStripMenuItem.Click += new System.EventHandler(this.exercíciosResolvidosOperaçõesComArcosToolStripMenuItem_Click);
            // 
            // equaçõesTrigonométricasToolStripMenuItem
            // 
            this.equaçõesTrigonométricasToolStripMenuItem.Name = "equaçõesTrigonométricasToolStripMenuItem";
            this.equaçõesTrigonométricasToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.equaçõesTrigonométricasToolStripMenuItem.Text = "Equações Trigonométricas";
            this.equaçõesTrigonométricasToolStripMenuItem.Click += new System.EventHandler(this.equaçõesTrigonométricasToolStripMenuItem_Click);
            // 
            // inequaçõesTrigonométricasToolStripMenuItem
            // 
            this.inequaçõesTrigonométricasToolStripMenuItem.Name = "inequaçõesTrigonométricasToolStripMenuItem";
            this.inequaçõesTrigonométricasToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.inequaçõesTrigonométricasToolStripMenuItem.Text = "Inequações Trigonométricas";
            this.inequaçõesTrigonométricasToolStripMenuItem.Click += new System.EventHandler(this.inequaçõesTrigonométricasToolStripMenuItem_Click);
            // 
            // funçãoSenoECossenoToolStripMenuItem
            // 
            this.funçãoSenoECossenoToolStripMenuItem.Name = "funçãoSenoECossenoToolStripMenuItem";
            this.funçãoSenoECossenoToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.funçãoSenoECossenoToolStripMenuItem.Text = "Função Seno e Cosseno";
            this.funçãoSenoECossenoToolStripMenuItem.Click += new System.EventHandler(this.funçãoSenoECossenoToolStripMenuItem_Click);
            // 
            // funçãoTgCotgSecECossecToolStripMenuItem
            // 
            this.funçãoTgCotgSecECossecToolStripMenuItem.Name = "funçãoTgCotgSecECossecToolStripMenuItem";
            this.funçãoTgCotgSecECossecToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.funçãoTgCotgSecECossecToolStripMenuItem.Text = "Função Tg, Cotg, Sec e Cossec";
            this.funçãoTgCotgSecECossecToolStripMenuItem.Click += new System.EventHandler(this.funçãoTgCotgSecECossecToolStripMenuItem_Click);
            // 
            // exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem
            // 
            this.exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem.Name = "exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem";
            this.exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem.Size = new System.Drawing.Size(435, 26);
            this.exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem.Text = "Exercícios Resolvidos - Funções Trigonométricas";
            this.exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem.Click += new System.EventHandler(this.exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem_Click);
            // 
            // geometriaEspacialToolStripMenuItem
            // 
            this.geometriaEspacialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tetraedroEOctaedroToolStripMenuItem,
            this.posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem,
            this.prismasIToolStripMenuItem,
            this.prismasIIToolStripMenuItem,
            this.exercíciosIToolStripMenuItem,
            this.pirâmidesIToolStripMenuItem,
            this.pirâmidesIIToolStripMenuItem,
            this.exercíciosIIToolStripMenuItem,
            this.cilindroToolStripMenuItem,
            this.coneToolStripMenuItem,
            this.esferaToolStripMenuItem,
            this.troncosToolStripMenuItem,
            this.exercíciosIIIToolStripMenuItem,
            this.exercíciosIVToolStripMenuItem,
            this.exercíciosVToolStripMenuItem});
            this.geometriaEspacialToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.geometriaEspacialToolStripMenuItem.Name = "geometriaEspacialToolStripMenuItem";
            this.geometriaEspacialToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.geometriaEspacialToolStripMenuItem.Text = "Geometria Espacial ";
            // 
            // tetraedroEOctaedroToolStripMenuItem
            // 
            this.tetraedroEOctaedroToolStripMenuItem.Name = "tetraedroEOctaedroToolStripMenuItem";
            this.tetraedroEOctaedroToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.tetraedroEOctaedroToolStripMenuItem.Text = "Tetraedro e Octaedro";
            // 
            // posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem
            // 
            this.posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem.Name = "posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem";
            this.posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem.Text = "Posição, Estruturas e Relação de Euler";
            this.posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem.Click += new System.EventHandler(this.posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem_Click);
            // 
            // prismasIToolStripMenuItem
            // 
            this.prismasIToolStripMenuItem.Name = "prismasIToolStripMenuItem";
            this.prismasIToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.prismasIToolStripMenuItem.Text = "Prismas I";
            this.prismasIToolStripMenuItem.Click += new System.EventHandler(this.prismasIToolStripMenuItem_Click);
            // 
            // prismasIIToolStripMenuItem
            // 
            this.prismasIIToolStripMenuItem.Name = "prismasIIToolStripMenuItem";
            this.prismasIIToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.prismasIIToolStripMenuItem.Text = "Prismas II";
            this.prismasIIToolStripMenuItem.Click += new System.EventHandler(this.prismasIIToolStripMenuItem_Click);
            // 
            // exercíciosIToolStripMenuItem
            // 
            this.exercíciosIToolStripMenuItem.Name = "exercíciosIToolStripMenuItem";
            this.exercíciosIToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.exercíciosIToolStripMenuItem.Text = "Exercícios I";
            this.exercíciosIToolStripMenuItem.Click += new System.EventHandler(this.exercíciosIToolStripMenuItem_Click);
            // 
            // pirâmidesIToolStripMenuItem
            // 
            this.pirâmidesIToolStripMenuItem.Name = "pirâmidesIToolStripMenuItem";
            this.pirâmidesIToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.pirâmidesIToolStripMenuItem.Text = "Pirâmides I";
            this.pirâmidesIToolStripMenuItem.Click += new System.EventHandler(this.pirâmidesIToolStripMenuItem_Click);
            // 
            // pirâmidesIIToolStripMenuItem
            // 
            this.pirâmidesIIToolStripMenuItem.Name = "pirâmidesIIToolStripMenuItem";
            this.pirâmidesIIToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.pirâmidesIIToolStripMenuItem.Text = "Pirâmides II";
            this.pirâmidesIIToolStripMenuItem.Click += new System.EventHandler(this.pirâmidesIIToolStripMenuItem_Click);
            // 
            // exercíciosIIToolStripMenuItem
            // 
            this.exercíciosIIToolStripMenuItem.Name = "exercíciosIIToolStripMenuItem";
            this.exercíciosIIToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.exercíciosIIToolStripMenuItem.Text = "Exercícios II";
            this.exercíciosIIToolStripMenuItem.Click += new System.EventHandler(this.exercíciosIIToolStripMenuItem_Click);
            // 
            // cilindroToolStripMenuItem
            // 
            this.cilindroToolStripMenuItem.Name = "cilindroToolStripMenuItem";
            this.cilindroToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.cilindroToolStripMenuItem.Text = "Cilindro";
            this.cilindroToolStripMenuItem.Click += new System.EventHandler(this.cilindroToolStripMenuItem_Click);
            // 
            // coneToolStripMenuItem
            // 
            this.coneToolStripMenuItem.Name = "coneToolStripMenuItem";
            this.coneToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.coneToolStripMenuItem.Text = "Cone";
            this.coneToolStripMenuItem.Click += new System.EventHandler(this.coneToolStripMenuItem_Click);
            // 
            // esferaToolStripMenuItem
            // 
            this.esferaToolStripMenuItem.Name = "esferaToolStripMenuItem";
            this.esferaToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.esferaToolStripMenuItem.Text = "Esfera";
            this.esferaToolStripMenuItem.Click += new System.EventHandler(this.esferaToolStripMenuItem_Click);
            // 
            // troncosToolStripMenuItem
            // 
            this.troncosToolStripMenuItem.Name = "troncosToolStripMenuItem";
            this.troncosToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.troncosToolStripMenuItem.Text = "Troncos";
            this.troncosToolStripMenuItem.Click += new System.EventHandler(this.troncosToolStripMenuItem_Click);
            // 
            // exercíciosIIIToolStripMenuItem
            // 
            this.exercíciosIIIToolStripMenuItem.Name = "exercíciosIIIToolStripMenuItem";
            this.exercíciosIIIToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.exercíciosIIIToolStripMenuItem.Text = "Exercícios III";
            this.exercíciosIIIToolStripMenuItem.Click += new System.EventHandler(this.exercíciosIIIToolStripMenuItem_Click);
            // 
            // exercíciosIVToolStripMenuItem
            // 
            this.exercíciosIVToolStripMenuItem.Name = "exercíciosIVToolStripMenuItem";
            this.exercíciosIVToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.exercíciosIVToolStripMenuItem.Text = "Exercícios IV";
            this.exercíciosIVToolStripMenuItem.Click += new System.EventHandler(this.exercíciosIVToolStripMenuItem_Click);
            // 
            // exercíciosVToolStripMenuItem
            // 
            this.exercíciosVToolStripMenuItem.Name = "exercíciosVToolStripMenuItem";
            this.exercíciosVToolStripMenuItem.Size = new System.Drawing.Size(352, 26);
            this.exercíciosVToolStripMenuItem.Text = "Exercícios V";
            this.exercíciosVToolStripMenuItem.Click += new System.EventHandler(this.exercíciosVToolStripMenuItem_Click);
            // 
            // geometriaAnalíticaToolStripMenuItem
            // 
            this.geometriaAnalíticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.distânciaEntre2PontosEPontoMédioToolStripMenuItem,
            this.baricentroEÁreaDeTriânguloToolStripMenuItem,
            this.exercicioToolStripMenuItem,
            this.condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem,
            this.estudoDaRetaIToolStripMenuItem,
            this.estudoDaRetaIIToolStripMenuItem,
            this.exercícioEstudoDaRetaToolStripMenuItem,
            this.estudoDaCircunferênciaToolStripMenuItem,
            this.estudoDaCircunferênciaExercícioToolStripMenuItem});
            this.geometriaAnalíticaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.geometriaAnalíticaToolStripMenuItem.Name = "geometriaAnalíticaToolStripMenuItem";
            this.geometriaAnalíticaToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.geometriaAnalíticaToolStripMenuItem.Text = "Geometria Analítica ";
            // 
            // distânciaEntre2PontosEPontoMédioToolStripMenuItem
            // 
            this.distânciaEntre2PontosEPontoMédioToolStripMenuItem.Name = "distânciaEntre2PontosEPontoMédioToolStripMenuItem";
            this.distânciaEntre2PontosEPontoMédioToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.distânciaEntre2PontosEPontoMédioToolStripMenuItem.Text = "Distância entre 2 pontos e Ponto médio";
            this.distânciaEntre2PontosEPontoMédioToolStripMenuItem.Click += new System.EventHandler(this.distânciaEntre2PontosEPontoMédioToolStripMenuItem_Click);
            // 
            // baricentroEÁreaDeTriânguloToolStripMenuItem
            // 
            this.baricentroEÁreaDeTriânguloToolStripMenuItem.Name = "baricentroEÁreaDeTriânguloToolStripMenuItem";
            this.baricentroEÁreaDeTriânguloToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.baricentroEÁreaDeTriânguloToolStripMenuItem.Text = "Baricentro e Área de Triângulo";
            this.baricentroEÁreaDeTriânguloToolStripMenuItem.Click += new System.EventHandler(this.baricentroEÁreaDeTriânguloToolStripMenuItem_Click);
            // 
            // exercicioToolStripMenuItem
            // 
            this.exercicioToolStripMenuItem.Name = "exercicioToolStripMenuItem";
            this.exercicioToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.exercicioToolStripMenuItem.Text = "Exercicio";
            this.exercicioToolStripMenuItem.Click += new System.EventHandler(this.exercicioToolStripMenuItem_Click);
            // 
            // condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem
            // 
            this.condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem.Name = "condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem";
            this.condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem.Text = "Condições de alinhamento de 3 pontos e Equação geral da reta";
            this.condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem.Click += new System.EventHandler(this.condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem_Click);
            // 
            // estudoDaRetaIToolStripMenuItem
            // 
            this.estudoDaRetaIToolStripMenuItem.Name = "estudoDaRetaIToolStripMenuItem";
            this.estudoDaRetaIToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.estudoDaRetaIToolStripMenuItem.Text = "Estudo da Reta I";
            this.estudoDaRetaIToolStripMenuItem.Click += new System.EventHandler(this.estudoDaRetaIToolStripMenuItem_Click);
            // 
            // estudoDaRetaIIToolStripMenuItem
            // 
            this.estudoDaRetaIIToolStripMenuItem.Name = "estudoDaRetaIIToolStripMenuItem";
            this.estudoDaRetaIIToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.estudoDaRetaIIToolStripMenuItem.Text = "Estudo da Reta II";
            this.estudoDaRetaIIToolStripMenuItem.Click += new System.EventHandler(this.estudoDaRetaIIToolStripMenuItem_Click);
            // 
            // exercícioEstudoDaRetaToolStripMenuItem
            // 
            this.exercícioEstudoDaRetaToolStripMenuItem.Name = "exercícioEstudoDaRetaToolStripMenuItem";
            this.exercícioEstudoDaRetaToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.exercícioEstudoDaRetaToolStripMenuItem.Text = "Exercício - Estudo da Reta";
            this.exercícioEstudoDaRetaToolStripMenuItem.Click += new System.EventHandler(this.exercícioEstudoDaRetaToolStripMenuItem_Click);
            // 
            // estudoDaCircunferênciaToolStripMenuItem
            // 
            this.estudoDaCircunferênciaToolStripMenuItem.Name = "estudoDaCircunferênciaToolStripMenuItem";
            this.estudoDaCircunferênciaToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.estudoDaCircunferênciaToolStripMenuItem.Text = "Estudo da Circunferência";
            this.estudoDaCircunferênciaToolStripMenuItem.Click += new System.EventHandler(this.estudoDaCircunferênciaToolStripMenuItem_Click);
            // 
            // estudoDaCircunferênciaExercícioToolStripMenuItem
            // 
            this.estudoDaCircunferênciaExercícioToolStripMenuItem.Name = "estudoDaCircunferênciaExercícioToolStripMenuItem";
            this.estudoDaCircunferênciaExercícioToolStripMenuItem.Size = new System.Drawing.Size(540, 26);
            this.estudoDaCircunferênciaExercícioToolStripMenuItem.Text = "Estudo da Circunferência: Exercício";
            this.estudoDaCircunferênciaExercícioToolStripMenuItem.Click += new System.EventHandler(this.estudoDaCircunferênciaExercícioToolStripMenuItem_Click);
            // 
            // númerosComplexosToolStripMenuItem
            // 
            this.númerosComplexosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unidadeImagináriaToolStripMenuItem,
            this.formaAlgébricaToolStripMenuItem,
            this.operaçõesNaFormaAlgébricaIToolStripMenuItem,
            this.operaçõesNaFormaAlgébricaIIToolStripMenuItem,
            this.potênciasDaUnidadeImagináriaiToolStripMenuItem});
            this.númerosComplexosToolStripMenuItem.Name = "númerosComplexosToolStripMenuItem";
            this.númerosComplexosToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.númerosComplexosToolStripMenuItem.Text = "Números Complexos ";
            // 
            // unidadeImagináriaToolStripMenuItem
            // 
            this.unidadeImagináriaToolStripMenuItem.Name = "unidadeImagináriaToolStripMenuItem";
            this.unidadeImagináriaToolStripMenuItem.Size = new System.Drawing.Size(336, 26);
            this.unidadeImagináriaToolStripMenuItem.Text = "Unidade Imaginária";
            this.unidadeImagináriaToolStripMenuItem.Click += new System.EventHandler(this.unidadeImagináriaToolStripMenuItem_Click);
            // 
            // formaAlgébricaToolStripMenuItem
            // 
            this.formaAlgébricaToolStripMenuItem.Name = "formaAlgébricaToolStripMenuItem";
            this.formaAlgébricaToolStripMenuItem.Size = new System.Drawing.Size(336, 26);
            this.formaAlgébricaToolStripMenuItem.Text = "Forma Algébrica";
            this.formaAlgébricaToolStripMenuItem.Click += new System.EventHandler(this.formaAlgébricaToolStripMenuItem_Click);
            // 
            // operaçõesNaFormaAlgébricaIToolStripMenuItem
            // 
            this.operaçõesNaFormaAlgébricaIToolStripMenuItem.Name = "operaçõesNaFormaAlgébricaIToolStripMenuItem";
            this.operaçõesNaFormaAlgébricaIToolStripMenuItem.Size = new System.Drawing.Size(336, 26);
            this.operaçõesNaFormaAlgébricaIToolStripMenuItem.Text = "Operações na Forma Algébrica I";
            this.operaçõesNaFormaAlgébricaIToolStripMenuItem.Click += new System.EventHandler(this.operaçõesNaFormaAlgébricaIToolStripMenuItem_Click);
            // 
            // operaçõesNaFormaAlgébricaIIToolStripMenuItem
            // 
            this.operaçõesNaFormaAlgébricaIIToolStripMenuItem.Name = "operaçõesNaFormaAlgébricaIIToolStripMenuItem";
            this.operaçõesNaFormaAlgébricaIIToolStripMenuItem.Size = new System.Drawing.Size(336, 26);
            this.operaçõesNaFormaAlgébricaIIToolStripMenuItem.Text = "Operações na Forma Algébrica II";
            this.operaçõesNaFormaAlgébricaIIToolStripMenuItem.Click += new System.EventHandler(this.operaçõesNaFormaAlgébricaIIToolStripMenuItem_Click);
            // 
            // potênciasDaUnidadeImagináriaiToolStripMenuItem
            // 
            this.potênciasDaUnidadeImagináriaiToolStripMenuItem.Name = "potênciasDaUnidadeImagináriaiToolStripMenuItem";
            this.potênciasDaUnidadeImagináriaiToolStripMenuItem.Size = new System.Drawing.Size(336, 26);
            this.potênciasDaUnidadeImagináriaiToolStripMenuItem.Text = "Potências da unidade Imaginária \"i\"";
            this.potênciasDaUnidadeImagináriaiToolStripMenuItem.Click += new System.EventHandler(this.potênciasDaUnidadeImagináriaiToolStripMenuItem_Click);
            // 
            // polinômiosEEquaçõesPolinomiaisToolStripMenuItem
            // 
            this.polinômiosEEquaçõesPolinomiaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.polinômiosIToolStripMenuItem,
            this.polinômiosIIToolStripMenuItem});
            this.polinômiosEEquaçõesPolinomiaisToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.polinômiosEEquaçõesPolinomiaisToolStripMenuItem.Name = "polinômiosEEquaçõesPolinomiaisToolStripMenuItem";
            this.polinômiosEEquaçõesPolinomiaisToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.polinômiosEEquaçõesPolinomiaisToolStripMenuItem.Text = "Polinômios e Equações Polinomiais";
            // 
            // polinômiosIToolStripMenuItem
            // 
            this.polinômiosIToolStripMenuItem.Name = "polinômiosIToolStripMenuItem";
            this.polinômiosIToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.polinômiosIToolStripMenuItem.Text = "Polinômios I";
            this.polinômiosIToolStripMenuItem.Click += new System.EventHandler(this.polinômiosIToolStripMenuItem_Click);
            // 
            // polinômiosIIToolStripMenuItem
            // 
            this.polinômiosIIToolStripMenuItem.Name = "polinômiosIIToolStripMenuItem";
            this.polinômiosIIToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.polinômiosIIToolStripMenuItem.Text = "Polinômios II";
            this.polinômiosIIToolStripMenuItem.Click += new System.EventHandler(this.polinômiosIIToolStripMenuItem_Click);
            // 
            // TerceiroMenuItem
            // 
            this.TerceiroMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.binômioDeNewtonToolStripMenuItem,
            this.coeficientesBinomiaisETriânguloDePascalToolStripMenuItem});
            this.TerceiroMenuItem.Name = "TerceiroMenuItem";
            this.TerceiroMenuItem.Size = new System.Drawing.Size(332, 26);
            this.TerceiroMenuItem.Text = "Binômio de Newton";
            // 
            // binômioDeNewtonToolStripMenuItem
            // 
            this.binômioDeNewtonToolStripMenuItem.Name = "binômioDeNewtonToolStripMenuItem";
            this.binômioDeNewtonToolStripMenuItem.Size = new System.Drawing.Size(401, 26);
            this.binômioDeNewtonToolStripMenuItem.Text = "Binômio de Newton";
            this.binômioDeNewtonToolStripMenuItem.Click += new System.EventHandler(this.binômioDeNewtonToolStripMenuItem_Click);
            // 
            // coeficientesBinomiaisETriânguloDePascalToolStripMenuItem
            // 
            this.coeficientesBinomiaisETriânguloDePascalToolStripMenuItem.Name = "coeficientesBinomiaisETriânguloDePascalToolStripMenuItem";
            this.coeficientesBinomiaisETriânguloDePascalToolStripMenuItem.Size = new System.Drawing.Size(401, 26);
            this.coeficientesBinomiaisETriânguloDePascalToolStripMenuItem.Text = "Coeficientes Binomiais e Triângulo de Pascal";
            this.coeficientesBinomiaisETriânguloDePascalToolStripMenuItem.Click += new System.EventHandler(this.coeficientesBinomiaisETriânguloDePascalToolStripMenuItem_Click);
            // 
            // SegundoMenuItem
            // 
            this.SegundoMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.princípioFundamentalDaContagemToolStripMenuItem1,
            this.princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem,
            this.fatorialEPermutaçãoToolStripMenuItem,
            this.permutaçãoNaVideolocadoraToolStripMenuItem,
            this.arranjoECombinaçãoToolStripMenuItem,
            this.conceitoDeCombinaçãoEArranjoToolStripMenuItem,
            this.análiseCombinatóriaquestãoFácilToolStripMenuItem,
            this.comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem,
            this.análiseCombinatóriacomPegadinhaToolStripMenuItem});
            this.SegundoMenuItem.ForeColor = System.Drawing.Color.Red;
            this.SegundoMenuItem.Name = "SegundoMenuItem";
            this.SegundoMenuItem.Size = new System.Drawing.Size(332, 26);
            this.SegundoMenuItem.Text = "Análise Combinatória";
            // 
            // princípioFundamentalDaContagemToolStripMenuItem1
            // 
            this.princípioFundamentalDaContagemToolStripMenuItem1.Name = "princípioFundamentalDaContagemToolStripMenuItem1";
            this.princípioFundamentalDaContagemToolStripMenuItem1.Size = new System.Drawing.Size(565, 26);
            this.princípioFundamentalDaContagemToolStripMenuItem1.Text = "Princípio Fundamental da Contagem";
            this.princípioFundamentalDaContagemToolStripMenuItem1.Click += new System.EventHandler(this.princípioFundamentalDaContagemToolStripMenuItem1_Click);
            // 
            // princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem
            // 
            this.princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem.Name = "princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem";
            this.princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem.Text = "Princípio Fundamental da Contagem e Notas das Escolas de Samba";
            this.princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem.Click += new System.EventHandler(this.princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem_Click);
            // 
            // fatorialEPermutaçãoToolStripMenuItem
            // 
            this.fatorialEPermutaçãoToolStripMenuItem.Name = "fatorialEPermutaçãoToolStripMenuItem";
            this.fatorialEPermutaçãoToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.fatorialEPermutaçãoToolStripMenuItem.Text = "Fatorial e Permutação";
            this.fatorialEPermutaçãoToolStripMenuItem.Click += new System.EventHandler(this.fatorialEPermutaçãoToolStripMenuItem_Click);
            // 
            // permutaçãoNaVideolocadoraToolStripMenuItem
            // 
            this.permutaçãoNaVideolocadoraToolStripMenuItem.Name = "permutaçãoNaVideolocadoraToolStripMenuItem";
            this.permutaçãoNaVideolocadoraToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.permutaçãoNaVideolocadoraToolStripMenuItem.Text = "Permutação na Videolocadora";
            this.permutaçãoNaVideolocadoraToolStripMenuItem.Click += new System.EventHandler(this.permutaçãoNaVideolocadoraToolStripMenuItem_Click);
            // 
            // arranjoECombinaçãoToolStripMenuItem
            // 
            this.arranjoECombinaçãoToolStripMenuItem.Name = "arranjoECombinaçãoToolStripMenuItem";
            this.arranjoECombinaçãoToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.arranjoECombinaçãoToolStripMenuItem.Text = "Arranjo e Combinação";
            this.arranjoECombinaçãoToolStripMenuItem.Click += new System.EventHandler(this.arranjoECombinaçãoToolStripMenuItem_Click);
            // 
            // conceitoDeCombinaçãoEArranjoToolStripMenuItem
            // 
            this.conceitoDeCombinaçãoEArranjoToolStripMenuItem.Name = "conceitoDeCombinaçãoEArranjoToolStripMenuItem";
            this.conceitoDeCombinaçãoEArranjoToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.conceitoDeCombinaçãoEArranjoToolStripMenuItem.Text = "Conceito de Combinação e Arranjo ";
            this.conceitoDeCombinaçãoEArranjoToolStripMenuItem.Click += new System.EventHandler(this.conceitoDeCombinaçãoEArranjoToolStripMenuItem_Click);
            // 
            // análiseCombinatóriaquestãoFácilToolStripMenuItem
            // 
            this.análiseCombinatóriaquestãoFácilToolStripMenuItem.Name = "análiseCombinatóriaquestãoFácilToolStripMenuItem";
            this.análiseCombinatóriaquestãoFácilToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.análiseCombinatóriaquestãoFácilToolStripMenuItem.Text = "Análise Combinatória (questão fácil)";
            this.análiseCombinatóriaquestãoFácilToolStripMenuItem.Click += new System.EventHandler(this.análiseCombinatóriaquestãoFácilToolStripMenuItem_Click);
            // 
            // comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem
            // 
            this.comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem.Name = "comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem";
            this.comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem.Text = "Comparação das Chances de Ganhar na Loteria ";
            this.comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem.Click += new System.EventHandler(this.comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem_Click);
            // 
            // análiseCombinatóriacomPegadinhaToolStripMenuItem
            // 
            this.análiseCombinatóriacomPegadinhaToolStripMenuItem.Name = "análiseCombinatóriacomPegadinhaToolStripMenuItem";
            this.análiseCombinatóriacomPegadinhaToolStripMenuItem.Size = new System.Drawing.Size(565, 26);
            this.análiseCombinatóriacomPegadinhaToolStripMenuItem.Text = "Análise Combinatória (com pegadinha)";
            this.análiseCombinatóriacomPegadinhaToolStripMenuItem.Click += new System.EventHandler(this.análiseCombinatóriacomPegadinhaToolStripMenuItem_Click);
            // 
            // probabilidadeToolStripMenuItem1
            // 
            this.probabilidadeToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte1ToolStripMenuItem2,
            this.parte2ToolStripMenuItem2,
            this.parte3ToolStripMenuItem,
            this.parte4ToolStripMenuItem,
            this.parte5ToolStripMenuItem,
            this.parte6ToolStripMenuItem});
            this.probabilidadeToolStripMenuItem1.Name = "probabilidadeToolStripMenuItem1";
            this.probabilidadeToolStripMenuItem1.Size = new System.Drawing.Size(332, 26);
            this.probabilidadeToolStripMenuItem1.Text = "Probabilidade ";
            // 
            // parte1ToolStripMenuItem2
            // 
            this.parte1ToolStripMenuItem2.Name = "parte1ToolStripMenuItem2";
            this.parte1ToolStripMenuItem2.Size = new System.Drawing.Size(131, 26);
            this.parte1ToolStripMenuItem2.Text = "Parte 1";
            this.parte1ToolStripMenuItem2.Click += new System.EventHandler(this.parte1ToolStripMenuItem2_Click);
            // 
            // parte2ToolStripMenuItem2
            // 
            this.parte2ToolStripMenuItem2.Name = "parte2ToolStripMenuItem2";
            this.parte2ToolStripMenuItem2.Size = new System.Drawing.Size(131, 26);
            this.parte2ToolStripMenuItem2.Text = "Parte 2";
            this.parte2ToolStripMenuItem2.Click += new System.EventHandler(this.parte2ToolStripMenuItem2_Click);
            // 
            // parte3ToolStripMenuItem
            // 
            this.parte3ToolStripMenuItem.Name = "parte3ToolStripMenuItem";
            this.parte3ToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.parte3ToolStripMenuItem.Text = "Parte 3";
            this.parte3ToolStripMenuItem.Click += new System.EventHandler(this.parte3ToolStripMenuItem_Click);
            // 
            // parte4ToolStripMenuItem
            // 
            this.parte4ToolStripMenuItem.Name = "parte4ToolStripMenuItem";
            this.parte4ToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.parte4ToolStripMenuItem.Text = "Parte 4";
            this.parte4ToolStripMenuItem.Click += new System.EventHandler(this.parte4ToolStripMenuItem_Click);
            // 
            // parte5ToolStripMenuItem
            // 
            this.parte5ToolStripMenuItem.Name = "parte5ToolStripMenuItem";
            this.parte5ToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.parte5ToolStripMenuItem.Text = "Parte 5";
            this.parte5ToolStripMenuItem.Click += new System.EventHandler(this.parte5ToolStripMenuItem_Click);
            // 
            // parte6ToolStripMenuItem
            // 
            this.parte6ToolStripMenuItem.Name = "parte6ToolStripMenuItem";
            this.parte6ToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.parte6ToolStripMenuItem.Text = "Parte 6";
            this.parte6ToolStripMenuItem.Click += new System.EventHandler(this.parte6ToolStripMenuItem_Click);
            // 
            // logaritmoToolStripMenuItem
            // 
            this.logaritmoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoParte1ToolStripMenuItem,
            this.introduçãoParte2ToolStripMenuItem,
            this.condiçãoDeExistênciaToolStripMenuItem,
            this.consequênciasDaDefiniçãoToolStripMenuItem,
            this.propriedadesOperatóriasToolStripMenuItem,
            this.propriedadesOperatóriasExercíciosToolStripMenuItem,
            this.cálculoDeLogaritmosToolStripMenuItem,
            this.mudançaDeBaseToolStripMenuItem,
            this.logaritmoEAsEquaçõesExponenciaisToolStripMenuItem,
            this.aplicaçõesToolStripMenuItem,
            this.funçãoLogarítmicaEGráficoToolStripMenuItem,
            this.equaçõesLogarítmicasParte1ToolStripMenuItem,
            this.equaçõesLogarítmicasParte2ToolStripMenuItem,
            this.inequaçõesLogarítmicasToolStripMenuItem,
            this.logaritmoQuestõesComentadasToolStripMenuItem,
            this.funçãoLogarítmicaQuestõesComentadasToolStripMenuItem,
            this.equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem});
            this.logaritmoToolStripMenuItem.Name = "logaritmoToolStripMenuItem";
            this.logaritmoToolStripMenuItem.Size = new System.Drawing.Size(332, 26);
            this.logaritmoToolStripMenuItem.Text = "Logaritmo";
            // 
            // introduçãoParte1ToolStripMenuItem
            // 
            this.introduçãoParte1ToolStripMenuItem.Name = "introduçãoParte1ToolStripMenuItem";
            this.introduçãoParte1ToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.introduçãoParte1ToolStripMenuItem.Text = "Introdução Parte 1";
            this.introduçãoParte1ToolStripMenuItem.Click += new System.EventHandler(this.introduçãoParte1ToolStripMenuItem_Click);
            // 
            // introduçãoParte2ToolStripMenuItem
            // 
            this.introduçãoParte2ToolStripMenuItem.Name = "introduçãoParte2ToolStripMenuItem";
            this.introduçãoParte2ToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.introduçãoParte2ToolStripMenuItem.Text = "Introdução Parte 2";
            this.introduçãoParte2ToolStripMenuItem.Click += new System.EventHandler(this.introduçãoParte2ToolStripMenuItem_Click);
            // 
            // condiçãoDeExistênciaToolStripMenuItem
            // 
            this.condiçãoDeExistênciaToolStripMenuItem.Name = "condiçãoDeExistênciaToolStripMenuItem";
            this.condiçãoDeExistênciaToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.condiçãoDeExistênciaToolStripMenuItem.Text = "Condição de Existência";
            this.condiçãoDeExistênciaToolStripMenuItem.Click += new System.EventHandler(this.condiçãoDeExistênciaToolStripMenuItem_Click);
            // 
            // consequênciasDaDefiniçãoToolStripMenuItem
            // 
            this.consequênciasDaDefiniçãoToolStripMenuItem.Name = "consequênciasDaDefiniçãoToolStripMenuItem";
            this.consequênciasDaDefiniçãoToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.consequênciasDaDefiniçãoToolStripMenuItem.Text = "Consequências da Definição";
            this.consequênciasDaDefiniçãoToolStripMenuItem.Click += new System.EventHandler(this.consequênciasDaDefiniçãoToolStripMenuItem_Click);
            // 
            // propriedadesOperatóriasToolStripMenuItem
            // 
            this.propriedadesOperatóriasToolStripMenuItem.Name = "propriedadesOperatóriasToolStripMenuItem";
            this.propriedadesOperatóriasToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.propriedadesOperatóriasToolStripMenuItem.Text = "Propriedades Operatórias";
            this.propriedadesOperatóriasToolStripMenuItem.Click += new System.EventHandler(this.propriedadesOperatóriasToolStripMenuItem_Click);
            // 
            // propriedadesOperatóriasExercíciosToolStripMenuItem
            // 
            this.propriedadesOperatóriasExercíciosToolStripMenuItem.Name = "propriedadesOperatóriasExercíciosToolStripMenuItem";
            this.propriedadesOperatóriasExercíciosToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.propriedadesOperatóriasExercíciosToolStripMenuItem.Text = "Propriedades Operatórias - Exercícios";
            this.propriedadesOperatóriasExercíciosToolStripMenuItem.Click += new System.EventHandler(this.propriedadesOperatóriasExercíciosToolStripMenuItem_Click);
            // 
            // cálculoDeLogaritmosToolStripMenuItem
            // 
            this.cálculoDeLogaritmosToolStripMenuItem.Name = "cálculoDeLogaritmosToolStripMenuItem";
            this.cálculoDeLogaritmosToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.cálculoDeLogaritmosToolStripMenuItem.Text = "Cálculo de Logaritmos";
            this.cálculoDeLogaritmosToolStripMenuItem.Click += new System.EventHandler(this.cálculoDeLogaritmosToolStripMenuItem_Click);
            // 
            // mudançaDeBaseToolStripMenuItem
            // 
            this.mudançaDeBaseToolStripMenuItem.Name = "mudançaDeBaseToolStripMenuItem";
            this.mudançaDeBaseToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.mudançaDeBaseToolStripMenuItem.Text = "Mudança de Base";
            this.mudançaDeBaseToolStripMenuItem.Click += new System.EventHandler(this.mudançaDeBaseToolStripMenuItem_Click);
            // 
            // logaritmoEAsEquaçõesExponenciaisToolStripMenuItem
            // 
            this.logaritmoEAsEquaçõesExponenciaisToolStripMenuItem.Name = "logaritmoEAsEquaçõesExponenciaisToolStripMenuItem";
            this.logaritmoEAsEquaçõesExponenciaisToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.logaritmoEAsEquaçõesExponenciaisToolStripMenuItem.Text = "Logaritmo e as Equações Exponenciais";
            this.logaritmoEAsEquaçõesExponenciaisToolStripMenuItem.Click += new System.EventHandler(this.logaritmoEAsEquaçõesExponenciaisToolStripMenuItem_Click);
            // 
            // aplicaçõesToolStripMenuItem
            // 
            this.aplicaçõesToolStripMenuItem.Name = "aplicaçõesToolStripMenuItem";
            this.aplicaçõesToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.aplicaçõesToolStripMenuItem.Text = "Aplicações";
            this.aplicaçõesToolStripMenuItem.Click += new System.EventHandler(this.aplicaçõesToolStripMenuItem_Click);
            // 
            // funçãoLogarítmicaEGráficoToolStripMenuItem
            // 
            this.funçãoLogarítmicaEGráficoToolStripMenuItem.Name = "funçãoLogarítmicaEGráficoToolStripMenuItem";
            this.funçãoLogarítmicaEGráficoToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.funçãoLogarítmicaEGráficoToolStripMenuItem.Text = "Função Logarítmica e Gráfico";
            this.funçãoLogarítmicaEGráficoToolStripMenuItem.Click += new System.EventHandler(this.funçãoLogarítmicaEGráficoToolStripMenuItem_Click);
            // 
            // equaçõesLogarítmicasParte1ToolStripMenuItem
            // 
            this.equaçõesLogarítmicasParte1ToolStripMenuItem.Name = "equaçõesLogarítmicasParte1ToolStripMenuItem";
            this.equaçõesLogarítmicasParte1ToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.equaçõesLogarítmicasParte1ToolStripMenuItem.Text = "Equações Logarítmicas - Parte 1";
            this.equaçõesLogarítmicasParte1ToolStripMenuItem.Click += new System.EventHandler(this.equaçõesLogarítmicasParte1ToolStripMenuItem_Click);
            // 
            // equaçõesLogarítmicasParte2ToolStripMenuItem
            // 
            this.equaçõesLogarítmicasParte2ToolStripMenuItem.Name = "equaçõesLogarítmicasParte2ToolStripMenuItem";
            this.equaçõesLogarítmicasParte2ToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.equaçõesLogarítmicasParte2ToolStripMenuItem.Text = "Equações Logarítmicas - Parte 2";
            this.equaçõesLogarítmicasParte2ToolStripMenuItem.Click += new System.EventHandler(this.equaçõesLogarítmicasParte2ToolStripMenuItem_Click);
            // 
            // inequaçõesLogarítmicasToolStripMenuItem
            // 
            this.inequaçõesLogarítmicasToolStripMenuItem.Name = "inequaçõesLogarítmicasToolStripMenuItem";
            this.inequaçõesLogarítmicasToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.inequaçõesLogarítmicasToolStripMenuItem.Text = "Inequações Logarítmicas";
            this.inequaçõesLogarítmicasToolStripMenuItem.Click += new System.EventHandler(this.inequaçõesLogarítmicasToolStripMenuItem_Click);
            // 
            // logaritmoQuestõesComentadasToolStripMenuItem
            // 
            this.logaritmoQuestõesComentadasToolStripMenuItem.Name = "logaritmoQuestõesComentadasToolStripMenuItem";
            this.logaritmoQuestõesComentadasToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.logaritmoQuestõesComentadasToolStripMenuItem.Text = "Questões Comentadas";
            this.logaritmoQuestõesComentadasToolStripMenuItem.Click += new System.EventHandler(this.logaritmoQuestõesComentadasToolStripMenuItem_Click);
            // 
            // funçãoLogarítmicaQuestõesComentadasToolStripMenuItem
            // 
            this.funçãoLogarítmicaQuestõesComentadasToolStripMenuItem.Name = "funçãoLogarítmicaQuestõesComentadasToolStripMenuItem";
            this.funçãoLogarítmicaQuestõesComentadasToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.funçãoLogarítmicaQuestõesComentadasToolStripMenuItem.Text = "Função Logarítmica: Questões Comentadas";
            this.funçãoLogarítmicaQuestõesComentadasToolStripMenuItem.Click += new System.EventHandler(this.funçãoLogarítmicaQuestõesComentadasToolStripMenuItem_Click);
            // 
            // equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem
            // 
            this.equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem.Name = "equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem";
            this.equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem.Size = new System.Drawing.Size(418, 26);
            this.equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem.Text = "Equações Logarítmicas: Questões Comentadas";
            this.equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem.Click += new System.EventHandler(this.equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.Tomato;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem48,
            this.toolStripMenuItem56,
            this.toolStripMenuItem64,
            this.toolStripMenuItem137,
            this.toolStripMenuItem158,
            this.toolStripMenuItem189,
            this.toolStripMenuItem204,
            this.toolStripMenuItem220,
            this.toolStripMenuItem230,
            this.toolStripMenuItem236,
            this.toolStripMenuItem239,
            this.toolStripMenuItem242,
            this.toolStripMenuItem252,
            this.toolStripMenuItem259});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(109, 25);
            this.toolStripMenuItem1.Text = "Perguntas";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem24});
            this.toolStripMenuItem2.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem2.Text = "Matemática Básica ";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem12,
            this.toolStripMenuItem14,
            this.toolStripMenuItem16,
            this.toolStripMenuItem17,
            this.toolStripMenuItem18,
            this.toolStripMenuItem19,
            this.toolStripMenuItem20,
            this.toolStripMenuItem22});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(131, 26);
            this.toolStripMenuItem3.Text = "Parte 1";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem4.Text = "Expressões numéricas";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem7.Text = "Fatoração de números inteiros";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem8.Text = "Quantidade de divisores de um número inteiro";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem9.Text = "Divisores de um número inteiro";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem10.Text = "Mínimo múltiplo comum - MMC";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem11.Text = "Máximo divisor comum - MDC";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem12.Text = "Frações";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem14.Text = "Números decimais";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem16.Text = "Dízimas periódicas (decimais periódicos)";
            this.toolStripMenuItem16.Click += new System.EventHandler(this.toolStripMenuItem16_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem17.Text = "Potenciação";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem18.Text = "Potência de dez e notação científica";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem19.Text = "Sistema de numeração decimal ou base dez";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem20.Text = "Radiciação";
            this.toolStripMenuItem20.Click += new System.EventHandler(this.toolStripMenuItem20_Click);
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(420, 26);
            this.toolStripMenuItem22.Text = "Produtos notáveis";
            this.toolStripMenuItem22.Click += new System.EventHandler(this.toolStripMenuItem22_Click);
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem25,
            this.toolStripMenuItem27,
            this.toolStripMenuItem28,
            this.toolStripMenuItem29,
            this.toolStripMenuItem31,
            this.toolStripMenuItem32,
            this.toolStripMenuItem33,
            this.toolStripMenuItem35,
            this.toolStripMenuItem37,
            this.toolStripMenuItem39,
            this.toolStripMenuItem40,
            this.toolStripMenuItem41,
            this.toolStripMenuItem42,
            this.toolStripMenuItem43,
            this.toolStripMenuItem44,
            this.toolStripMenuItem45,
            this.toolStripMenuItem46,
            this.toolStripMenuItem47});
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(131, 26);
            this.toolStripMenuItem24.Text = "Parte 2";
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem25.Text = "Fatoração de expressões algébricas";
            this.toolStripMenuItem25.Click += new System.EventHandler(this.toolStripMenuItem25_Click);
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem27.Text = "Frações Algébricas";
            this.toolStripMenuItem27.Click += new System.EventHandler(this.toolStripMenuItem27_Click);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem28.Text = "Racionalização de denominadores";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.toolStripMenuItem28_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem29.Text = "Razão e Proporção";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem31.Text = "Regra de Três Simples";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.toolStripMenuItem31_Click);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem32.Text = "Regra de Três Composta";
            this.toolStripMenuItem32.Click += new System.EventHandler(this.toolStripMenuItem32_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem33.Text = "Porcentagem";
            this.toolStripMenuItem33.Click += new System.EventHandler(this.toolStripMenuItem33_Click);
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem35.Text = "Juros Simples";
            this.toolStripMenuItem35.Click += new System.EventHandler(this.toolStripMenuItem35_Click);
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem37.Text = "Juros Compostos";
            this.toolStripMenuItem37.Click += new System.EventHandler(this.toolStripMenuItem37_Click);
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem39.Text = "Sistema Métrico Decimal";
            this.toolStripMenuItem39.Click += new System.EventHandler(this.toolStripMenuItem39_Click);
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem40.Text = "Média Aritmética";
            this.toolStripMenuItem40.Click += new System.EventHandler(this.toolStripMenuItem40_Click);
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem41.Text = "Média Ponderada";
            this.toolStripMenuItem41.Click += new System.EventHandler(this.toolStripMenuItem41_Click);
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem42.Text = "Média Geométrica";
            this.toolStripMenuItem42.Click += new System.EventHandler(this.toolStripMenuItem42_Click);
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem43.Text = "Média Harmônica";
            this.toolStripMenuItem43.Click += new System.EventHandler(this.toolStripMenuItem43_Click);
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem44.Text = "Equação do 1° Grau";
            this.toolStripMenuItem44.Click += new System.EventHandler(this.toolStripMenuItem44_Click);
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem45.Text = "Equação do 2° Grau";
            this.toolStripMenuItem45.Click += new System.EventHandler(this.toolStripMenuItem45_Click);
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem46.Text = "Equações Irracionais";
            this.toolStripMenuItem46.Click += new System.EventHandler(this.toolStripMenuItem46_Click);
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem47.Text = "Equações Biquadradas";
            this.toolStripMenuItem47.Click += new System.EventHandler(this.toolStripMenuItem47_Click);
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem49,
            this.toolStripMenuItem50,
            this.toolStripMenuItem51,
            this.toolStripMenuItem52});
            this.toolStripMenuItem48.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem48.Text = "Conjuntos Numéricos";
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(397, 26);
            this.toolStripMenuItem49.Text = "Números Naturais e Inteiros";
            this.toolStripMenuItem49.Click += new System.EventHandler(this.toolStripMenuItem49_Click);
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(397, 26);
            this.toolStripMenuItem50.Text = "Números Racionais";
            this.toolStripMenuItem50.Click += new System.EventHandler(this.toolStripMenuItem50_Click);
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(397, 26);
            this.toolStripMenuItem51.Text = "Números Irracionais e Reais";
            this.toolStripMenuItem51.Click += new System.EventHandler(this.toolStripMenuItem51_Click);
            // 
            // toolStripMenuItem52
            // 
            this.toolStripMenuItem52.Name = "toolStripMenuItem52";
            this.toolStripMenuItem52.Size = new System.Drawing.Size(397, 26);
            this.toolStripMenuItem52.Text = "Intervalos Reais, Operações e Propriedades";
            this.toolStripMenuItem52.Click += new System.EventHandler(this.toolStripMenuItem52_Click);
            // 
            // toolStripMenuItem56
            // 
            this.toolStripMenuItem56.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem56.Name = "toolStripMenuItem56";
            this.toolStripMenuItem56.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem56.Text = "Conjuntos";
            this.toolStripMenuItem56.Click += new System.EventHandler(this.toolStripMenuItem56_Click);
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem65,
            this.toolStripMenuItem83,
            this.toolStripMenuItem95,
            this.toolStripMenuItem101,
            this.toolStripMenuItem113,
            this.toolStripMenuItem119,
            this.toolStripMenuItem127});
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem64.Text = "Funções";
            // 
            // toolStripMenuItem65
            // 
            this.toolStripMenuItem65.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem65.Name = "toolStripMenuItem65";
            this.toolStripMenuItem65.Size = new System.Drawing.Size(418, 26);
            this.toolStripMenuItem65.Text = "Funções";
            // 
            // toolStripMenuItem83
            // 
            this.toolStripMenuItem83.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem83.Name = "toolStripMenuItem83";
            this.toolStripMenuItem83.Size = new System.Drawing.Size(418, 26);
            this.toolStripMenuItem83.Text = "Função 1º Grau (Função Afim)";
            // 
            // toolStripMenuItem95
            // 
            this.toolStripMenuItem95.Name = "toolStripMenuItem95";
            this.toolStripMenuItem95.Size = new System.Drawing.Size(418, 26);
            this.toolStripMenuItem95.Text = "Inequação do Primeiro Grau";
            // 
            // toolStripMenuItem101
            // 
            this.toolStripMenuItem101.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem101.Name = "toolStripMenuItem101";
            this.toolStripMenuItem101.Size = new System.Drawing.Size(418, 26);
            this.toolStripMenuItem101.Text = "Função Polinomial 2º Grau (Função Quadrática)";
            // 
            // toolStripMenuItem113
            // 
            this.toolStripMenuItem113.Name = "toolStripMenuItem113";
            this.toolStripMenuItem113.Size = new System.Drawing.Size(418, 26);
            this.toolStripMenuItem113.Text = "Inequação do Segundo Grau";
            // 
            // toolStripMenuItem119
            // 
            this.toolStripMenuItem119.Name = "toolStripMenuItem119";
            this.toolStripMenuItem119.Size = new System.Drawing.Size(418, 26);
            this.toolStripMenuItem119.Text = "Função Modular";
            // 
            // toolStripMenuItem127
            // 
            this.toolStripMenuItem127.Name = "toolStripMenuItem127";
            this.toolStripMenuItem127.Size = new System.Drawing.Size(418, 26);
            this.toolStripMenuItem127.Text = "Função Exponencial";
            // 
            // toolStripMenuItem137
            // 
            this.toolStripMenuItem137.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem138,
            this.toolStripMenuItem147});
            this.toolStripMenuItem137.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem137.Name = "toolStripMenuItem137";
            this.toolStripMenuItem137.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem137.Text = "Sequências";
            // 
            // toolStripMenuItem138
            // 
            this.toolStripMenuItem138.Name = "toolStripMenuItem138";
            this.toolStripMenuItem138.Size = new System.Drawing.Size(291, 26);
            this.toolStripMenuItem138.Text = "Progressão Aritmética (P.A.)";
            // 
            // toolStripMenuItem147
            // 
            this.toolStripMenuItem147.Name = "toolStripMenuItem147";
            this.toolStripMenuItem147.Size = new System.Drawing.Size(291, 26);
            this.toolStripMenuItem147.Text = "Progressão Geométrica (P.G.)";
            // 
            // toolStripMenuItem158
            // 
            this.toolStripMenuItem158.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem159,
            this.toolStripMenuItem175});
            this.toolStripMenuItem158.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem158.Name = "toolStripMenuItem158";
            this.toolStripMenuItem158.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem158.Text = "Geometria Plana ";
            // 
            // toolStripMenuItem159
            // 
            this.toolStripMenuItem159.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem162,
            this.toolStripMenuItem163,
            this.toolStripMenuItem167,
            this.toolStripMenuItem168,
            this.toolStripMenuItem169,
            this.toolStripMenuItem171,
            this.toolStripMenuItem172,
            this.toolStripMenuItem173,
            this.toolStripMenuItem174});
            this.toolStripMenuItem159.Name = "toolStripMenuItem159";
            this.toolStripMenuItem159.Size = new System.Drawing.Size(152, 26);
            this.toolStripMenuItem159.Text = "Parte 1";
            // 
            // toolStripMenuItem162
            // 
            this.toolStripMenuItem162.Name = "toolStripMenuItem162";
            this.toolStripMenuItem162.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem162.Text = "Polígonos";
            this.toolStripMenuItem162.Click += new System.EventHandler(this.toolStripMenuItem162_Click);
            // 
            // toolStripMenuItem163
            // 
            this.toolStripMenuItem163.Name = "toolStripMenuItem163";
            this.toolStripMenuItem163.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem163.Text = "Polígonos Regulares";
            this.toolStripMenuItem163.Click += new System.EventHandler(this.toolStripMenuItem163_Click);
            // 
            // toolStripMenuItem167
            // 
            this.toolStripMenuItem167.Name = "toolStripMenuItem167";
            this.toolStripMenuItem167.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem167.Text = "Área de Triângulos";
            this.toolStripMenuItem167.Click += new System.EventHandler(this.toolStripMenuItem167_Click);
            // 
            // toolStripMenuItem168
            // 
            this.toolStripMenuItem168.Name = "toolStripMenuItem168";
            this.toolStripMenuItem168.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem168.Text = "Semelhança de Triângulos";
            this.toolStripMenuItem168.Click += new System.EventHandler(this.toolStripMenuItem168_Click);
            // 
            // toolStripMenuItem169
            // 
            this.toolStripMenuItem169.Name = "toolStripMenuItem169";
            this.toolStripMenuItem169.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem169.Text = "Triângulo Retângulo - Relações Métricas";
            this.toolStripMenuItem169.Click += new System.EventHandler(this.toolStripMenuItem169_Click);
            // 
            // toolStripMenuItem171
            // 
            this.toolStripMenuItem171.Name = "toolStripMenuItem171";
            this.toolStripMenuItem171.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem171.Text = "Triângulo Equilátero";
            this.toolStripMenuItem171.Click += new System.EventHandler(this.toolStripMenuItem171_Click);
            // 
            // toolStripMenuItem172
            // 
            this.toolStripMenuItem172.Name = "toolStripMenuItem172";
            this.toolStripMenuItem172.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem172.Text = "Teorema de Tales";
            this.toolStripMenuItem172.Click += new System.EventHandler(this.toolStripMenuItem172_Click);
            // 
            // toolStripMenuItem173
            // 
            this.toolStripMenuItem173.Name = "toolStripMenuItem173";
            this.toolStripMenuItem173.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem173.Text = "Quadriláteros - Paralelogramo";
            this.toolStripMenuItem173.Click += new System.EventHandler(this.toolStripMenuItem173_Click);
            // 
            // toolStripMenuItem174
            // 
            this.toolStripMenuItem174.Name = "toolStripMenuItem174";
            this.toolStripMenuItem174.Size = new System.Drawing.Size(373, 26);
            this.toolStripMenuItem174.Text = "Quadriláteros - Retângulo";
            this.toolStripMenuItem174.Click += new System.EventHandler(this.toolStripMenuItem174_Click);
            // 
            // toolStripMenuItem175
            // 
            this.toolStripMenuItem175.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem176,
            this.toolStripMenuItem177,
            this.toolStripMenuItem178,
            this.toolStripMenuItem179,
            this.toolStripMenuItem180,
            this.toolStripMenuItem183,
            this.toolStripMenuItem185});
            this.toolStripMenuItem175.Name = "toolStripMenuItem175";
            this.toolStripMenuItem175.Size = new System.Drawing.Size(152, 26);
            this.toolStripMenuItem175.Text = "Parte 2";
            // 
            // toolStripMenuItem176
            // 
            this.toolStripMenuItem176.Name = "toolStripMenuItem176";
            this.toolStripMenuItem176.Size = new System.Drawing.Size(313, 26);
            this.toolStripMenuItem176.Text = "Quadriláteros - Losango";
            this.toolStripMenuItem176.Click += new System.EventHandler(this.toolStripMenuItem176_Click);
            // 
            // toolStripMenuItem177
            // 
            this.toolStripMenuItem177.Name = "toolStripMenuItem177";
            this.toolStripMenuItem177.Size = new System.Drawing.Size(313, 26);
            this.toolStripMenuItem177.Text = "Quadriláteros - Quadrado";
            this.toolStripMenuItem177.Click += new System.EventHandler(this.toolStripMenuItem177_Click);
            // 
            // toolStripMenuItem178
            // 
            this.toolStripMenuItem178.Name = "toolStripMenuItem178";
            this.toolStripMenuItem178.Size = new System.Drawing.Size(313, 26);
            this.toolStripMenuItem178.Text = "Quadriláteros Trapézio";
            this.toolStripMenuItem178.Click += new System.EventHandler(this.toolStripMenuItem178_Click);
            // 
            // toolStripMenuItem179
            // 
            this.toolStripMenuItem179.Name = "toolStripMenuItem179";
            this.toolStripMenuItem179.Size = new System.Drawing.Size(313, 26);
            this.toolStripMenuItem179.Text = "Hexágono Regular";
            this.toolStripMenuItem179.Click += new System.EventHandler(this.toolStripMenuItem179_Click);
            // 
            // toolStripMenuItem180
            // 
            this.toolStripMenuItem180.Name = "toolStripMenuItem180";
            this.toolStripMenuItem180.Size = new System.Drawing.Size(313, 26);
            this.toolStripMenuItem180.Text = "Circunferência";
            this.toolStripMenuItem180.Click += new System.EventHandler(this.toolStripMenuItem180_Click);
            // 
            // toolStripMenuItem183
            // 
            this.toolStripMenuItem183.Name = "toolStripMenuItem183";
            this.toolStripMenuItem183.Size = new System.Drawing.Size(313, 26);
            this.toolStripMenuItem183.Text = "Ângulos na Circunferência";
            this.toolStripMenuItem183.Click += new System.EventHandler(this.toolStripMenuItem183_Click);
            // 
            // toolStripMenuItem185
            // 
            this.toolStripMenuItem185.Name = "toolStripMenuItem185";
            this.toolStripMenuItem185.Size = new System.Drawing.Size(313, 26);
            this.toolStripMenuItem185.Text = "Comprimento da Circunferência";
            this.toolStripMenuItem185.Click += new System.EventHandler(this.toolStripMenuItem185_Click);
            // 
            // toolStripMenuItem189
            // 
            this.toolStripMenuItem189.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem190,
            this.toolStripMenuItem192,
            this.toolStripMenuItem194,
            this.toolStripMenuItem196,
            this.toolStripMenuItem197,
            this.toolStripMenuItem199,
            this.toolStripMenuItem200,
            this.toolStripMenuItem201,
            this.toolStripMenuItem202});
            this.toolStripMenuItem189.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem189.Name = "toolStripMenuItem189";
            this.toolStripMenuItem189.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem189.Text = "Trigonometria ";
            // 
            // toolStripMenuItem190
            // 
            this.toolStripMenuItem190.Name = "toolStripMenuItem190";
            this.toolStripMenuItem190.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem190.Text = "Triângulo Retângulo";
            this.toolStripMenuItem190.Click += new System.EventHandler(this.toolStripMenuItem190_Click);
            // 
            // toolStripMenuItem192
            // 
            this.toolStripMenuItem192.Name = "toolStripMenuItem192";
            this.toolStripMenuItem192.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem192.Text = "Triângulo Qualquer (Lei dos Senos e Cossenos)";
            this.toolStripMenuItem192.Click += new System.EventHandler(this.toolStripMenuItem192_Click);
            // 
            // toolStripMenuItem194
            // 
            this.toolStripMenuItem194.Name = "toolStripMenuItem194";
            this.toolStripMenuItem194.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem194.Text = "Ciclo Trigonométrico";
            this.toolStripMenuItem194.Click += new System.EventHandler(this.toolStripMenuItem194_Click);
            // 
            // toolStripMenuItem196
            // 
            this.toolStripMenuItem196.Name = "toolStripMenuItem196";
            this.toolStripMenuItem196.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem196.Text = "Relações Trigonométricas";
            this.toolStripMenuItem196.Click += new System.EventHandler(this.toolStripMenuItem196_Click);
            // 
            // toolStripMenuItem197
            // 
            this.toolStripMenuItem197.Name = "toolStripMenuItem197";
            this.toolStripMenuItem197.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem197.Text = "Operações com Arcos";
            this.toolStripMenuItem197.Click += new System.EventHandler(this.toolStripMenuItem197_Click);
            // 
            // toolStripMenuItem199
            // 
            this.toolStripMenuItem199.Name = "toolStripMenuItem199";
            this.toolStripMenuItem199.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem199.Text = "Equações Trigonométricas";
            this.toolStripMenuItem199.Click += new System.EventHandler(this.toolStripMenuItem199_Click);
            // 
            // toolStripMenuItem200
            // 
            this.toolStripMenuItem200.Name = "toolStripMenuItem200";
            this.toolStripMenuItem200.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem200.Text = "Inequações Trigonométricas";
            this.toolStripMenuItem200.Click += new System.EventHandler(this.toolStripMenuItem200_Click);
            // 
            // toolStripMenuItem201
            // 
            this.toolStripMenuItem201.Name = "toolStripMenuItem201";
            this.toolStripMenuItem201.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem201.Text = "Função Seno e Cosseno";
            this.toolStripMenuItem201.Click += new System.EventHandler(this.toolStripMenuItem201_Click);
            // 
            // toolStripMenuItem202
            // 
            this.toolStripMenuItem202.Name = "toolStripMenuItem202";
            this.toolStripMenuItem202.Size = new System.Drawing.Size(419, 26);
            this.toolStripMenuItem202.Text = "Função Tg, Cotg, Sec e Cossec";
            this.toolStripMenuItem202.Click += new System.EventHandler(this.toolStripMenuItem202_Click);
            // 
            // toolStripMenuItem204
            // 
            this.toolStripMenuItem204.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem205,
            this.toolStripMenuItem206,
            this.toolStripMenuItem207,
            this.toolStripMenuItem210,
            this.toolStripMenuItem213,
            this.toolStripMenuItem214,
            this.toolStripMenuItem215,
            this.toolStripMenuItem216});
            this.toolStripMenuItem204.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem204.Name = "toolStripMenuItem204";
            this.toolStripMenuItem204.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem204.Text = "Geometria Espacial ";
            // 
            // toolStripMenuItem205
            // 
            this.toolStripMenuItem205.Name = "toolStripMenuItem205";
            this.toolStripMenuItem205.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem205.Text = "Tetraedro e Octaedro";
            this.toolStripMenuItem205.Click += new System.EventHandler(this.toolStripMenuItem205_Click);
            // 
            // toolStripMenuItem206
            // 
            this.toolStripMenuItem206.Name = "toolStripMenuItem206";
            this.toolStripMenuItem206.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem206.Text = "Posição, Estruturas e Relação de Euler";
            this.toolStripMenuItem206.Click += new System.EventHandler(this.toolStripMenuItem206_Click);
            // 
            // toolStripMenuItem207
            // 
            this.toolStripMenuItem207.Name = "toolStripMenuItem207";
            this.toolStripMenuItem207.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem207.Text = "Prismas";
            this.toolStripMenuItem207.Click += new System.EventHandler(this.toolStripMenuItem207_Click);
            // 
            // toolStripMenuItem210
            // 
            this.toolStripMenuItem210.Name = "toolStripMenuItem210";
            this.toolStripMenuItem210.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem210.Text = "Pirâmides";
            this.toolStripMenuItem210.Click += new System.EventHandler(this.toolStripMenuItem210_Click);
            // 
            // toolStripMenuItem213
            // 
            this.toolStripMenuItem213.Name = "toolStripMenuItem213";
            this.toolStripMenuItem213.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem213.Text = "Cilindro";
            this.toolStripMenuItem213.Click += new System.EventHandler(this.toolStripMenuItem213_Click);
            // 
            // toolStripMenuItem214
            // 
            this.toolStripMenuItem214.Name = "toolStripMenuItem214";
            this.toolStripMenuItem214.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem214.Text = "Cone";
            this.toolStripMenuItem214.Click += new System.EventHandler(this.toolStripMenuItem214_Click);
            // 
            // toolStripMenuItem215
            // 
            this.toolStripMenuItem215.Name = "toolStripMenuItem215";
            this.toolStripMenuItem215.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem215.Text = "Esfera";
            this.toolStripMenuItem215.Click += new System.EventHandler(this.toolStripMenuItem215_Click);
            // 
            // toolStripMenuItem216
            // 
            this.toolStripMenuItem216.Name = "toolStripMenuItem216";
            this.toolStripMenuItem216.Size = new System.Drawing.Size(352, 26);
            this.toolStripMenuItem216.Text = "Troncos";
            this.toolStripMenuItem216.Click += new System.EventHandler(this.toolStripMenuItem216_Click);
            // 
            // toolStripMenuItem220
            // 
            this.toolStripMenuItem220.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem221,
            this.toolStripMenuItem222,
            this.toolStripMenuItem225,
            this.toolStripMenuItem228});
            this.toolStripMenuItem220.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem220.Name = "toolStripMenuItem220";
            this.toolStripMenuItem220.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem220.Text = "Geometria Analítica ";
            // 
            // toolStripMenuItem221
            // 
            this.toolStripMenuItem221.Name = "toolStripMenuItem221";
            this.toolStripMenuItem221.Size = new System.Drawing.Size(368, 26);
            this.toolStripMenuItem221.Text = "Distância entre 2 pontos e Ponto médio";
            this.toolStripMenuItem221.Click += new System.EventHandler(this.toolStripMenuItem221_Click);
            // 
            // toolStripMenuItem222
            // 
            this.toolStripMenuItem222.Name = "toolStripMenuItem222";
            this.toolStripMenuItem222.Size = new System.Drawing.Size(368, 26);
            this.toolStripMenuItem222.Text = "Baricentro e Área de Triângulo";
            this.toolStripMenuItem222.Click += new System.EventHandler(this.toolStripMenuItem222_Click);
            // 
            // toolStripMenuItem225
            // 
            this.toolStripMenuItem225.Name = "toolStripMenuItem225";
            this.toolStripMenuItem225.Size = new System.Drawing.Size(368, 26);
            this.toolStripMenuItem225.Text = "Estudo da Reta";
            this.toolStripMenuItem225.Click += new System.EventHandler(this.toolStripMenuItem225_Click);
            // 
            // toolStripMenuItem228
            // 
            this.toolStripMenuItem228.Name = "toolStripMenuItem228";
            this.toolStripMenuItem228.Size = new System.Drawing.Size(368, 26);
            this.toolStripMenuItem228.Text = "Estudo da Circunferência";
            this.toolStripMenuItem228.Click += new System.EventHandler(this.toolStripMenuItem228_Click);
            // 
            // toolStripMenuItem230
            // 
            this.toolStripMenuItem230.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem231,
            this.toolStripMenuItem232,
            this.toolStripMenuItem233,
            this.toolStripMenuItem235});
            this.toolStripMenuItem230.Name = "toolStripMenuItem230";
            this.toolStripMenuItem230.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem230.Text = "Números Complexos ";
            // 
            // toolStripMenuItem231
            // 
            this.toolStripMenuItem231.Name = "toolStripMenuItem231";
            this.toolStripMenuItem231.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem231.Text = "Unidade Imaginária";
            this.toolStripMenuItem231.Click += new System.EventHandler(this.toolStripMenuItem231_Click);
            // 
            // toolStripMenuItem232
            // 
            this.toolStripMenuItem232.Name = "toolStripMenuItem232";
            this.toolStripMenuItem232.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem232.Text = "Forma Algébrica";
            this.toolStripMenuItem232.Click += new System.EventHandler(this.toolStripMenuItem232_Click);
            // 
            // toolStripMenuItem233
            // 
            this.toolStripMenuItem233.Name = "toolStripMenuItem233";
            this.toolStripMenuItem233.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem233.Text = "Operações na Forma Algébrica";
            this.toolStripMenuItem233.Click += new System.EventHandler(this.toolStripMenuItem233_Click);
            // 
            // toolStripMenuItem235
            // 
            this.toolStripMenuItem235.Name = "toolStripMenuItem235";
            this.toolStripMenuItem235.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem235.Text = "Potências da unidade Imaginária i";
            this.toolStripMenuItem235.Click += new System.EventHandler(this.toolStripMenuItem235_Click);
            // 
            // toolStripMenuItem236
            // 
            this.toolStripMenuItem236.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem236.Name = "toolStripMenuItem236";
            this.toolStripMenuItem236.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem236.Text = "Polinômios e Equações Polinomiais";
            this.toolStripMenuItem236.Click += new System.EventHandler(this.toolStripMenuItem236_Click);
            // 
            // toolStripMenuItem239
            // 
            this.toolStripMenuItem239.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem240,
            this.toolStripMenuItem241});
            this.toolStripMenuItem239.Name = "toolStripMenuItem239";
            this.toolStripMenuItem239.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem239.Text = "Binômio de Newton";
            // 
            // toolStripMenuItem240
            // 
            this.toolStripMenuItem240.Name = "toolStripMenuItem240";
            this.toolStripMenuItem240.Size = new System.Drawing.Size(401, 26);
            this.toolStripMenuItem240.Text = "Binômio de Newton";
            this.toolStripMenuItem240.Click += new System.EventHandler(this.toolStripMenuItem240_Click);
            // 
            // toolStripMenuItem241
            // 
            this.toolStripMenuItem241.Name = "toolStripMenuItem241";
            this.toolStripMenuItem241.Size = new System.Drawing.Size(401, 26);
            this.toolStripMenuItem241.Text = "Coeficientes Binomiais e Triângulo de Pascal";
            this.toolStripMenuItem241.Click += new System.EventHandler(this.toolStripMenuItem241_Click);
            // 
            // toolStripMenuItem242
            // 
            this.toolStripMenuItem242.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem245,
            this.toolStripMenuItem247});
            this.toolStripMenuItem242.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem242.Name = "toolStripMenuItem242";
            this.toolStripMenuItem242.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem242.Text = "Análise Combinatória";
            // 
            // toolStripMenuItem245
            // 
            this.toolStripMenuItem245.Name = "toolStripMenuItem245";
            this.toolStripMenuItem245.Size = new System.Drawing.Size(242, 26);
            this.toolStripMenuItem245.Text = "Fatorial e Permutação";
            this.toolStripMenuItem245.Click += new System.EventHandler(this.toolStripMenuItem245_Click);
            // 
            // toolStripMenuItem247
            // 
            this.toolStripMenuItem247.Name = "toolStripMenuItem247";
            this.toolStripMenuItem247.Size = new System.Drawing.Size(242, 26);
            this.toolStripMenuItem247.Text = "Arranjo e Combinação";
            this.toolStripMenuItem247.Click += new System.EventHandler(this.toolStripMenuItem247_Click);
            // 
            // toolStripMenuItem252
            // 
            this.toolStripMenuItem252.Name = "toolStripMenuItem252";
            this.toolStripMenuItem252.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem252.Text = "Probabilidade ";
            this.toolStripMenuItem252.Click += new System.EventHandler(this.toolStripMenuItem252_Click);
            // 
            // toolStripMenuItem259
            // 
            this.toolStripMenuItem259.Name = "toolStripMenuItem259";
            this.toolStripMenuItem259.Size = new System.Drawing.Size(332, 26);
            this.toolStripMenuItem259.Text = "Logaritmo";
            this.toolStripMenuItem259.Click += new System.EventHandler(this.toolStripMenuItem259_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(914, 612);
            this.sfoPlayer.TabIndex = 43;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(914, 612);
            this.PictureCSharp.TabIndex = 44;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(914, 612);
            this.panelQuiz.TabIndex = 65;
            // 
            // FrmMat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmMat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmCss";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fecharMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cursoEmVídeoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SegundoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TerceiroMenuItem;
        private System.Windows.Forms.ToolStripMenuItem QuartoMenuItem;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem geometriaAnalíticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geometriaPlanaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matemáticaBásicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númerosComplexosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polinômiosEEquaçõesPolinomiaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trigonometriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem binômioDeNewtonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coeficientesBinomiaisETriânguloDePascalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem progressãoAritméticaPAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem progressãoGeométricaPGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geometriaEspacialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tetraedroEOctaedroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expressõesNuméricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem critériosDeDivisibilidadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númerosPrimosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoraçãoDeNúmerosInteirosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem divisoresDeUmNúmeroInteiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mínimoMúltiploComumMMCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem máximoDivisorComumMDCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fraçõesparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fraçõesparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númerosDecimaisparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númerosDecimaisparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potenciaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potênciaDeDezENotaçãoCientíficaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem radiciaçãoparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem radiciaçãoparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtosNotáveisparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtosNotáveisparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fraçõesAlgébricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem racionalizaçãoDeDenominadoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem razãoEProporçãoparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem razãoEProporçãoparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regraDeTrêsSimplesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regraDeTrêsCompostaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porcentagemparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem porcentagemparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jurosSimplesparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jurosSimplesparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jurosCompostosparte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jurosCompostosparte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaMétricoDecimalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem médiaAritméticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem médiaPonderadaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem médiaGeométricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem médiaHarmônicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçãoDo1GrauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçãoDo2GrauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesIrracionaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesBiquadradasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem princípioFundamentalDaContagemToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatorialEPermutaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem permutaçãoNaVideolocadoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arranjoECombinaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitoDeCombinaçãoEArranjoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem análiseCombinatóriaquestãoFácilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem análiseCombinatóriacomPegadinhaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem termoGeralToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem termoGeralExercíciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notaçõesEspeciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interpolaçãoDeMeiosAritméticosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem somaDosTermosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem termoGeralToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem termoGeralExercíciosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem notaçõesEspeciaisToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem interpolaçãoDeMeiosGeométricosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem somaDosTermosDeUmaPGFinitaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem somaDosTermosDeUmaPGInfinitaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosDePAEPGSimultaneamenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem conjuntosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem subconjuntosEConjuntoDasPartesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uniãoEIntersecçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diferençaEComplementarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasConjuntosNívelBásicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasConjuntosNívelAvançadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conjuntosNuméricosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númerosNaturaisEInteirosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númerosRacionaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númerosIrracionaisEReaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem intervalosReaisOperaçõesEPropriedadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conjuntosNuméricosNívelBásicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçõesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem noçõesBásicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem domínioContradomínioEConjuntoImagemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudoDoDomínioDasFunçõesReaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noçõesBásicasDePlanoCartesianoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem construçãoDeGráficosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem domínioEImagemAtravésDoGráficoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reconhecendoUmaFunçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem analisandoOGráficoDeFunçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasAnáliseDeGráficosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoParEFunçãoÍmparToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoInjetoraFunçãoInjetivaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoBijetoraFunçãoBijetivaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoCompostaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoInversaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasFunçãoInversaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoDoPrimeiroGrauFunçãoAfimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitosIniciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem determinandoAFunçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coeficienteAngularECoeficienteLinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem casosParticularesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zeroOuRaizDaFunçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudoDoSinalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem funçãoPolinomialDo2ºGrauFunçãoQuadráticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitosIniciaisToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quantidadeDeRaízesReaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem gráficoParábolaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficoParábolaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosSobreGráficoParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosSobreGráficoParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudoDoSinalGráficoParábolaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte2ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem inequaçãoDoPrimeiroGrauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitosIniciaisToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem inequaçõesSimultâneasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçãoProdutoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçãoQuocienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçãoDoSegundoGrauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçõesSimultâneasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem inequaçãoProdutoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem inequaçãoQuocienteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoModularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem móduloDeUmNúmeroRealToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem propriedadesDoMóduloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem equaçõesModularesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçõesModularesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasFunçãoModularParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasFunçãoModularParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoExponencialToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem revisãoDePotenciaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem gráficoParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficoParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesExponenciaisParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesExponenciaisParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçõesExponenciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte1ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem questõesComentadasParte2ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem parte1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem introduçãoÂngulosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paralelismoEntreRetasNoPlanoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polígonosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polígonosRegularesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoAosTriângulosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classificaçãoDosTriângulosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pontosNotáveisDoTriânguloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem áreaDeTriângulosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem semelhançaDeTriângulosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem triânguloRetânguloRelaçõesMétricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem triânguloRetânguloExercíciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem triânguloEquiláteroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teoremaDeTalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quadriláterosParalelogramoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quadriláterosRetânguloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem quadriláterosLosangoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quadriláterosQuadradoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quadriláterosTrapézioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hexágonoRegularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circunferênciaConceitosIniciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaçõesMétricasNaCircunferênciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circunferênciaPotênciaDePontoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ângulosNaCircunferênciaParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ângulosNaCircunferênciaParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comprimentoDaCircunferênciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem áreaDoCírculoESetorCircularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem áreaDeSegmentoECoroaCircularesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem áreasSemelhantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logaritmoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem condiçãoDeExistênciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consequênciasDaDefiniçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propriedadesOperatóriasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propriedadesOperatóriasExercíciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cálculoDeLogaritmosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mudançaDeBaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logaritmoEAsEquaçõesExponenciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aplicaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoLogarítmicaEGráficoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesLogarítmicasParte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesLogarítmicasParte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçõesLogarítmicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logaritmoQuestõesComentadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoLogarítmicaQuestõesComentadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitosIniciaisToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem distânciaEntre2PontosEPontoMédioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem baricentroEÁreaDeTriânguloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudoDaRetaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudoDaRetaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercícioEstudoDaRetaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudoDaCircunferênciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudoDaCircunferênciaExercícioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prismasIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prismasIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pirâmidesIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pirâmidesIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cilindroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem esferaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem troncosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosIIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosIVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unidadeImagináriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formaAlgébricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operaçõesNaFormaAlgébricaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operaçõesNaFormaAlgébricaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potênciasDaUnidadeImagináriaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem triânguloRetânguloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trigonometriaNoTriânguloRetânguloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem triânguloQualquerLeiDosSenosECossenosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leiDosSenosECossenosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cicloTrigonométricoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosResolvidosCicloTrigonométricoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaçõesTrigonométricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operaçõesComArcosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosResolvidosOperaçõesComArcosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equaçõesTrigonométricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inequaçõesTrigonométricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoSenoECossenoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funçãoTgCotgSecECossecToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polinômiosIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polinômiosIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem probabilidadeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parte1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parte2ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parte3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte6ToolStripMenuItem;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem65;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem83;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem95;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem101;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem113;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem119;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem127;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem137;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem138;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem147;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem158;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem159;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem162;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem163;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem167;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem168;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem169;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem171;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem172;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem173;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem174;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem175;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem176;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem177;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem178;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem179;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem180;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem183;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem185;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem189;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem190;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem192;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem194;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem196;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem197;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem199;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem200;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem201;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem202;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem204;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem205;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem206;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem207;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem210;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem213;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem214;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem215;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem216;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem220;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem221;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem222;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem225;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem228;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem230;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem231;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem232;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem233;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem235;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem236;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem239;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem240;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem241;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem242;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem245;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem247;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem252;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem259;
    }
}