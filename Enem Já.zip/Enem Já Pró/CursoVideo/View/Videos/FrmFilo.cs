﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmFilo : Form
    {
        public FrmFilo()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }

        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }

        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }

        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Filosofia";
           
            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void grátisIntroduçãoÀFilosofiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EbDcrCgJgH8&index=4");
        }

        private void moralÉticaELeiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void moralGregaSócratesPlatãoEAristótelesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void éticaHelênicaEMoralCristãToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=DG_x1JeiUJk&index=3");
        }

        private void éticaDeontológicaEConsequencialistaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void éticaContemporâneaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=I36ruBPoA2s&index=24");
        }

        private void éticaMoralEValoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-pAQS5Aqo88");
        }

        private void sócratesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7n9pjrsMP-Y");
        }

        private void platãoPolíticaDialéticaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5BikS8Nnwlo&index=5"); 
        }

        private void aristótelesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ARz_Ng4qynU&index=7");
        }

        private void aTeoriaDasIdeiasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BYDuLFNfrJM&index=6");
        }

        private void filosofiasHelenísticasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pgZyBV-zMvY");
        }

        private void filosofiaMedievalISantoAgostinhoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yJpwoA_BOtk");
        }

        private void filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OWRb5AEGHgs");
        }

        private void oSURGIMENTODAPOLÍTICAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oWrzWTO9RaU&index=25");
        }

        private void maquiavelManutençãoDoPoderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=zvdT4fmOqDI"); 
        }

        private void contratoSocialHobbesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7BTP1JLqxyI");
        }

        private void johnLockeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=d4MtEiorFLQ");
        }

        private void rousseauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=N2SlXIQYivw"); 
        }

        private void iluminismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=A9D7VEy53Cs&index=21");
        }

        private void karlMarxParteIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5Qv8pNeFOLM&index=27");
        }

        private void karlMarxParteIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JSE6uQmIjTY&index=28");
        }

        private void feminismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=C6Z1OPlhBa4");
        }

        private void aDemocraciaGregaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=RAoKb__wOyc");
        }

        private void éticaHelênicaEMoralCristãToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=DG_x1JeiUJk&index=3");
        }

        private void foucaultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=IPcwf-nHLm0&index=33");
        }

        private void relaçõesDePoderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ydO_iLRZfqU&index=2");
        }

        private void introduçãoTeoriaDoConhecimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=rIe547sS6II&index=1");
        }

        private void francisBaconToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=UfyOLHiY-lE");
        }

        private void renéDescartesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=We3WMDmr8SY&index=17");
        }

        private void immanuelKantParteIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BuvKyjhcS1o");
        }

        private void immanuelKantParteIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=O3McwGDyBjA");
        }

        private void oSerOMovimentoEAsVirtudesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5Qk6xDtAzT4&index=8");
        }

        private void davidHumeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=z9mAph7O25k&index=19");
        }

        private void georgeBerkeleyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xqlocF6RsQI");
        }

        private void racionalismoModernoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=rGGxJMxZawM");
        }

        private void toolStripMenuItem31_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem31.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Ética, Moral e Valores";
            ChamarQuiz();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Sócrates";
            ChamarQuiz();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Platão: Política/Dialética";
            ChamarQuiz();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "A Teoria das Ideias";
            ChamarQuiz();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Aristóteles";
            ChamarQuiz();
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem12.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem13.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem14.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem15.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem16.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem17.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem19.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem24_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem24.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem26_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem26.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem27_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem27.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem28_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem30_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem32_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem32.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem34_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem34.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem36_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem36.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem40_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem40.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem41_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem41.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem42_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem42.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem43_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem43.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem45_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem45.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem46_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem46.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem48_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem48.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem49_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem49.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem51_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem51.Text;
            ChamarQuiz();
        }

        private void fecharMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
             MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }
    }
}
