﻿namespace CursoVideo.View.Videos
{
    partial class FrmGeo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGeo));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fecharMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cursoEmVídeoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orientaçãoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.escalaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.coordenadasGeográficasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projeçõesCartográficasCônicaEAzimutalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fusoHorárioIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fusoHorárioIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fusoHorárioIIIBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PrimeiroMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentosDaTerraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rotaçãoETranslaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.solstíciosEEquinóciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zonasTérmicasEPeriélioEAfélioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoAparenteDoSolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.climatologiaClimasEAnomaliasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oQueÉClimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoresClimáticosIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circulaçãoGeralDaAtmosferaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circulaçãoGeralDaAtmosferaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposDeChuvaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dinâmicaDeBrisasEMonçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.climasDoBrasilIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.climasDoBrasilIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.elNiñoELaNiñaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geologiaERecursosNaturaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tempoGeológicoIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tempoGeológicoIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estruturaInternaDaTerraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.placasTectônicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposDeRochaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estruturasGeológicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geomorfologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agentesInternosDeFormaçãoDeRelevoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agentesExternosDeFormaçãoDeRelevoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.planaltoPlanícieEDepressãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relevoBrasileiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relevoMarinhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaçãoDeSolosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaçõesVegetaisIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaçõesVegetaisIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.osDomíniosMorfoclimáticosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.domíniosMorfoclimáticosIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.domíniosMorfoclimáticosIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questãoAmbientalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoAQuestãoAmbientalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impactosAmbientaisIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impactosAmbientaisIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impactosAmbientaisIIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impactosAmbientaisIVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pedologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aspectosPedológicosBásicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recursosNaturaisNoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.amazôniaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SegundoAMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.demografiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teoriasDemográficasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fasesDoCrescimentoVegetativoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taxasEConceitosParaEstudoDemográficoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pirâmidesEtáriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposDeMigraçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.migraçõesBrasileirasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estruturaEconômicaDaPopulaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.industrializaçãoBrasileiraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asRevoluçõesIndustriaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aIndustrializaçãoBrasileiraIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aIndustrializaçãoBrasileiraIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.urbanizaçãoMundialEBrasileiraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.principaisConceitosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitoEClassificaçãoDeCidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regiõesMetropolitanasBrasileirasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transportesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geografiaAgráriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemasAgrícolasIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemasAgrícolasIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mecanizaçãoBrasileiraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geopolíticaEAsOrdensMundiaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noçõesDeCorrentesEconômicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordensMundiaisIAVelhaORDEMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordensMundiaisIIGUERRAFRIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.globalizaçãoEconômicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blocosEconômicosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.recursosEnergéticosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recursosRenováveisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recursosNãoRenováveisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.economiaIndustrialEmExpansãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SegundoBMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eUASuperpotênciaGlobalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conflitosNaEuropaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conflitosNaMultipolaridadeAméricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conflitosNoOrienteMédioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conflitosNoExtremoOrienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japãoESuasCaracterísticasFísicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chinaAPotênciaDoSéculoXXIToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.uniãoEuropeiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bRICToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bRICSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disponibilidadeDeÁguaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem38 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem55 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem56 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem57 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem58 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem59 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem60 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem61 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem62 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem63 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem65 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem66 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem68 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem69 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem70 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem71 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem72 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem74 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem76 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem77 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem78 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem79 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem80 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem82 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem83 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem84 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem85 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem86 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem87 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem88 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem89 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem90 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem91 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem92 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem93 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem94 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem95 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem96 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem97 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem98 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem99 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem100 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem101 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem102 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem103 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem104 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem105 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharMenuItem,
            this.cursoEmVídeoToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(122, 612);
            this.menuStrip1.TabIndex = 39;
            // 
            // fecharMenuItem
            // 
            this.fecharMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.fecharMenuItem.BackColor = System.Drawing.SystemColors.ControlLight;
            this.fecharMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharMenuItem.Image")));
            this.fecharMenuItem.Name = "fecharMenuItem";
            this.fecharMenuItem.Size = new System.Drawing.Size(109, 39);
            this.fecharMenuItem.Text = "FECHAR";
            this.fecharMenuItem.Click += new System.EventHandler(this.fecharMenuItem_Click);
            // 
            // cursoEmVídeoToolStripMenuItem
            // 
            this.cursoEmVídeoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem,
            this.PrimeiroMenuItem,
            this.SegundoAMenuItem,
            this.SegundoBMenuItem});
            this.cursoEmVídeoToolStripMenuItem.Name = "cursoEmVídeoToolStripMenuItem";
            this.cursoEmVídeoToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.cursoEmVídeoToolStripMenuItem.Text = "Geografia";
            // 
            // cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem
            // 
            this.cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.orientaçãoToolStripMenuItem1,
            this.escalaToolStripMenuItem1,
            this.coordenadasGeográficasToolStripMenuItem1,
            this.projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem,
            this.projeçõesCartográficasCônicaEAzimutalToolStripMenuItem,
            this.fusoHorárioIToolStripMenuItem,
            this.fusoHorárioIIToolStripMenuItem,
            this.fusoHorárioIIIBrasilToolStripMenuItem});
            this.cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem.Name = "cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem";
            this.cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem.Size = new System.Drawing.Size(512, 26);
            this.cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem.Text = "Cartografia, Sistemas de Coordenadas e outras convenções";
            // 
            // orientaçãoToolStripMenuItem1
            // 
            this.orientaçãoToolStripMenuItem1.Name = "orientaçãoToolStripMenuItem1";
            this.orientaçãoToolStripMenuItem1.Size = new System.Drawing.Size(468, 26);
            this.orientaçãoToolStripMenuItem1.Text = "Orientação";
            this.orientaçãoToolStripMenuItem1.Click += new System.EventHandler(this.orientaçãoToolStripMenuItem1_Click);
            // 
            // escalaToolStripMenuItem1
            // 
            this.escalaToolStripMenuItem1.Name = "escalaToolStripMenuItem1";
            this.escalaToolStripMenuItem1.Size = new System.Drawing.Size(468, 26);
            this.escalaToolStripMenuItem1.Text = "Escala";
            this.escalaToolStripMenuItem1.Click += new System.EventHandler(this.escalaToolStripMenuItem1_Click);
            // 
            // coordenadasGeográficasToolStripMenuItem1
            // 
            this.coordenadasGeográficasToolStripMenuItem1.Name = "coordenadasGeográficasToolStripMenuItem1";
            this.coordenadasGeográficasToolStripMenuItem1.Size = new System.Drawing.Size(468, 26);
            this.coordenadasGeográficasToolStripMenuItem1.Text = "Coordenadas Geográficas Paralelos e Meridianos";
            this.coordenadasGeográficasToolStripMenuItem1.Click += new System.EventHandler(this.coordenadasGeográficasToolStripMenuItem1_Click);
            // 
            // projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem
            // 
            this.projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem.Name = "projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem";
            this.projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem.Size = new System.Drawing.Size(468, 26);
            this.projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem.Text = "Projeções Cartográficas: Cilíndrica -Mercator e Peters";
            this.projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem.Click += new System.EventHandler(this.projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem_Click);
            // 
            // projeçõesCartográficasCônicaEAzimutalToolStripMenuItem
            // 
            this.projeçõesCartográficasCônicaEAzimutalToolStripMenuItem.Name = "projeçõesCartográficasCônicaEAzimutalToolStripMenuItem";
            this.projeçõesCartográficasCônicaEAzimutalToolStripMenuItem.Size = new System.Drawing.Size(468, 26);
            this.projeçõesCartográficasCônicaEAzimutalToolStripMenuItem.Text = "Projeções Cartográficas: Cônica e Azimutal";
            this.projeçõesCartográficasCônicaEAzimutalToolStripMenuItem.Click += new System.EventHandler(this.projeçõesCartográficasCônicaEAzimutalToolStripMenuItem_Click);
            // 
            // fusoHorárioIToolStripMenuItem
            // 
            this.fusoHorárioIToolStripMenuItem.Name = "fusoHorárioIToolStripMenuItem";
            this.fusoHorárioIToolStripMenuItem.Size = new System.Drawing.Size(468, 26);
            this.fusoHorárioIToolStripMenuItem.Text = "Fuso Horário I";
            this.fusoHorárioIToolStripMenuItem.Click += new System.EventHandler(this.fusoHorárioIToolStripMenuItem_Click);
            // 
            // fusoHorárioIIToolStripMenuItem
            // 
            this.fusoHorárioIIToolStripMenuItem.Name = "fusoHorárioIIToolStripMenuItem";
            this.fusoHorárioIIToolStripMenuItem.Size = new System.Drawing.Size(468, 26);
            this.fusoHorárioIIToolStripMenuItem.Text = "Fuso Horário II";
            this.fusoHorárioIIToolStripMenuItem.Click += new System.EventHandler(this.fusoHorárioIIToolStripMenuItem_Click);
            // 
            // fusoHorárioIIIBrasilToolStripMenuItem
            // 
            this.fusoHorárioIIIBrasilToolStripMenuItem.Name = "fusoHorárioIIIBrasilToolStripMenuItem";
            this.fusoHorárioIIIBrasilToolStripMenuItem.Size = new System.Drawing.Size(468, 26);
            this.fusoHorárioIIIBrasilToolStripMenuItem.Text = "Fuso Horário III - Brasil";
            this.fusoHorárioIIIBrasilToolStripMenuItem.Click += new System.EventHandler(this.fusoHorárioIIIBrasilToolStripMenuItem_Click);
            // 
            // PrimeiroMenuItem
            // 
            this.PrimeiroMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.movimentosDaTerraToolStripMenuItem,
            this.climatologiaClimasEAnomaliasToolStripMenuItem,
            this.geologiaERecursosNaturaisToolStripMenuItem,
            this.geomorfologiaToolStripMenuItem,
            this.vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem,
            this.questãoAmbientalToolStripMenuItem,
            this.pedologiaToolStripMenuItem,
            this.recursosNaturaisNoBrasilToolStripMenuItem});
            this.PrimeiroMenuItem.Name = "PrimeiroMenuItem";
            this.PrimeiroMenuItem.Size = new System.Drawing.Size(512, 26);
            this.PrimeiroMenuItem.Text = "Geografia Física";
            // 
            // movimentosDaTerraToolStripMenuItem
            // 
            this.movimentosDaTerraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rotaçãoETranslaçãoToolStripMenuItem,
            this.solstíciosEEquinóciosToolStripMenuItem,
            this.zonasTérmicasEPeriélioEAfélioToolStripMenuItem,
            this.movimentoAparenteDoSolToolStripMenuItem});
            this.movimentosDaTerraToolStripMenuItem.Name = "movimentosDaTerraToolStripMenuItem";
            this.movimentosDaTerraToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.movimentosDaTerraToolStripMenuItem.Text = "Movimentos da terra";
            // 
            // rotaçãoETranslaçãoToolStripMenuItem
            // 
            this.rotaçãoETranslaçãoToolStripMenuItem.Name = "rotaçãoETranslaçãoToolStripMenuItem";
            this.rotaçãoETranslaçãoToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.rotaçãoETranslaçãoToolStripMenuItem.Text = "Rotação e Translação";
            this.rotaçãoETranslaçãoToolStripMenuItem.Click += new System.EventHandler(this.rotaçãoETranslaçãoToolStripMenuItem_Click);
            // 
            // solstíciosEEquinóciosToolStripMenuItem
            // 
            this.solstíciosEEquinóciosToolStripMenuItem.Name = "solstíciosEEquinóciosToolStripMenuItem";
            this.solstíciosEEquinóciosToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.solstíciosEEquinóciosToolStripMenuItem.Text = "Solstícios e Equinócios";
            this.solstíciosEEquinóciosToolStripMenuItem.Click += new System.EventHandler(this.solstíciosEEquinóciosToolStripMenuItem_Click);
            // 
            // zonasTérmicasEPeriélioEAfélioToolStripMenuItem
            // 
            this.zonasTérmicasEPeriélioEAfélioToolStripMenuItem.Name = "zonasTérmicasEPeriélioEAfélioToolStripMenuItem";
            this.zonasTérmicasEPeriélioEAfélioToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.zonasTérmicasEPeriélioEAfélioToolStripMenuItem.Text = "Zonas Térmicas e Periélio e Afélio";
            this.zonasTérmicasEPeriélioEAfélioToolStripMenuItem.Click += new System.EventHandler(this.zonasTérmicasEPeriélioEAfélioToolStripMenuItem_Click);
            // 
            // movimentoAparenteDoSolToolStripMenuItem
            // 
            this.movimentoAparenteDoSolToolStripMenuItem.Name = "movimentoAparenteDoSolToolStripMenuItem";
            this.movimentoAparenteDoSolToolStripMenuItem.Size = new System.Drawing.Size(322, 26);
            this.movimentoAparenteDoSolToolStripMenuItem.Text = "Movimento Aparente do Sol";
            this.movimentoAparenteDoSolToolStripMenuItem.Click += new System.EventHandler(this.movimentoAparenteDoSolToolStripMenuItem_Click);
            // 
            // climatologiaClimasEAnomaliasToolStripMenuItem
            // 
            this.climatologiaClimasEAnomaliasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oQueÉClimaToolStripMenuItem,
            this.fatoresClimáticosIIToolStripMenuItem,
            this.circulaçãoGeralDaAtmosferaIToolStripMenuItem,
            this.circulaçãoGeralDaAtmosferaIIToolStripMenuItem,
            this.tiposDeChuvaToolStripMenuItem,
            this.dinâmicaDeBrisasEMonçõesToolStripMenuItem,
            this.climasDoBrasilIToolStripMenuItem,
            this.climasDoBrasilIIToolStripMenuItem,
            this.elNiñoELaNiñaToolStripMenuItem});
            this.climatologiaClimasEAnomaliasToolStripMenuItem.Name = "climatologiaClimasEAnomaliasToolStripMenuItem";
            this.climatologiaClimasEAnomaliasToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.climatologiaClimasEAnomaliasToolStripMenuItem.Text = "Climatologia - Climas e Anomalias";
            // 
            // oQueÉClimaToolStripMenuItem
            // 
            this.oQueÉClimaToolStripMenuItem.Name = "oQueÉClimaToolStripMenuItem";
            this.oQueÉClimaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.oQueÉClimaToolStripMenuItem.Text = "O que é clima";
            this.oQueÉClimaToolStripMenuItem.Click += new System.EventHandler(this.oQueÉClimaToolStripMenuItem_Click);
            // 
            // fatoresClimáticosIIToolStripMenuItem
            // 
            this.fatoresClimáticosIIToolStripMenuItem.Name = "fatoresClimáticosIIToolStripMenuItem";
            this.fatoresClimáticosIIToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.fatoresClimáticosIIToolStripMenuItem.Text = "Fatores Climáticos II";
            this.fatoresClimáticosIIToolStripMenuItem.Click += new System.EventHandler(this.fatoresClimáticosIIToolStripMenuItem_Click);
            // 
            // circulaçãoGeralDaAtmosferaIToolStripMenuItem
            // 
            this.circulaçãoGeralDaAtmosferaIToolStripMenuItem.Name = "circulaçãoGeralDaAtmosferaIToolStripMenuItem";
            this.circulaçãoGeralDaAtmosferaIToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.circulaçãoGeralDaAtmosferaIToolStripMenuItem.Text = "Circulação Geral da Atmosfera I";
            this.circulaçãoGeralDaAtmosferaIToolStripMenuItem.Click += new System.EventHandler(this.circulaçãoGeralDaAtmosferaIToolStripMenuItem_Click);
            // 
            // circulaçãoGeralDaAtmosferaIIToolStripMenuItem
            // 
            this.circulaçãoGeralDaAtmosferaIIToolStripMenuItem.Name = "circulaçãoGeralDaAtmosferaIIToolStripMenuItem";
            this.circulaçãoGeralDaAtmosferaIIToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.circulaçãoGeralDaAtmosferaIIToolStripMenuItem.Text = "Circulação Geral da Atmosfera II";
            this.circulaçãoGeralDaAtmosferaIIToolStripMenuItem.Click += new System.EventHandler(this.circulaçãoGeralDaAtmosferaIIToolStripMenuItem_Click);
            // 
            // tiposDeChuvaToolStripMenuItem
            // 
            this.tiposDeChuvaToolStripMenuItem.Name = "tiposDeChuvaToolStripMenuItem";
            this.tiposDeChuvaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.tiposDeChuvaToolStripMenuItem.Text = "Tipos de Chuva";
            this.tiposDeChuvaToolStripMenuItem.Click += new System.EventHandler(this.tiposDeChuvaToolStripMenuItem_Click);
            // 
            // dinâmicaDeBrisasEMonçõesToolStripMenuItem
            // 
            this.dinâmicaDeBrisasEMonçõesToolStripMenuItem.Name = "dinâmicaDeBrisasEMonçõesToolStripMenuItem";
            this.dinâmicaDeBrisasEMonçõesToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.dinâmicaDeBrisasEMonçõesToolStripMenuItem.Text = "Dinâmica de Brisas e Monções";
            this.dinâmicaDeBrisasEMonçõesToolStripMenuItem.Click += new System.EventHandler(this.dinâmicaDeBrisasEMonçõesToolStripMenuItem_Click);
            // 
            // climasDoBrasilIToolStripMenuItem
            // 
            this.climasDoBrasilIToolStripMenuItem.Name = "climasDoBrasilIToolStripMenuItem";
            this.climasDoBrasilIToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.climasDoBrasilIToolStripMenuItem.Text = "Climas Do Brasil I";
            this.climasDoBrasilIToolStripMenuItem.Click += new System.EventHandler(this.climasDoBrasilIToolStripMenuItem_Click);
            // 
            // climasDoBrasilIIToolStripMenuItem
            // 
            this.climasDoBrasilIIToolStripMenuItem.Name = "climasDoBrasilIIToolStripMenuItem";
            this.climasDoBrasilIIToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.climasDoBrasilIIToolStripMenuItem.Text = "Climas Do Brasil II";
            this.climasDoBrasilIIToolStripMenuItem.Click += new System.EventHandler(this.climasDoBrasilIIToolStripMenuItem_Click);
            // 
            // elNiñoELaNiñaToolStripMenuItem
            // 
            this.elNiñoELaNiñaToolStripMenuItem.Name = "elNiñoELaNiñaToolStripMenuItem";
            this.elNiñoELaNiñaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.elNiñoELaNiñaToolStripMenuItem.Text = "El Niño e La Niña";
            this.elNiñoELaNiñaToolStripMenuItem.Click += new System.EventHandler(this.elNiñoELaNiñaToolStripMenuItem_Click);
            // 
            // geologiaERecursosNaturaisToolStripMenuItem
            // 
            this.geologiaERecursosNaturaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tempoGeológicoIToolStripMenuItem,
            this.tempoGeológicoIIToolStripMenuItem,
            this.estruturaInternaDaTerraToolStripMenuItem,
            this.placasTectônicasToolStripMenuItem,
            this.tiposDeRochaToolStripMenuItem,
            this.estruturasGeológicasToolStripMenuItem});
            this.geologiaERecursosNaturaisToolStripMenuItem.Name = "geologiaERecursosNaturaisToolStripMenuItem";
            this.geologiaERecursosNaturaisToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.geologiaERecursosNaturaisToolStripMenuItem.Text = "Geologia e Recursos Naturais";
            // 
            // tempoGeológicoIToolStripMenuItem
            // 
            this.tempoGeológicoIToolStripMenuItem.Name = "tempoGeológicoIToolStripMenuItem";
            this.tempoGeológicoIToolStripMenuItem.Size = new System.Drawing.Size(263, 26);
            this.tempoGeológicoIToolStripMenuItem.Text = "Tempo Geológico I";
            this.tempoGeológicoIToolStripMenuItem.Click += new System.EventHandler(this.tempoGeológicoIToolStripMenuItem_Click);
            // 
            // tempoGeológicoIIToolStripMenuItem
            // 
            this.tempoGeológicoIIToolStripMenuItem.Name = "tempoGeológicoIIToolStripMenuItem";
            this.tempoGeológicoIIToolStripMenuItem.Size = new System.Drawing.Size(263, 26);
            this.tempoGeológicoIIToolStripMenuItem.Text = "Tempo Geológico II";
            this.tempoGeológicoIIToolStripMenuItem.Click += new System.EventHandler(this.tempoGeológicoIIToolStripMenuItem_Click);
            // 
            // estruturaInternaDaTerraToolStripMenuItem
            // 
            this.estruturaInternaDaTerraToolStripMenuItem.Name = "estruturaInternaDaTerraToolStripMenuItem";
            this.estruturaInternaDaTerraToolStripMenuItem.Size = new System.Drawing.Size(263, 26);
            this.estruturaInternaDaTerraToolStripMenuItem.Text = "Estrutura Interna da Terra";
            this.estruturaInternaDaTerraToolStripMenuItem.Click += new System.EventHandler(this.estruturaInternaDaTerraToolStripMenuItem_Click);
            // 
            // placasTectônicasToolStripMenuItem
            // 
            this.placasTectônicasToolStripMenuItem.Name = "placasTectônicasToolStripMenuItem";
            this.placasTectônicasToolStripMenuItem.Size = new System.Drawing.Size(263, 26);
            this.placasTectônicasToolStripMenuItem.Text = "Placas Tectônicas";
            this.placasTectônicasToolStripMenuItem.Click += new System.EventHandler(this.placasTectônicasToolStripMenuItem_Click);
            // 
            // tiposDeRochaToolStripMenuItem
            // 
            this.tiposDeRochaToolStripMenuItem.Name = "tiposDeRochaToolStripMenuItem";
            this.tiposDeRochaToolStripMenuItem.Size = new System.Drawing.Size(263, 26);
            this.tiposDeRochaToolStripMenuItem.Text = "Tipos de Rocha";
            this.tiposDeRochaToolStripMenuItem.Click += new System.EventHandler(this.tiposDeRochaToolStripMenuItem_Click);
            // 
            // estruturasGeológicasToolStripMenuItem
            // 
            this.estruturasGeológicasToolStripMenuItem.Name = "estruturasGeológicasToolStripMenuItem";
            this.estruturasGeológicasToolStripMenuItem.Size = new System.Drawing.Size(263, 26);
            this.estruturasGeológicasToolStripMenuItem.Text = "Estruturas Geológicas";
            this.estruturasGeológicasToolStripMenuItem.Click += new System.EventHandler(this.estruturasGeológicasToolStripMenuItem_Click);
            // 
            // geomorfologiaToolStripMenuItem
            // 
            this.geomorfologiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agentesInternosDeFormaçãoDeRelevoToolStripMenuItem,
            this.agentesExternosDeFormaçãoDeRelevoToolStripMenuItem,
            this.planaltoPlanícieEDepressãoToolStripMenuItem,
            this.relevoBrasileiroToolStripMenuItem,
            this.relevoMarinhoToolStripMenuItem,
            this.formaçãoDeSolosToolStripMenuItem});
            this.geomorfologiaToolStripMenuItem.Name = "geomorfologiaToolStripMenuItem";
            this.geomorfologiaToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.geomorfologiaToolStripMenuItem.Text = "Geomorfologia";
            // 
            // agentesInternosDeFormaçãoDeRelevoToolStripMenuItem
            // 
            this.agentesInternosDeFormaçãoDeRelevoToolStripMenuItem.Name = "agentesInternosDeFormaçãoDeRelevoToolStripMenuItem";
            this.agentesInternosDeFormaçãoDeRelevoToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.agentesInternosDeFormaçãoDeRelevoToolStripMenuItem.Text = "Agentes Internos de Formação de Relevo";
            this.agentesInternosDeFormaçãoDeRelevoToolStripMenuItem.Click += new System.EventHandler(this.agentesInternosDeFormaçãoDeRelevoToolStripMenuItem_Click);
            // 
            // agentesExternosDeFormaçãoDeRelevoToolStripMenuItem
            // 
            this.agentesExternosDeFormaçãoDeRelevoToolStripMenuItem.Name = "agentesExternosDeFormaçãoDeRelevoToolStripMenuItem";
            this.agentesExternosDeFormaçãoDeRelevoToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.agentesExternosDeFormaçãoDeRelevoToolStripMenuItem.Text = "Agentes Externos de Formação de Relevo";
            this.agentesExternosDeFormaçãoDeRelevoToolStripMenuItem.Click += new System.EventHandler(this.agentesExternosDeFormaçãoDeRelevoToolStripMenuItem_Click);
            // 
            // planaltoPlanícieEDepressãoToolStripMenuItem
            // 
            this.planaltoPlanícieEDepressãoToolStripMenuItem.Name = "planaltoPlanícieEDepressãoToolStripMenuItem";
            this.planaltoPlanícieEDepressãoToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.planaltoPlanícieEDepressãoToolStripMenuItem.Text = "Planalto, Planície e Depressão";
            this.planaltoPlanícieEDepressãoToolStripMenuItem.Click += new System.EventHandler(this.planaltoPlanícieEDepressãoToolStripMenuItem_Click);
            // 
            // relevoBrasileiroToolStripMenuItem
            // 
            this.relevoBrasileiroToolStripMenuItem.Name = "relevoBrasileiroToolStripMenuItem";
            this.relevoBrasileiroToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.relevoBrasileiroToolStripMenuItem.Text = "Relevo Brasileiro";
            this.relevoBrasileiroToolStripMenuItem.Click += new System.EventHandler(this.relevoBrasileiroToolStripMenuItem_Click);
            // 
            // relevoMarinhoToolStripMenuItem
            // 
            this.relevoMarinhoToolStripMenuItem.Name = "relevoMarinhoToolStripMenuItem";
            this.relevoMarinhoToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.relevoMarinhoToolStripMenuItem.Text = "Relevo Marinho";
            this.relevoMarinhoToolStripMenuItem.Click += new System.EventHandler(this.relevoMarinhoToolStripMenuItem_Click);
            // 
            // formaçãoDeSolosToolStripMenuItem
            // 
            this.formaçãoDeSolosToolStripMenuItem.Name = "formaçãoDeSolosToolStripMenuItem";
            this.formaçãoDeSolosToolStripMenuItem.Size = new System.Drawing.Size(384, 26);
            this.formaçãoDeSolosToolStripMenuItem.Text = "Formação de Solos";
            this.formaçãoDeSolosToolStripMenuItem.Click += new System.EventHandler(this.formaçãoDeSolosToolStripMenuItem_Click);
            // 
            // vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem
            // 
            this.vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formaçõesVegetaisIToolStripMenuItem,
            this.formaçõesVegetaisIIToolStripMenuItem,
            this.formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem,
            this.osDomíniosMorfoclimáticosToolStripMenuItem});
            this.vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem.Name = "vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem";
            this.vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem.Text = "Vegetação e domínio morfoclimáticos";
            // 
            // formaçõesVegetaisIToolStripMenuItem
            // 
            this.formaçõesVegetaisIToolStripMenuItem.Name = "formaçõesVegetaisIToolStripMenuItem";
            this.formaçõesVegetaisIToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.formaçõesVegetaisIToolStripMenuItem.Text = "Formações Vegetais I";
            this.formaçõesVegetaisIToolStripMenuItem.Click += new System.EventHandler(this.formaçõesVegetaisIToolStripMenuItem_Click);
            // 
            // formaçõesVegetaisIIToolStripMenuItem
            // 
            this.formaçõesVegetaisIIToolStripMenuItem.Name = "formaçõesVegetaisIIToolStripMenuItem";
            this.formaçõesVegetaisIIToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.formaçõesVegetaisIIToolStripMenuItem.Text = "Formações Vegetais II";
            this.formaçõesVegetaisIIToolStripMenuItem.Click += new System.EventHandler(this.formaçõesVegetaisIIToolStripMenuItem_Click);
            // 
            // formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem
            // 
            this.formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem.Name = "formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem";
            this.formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem.Text = "Formações Vegetais e Biomas Brasileiros";
            this.formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem.Click += new System.EventHandler(this.formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem_Click);
            // 
            // osDomíniosMorfoclimáticosToolStripMenuItem
            // 
            this.osDomíniosMorfoclimáticosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.domíniosMorfoclimáticosIToolStripMenuItem,
            this.domíniosMorfoclimáticosIIToolStripMenuItem});
            this.osDomíniosMorfoclimáticosToolStripMenuItem.Name = "osDomíniosMorfoclimáticosToolStripMenuItem";
            this.osDomíniosMorfoclimáticosToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.osDomíniosMorfoclimáticosToolStripMenuItem.Text = "Os Domínios Morfoclimáticos";
            // 
            // domíniosMorfoclimáticosIToolStripMenuItem
            // 
            this.domíniosMorfoclimáticosIToolStripMenuItem.Name = "domíniosMorfoclimáticosIToolStripMenuItem";
            this.domíniosMorfoclimáticosIToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.domíniosMorfoclimáticosIToolStripMenuItem.Text = "Domínios Morfoclimáticos I";
            this.domíniosMorfoclimáticosIToolStripMenuItem.Click += new System.EventHandler(this.domíniosMorfoclimáticosIToolStripMenuItem_Click);
            // 
            // domíniosMorfoclimáticosIIToolStripMenuItem
            // 
            this.domíniosMorfoclimáticosIIToolStripMenuItem.Name = "domíniosMorfoclimáticosIIToolStripMenuItem";
            this.domíniosMorfoclimáticosIIToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.domíniosMorfoclimáticosIIToolStripMenuItem.Text = "Domínios Morfoclimáticos II";
            this.domíniosMorfoclimáticosIIToolStripMenuItem.Click += new System.EventHandler(this.domíniosMorfoclimáticosIIToolStripMenuItem_Click);
            // 
            // questãoAmbientalToolStripMenuItem
            // 
            this.questãoAmbientalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoAQuestãoAmbientalToolStripMenuItem,
            this.impactosAmbientaisIToolStripMenuItem,
            this.impactosAmbientaisIIToolStripMenuItem,
            this.impactosAmbientaisIIIToolStripMenuItem,
            this.impactosAmbientaisIVToolStripMenuItem});
            this.questãoAmbientalToolStripMenuItem.Name = "questãoAmbientalToolStripMenuItem";
            this.questãoAmbientalToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.questãoAmbientalToolStripMenuItem.Text = "Questão Ambiental";
            // 
            // introduçãoAQuestãoAmbientalToolStripMenuItem
            // 
            this.introduçãoAQuestãoAmbientalToolStripMenuItem.Name = "introduçãoAQuestãoAmbientalToolStripMenuItem";
            this.introduçãoAQuestãoAmbientalToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.introduçãoAQuestãoAmbientalToolStripMenuItem.Text = "Introdução a questão ambiental";
            this.introduçãoAQuestãoAmbientalToolStripMenuItem.Click += new System.EventHandler(this.introduçãoAQuestãoAmbientalToolStripMenuItem_Click);
            // 
            // impactosAmbientaisIToolStripMenuItem
            // 
            this.impactosAmbientaisIToolStripMenuItem.Name = "impactosAmbientaisIToolStripMenuItem";
            this.impactosAmbientaisIToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.impactosAmbientaisIToolStripMenuItem.Text = "Impactos ambientais I";
            this.impactosAmbientaisIToolStripMenuItem.Click += new System.EventHandler(this.impactosAmbientaisIToolStripMenuItem_Click);
            // 
            // impactosAmbientaisIIToolStripMenuItem
            // 
            this.impactosAmbientaisIIToolStripMenuItem.Name = "impactosAmbientaisIIToolStripMenuItem";
            this.impactosAmbientaisIIToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.impactosAmbientaisIIToolStripMenuItem.Text = "Impactos ambientais II";
            this.impactosAmbientaisIIToolStripMenuItem.Click += new System.EventHandler(this.impactosAmbientaisIIToolStripMenuItem_Click);
            // 
            // impactosAmbientaisIIIToolStripMenuItem
            // 
            this.impactosAmbientaisIIIToolStripMenuItem.Name = "impactosAmbientaisIIIToolStripMenuItem";
            this.impactosAmbientaisIIIToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.impactosAmbientaisIIIToolStripMenuItem.Text = "Impactos ambientais III";
            this.impactosAmbientaisIIIToolStripMenuItem.Click += new System.EventHandler(this.impactosAmbientaisIIIToolStripMenuItem_Click);
            // 
            // impactosAmbientaisIVToolStripMenuItem
            // 
            this.impactosAmbientaisIVToolStripMenuItem.Name = "impactosAmbientaisIVToolStripMenuItem";
            this.impactosAmbientaisIVToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.impactosAmbientaisIVToolStripMenuItem.Text = "Impactos ambientais IV";
            this.impactosAmbientaisIVToolStripMenuItem.Click += new System.EventHandler(this.impactosAmbientaisIVToolStripMenuItem_Click);
            // 
            // pedologiaToolStripMenuItem
            // 
            this.pedologiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aspectosPedológicosBásicosToolStripMenuItem});
            this.pedologiaToolStripMenuItem.Name = "pedologiaToolStripMenuItem";
            this.pedologiaToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.pedologiaToolStripMenuItem.Text = "Pedologia";
            // 
            // aspectosPedológicosBásicosToolStripMenuItem
            // 
            this.aspectosPedológicosBásicosToolStripMenuItem.Name = "aspectosPedológicosBásicosToolStripMenuItem";
            this.aspectosPedológicosBásicosToolStripMenuItem.Size = new System.Drawing.Size(300, 26);
            this.aspectosPedológicosBásicosToolStripMenuItem.Text = "Aspectos Pedológicos Básicos";
            this.aspectosPedológicosBásicosToolStripMenuItem.Click += new System.EventHandler(this.aspectosPedológicosBásicosToolStripMenuItem_Click);
            // 
            // recursosNaturaisNoBrasilToolStripMenuItem
            // 
            this.recursosNaturaisNoBrasilToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.amazôniaToolStripMenuItem});
            this.recursosNaturaisNoBrasilToolStripMenuItem.Name = "recursosNaturaisNoBrasilToolStripMenuItem";
            this.recursosNaturaisNoBrasilToolStripMenuItem.Size = new System.Drawing.Size(358, 26);
            this.recursosNaturaisNoBrasilToolStripMenuItem.Text = "Recursos Naturais no Brasil";
            // 
            // amazôniaToolStripMenuItem
            // 
            this.amazôniaToolStripMenuItem.Name = "amazôniaToolStripMenuItem";
            this.amazôniaToolStripMenuItem.Size = new System.Drawing.Size(151, 26);
            this.amazôniaToolStripMenuItem.Text = "Amazônia";
            this.amazôniaToolStripMenuItem.Click += new System.EventHandler(this.amazôniaToolStripMenuItem_Click);
            // 
            // SegundoAMenuItem
            // 
            this.SegundoAMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.demografiaToolStripMenuItem,
            this.industrializaçãoBrasileiraToolStripMenuItem,
            this.urbanizaçãoMundialEBrasileiraToolStripMenuItem,
            this.geografiaAgráriaToolStripMenuItem,
            this.geopolíticaEAsOrdensMundiaisToolStripMenuItem,
            this.recursosEnergéticosToolStripMenuItem,
            this.economiaIndustrialEmExpansãoToolStripMenuItem});
            this.SegundoAMenuItem.Name = "SegundoAMenuItem";
            this.SegundoAMenuItem.Size = new System.Drawing.Size(512, 26);
            this.SegundoAMenuItem.Text = "Geografia Humana e Econômica";
            // 
            // demografiaToolStripMenuItem
            // 
            this.demografiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.teoriasDemográficasToolStripMenuItem,
            this.fasesDoCrescimentoVegetativoToolStripMenuItem,
            this.taxasEConceitosParaEstudoDemográficoToolStripMenuItem,
            this.pirâmidesEtáriasToolStripMenuItem,
            this.tiposDeMigraçãoToolStripMenuItem,
            this.migraçõesBrasileirasToolStripMenuItem,
            this.estruturaEconômicaDaPopulaçãoToolStripMenuItem});
            this.demografiaToolStripMenuItem.Name = "demografiaToolStripMenuItem";
            this.demografiaToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.demografiaToolStripMenuItem.Text = "Demografia";
            // 
            // teoriasDemográficasToolStripMenuItem
            // 
            this.teoriasDemográficasToolStripMenuItem.Name = "teoriasDemográficasToolStripMenuItem";
            this.teoriasDemográficasToolStripMenuItem.Size = new System.Drawing.Size(396, 26);
            this.teoriasDemográficasToolStripMenuItem.Text = "Teorias Demográficas";
            this.teoriasDemográficasToolStripMenuItem.Click += new System.EventHandler(this.teoriasDemográficasToolStripMenuItem_Click);
            // 
            // fasesDoCrescimentoVegetativoToolStripMenuItem
            // 
            this.fasesDoCrescimentoVegetativoToolStripMenuItem.Name = "fasesDoCrescimentoVegetativoToolStripMenuItem";
            this.fasesDoCrescimentoVegetativoToolStripMenuItem.Size = new System.Drawing.Size(396, 26);
            this.fasesDoCrescimentoVegetativoToolStripMenuItem.Text = "Fases do Crescimento Vegetativo";
            this.fasesDoCrescimentoVegetativoToolStripMenuItem.Click += new System.EventHandler(this.fasesDoCrescimentoVegetativoToolStripMenuItem_Click);
            // 
            // taxasEConceitosParaEstudoDemográficoToolStripMenuItem
            // 
            this.taxasEConceitosParaEstudoDemográficoToolStripMenuItem.Name = "taxasEConceitosParaEstudoDemográficoToolStripMenuItem";
            this.taxasEConceitosParaEstudoDemográficoToolStripMenuItem.Size = new System.Drawing.Size(396, 26);
            this.taxasEConceitosParaEstudoDemográficoToolStripMenuItem.Text = "Taxas e conceitos para estudo demográfico";
            this.taxasEConceitosParaEstudoDemográficoToolStripMenuItem.Click += new System.EventHandler(this.taxasEConceitosParaEstudoDemográficoToolStripMenuItem_Click);
            // 
            // pirâmidesEtáriasToolStripMenuItem
            // 
            this.pirâmidesEtáriasToolStripMenuItem.Name = "pirâmidesEtáriasToolStripMenuItem";
            this.pirâmidesEtáriasToolStripMenuItem.Size = new System.Drawing.Size(396, 26);
            this.pirâmidesEtáriasToolStripMenuItem.Text = "Pirâmides Etárias";
            this.pirâmidesEtáriasToolStripMenuItem.Click += new System.EventHandler(this.pirâmidesEtáriasToolStripMenuItem_Click);
            // 
            // tiposDeMigraçãoToolStripMenuItem
            // 
            this.tiposDeMigraçãoToolStripMenuItem.Name = "tiposDeMigraçãoToolStripMenuItem";
            this.tiposDeMigraçãoToolStripMenuItem.Size = new System.Drawing.Size(396, 26);
            this.tiposDeMigraçãoToolStripMenuItem.Text = "Tipos de Migração";
            this.tiposDeMigraçãoToolStripMenuItem.Click += new System.EventHandler(this.tiposDeMigraçãoToolStripMenuItem_Click);
            // 
            // migraçõesBrasileirasToolStripMenuItem
            // 
            this.migraçõesBrasileirasToolStripMenuItem.Name = "migraçõesBrasileirasToolStripMenuItem";
            this.migraçõesBrasileirasToolStripMenuItem.Size = new System.Drawing.Size(396, 26);
            this.migraçõesBrasileirasToolStripMenuItem.Text = "Migrações Brasileiras";
            this.migraçõesBrasileirasToolStripMenuItem.Click += new System.EventHandler(this.migraçõesBrasileirasToolStripMenuItem_Click);
            // 
            // estruturaEconômicaDaPopulaçãoToolStripMenuItem
            // 
            this.estruturaEconômicaDaPopulaçãoToolStripMenuItem.Name = "estruturaEconômicaDaPopulaçãoToolStripMenuItem";
            this.estruturaEconômicaDaPopulaçãoToolStripMenuItem.Size = new System.Drawing.Size(396, 26);
            this.estruturaEconômicaDaPopulaçãoToolStripMenuItem.Text = "Estrutura Econômica da População";
            this.estruturaEconômicaDaPopulaçãoToolStripMenuItem.Click += new System.EventHandler(this.estruturaEconômicaDaPopulaçãoToolStripMenuItem_Click);
            // 
            // industrializaçãoBrasileiraToolStripMenuItem
            // 
            this.industrializaçãoBrasileiraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.asRevoluçõesIndustriaisToolStripMenuItem,
            this.aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem,
            this.modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem,
            this.conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem,
            this.aIndustrializaçãoBrasileiraIToolStripMenuItem,
            this.aIndustrializaçãoBrasileiraIIToolStripMenuItem});
            this.industrializaçãoBrasileiraToolStripMenuItem.Name = "industrializaçãoBrasileiraToolStripMenuItem";
            this.industrializaçãoBrasileiraToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.industrializaçãoBrasileiraToolStripMenuItem.Text = "Industrialização Mundial Brasileira";
            // 
            // asRevoluçõesIndustriaisToolStripMenuItem
            // 
            this.asRevoluçõesIndustriaisToolStripMenuItem.Name = "asRevoluçõesIndustriaisToolStripMenuItem";
            this.asRevoluçõesIndustriaisToolStripMenuItem.Size = new System.Drawing.Size(583, 26);
            this.asRevoluçõesIndustriaisToolStripMenuItem.Text = "As Revoluções Industriais";
            this.asRevoluçõesIndustriaisToolStripMenuItem.Click += new System.EventHandler(this.asRevoluçõesIndustriaisToolStripMenuItem_Click);
            // 
            // aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem
            // 
            this.aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem.Name = "aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem";
            this.aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem.Size = new System.Drawing.Size(583, 26);
            this.aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem.Text = "A terceira revolução Industrial: Meio Técnico Científico Informacional";
            this.aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem.Click += new System.EventHandler(this.aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem_Click);
            // 
            // modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem
            // 
            this.modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem.Name = "modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem";
            this.modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem.Size = new System.Drawing.Size(583, 26);
            this.modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem.Text = "Modos de Produção: Taylorismo, Fordismo e Toyotismo";
            this.modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem.Click += new System.EventHandler(this.modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem_Click);
            // 
            // conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem
            // 
            this.conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem.Name = "conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem";
            this.conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem.Size = new System.Drawing.Size(583, 26);
            this.conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem.Text = "Conceitos Econômicos: Cartel, Truste, Joint Venture e etc.";
            this.conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem.Click += new System.EventHandler(this.conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem_Click);
            // 
            // aIndustrializaçãoBrasileiraIToolStripMenuItem
            // 
            this.aIndustrializaçãoBrasileiraIToolStripMenuItem.Name = "aIndustrializaçãoBrasileiraIToolStripMenuItem";
            this.aIndustrializaçãoBrasileiraIToolStripMenuItem.Size = new System.Drawing.Size(583, 26);
            this.aIndustrializaçãoBrasileiraIToolStripMenuItem.Text = "A industrialização Brasileira I";
            this.aIndustrializaçãoBrasileiraIToolStripMenuItem.Click += new System.EventHandler(this.aIndustrializaçãoBrasileiraIToolStripMenuItem_Click);
            // 
            // aIndustrializaçãoBrasileiraIIToolStripMenuItem
            // 
            this.aIndustrializaçãoBrasileiraIIToolStripMenuItem.Name = "aIndustrializaçãoBrasileiraIIToolStripMenuItem";
            this.aIndustrializaçãoBrasileiraIIToolStripMenuItem.Size = new System.Drawing.Size(583, 26);
            this.aIndustrializaçãoBrasileiraIIToolStripMenuItem.Text = "A industrialização Brasileira II";
            this.aIndustrializaçãoBrasileiraIIToolStripMenuItem.Click += new System.EventHandler(this.aIndustrializaçãoBrasileiraIIToolStripMenuItem_Click);
            // 
            // urbanizaçãoMundialEBrasileiraToolStripMenuItem
            // 
            this.urbanizaçãoMundialEBrasileiraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.principaisConceitosToolStripMenuItem,
            this.conceitoEClassificaçãoDeCidadesToolStripMenuItem,
            this.regiõesMetropolitanasBrasileirasToolStripMenuItem,
            this.transportesToolStripMenuItem});
            this.urbanizaçãoMundialEBrasileiraToolStripMenuItem.Name = "urbanizaçãoMundialEBrasileiraToolStripMenuItem";
            this.urbanizaçãoMundialEBrasileiraToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.urbanizaçãoMundialEBrasileiraToolStripMenuItem.Text = "Urbanização Mundial e Brasileira";
            // 
            // principaisConceitosToolStripMenuItem
            // 
            this.principaisConceitosToolStripMenuItem.Name = "principaisConceitosToolStripMenuItem";
            this.principaisConceitosToolStripMenuItem.Size = new System.Drawing.Size(340, 26);
            this.principaisConceitosToolStripMenuItem.Text = " Principais Conceitos";
            this.principaisConceitosToolStripMenuItem.Click += new System.EventHandler(this.principaisConceitosToolStripMenuItem_Click);
            // 
            // conceitoEClassificaçãoDeCidadesToolStripMenuItem
            // 
            this.conceitoEClassificaçãoDeCidadesToolStripMenuItem.Name = "conceitoEClassificaçãoDeCidadesToolStripMenuItem";
            this.conceitoEClassificaçãoDeCidadesToolStripMenuItem.Size = new System.Drawing.Size(340, 26);
            this.conceitoEClassificaçãoDeCidadesToolStripMenuItem.Text = "Conceito e Classificação de Cidades";
            this.conceitoEClassificaçãoDeCidadesToolStripMenuItem.Click += new System.EventHandler(this.conceitoEClassificaçãoDeCidadesToolStripMenuItem_Click);
            // 
            // regiõesMetropolitanasBrasileirasToolStripMenuItem
            // 
            this.regiõesMetropolitanasBrasileirasToolStripMenuItem.Name = "regiõesMetropolitanasBrasileirasToolStripMenuItem";
            this.regiõesMetropolitanasBrasileirasToolStripMenuItem.Size = new System.Drawing.Size(340, 26);
            this.regiõesMetropolitanasBrasileirasToolStripMenuItem.Text = " Regiões Metropolitanas Brasileiras";
            this.regiõesMetropolitanasBrasileirasToolStripMenuItem.Click += new System.EventHandler(this.regiõesMetropolitanasBrasileirasToolStripMenuItem_Click);
            // 
            // transportesToolStripMenuItem
            // 
            this.transportesToolStripMenuItem.Name = "transportesToolStripMenuItem";
            this.transportesToolStripMenuItem.Size = new System.Drawing.Size(340, 26);
            this.transportesToolStripMenuItem.Text = "Transportes";
            this.transportesToolStripMenuItem.Click += new System.EventHandler(this.transportesToolStripMenuItem_Click);
            // 
            // geografiaAgráriaToolStripMenuItem
            // 
            this.geografiaAgráriaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sistemasAgrícolasIToolStripMenuItem,
            this.sistemasAgrícolasIIToolStripMenuItem,
            this.mecanizaçãoBrasileiraToolStripMenuItem});
            this.geografiaAgráriaToolStripMenuItem.Name = "geografiaAgráriaToolStripMenuItem";
            this.geografiaAgráriaToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.geografiaAgráriaToolStripMenuItem.Text = "Geografia Agrária";
            // 
            // sistemasAgrícolasIToolStripMenuItem
            // 
            this.sistemasAgrícolasIToolStripMenuItem.Name = "sistemasAgrícolasIToolStripMenuItem";
            this.sistemasAgrícolasIToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.sistemasAgrícolasIToolStripMenuItem.Text = "Sistemas Agrícolas I";
            this.sistemasAgrícolasIToolStripMenuItem.Click += new System.EventHandler(this.sistemasAgrícolasIToolStripMenuItem_Click);
            // 
            // sistemasAgrícolasIIToolStripMenuItem
            // 
            this.sistemasAgrícolasIIToolStripMenuItem.Name = "sistemasAgrícolasIIToolStripMenuItem";
            this.sistemasAgrícolasIIToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.sistemasAgrícolasIIToolStripMenuItem.Text = "Sistemas Agrícolas II";
            this.sistemasAgrícolasIIToolStripMenuItem.Click += new System.EventHandler(this.sistemasAgrícolasIIToolStripMenuItem_Click);
            // 
            // mecanizaçãoBrasileiraToolStripMenuItem
            // 
            this.mecanizaçãoBrasileiraToolStripMenuItem.Name = "mecanizaçãoBrasileiraToolStripMenuItem";
            this.mecanizaçãoBrasileiraToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.mecanizaçãoBrasileiraToolStripMenuItem.Text = "Mecanização Brasileira";
            this.mecanizaçãoBrasileiraToolStripMenuItem.Click += new System.EventHandler(this.mecanizaçãoBrasileiraToolStripMenuItem_Click);
            // 
            // geopolíticaEAsOrdensMundiaisToolStripMenuItem
            // 
            this.geopolíticaEAsOrdensMundiaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noçõesDeCorrentesEconômicasToolStripMenuItem,
            this.ordensMundiaisIAVelhaORDEMToolStripMenuItem,
            this.ordensMundiaisIIGUERRAFRIAToolStripMenuItem,
            this.ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem,
            this.globalizaçãoEconômicaToolStripMenuItem,
            this.blocosEconômicosToolStripMenuItem1});
            this.geopolíticaEAsOrdensMundiaisToolStripMenuItem.Name = "geopolíticaEAsOrdensMundiaisToolStripMenuItem";
            this.geopolíticaEAsOrdensMundiaisToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.geopolíticaEAsOrdensMundiaisToolStripMenuItem.Text = "Geopolítica e as ordens mundiais";
            // 
            // noçõesDeCorrentesEconômicasToolStripMenuItem
            // 
            this.noçõesDeCorrentesEconômicasToolStripMenuItem.Name = "noçõesDeCorrentesEconômicasToolStripMenuItem";
            this.noçõesDeCorrentesEconômicasToolStripMenuItem.Size = new System.Drawing.Size(426, 26);
            this.noçõesDeCorrentesEconômicasToolStripMenuItem.Text = "Noções de Correntes Econômicas";
            this.noçõesDeCorrentesEconômicasToolStripMenuItem.Click += new System.EventHandler(this.noçõesDeCorrentesEconômicasToolStripMenuItem_Click);
            // 
            // ordensMundiaisIAVelhaORDEMToolStripMenuItem
            // 
            this.ordensMundiaisIAVelhaORDEMToolStripMenuItem.Name = "ordensMundiaisIAVelhaORDEMToolStripMenuItem";
            this.ordensMundiaisIAVelhaORDEMToolStripMenuItem.Size = new System.Drawing.Size(426, 26);
            this.ordensMundiaisIAVelhaORDEMToolStripMenuItem.Text = "Ordens Mundiais I: A velha ORDEM";
            this.ordensMundiaisIAVelhaORDEMToolStripMenuItem.Click += new System.EventHandler(this.ordensMundiaisIAVelhaORDEMToolStripMenuItem_Click);
            // 
            // ordensMundiaisIIGUERRAFRIAToolStripMenuItem
            // 
            this.ordensMundiaisIIGUERRAFRIAToolStripMenuItem.Name = "ordensMundiaisIIGUERRAFRIAToolStripMenuItem";
            this.ordensMundiaisIIGUERRAFRIAToolStripMenuItem.Size = new System.Drawing.Size(426, 26);
            this.ordensMundiaisIIGUERRAFRIAToolStripMenuItem.Text = "Ordens Mundiais II:GUERRA FRIA";
            this.ordensMundiaisIIGUERRAFRIAToolStripMenuItem.Click += new System.EventHandler(this.ordensMundiaisIIGUERRAFRIAToolStripMenuItem_Click);
            // 
            // ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem
            // 
            this.ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem.Name = "ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem";
            this.ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem.Size = new System.Drawing.Size(426, 26);
            this.ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem.Text = "Ordens Mundiais III: A NOVA ORDEM MUNDIAL";
            this.ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem.Click += new System.EventHandler(this.ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem_Click);
            // 
            // globalizaçãoEconômicaToolStripMenuItem
            // 
            this.globalizaçãoEconômicaToolStripMenuItem.Name = "globalizaçãoEconômicaToolStripMenuItem";
            this.globalizaçãoEconômicaToolStripMenuItem.Size = new System.Drawing.Size(426, 26);
            this.globalizaçãoEconômicaToolStripMenuItem.Text = "Globalização Econômica";
            this.globalizaçãoEconômicaToolStripMenuItem.Click += new System.EventHandler(this.globalizaçãoEconômicaToolStripMenuItem_Click);
            // 
            // blocosEconômicosToolStripMenuItem1
            // 
            this.blocosEconômicosToolStripMenuItem1.Name = "blocosEconômicosToolStripMenuItem1";
            this.blocosEconômicosToolStripMenuItem1.Size = new System.Drawing.Size(426, 26);
            this.blocosEconômicosToolStripMenuItem1.Text = "Blocos Econômicos";
            this.blocosEconômicosToolStripMenuItem1.Click += new System.EventHandler(this.blocosEconômicosToolStripMenuItem1_Click);
            // 
            // recursosEnergéticosToolStripMenuItem
            // 
            this.recursosEnergéticosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.recursosRenováveisToolStripMenuItem,
            this.recursosNãoRenováveisToolStripMenuItem});
            this.recursosEnergéticosToolStripMenuItem.Name = "recursosEnergéticosToolStripMenuItem";
            this.recursosEnergéticosToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.recursosEnergéticosToolStripMenuItem.Text = "Recursos Energéticos";
            // 
            // recursosRenováveisToolStripMenuItem
            // 
            this.recursosRenováveisToolStripMenuItem.Name = "recursosRenováveisToolStripMenuItem";
            this.recursosRenováveisToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.recursosRenováveisToolStripMenuItem.Text = "Recursos Renováveis";
            this.recursosRenováveisToolStripMenuItem.Click += new System.EventHandler(this.recursosRenováveisToolStripMenuItem_Click);
            // 
            // recursosNãoRenováveisToolStripMenuItem
            // 
            this.recursosNãoRenováveisToolStripMenuItem.Name = "recursosNãoRenováveisToolStripMenuItem";
            this.recursosNãoRenováveisToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.recursosNãoRenováveisToolStripMenuItem.Text = "Recursos Não Renováveis";
            this.recursosNãoRenováveisToolStripMenuItem.Click += new System.EventHandler(this.recursosNãoRenováveisToolStripMenuItem_Click);
            // 
            // economiaIndustrialEmExpansãoToolStripMenuItem
            // 
            this.economiaIndustrialEmExpansãoToolStripMenuItem.Name = "economiaIndustrialEmExpansãoToolStripMenuItem";
            this.economiaIndustrialEmExpansãoToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.economiaIndustrialEmExpansãoToolStripMenuItem.Text = "Economia Industrial em Expansão";
            // 
            // SegundoBMenuItem
            // 
            this.SegundoBMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eUASuperpotênciaGlobalToolStripMenuItem,
            this.conflitosNaEuropaToolStripMenuItem,
            this.conflitosNaMultipolaridadeAméricaToolStripMenuItem,
            this.conflitosNoOrienteMédioToolStripMenuItem,
            this.conflitosNoExtremoOrienteToolStripMenuItem,
            this.japãoESuasCaracterísticasFísicasToolStripMenuItem,
            this.chinaAPotênciaDoSéculoXXIToolStripMenuItem1,
            this.uniãoEuropeiaToolStripMenuItem,
            this.bRICToolStripMenuItem,
            this.bRICSToolStripMenuItem,
            this.disponibilidadeDeÁguaToolStripMenuItem});
            this.SegundoBMenuItem.Name = "SegundoBMenuItem";
            this.SegundoBMenuItem.Size = new System.Drawing.Size(512, 26);
            this.SegundoBMenuItem.Text = "Geopolítica";
            // 
            // eUASuperpotênciaGlobalToolStripMenuItem
            // 
            this.eUASuperpotênciaGlobalToolStripMenuItem.Name = "eUASuperpotênciaGlobalToolStripMenuItem";
            this.eUASuperpotênciaGlobalToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.eUASuperpotênciaGlobalToolStripMenuItem.Text = "EUA: Superpotência Global";
            this.eUASuperpotênciaGlobalToolStripMenuItem.Click += new System.EventHandler(this.eUASuperpotênciaGlobalToolStripMenuItem_Click);
            // 
            // conflitosNaEuropaToolStripMenuItem
            // 
            this.conflitosNaEuropaToolStripMenuItem.Name = "conflitosNaEuropaToolStripMenuItem";
            this.conflitosNaEuropaToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.conflitosNaEuropaToolStripMenuItem.Text = "Conflitos na Europa";
            this.conflitosNaEuropaToolStripMenuItem.Click += new System.EventHandler(this.conflitosNaEuropaToolStripMenuItem_Click);
            // 
            // conflitosNaMultipolaridadeAméricaToolStripMenuItem
            // 
            this.conflitosNaMultipolaridadeAméricaToolStripMenuItem.Name = "conflitosNaMultipolaridadeAméricaToolStripMenuItem";
            this.conflitosNaMultipolaridadeAméricaToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.conflitosNaMultipolaridadeAméricaToolStripMenuItem.Text = "Conflitos na Multipolaridade - América";
            this.conflitosNaMultipolaridadeAméricaToolStripMenuItem.Click += new System.EventHandler(this.conflitosNaMultipolaridadeAméricaToolStripMenuItem_Click);
            // 
            // conflitosNoOrienteMédioToolStripMenuItem
            // 
            this.conflitosNoOrienteMédioToolStripMenuItem.Name = "conflitosNoOrienteMédioToolStripMenuItem";
            this.conflitosNoOrienteMédioToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.conflitosNoOrienteMédioToolStripMenuItem.Text = "Conflitos no Oriente Médio";
            this.conflitosNoOrienteMédioToolStripMenuItem.Click += new System.EventHandler(this.conflitosNoOrienteMédioToolStripMenuItem_Click);
            // 
            // conflitosNoExtremoOrienteToolStripMenuItem
            // 
            this.conflitosNoExtremoOrienteToolStripMenuItem.Name = "conflitosNoExtremoOrienteToolStripMenuItem";
            this.conflitosNoExtremoOrienteToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.conflitosNoExtremoOrienteToolStripMenuItem.Text = "Conflitos no Extremo Oriente";
            this.conflitosNoExtremoOrienteToolStripMenuItem.Click += new System.EventHandler(this.conflitosNoExtremoOrienteToolStripMenuItem_Click);
            // 
            // japãoESuasCaracterísticasFísicasToolStripMenuItem
            // 
            this.japãoESuasCaracterísticasFísicasToolStripMenuItem.Name = "japãoESuasCaracterísticasFísicasToolStripMenuItem";
            this.japãoESuasCaracterísticasFísicasToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.japãoESuasCaracterísticasFísicasToolStripMenuItem.Text = "Japão e Suas Características Físicas";
            this.japãoESuasCaracterísticasFísicasToolStripMenuItem.Click += new System.EventHandler(this.japãoESuasCaracterísticasFísicasToolStripMenuItem_Click);
            // 
            // chinaAPotênciaDoSéculoXXIToolStripMenuItem1
            // 
            this.chinaAPotênciaDoSéculoXXIToolStripMenuItem1.Name = "chinaAPotênciaDoSéculoXXIToolStripMenuItem1";
            this.chinaAPotênciaDoSéculoXXIToolStripMenuItem1.Size = new System.Drawing.Size(362, 26);
            this.chinaAPotênciaDoSéculoXXIToolStripMenuItem1.Text = "China a Potência do Século XXI";
            this.chinaAPotênciaDoSéculoXXIToolStripMenuItem1.Click += new System.EventHandler(this.chinaAPotênciaDoSéculoXXIToolStripMenuItem1_Click);
            // 
            // uniãoEuropeiaToolStripMenuItem
            // 
            this.uniãoEuropeiaToolStripMenuItem.Name = "uniãoEuropeiaToolStripMenuItem";
            this.uniãoEuropeiaToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.uniãoEuropeiaToolStripMenuItem.Text = "União Europeia";
            this.uniãoEuropeiaToolStripMenuItem.Click += new System.EventHandler(this.uniãoEuropeiaToolStripMenuItem_Click);
            // 
            // bRICToolStripMenuItem
            // 
            this.bRICToolStripMenuItem.Name = "bRICToolStripMenuItem";
            this.bRICToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.bRICToolStripMenuItem.Text = "BRIC";
            this.bRICToolStripMenuItem.Click += new System.EventHandler(this.bRICToolStripMenuItem_Click);
            // 
            // bRICSToolStripMenuItem
            // 
            this.bRICSToolStripMenuItem.Name = "bRICSToolStripMenuItem";
            this.bRICSToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.bRICSToolStripMenuItem.Text = "BRICS";
            this.bRICSToolStripMenuItem.Click += new System.EventHandler(this.bRICSToolStripMenuItem_Click);
            // 
            // disponibilidadeDeÁguaToolStripMenuItem
            // 
            this.disponibilidadeDeÁguaToolStripMenuItem.Name = "disponibilidadeDeÁguaToolStripMenuItem";
            this.disponibilidadeDeÁguaToolStripMenuItem.Size = new System.Drawing.Size(362, 26);
            this.disponibilidadeDeÁguaToolStripMenuItem.Text = "Disponibilidade de Água";
            this.disponibilidadeDeÁguaToolStripMenuItem.Click += new System.EventHandler(this.disponibilidadeDeÁguaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.Tomato;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem11,
            this.toolStripMenuItem58,
            this.toolStripMenuItem94});
            this.toolStripMenuItem1.ForeColor = System.Drawing.Color.Black;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(109, 25);
            this.toolStripMenuItem1.Text = "Perguntas";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem10});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(512, 26);
            this.toolStripMenuItem2.Text = "Cartografia, Sistemas de Coordenadas e outras convenções";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(468, 26);
            this.toolStripMenuItem3.Text = "Orientação";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(468, 26);
            this.toolStripMenuItem4.Text = "Escala";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(468, 26);
            this.toolStripMenuItem5.Text = "Coordenadas Geográficas Paralelos e Meridianos";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(468, 26);
            this.toolStripMenuItem6.Text = "Projeções Cartográficas: Cilíndrica -Mercator e Peters";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(468, 26);
            this.toolStripMenuItem7.Text = "Projeções Cartográficas: Cônica e Azimutal";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(468, 26);
            this.toolStripMenuItem8.Text = "Fuso Horário";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(468, 26);
            this.toolStripMenuItem10.Text = "Fuso Horário - Brasil";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem17,
            this.toolStripMenuItem27,
            this.toolStripMenuItem34,
            this.toolStripMenuItem41,
            this.toolStripMenuItem48,
            this.toolStripMenuItem54,
            this.toolStripMenuItem56});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(512, 26);
            this.toolStripMenuItem11.Text = "Geografia Física";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.toolStripMenuItem15,
            this.toolStripMenuItem16});
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem12.Text = "Movimentos da terra";
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem13.Text = "Rotação e Translação";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem14.Text = "Solstícios e Equinócios";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem15.Text = "Zonas Térmicas e Periélio e Afélio";
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(322, 26);
            this.toolStripMenuItem16.Text = "Movimento Aparente do Sol";
            this.toolStripMenuItem16.Click += new System.EventHandler(this.toolStripMenuItem16_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem18,
            this.toolStripMenuItem19,
            this.toolStripMenuItem20,
            this.toolStripMenuItem22,
            this.toolStripMenuItem23,
            this.toolStripMenuItem24,
            this.toolStripMenuItem26});
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem17.Text = "Climatologia - Climas e Anomalias";
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem18.Text = "O que é clima";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem19.Text = "Fatores Climáticos";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem20.Text = "Circulação Geral da Atmosfera";
            this.toolStripMenuItem20.Click += new System.EventHandler(this.toolStripMenuItem20_Click);
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem22.Text = "Tipos de Chuva";
            this.toolStripMenuItem22.Click += new System.EventHandler(this.toolStripMenuItem22_Click);
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem23.Text = "Dinâmica de Brisas e Monções";
            this.toolStripMenuItem23.Click += new System.EventHandler(this.toolStripMenuItem23_Click);
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem24.Text = "Climas Do Brasil";
            this.toolStripMenuItem24.Click += new System.EventHandler(this.toolStripMenuItem24_Click);
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem26.Text = "El Niño e La Niña";
            this.toolStripMenuItem26.Click += new System.EventHandler(this.toolStripMenuItem26_Click);
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem28,
            this.toolStripMenuItem30,
            this.toolStripMenuItem31,
            this.toolStripMenuItem32,
            this.toolStripMenuItem33});
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem27.Text = "Geologia e Recursos Naturais";
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem28.Text = "Tempo Geológico";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.toolStripMenuItem28_Click);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem30.Text = "Estrutura Interna da Terra";
            this.toolStripMenuItem30.Click += new System.EventHandler(this.toolStripMenuItem30_Click);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem31.Text = "Placas Tectônicas";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.toolStripMenuItem31_Click);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem32.Text = "Tipos de Rocha";
            this.toolStripMenuItem32.Click += new System.EventHandler(this.toolStripMenuItem32_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem33.Text = "Estruturas Geológicas";
            this.toolStripMenuItem33.Click += new System.EventHandler(this.toolStripMenuItem33_Click);
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem35,
            this.toolStripMenuItem36,
            this.toolStripMenuItem37,
            this.toolStripMenuItem38,
            this.toolStripMenuItem39,
            this.toolStripMenuItem40});
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem34.Text = "Geomorfologia";
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem35.Text = "Agentes Internos de Formação de Relevo";
            this.toolStripMenuItem35.Click += new System.EventHandler(this.toolStripMenuItem35_Click);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem36.Text = "Agentes Externos de Formação de Relevo";
            this.toolStripMenuItem36.Click += new System.EventHandler(this.toolStripMenuItem36_Click);
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem37.Text = "Planalto, Planície e Depressão";
            this.toolStripMenuItem37.Click += new System.EventHandler(this.toolStripMenuItem37_Click);
            // 
            // toolStripMenuItem38
            // 
            this.toolStripMenuItem38.Name = "toolStripMenuItem38";
            this.toolStripMenuItem38.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem38.Text = "Relevo Brasileiro";
            this.toolStripMenuItem38.Click += new System.EventHandler(this.toolStripMenuItem38_Click);
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem39.Text = "Relevo Marinho";
            this.toolStripMenuItem39.Click += new System.EventHandler(this.toolStripMenuItem39_Click);
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(384, 26);
            this.toolStripMenuItem40.Text = "Formação de Solos";
            this.toolStripMenuItem40.Click += new System.EventHandler(this.toolStripMenuItem40_Click);
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem42,
            this.toolStripMenuItem44,
            this.toolStripMenuItem45});
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem41.Text = "Vegetação e domínio morfoclimáticos";
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(375, 26);
            this.toolStripMenuItem42.Text = "Formações Vegetais";
            this.toolStripMenuItem42.Click += new System.EventHandler(this.toolStripMenuItem42_Click);
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(375, 26);
            this.toolStripMenuItem44.Text = "Formações Vegetais e Biomas Brasileiros";
            this.toolStripMenuItem44.Click += new System.EventHandler(this.toolStripMenuItem44_Click);
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(375, 26);
            this.toolStripMenuItem45.Text = "Os Domínios Morfoclimáticos";
            this.toolStripMenuItem45.Click += new System.EventHandler(this.toolStripMenuItem45_Click);
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem50});
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem48.Text = "Questão Ambiental";
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(231, 26);
            this.toolStripMenuItem50.Text = "Impactos ambientais";
            this.toolStripMenuItem50.Click += new System.EventHandler(this.toolStripMenuItem50_Click);
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem55});
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem54.Text = "Pedologia";
            // 
            // toolStripMenuItem55
            // 
            this.toolStripMenuItem55.Name = "toolStripMenuItem55";
            this.toolStripMenuItem55.Size = new System.Drawing.Size(300, 26);
            this.toolStripMenuItem55.Text = "Aspectos Pedológicos Básicos";
            this.toolStripMenuItem55.Click += new System.EventHandler(this.toolStripMenuItem55_Click);
            // 
            // toolStripMenuItem56
            // 
            this.toolStripMenuItem56.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem57});
            this.toolStripMenuItem56.Name = "toolStripMenuItem56";
            this.toolStripMenuItem56.Size = new System.Drawing.Size(358, 26);
            this.toolStripMenuItem56.Text = "Recursos Naturais no Brasil";
            // 
            // toolStripMenuItem57
            // 
            this.toolStripMenuItem57.Name = "toolStripMenuItem57";
            this.toolStripMenuItem57.Size = new System.Drawing.Size(151, 26);
            this.toolStripMenuItem57.Text = "Amazônia";
            this.toolStripMenuItem57.Click += new System.EventHandler(this.toolStripMenuItem57_Click);
            // 
            // toolStripMenuItem58
            // 
            this.toolStripMenuItem58.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem59,
            this.toolStripMenuItem67,
            this.toolStripMenuItem74,
            this.toolStripMenuItem79,
            this.toolStripMenuItem83,
            this.toolStripMenuItem90,
            this.toolStripMenuItem93});
            this.toolStripMenuItem58.Name = "toolStripMenuItem58";
            this.toolStripMenuItem58.Size = new System.Drawing.Size(512, 26);
            this.toolStripMenuItem58.Text = "Geografia Humana e Econômica";
            // 
            // toolStripMenuItem59
            // 
            this.toolStripMenuItem59.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem60,
            this.toolStripMenuItem61,
            this.toolStripMenuItem62,
            this.toolStripMenuItem63,
            this.toolStripMenuItem64,
            this.toolStripMenuItem65,
            this.toolStripMenuItem66});
            this.toolStripMenuItem59.Name = "toolStripMenuItem59";
            this.toolStripMenuItem59.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem59.Text = "Demografia";
            // 
            // toolStripMenuItem60
            // 
            this.toolStripMenuItem60.Name = "toolStripMenuItem60";
            this.toolStripMenuItem60.Size = new System.Drawing.Size(396, 26);
            this.toolStripMenuItem60.Text = "Teorias Demográficas";
            this.toolStripMenuItem60.Click += new System.EventHandler(this.toolStripMenuItem60_Click);
            // 
            // toolStripMenuItem61
            // 
            this.toolStripMenuItem61.Name = "toolStripMenuItem61";
            this.toolStripMenuItem61.Size = new System.Drawing.Size(396, 26);
            this.toolStripMenuItem61.Text = "Fases do Crescimento Vegetativo";
            this.toolStripMenuItem61.Click += new System.EventHandler(this.toolStripMenuItem61_Click);
            // 
            // toolStripMenuItem62
            // 
            this.toolStripMenuItem62.Name = "toolStripMenuItem62";
            this.toolStripMenuItem62.Size = new System.Drawing.Size(396, 26);
            this.toolStripMenuItem62.Text = "Taxas e conceitos para estudo demográfico";
            this.toolStripMenuItem62.Click += new System.EventHandler(this.toolStripMenuItem62_Click);
            // 
            // toolStripMenuItem63
            // 
            this.toolStripMenuItem63.Name = "toolStripMenuItem63";
            this.toolStripMenuItem63.Size = new System.Drawing.Size(396, 26);
            this.toolStripMenuItem63.Text = "Pirâmides Etárias";
            this.toolStripMenuItem63.Click += new System.EventHandler(this.toolStripMenuItem63_Click);
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(396, 26);
            this.toolStripMenuItem64.Text = "Tipos de Migração";
            this.toolStripMenuItem64.Click += new System.EventHandler(this.toolStripMenuItem64_Click);
            // 
            // toolStripMenuItem65
            // 
            this.toolStripMenuItem65.Name = "toolStripMenuItem65";
            this.toolStripMenuItem65.Size = new System.Drawing.Size(396, 26);
            this.toolStripMenuItem65.Text = "Migrações Brasileiras";
            this.toolStripMenuItem65.Click += new System.EventHandler(this.toolStripMenuItem65_Click);
            // 
            // toolStripMenuItem66
            // 
            this.toolStripMenuItem66.Name = "toolStripMenuItem66";
            this.toolStripMenuItem66.Size = new System.Drawing.Size(396, 26);
            this.toolStripMenuItem66.Text = "Estrutura Econômica da População";
            this.toolStripMenuItem66.Click += new System.EventHandler(this.toolStripMenuItem66_Click);
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem68,
            this.toolStripMenuItem69,
            this.toolStripMenuItem70,
            this.toolStripMenuItem71,
            this.toolStripMenuItem72});
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem67.Text = "Industrialização Mundial Brasileira";
            // 
            // toolStripMenuItem68
            // 
            this.toolStripMenuItem68.Name = "toolStripMenuItem68";
            this.toolStripMenuItem68.Size = new System.Drawing.Size(583, 26);
            this.toolStripMenuItem68.Text = "As Revoluções Industriais";
            this.toolStripMenuItem68.Click += new System.EventHandler(this.toolStripMenuItem68_Click);
            // 
            // toolStripMenuItem69
            // 
            this.toolStripMenuItem69.Name = "toolStripMenuItem69";
            this.toolStripMenuItem69.Size = new System.Drawing.Size(583, 26);
            this.toolStripMenuItem69.Text = "A terceira revolução Industrial: Meio Técnico Científico Informacional";
            this.toolStripMenuItem69.Click += new System.EventHandler(this.toolStripMenuItem69_Click);
            // 
            // toolStripMenuItem70
            // 
            this.toolStripMenuItem70.Name = "toolStripMenuItem70";
            this.toolStripMenuItem70.Size = new System.Drawing.Size(583, 26);
            this.toolStripMenuItem70.Text = "Modos de Produção: Taylorismo, Fordismo e Toyotismo";
            this.toolStripMenuItem70.Click += new System.EventHandler(this.toolStripMenuItem70_Click);
            // 
            // toolStripMenuItem71
            // 
            this.toolStripMenuItem71.Name = "toolStripMenuItem71";
            this.toolStripMenuItem71.Size = new System.Drawing.Size(583, 26);
            this.toolStripMenuItem71.Text = "Conceitos Econômicos: Cartel, Truste, Joint Venture e etc.";
            this.toolStripMenuItem71.Click += new System.EventHandler(this.toolStripMenuItem71_Click);
            // 
            // toolStripMenuItem72
            // 
            this.toolStripMenuItem72.Name = "toolStripMenuItem72";
            this.toolStripMenuItem72.Size = new System.Drawing.Size(583, 26);
            this.toolStripMenuItem72.Text = "A industrialização Brasileira";
            this.toolStripMenuItem72.Click += new System.EventHandler(this.toolStripMenuItem72_Click);
            // 
            // toolStripMenuItem74
            // 
            this.toolStripMenuItem74.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem76,
            this.toolStripMenuItem77,
            this.toolStripMenuItem78});
            this.toolStripMenuItem74.Name = "toolStripMenuItem74";
            this.toolStripMenuItem74.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem74.Text = "Urbanização Mundial e Brasileira";
            // 
            // toolStripMenuItem76
            // 
            this.toolStripMenuItem76.Name = "toolStripMenuItem76";
            this.toolStripMenuItem76.Size = new System.Drawing.Size(340, 26);
            this.toolStripMenuItem76.Text = "Conceito e Classificação de Cidades";
            this.toolStripMenuItem76.Click += new System.EventHandler(this.toolStripMenuItem76_Click);
            // 
            // toolStripMenuItem77
            // 
            this.toolStripMenuItem77.Name = "toolStripMenuItem77";
            this.toolStripMenuItem77.Size = new System.Drawing.Size(340, 26);
            this.toolStripMenuItem77.Text = "Regiões Metropolitanas Brasileiras";
            this.toolStripMenuItem77.Click += new System.EventHandler(this.toolStripMenuItem77_Click);
            // 
            // toolStripMenuItem78
            // 
            this.toolStripMenuItem78.Name = "toolStripMenuItem78";
            this.toolStripMenuItem78.Size = new System.Drawing.Size(340, 26);
            this.toolStripMenuItem78.Text = "Transportes";
            this.toolStripMenuItem78.Click += new System.EventHandler(this.toolStripMenuItem78_Click);
            // 
            // toolStripMenuItem79
            // 
            this.toolStripMenuItem79.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem80,
            this.toolStripMenuItem82});
            this.toolStripMenuItem79.Name = "toolStripMenuItem79";
            this.toolStripMenuItem79.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem79.Text = "Geografia Agrária";
            // 
            // toolStripMenuItem80
            // 
            this.toolStripMenuItem80.Name = "toolStripMenuItem80";
            this.toolStripMenuItem80.Size = new System.Drawing.Size(244, 26);
            this.toolStripMenuItem80.Text = "Sistemas Agrícolas";
            this.toolStripMenuItem80.Click += new System.EventHandler(this.toolStripMenuItem80_Click);
            // 
            // toolStripMenuItem82
            // 
            this.toolStripMenuItem82.Name = "toolStripMenuItem82";
            this.toolStripMenuItem82.Size = new System.Drawing.Size(244, 26);
            this.toolStripMenuItem82.Text = "Mecanização Brasileira";
            this.toolStripMenuItem82.Click += new System.EventHandler(this.toolStripMenuItem82_Click);
            // 
            // toolStripMenuItem83
            // 
            this.toolStripMenuItem83.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem84,
            this.toolStripMenuItem85,
            this.toolStripMenuItem86,
            this.toolStripMenuItem87,
            this.toolStripMenuItem88,
            this.toolStripMenuItem89});
            this.toolStripMenuItem83.Name = "toolStripMenuItem83";
            this.toolStripMenuItem83.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem83.Text = "Geopolítica e as ordens mundiais";
            // 
            // toolStripMenuItem84
            // 
            this.toolStripMenuItem84.Name = "toolStripMenuItem84";
            this.toolStripMenuItem84.Size = new System.Drawing.Size(426, 26);
            this.toolStripMenuItem84.Text = "Noções de Correntes Econômicas";
            this.toolStripMenuItem84.Click += new System.EventHandler(this.toolStripMenuItem84_Click);
            // 
            // toolStripMenuItem85
            // 
            this.toolStripMenuItem85.Name = "toolStripMenuItem85";
            this.toolStripMenuItem85.Size = new System.Drawing.Size(426, 26);
            this.toolStripMenuItem85.Text = "Ordens Mundiais I: A velha ORDEM";
            this.toolStripMenuItem85.Click += new System.EventHandler(this.toolStripMenuItem85_Click);
            // 
            // toolStripMenuItem86
            // 
            this.toolStripMenuItem86.Name = "toolStripMenuItem86";
            this.toolStripMenuItem86.Size = new System.Drawing.Size(426, 26);
            this.toolStripMenuItem86.Text = "Ordens Mundiais II: GUERRA FRIA";
            this.toolStripMenuItem86.Click += new System.EventHandler(this.toolStripMenuItem86_Click);
            // 
            // toolStripMenuItem87
            // 
            this.toolStripMenuItem87.Name = "toolStripMenuItem87";
            this.toolStripMenuItem87.Size = new System.Drawing.Size(426, 26);
            this.toolStripMenuItem87.Text = "Ordens Mundiais III: A NOVA ORDEM MUNDIAL";
            this.toolStripMenuItem87.Click += new System.EventHandler(this.toolStripMenuItem87_Click);
            // 
            // toolStripMenuItem88
            // 
            this.toolStripMenuItem88.Name = "toolStripMenuItem88";
            this.toolStripMenuItem88.Size = new System.Drawing.Size(426, 26);
            this.toolStripMenuItem88.Text = "Globalização Econômica";
            this.toolStripMenuItem88.Click += new System.EventHandler(this.toolStripMenuItem88_Click);
            // 
            // toolStripMenuItem89
            // 
            this.toolStripMenuItem89.Name = "toolStripMenuItem89";
            this.toolStripMenuItem89.Size = new System.Drawing.Size(426, 26);
            this.toolStripMenuItem89.Text = "Blocos Econômicos";
            this.toolStripMenuItem89.Click += new System.EventHandler(this.toolStripMenuItem89_Click);
            // 
            // toolStripMenuItem90
            // 
            this.toolStripMenuItem90.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem91,
            this.toolStripMenuItem92});
            this.toolStripMenuItem90.Name = "toolStripMenuItem90";
            this.toolStripMenuItem90.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem90.Text = "Recursos Energéticos";
            // 
            // toolStripMenuItem91
            // 
            this.toolStripMenuItem91.Name = "toolStripMenuItem91";
            this.toolStripMenuItem91.Size = new System.Drawing.Size(266, 26);
            this.toolStripMenuItem91.Text = "Recursos Renováveis";
            this.toolStripMenuItem91.Click += new System.EventHandler(this.toolStripMenuItem91_Click);
            // 
            // toolStripMenuItem92
            // 
            this.toolStripMenuItem92.Name = "toolStripMenuItem92";
            this.toolStripMenuItem92.Size = new System.Drawing.Size(266, 26);
            this.toolStripMenuItem92.Text = "Recursos Não Renováveis";
            this.toolStripMenuItem92.Click += new System.EventHandler(this.toolStripMenuItem92_Click);
            // 
            // toolStripMenuItem93
            // 
            this.toolStripMenuItem93.Name = "toolStripMenuItem93";
            this.toolStripMenuItem93.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem93.Text = "Economia Industrial em Expansão";
            this.toolStripMenuItem93.Click += new System.EventHandler(this.toolStripMenuItem93_Click);
            // 
            // toolStripMenuItem94
            // 
            this.toolStripMenuItem94.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem95,
            this.toolStripMenuItem96,
            this.toolStripMenuItem97,
            this.toolStripMenuItem98,
            this.toolStripMenuItem99,
            this.toolStripMenuItem100,
            this.toolStripMenuItem101,
            this.toolStripMenuItem102,
            this.toolStripMenuItem103,
            this.toolStripMenuItem104,
            this.toolStripMenuItem105});
            this.toolStripMenuItem94.Name = "toolStripMenuItem94";
            this.toolStripMenuItem94.Size = new System.Drawing.Size(512, 26);
            this.toolStripMenuItem94.Text = "Geopolítica";
            // 
            // toolStripMenuItem95
            // 
            this.toolStripMenuItem95.Name = "toolStripMenuItem95";
            this.toolStripMenuItem95.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem95.Text = "EUA: Superpotência Global";
            this.toolStripMenuItem95.Click += new System.EventHandler(this.toolStripMenuItem95_Click);
            // 
            // toolStripMenuItem96
            // 
            this.toolStripMenuItem96.Name = "toolStripMenuItem96";
            this.toolStripMenuItem96.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem96.Text = "Conflitos na Europa";
            this.toolStripMenuItem96.Click += new System.EventHandler(this.toolStripMenuItem96_Click);
            // 
            // toolStripMenuItem97
            // 
            this.toolStripMenuItem97.Name = "toolStripMenuItem97";
            this.toolStripMenuItem97.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem97.Text = "Conflitos na Multipolaridade - América";
            this.toolStripMenuItem97.Click += new System.EventHandler(this.toolStripMenuItem97_Click);
            // 
            // toolStripMenuItem98
            // 
            this.toolStripMenuItem98.Name = "toolStripMenuItem98";
            this.toolStripMenuItem98.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem98.Text = "Conflitos no Oriente Médio";
            this.toolStripMenuItem98.Click += new System.EventHandler(this.toolStripMenuItem98_Click);
            // 
            // toolStripMenuItem99
            // 
            this.toolStripMenuItem99.Name = "toolStripMenuItem99";
            this.toolStripMenuItem99.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem99.Text = "Conflitos no Extremo Oriente";
            this.toolStripMenuItem99.Click += new System.EventHandler(this.toolStripMenuItem99_Click);
            // 
            // toolStripMenuItem100
            // 
            this.toolStripMenuItem100.Name = "toolStripMenuItem100";
            this.toolStripMenuItem100.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem100.Text = "Japão e Suas Características Físicas";
            this.toolStripMenuItem100.Click += new System.EventHandler(this.toolStripMenuItem100_Click);
            // 
            // toolStripMenuItem101
            // 
            this.toolStripMenuItem101.Name = "toolStripMenuItem101";
            this.toolStripMenuItem101.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem101.Text = "China a Potência do Século XXI";
            this.toolStripMenuItem101.Click += new System.EventHandler(this.toolStripMenuItem101_Click);
            // 
            // toolStripMenuItem102
            // 
            this.toolStripMenuItem102.Name = "toolStripMenuItem102";
            this.toolStripMenuItem102.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem102.Text = "União Europeia";
            this.toolStripMenuItem102.Click += new System.EventHandler(this.toolStripMenuItem102_Click);
            // 
            // toolStripMenuItem103
            // 
            this.toolStripMenuItem103.Name = "toolStripMenuItem103";
            this.toolStripMenuItem103.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem103.Text = "BRIC";
            this.toolStripMenuItem103.Click += new System.EventHandler(this.toolStripMenuItem103_Click);
            // 
            // toolStripMenuItem104
            // 
            this.toolStripMenuItem104.Name = "toolStripMenuItem104";
            this.toolStripMenuItem104.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem104.Text = "BRICS";
            this.toolStripMenuItem104.Click += new System.EventHandler(this.toolStripMenuItem104_Click);
            // 
            // toolStripMenuItem105
            // 
            this.toolStripMenuItem105.Name = "toolStripMenuItem105";
            this.toolStripMenuItem105.Size = new System.Drawing.Size(362, 26);
            this.toolStripMenuItem105.Text = "Disponibilidade de Água";
            this.toolStripMenuItem105.Click += new System.EventHandler(this.toolStripMenuItem105_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(914, 612);
            this.sfoPlayer.TabIndex = 41;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(914, 612);
            this.PictureCSharp.TabIndex = 42;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(914, 612);
            this.panelQuiz.TabIndex = 65;
            // 
            // FrmGeo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmGeo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmJava";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fecharMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cursoEmVídeoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PrimeiroMenuItem;
        private System.Windows.Forms.ToolStripMenuItem climatologiaClimasEAnomaliasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geologiaERecursosNaturaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geomorfologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pedologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recursosNaturaisNoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SegundoAMenuItem;
        private System.Windows.Forms.ToolStripMenuItem demografiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem economiaIndustrialEmExpansãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem industrializaçãoBrasileiraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem urbanizaçãoMundialEBrasileiraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SegundoBMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conflitosNaEuropaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conflitosNaMultipolaridadeAméricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conflitosNoOrienteMédioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eUASuperpotênciaGlobalToolStripMenuItem;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem oQueÉClimaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoresClimáticosIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circulaçãoGeralDaAtmosferaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circulaçãoGeralDaAtmosferaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposDeChuvaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dinâmicaDeBrisasEMonçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem climasDoBrasilIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem climasDoBrasilIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem elNiñoELaNiñaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tempoGeológicoIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tempoGeológicoIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estruturaInternaDaTerraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem placasTectônicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposDeRochaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estruturasGeológicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agentesInternosDeFormaçãoDeRelevoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agentesExternosDeFormaçãoDeRelevoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem planaltoPlanícieEDepressãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relevoBrasileiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relevoMarinhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formaçãoDeSolosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vegetaçãoEDomínioMorfoclimáticosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formaçõesVegetaisIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formaçõesVegetaisIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem osDomíniosMorfoclimáticosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem domíniosMorfoclimáticosIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem domíniosMorfoclimáticosIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cartografiaSistemasDeCoordenadasEOutrasConvençõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orientaçãoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem escalaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem coordenadasGeográficasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projeçõesCartográficasCônicaEAzimutalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fusoHorárioIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fusoHorárioIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fusoHorárioIIIBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentosDaTerraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rotaçãoETranslaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem solstíciosEEquinóciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zonasTérmicasEPeriélioEAfélioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoAparenteDoSolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questãoAmbientalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoAQuestãoAmbientalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impactosAmbientaisIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impactosAmbientaisIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impactosAmbientaisIIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impactosAmbientaisIVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aspectosPedológicosBásicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem amazôniaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teoriasDemográficasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fasesDoCrescimentoVegetativoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taxasEConceitosParaEstudoDemográficoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pirâmidesEtáriasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposDeMigraçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem migraçõesBrasileirasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estruturaEconômicaDaPopulaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asRevoluçõesIndustriaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aIndustrializaçãoBrasileiraIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aIndustrializaçãoBrasileiraIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem principaisConceitosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transportesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regiõesMetropolitanasBrasileirasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitoEClassificaçãoDeCidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geografiaAgráriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemasAgrícolasIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemasAgrícolasIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mecanizaçãoBrasileiraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geopolíticaEAsOrdensMundiaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noçõesDeCorrentesEconômicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordensMundiaisIAVelhaORDEMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordensMundiaisIIGUERRAFRIAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem globalizaçãoEconômicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blocosEconômicosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem recursosEnergéticosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recursosRenováveisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recursosNãoRenováveisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japãoESuasCaracterísticasFísicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uniãoEuropeiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bRICToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bRICSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disponibilidadeDeÁguaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conflitosNoExtremoOrienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chinaAPotênciaDoSéculoXXIToolStripMenuItem1;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem57;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem58;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem59;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem60;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem61;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem62;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem63;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem65;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem66;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem68;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem69;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem70;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem71;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem72;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem74;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem76;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem77;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem78;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem79;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem80;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem82;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem83;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem84;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem85;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem86;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem87;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem88;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem89;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem90;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem91;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem92;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem93;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem94;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem95;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem96;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem97;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem98;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem99;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem100;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem101;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem102;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem103;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem104;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem105;
    }
}