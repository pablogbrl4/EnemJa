﻿namespace CursoVideo.View.Videos
{
    partial class FrmPort
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPort));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fecharMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cursoEmVídeoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.históriaDaInternetToolItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interpretaçãoDeTextosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.figurasDeLinguagemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aula01ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aula02ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.perguntasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interpretaçãoDeTextosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.figurasDeLinguagemToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.literaturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoÀLiteraturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quinhentismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.barrocoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arcadismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oRomantismoNoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poesiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prosaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.realismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.naturalismoImpressionismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parnasianismoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.simbolismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.préModernismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.semanaDeArteModernaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vanguardasEuropeiasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cubismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dadaísmoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expressionismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fauvismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.futurismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.surrealismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modernismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ªFaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ªFasePoesiaModernaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ªFaseRomanceDe30ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ªFaseGeraçãoDe45ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.concretismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.literaturaPortuguesaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trovadorismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cantigasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.humanismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renascimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.classicismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.perguntasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.quinhentismoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem149 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem150 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem151 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem153 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem154 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem155 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem156 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem157 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem158 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem159 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem160 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem161 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem162 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem163 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem164 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem165 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem166 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem167 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem168 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem169 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem170 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem171 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem172 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem173 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem174 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem175 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem178 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem179 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem180 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem181 = new System.Windows.Forms.ToolStripMenuItem();
            this.siteCompletoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.perguntasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem60 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem65 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem70 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem75 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem78 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem81 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem82 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem85 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem89 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem123 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem124 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem131 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem135 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem136 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem137 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem138 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem139 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem140 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem144 = new System.Windows.Forms.ToolStripMenuItem();
            this.asDivisõesDaGramáticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.morfologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.substantivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.advérbiosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.artigoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conjunçõesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.numeraisEInterjeiçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classesGramaticaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pronomesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.verbosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIIToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIVToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVIToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVIIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteXIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteXIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteXIIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteXIVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.semânticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte03ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte04ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fonéticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte03ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte04ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.craseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte03ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte04ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.ortografiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.fonologiaEAcentuaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acentuaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.ortografiaAcentuaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte03ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.sintaxeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposDeSujeitoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.osTermosDaOraçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oraçãoFormaçãoEPeríodoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoSimplesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.adjuntoAdnominalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oSSToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.complementosNominaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.apostoEVocativoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.complementosVerbaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoCompostoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.oSSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.oSAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte03ToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.oSAToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte01ToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte02ToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.oSADToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parte2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.oCAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eRRADOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oCSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regênciaNominalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regênciaVerbalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.concordânciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.concordânciaVerbalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIIToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIVToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.concordânciaNominalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIIToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.predicaçãoVerbaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verbosTransitivosDiretosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verbosTransitivosIndiretosEBitransitivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verbosIntransitivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verbosDeLigaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colocaçãoPronominalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.parte03ToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.pontuaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.redaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dissertaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIIToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIVToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteVToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tópicosFrasaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIIToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharMenuItem,
            this.cursoEmVídeoToolStripMenuItem,
            this.literaturaToolStripMenuItem,
            this.siteCompletoMenuItem,
            this.redaçãoToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(122, 612);
            this.menuStrip1.TabIndex = 36;
            // 
            // fecharMenuItem
            // 
            this.fecharMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.fecharMenuItem.BackColor = System.Drawing.SystemColors.ControlLight;
            this.fecharMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharMenuItem.Image")));
            this.fecharMenuItem.Name = "fecharMenuItem";
            this.fecharMenuItem.Size = new System.Drawing.Size(109, 39);
            this.fecharMenuItem.Text = "FECHAR";
            this.fecharMenuItem.Click += new System.EventHandler(this.fecharMenuItem_Click);
            // 
            // cursoEmVídeoToolStripMenuItem
            // 
            this.cursoEmVídeoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.históriaDaInternetToolItem,
            this.figurasDeLinguagemToolStripMenuItem,
            this.perguntasToolStripMenuItem});
            this.cursoEmVídeoToolStripMenuItem.Name = "cursoEmVídeoToolStripMenuItem";
            this.cursoEmVídeoToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.cursoEmVídeoToolStripMenuItem.Text = "Português";
            // 
            // históriaDaInternetToolItem
            // 
            this.históriaDaInternetToolItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.interpretaçãoDeTextosToolStripMenuItem});
            this.históriaDaInternetToolItem.ForeColor = System.Drawing.Color.Red;
            this.históriaDaInternetToolItem.Name = "históriaDaInternetToolItem";
            this.históriaDaInternetToolItem.Size = new System.Drawing.Size(254, 26);
            this.históriaDaInternetToolItem.Text = "Interpretação de Textos";
            // 
            // interpretaçãoDeTextosToolStripMenuItem
            // 
            this.interpretaçãoDeTextosToolStripMenuItem.Name = "interpretaçãoDeTextosToolStripMenuItem";
            this.interpretaçãoDeTextosToolStripMenuItem.Size = new System.Drawing.Size(254, 26);
            this.interpretaçãoDeTextosToolStripMenuItem.Text = "Interpretação de Textos";
            this.interpretaçãoDeTextosToolStripMenuItem.Click += new System.EventHandler(this.interpretaçãoDeTextosToolStripMenuItem_Click);
            // 
            // figurasDeLinguagemToolStripMenuItem
            // 
            this.figurasDeLinguagemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aula01ToolStripMenuItem,
            this.aula02ToolStripMenuItem});
            this.figurasDeLinguagemToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.figurasDeLinguagemToolStripMenuItem.Name = "figurasDeLinguagemToolStripMenuItem";
            this.figurasDeLinguagemToolStripMenuItem.Size = new System.Drawing.Size(254, 26);
            this.figurasDeLinguagemToolStripMenuItem.Text = "Figuras de Linguagem";
            // 
            // aula01ToolStripMenuItem
            // 
            this.aula01ToolStripMenuItem.Name = "aula01ToolStripMenuItem";
            this.aula01ToolStripMenuItem.Size = new System.Drawing.Size(134, 26);
            this.aula01ToolStripMenuItem.Text = "Aula 01";
            this.aula01ToolStripMenuItem.Click += new System.EventHandler(this.aula01ToolStripMenuItem_Click);
            // 
            // aula02ToolStripMenuItem
            // 
            this.aula02ToolStripMenuItem.Name = "aula02ToolStripMenuItem";
            this.aula02ToolStripMenuItem.Size = new System.Drawing.Size(134, 26);
            this.aula02ToolStripMenuItem.Text = "Aula 02";
            this.aula02ToolStripMenuItem.Click += new System.EventHandler(this.aula02ToolStripMenuItem_Click);
            // 
            // perguntasToolStripMenuItem
            // 
            this.perguntasToolStripMenuItem.BackColor = System.Drawing.Color.Tomato;
            this.perguntasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.interpretaçãoDeTextosToolStripMenuItem1,
            this.figurasDeLinguagemToolStripMenuItem1});
            this.perguntasToolStripMenuItem.Name = "perguntasToolStripMenuItem";
            this.perguntasToolStripMenuItem.Size = new System.Drawing.Size(254, 26);
            this.perguntasToolStripMenuItem.Text = "Perguntas";
            // 
            // interpretaçãoDeTextosToolStripMenuItem1
            // 
            this.interpretaçãoDeTextosToolStripMenuItem1.Name = "interpretaçãoDeTextosToolStripMenuItem1";
            this.interpretaçãoDeTextosToolStripMenuItem1.Size = new System.Drawing.Size(254, 26);
            this.interpretaçãoDeTextosToolStripMenuItem1.Text = "Interpretação de Textos";
            this.interpretaçãoDeTextosToolStripMenuItem1.Click += new System.EventHandler(this.interpretaçãoDeTextosToolStripMenuItem1_Click);
            // 
            // figurasDeLinguagemToolStripMenuItem1
            // 
            this.figurasDeLinguagemToolStripMenuItem1.Name = "figurasDeLinguagemToolStripMenuItem1";
            this.figurasDeLinguagemToolStripMenuItem1.Size = new System.Drawing.Size(254, 26);
            this.figurasDeLinguagemToolStripMenuItem1.Text = "Figuras de Linguagem";
            this.figurasDeLinguagemToolStripMenuItem1.Click += new System.EventHandler(this.figurasDeLinguagemToolStripMenuItem1_Click);
            // 
            // literaturaToolStripMenuItem
            // 
            this.literaturaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoÀLiteraturaToolStripMenuItem,
            this.quinhentismoToolStripMenuItem,
            this.barrocoToolStripMenuItem,
            this.arcadismoToolStripMenuItem,
            this.oRomantismoNoBrasilToolStripMenuItem,
            this.realismoToolStripMenuItem,
            this.naturalismoImpressionismoToolStripMenuItem,
            this.parnasianismoToolStripMenuItem1,
            this.simbolismoToolStripMenuItem,
            this.préModernismoToolStripMenuItem,
            this.semanaDeArteModernaToolStripMenuItem,
            this.vanguardasEuropeiasToolStripMenuItem,
            this.modernismoToolStripMenuItem,
            this.concretismoToolStripMenuItem,
            this.literaturaPortuguesaToolStripMenuItem,
            this.perguntasToolStripMenuItem2});
            this.literaturaToolStripMenuItem.Name = "literaturaToolStripMenuItem";
            this.literaturaToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.literaturaToolStripMenuItem.Text = "Literatura";
            // 
            // introduçãoÀLiteraturaToolStripMenuItem
            // 
            this.introduçãoÀLiteraturaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.introduçãoÀLiteraturaToolStripMenuItem.Name = "introduçãoÀLiteraturaToolStripMenuItem";
            this.introduçãoÀLiteraturaToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.introduçãoÀLiteraturaToolStripMenuItem.Text = "Introdução à Literatura";
            this.introduçãoÀLiteraturaToolStripMenuItem.Click += new System.EventHandler(this.introduçãoÀLiteraturaToolStripMenuItem_Click);
            // 
            // quinhentismoToolStripMenuItem
            // 
            this.quinhentismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.quinhentismoToolStripMenuItem.Name = "quinhentismoToolStripMenuItem";
            this.quinhentismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.quinhentismoToolStripMenuItem.Text = "Quinhentismo";
            this.quinhentismoToolStripMenuItem.Click += new System.EventHandler(this.quinhentismoToolStripMenuItem_Click);
            // 
            // barrocoToolStripMenuItem
            // 
            this.barrocoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.barrocoToolStripMenuItem.Name = "barrocoToolStripMenuItem";
            this.barrocoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.barrocoToolStripMenuItem.Text = "Barroco";
            this.barrocoToolStripMenuItem.Click += new System.EventHandler(this.barrocoToolStripMenuItem_Click);
            // 
            // arcadismoToolStripMenuItem
            // 
            this.arcadismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.arcadismoToolStripMenuItem.Name = "arcadismoToolStripMenuItem";
            this.arcadismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.arcadismoToolStripMenuItem.Text = "Arcadismo";
            this.arcadismoToolStripMenuItem.Click += new System.EventHandler(this.arcadismoToolStripMenuItem_Click);
            // 
            // oRomantismoNoBrasilToolStripMenuItem
            // 
            this.oRomantismoNoBrasilToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem,
            this.poesiaToolStripMenuItem,
            this.prosaToolStripMenuItem});
            this.oRomantismoNoBrasilToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.oRomantismoNoBrasilToolStripMenuItem.Name = "oRomantismoNoBrasilToolStripMenuItem";
            this.oRomantismoNoBrasilToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.oRomantismoNoBrasilToolStripMenuItem.Text = "Romantismo";
            // 
            // introduçãoToolStripMenuItem
            // 
            this.introduçãoToolStripMenuItem.Name = "introduçãoToolStripMenuItem";
            this.introduçãoToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.introduçãoToolStripMenuItem.Text = "Introdução";
            this.introduçãoToolStripMenuItem.Click += new System.EventHandler(this.introduçãoToolStripMenuItem_Click);
            // 
            // poesiaToolStripMenuItem
            // 
            this.poesiaToolStripMenuItem.Name = "poesiaToolStripMenuItem";
            this.poesiaToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.poesiaToolStripMenuItem.Text = "Poesia";
            this.poesiaToolStripMenuItem.Click += new System.EventHandler(this.poesiaToolStripMenuItem_Click);
            // 
            // prosaToolStripMenuItem
            // 
            this.prosaToolStripMenuItem.Name = "prosaToolStripMenuItem";
            this.prosaToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.prosaToolStripMenuItem.Text = "Prosa";
            this.prosaToolStripMenuItem.Click += new System.EventHandler(this.prosaToolStripMenuItem_Click);
            // 
            // realismoToolStripMenuItem
            // 
            this.realismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.realismoToolStripMenuItem.Name = "realismoToolStripMenuItem";
            this.realismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.realismoToolStripMenuItem.Text = "Realismo";
            this.realismoToolStripMenuItem.Click += new System.EventHandler(this.realismoToolStripMenuItem_Click);
            // 
            // naturalismoImpressionismoToolStripMenuItem
            // 
            this.naturalismoImpressionismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.naturalismoImpressionismoToolStripMenuItem.Name = "naturalismoImpressionismoToolStripMenuItem";
            this.naturalismoImpressionismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.naturalismoImpressionismoToolStripMenuItem.Text = "Naturalismo / Impressionismo";
            this.naturalismoImpressionismoToolStripMenuItem.Click += new System.EventHandler(this.naturalismoImpressionismoToolStripMenuItem_Click);
            // 
            // parnasianismoToolStripMenuItem1
            // 
            this.parnasianismoToolStripMenuItem1.ForeColor = System.Drawing.Color.Red;
            this.parnasianismoToolStripMenuItem1.Name = "parnasianismoToolStripMenuItem1";
            this.parnasianismoToolStripMenuItem1.Size = new System.Drawing.Size(299, 26);
            this.parnasianismoToolStripMenuItem1.Text = "Parnasianismo";
            this.parnasianismoToolStripMenuItem1.Click += new System.EventHandler(this.parnasianismoToolStripMenuItem1_Click);
            // 
            // simbolismoToolStripMenuItem
            // 
            this.simbolismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.simbolismoToolStripMenuItem.Name = "simbolismoToolStripMenuItem";
            this.simbolismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.simbolismoToolStripMenuItem.Text = "Simbolismo";
            this.simbolismoToolStripMenuItem.Click += new System.EventHandler(this.simbolismoToolStripMenuItem_Click);
            // 
            // préModernismoToolStripMenuItem
            // 
            this.préModernismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.préModernismoToolStripMenuItem.Name = "préModernismoToolStripMenuItem";
            this.préModernismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.préModernismoToolStripMenuItem.Text = "Pré-Modernismo";
            this.préModernismoToolStripMenuItem.Click += new System.EventHandler(this.préModernismoToolStripMenuItem_Click);
            // 
            // semanaDeArteModernaToolStripMenuItem
            // 
            this.semanaDeArteModernaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.semanaDeArteModernaToolStripMenuItem.Name = "semanaDeArteModernaToolStripMenuItem";
            this.semanaDeArteModernaToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.semanaDeArteModernaToolStripMenuItem.Text = "Semana de Arte Moderna";
            this.semanaDeArteModernaToolStripMenuItem.Click += new System.EventHandler(this.semanaDeArteModernaToolStripMenuItem_Click);
            // 
            // vanguardasEuropeiasToolStripMenuItem
            // 
            this.vanguardasEuropeiasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cubismoToolStripMenuItem,
            this.dadaísmoToolStripMenuItem,
            this.expressionismoToolStripMenuItem,
            this.fauvismoToolStripMenuItem,
            this.futurismoToolStripMenuItem,
            this.surrealismoToolStripMenuItem});
            this.vanguardasEuropeiasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.vanguardasEuropeiasToolStripMenuItem.Name = "vanguardasEuropeiasToolStripMenuItem";
            this.vanguardasEuropeiasToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.vanguardasEuropeiasToolStripMenuItem.Text = "Vanguardas Europeias";
            // 
            // cubismoToolStripMenuItem
            // 
            this.cubismoToolStripMenuItem.Name = "cubismoToolStripMenuItem";
            this.cubismoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.cubismoToolStripMenuItem.Text = "Cubismo";
            this.cubismoToolStripMenuItem.Click += new System.EventHandler(this.cubismoToolStripMenuItem_Click);
            // 
            // dadaísmoToolStripMenuItem
            // 
            this.dadaísmoToolStripMenuItem.Name = "dadaísmoToolStripMenuItem";
            this.dadaísmoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.dadaísmoToolStripMenuItem.Text = "Dadaísmo";
            this.dadaísmoToolStripMenuItem.Click += new System.EventHandler(this.dadaísmoToolStripMenuItem_Click);
            // 
            // expressionismoToolStripMenuItem
            // 
            this.expressionismoToolStripMenuItem.Name = "expressionismoToolStripMenuItem";
            this.expressionismoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.expressionismoToolStripMenuItem.Text = "Expressionismo";
            this.expressionismoToolStripMenuItem.Click += new System.EventHandler(this.expressionismoToolStripMenuItem_Click);
            // 
            // fauvismoToolStripMenuItem
            // 
            this.fauvismoToolStripMenuItem.Name = "fauvismoToolStripMenuItem";
            this.fauvismoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.fauvismoToolStripMenuItem.Text = "Fauvismo";
            this.fauvismoToolStripMenuItem.Click += new System.EventHandler(this.fauvismoToolStripMenuItem_Click);
            // 
            // futurismoToolStripMenuItem
            // 
            this.futurismoToolStripMenuItem.Name = "futurismoToolStripMenuItem";
            this.futurismoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.futurismoToolStripMenuItem.Text = "Futurismo";
            this.futurismoToolStripMenuItem.Click += new System.EventHandler(this.futurismoToolStripMenuItem_Click);
            // 
            // surrealismoToolStripMenuItem
            // 
            this.surrealismoToolStripMenuItem.Name = "surrealismoToolStripMenuItem";
            this.surrealismoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.surrealismoToolStripMenuItem.Text = "Surrealismo";
            this.surrealismoToolStripMenuItem.Click += new System.EventHandler(this.surrealismoToolStripMenuItem_Click);
            // 
            // modernismoToolStripMenuItem
            // 
            this.modernismoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ªFaseToolStripMenuItem,
            this.ªFasePoesiaModernaToolStripMenuItem,
            this.ªFaseRomanceDe30ToolStripMenuItem,
            this.ªFaseGeraçãoDe45ToolStripMenuItem});
            this.modernismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.modernismoToolStripMenuItem.Name = "modernismoToolStripMenuItem";
            this.modernismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.modernismoToolStripMenuItem.Text = "Modernismo ";
            // 
            // ªFaseToolStripMenuItem
            // 
            this.ªFaseToolStripMenuItem.Name = "ªFaseToolStripMenuItem";
            this.ªFaseToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.ªFaseToolStripMenuItem.Text = "1ª fase - Heroica/Experimental";
            this.ªFaseToolStripMenuItem.Click += new System.EventHandler(this.ªFaseToolStripMenuItem_Click);
            // 
            // ªFasePoesiaModernaToolStripMenuItem
            // 
            this.ªFasePoesiaModernaToolStripMenuItem.Name = "ªFasePoesiaModernaToolStripMenuItem";
            this.ªFasePoesiaModernaToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.ªFasePoesiaModernaToolStripMenuItem.Text = "2ª fase - Poesia Moderna";
            this.ªFasePoesiaModernaToolStripMenuItem.Click += new System.EventHandler(this.ªFasePoesiaModernaToolStripMenuItem_Click);
            // 
            // ªFaseRomanceDe30ToolStripMenuItem
            // 
            this.ªFaseRomanceDe30ToolStripMenuItem.Name = "ªFaseRomanceDe30ToolStripMenuItem";
            this.ªFaseRomanceDe30ToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.ªFaseRomanceDe30ToolStripMenuItem.Text = "2ª fase - Romance de 30";
            this.ªFaseRomanceDe30ToolStripMenuItem.Click += new System.EventHandler(this.ªFaseRomanceDe30ToolStripMenuItem_Click);
            // 
            // ªFaseGeraçãoDe45ToolStripMenuItem
            // 
            this.ªFaseGeraçãoDe45ToolStripMenuItem.Name = "ªFaseGeraçãoDe45ToolStripMenuItem";
            this.ªFaseGeraçãoDe45ToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.ªFaseGeraçãoDe45ToolStripMenuItem.Text = "3ª fase - Geração de 45";
            this.ªFaseGeraçãoDe45ToolStripMenuItem.Click += new System.EventHandler(this.ªFaseGeraçãoDe45ToolStripMenuItem_Click);
            // 
            // concretismoToolStripMenuItem
            // 
            this.concretismoToolStripMenuItem.Name = "concretismoToolStripMenuItem";
            this.concretismoToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.concretismoToolStripMenuItem.Text = "Concretismo";
            this.concretismoToolStripMenuItem.Click += new System.EventHandler(this.concretismoToolStripMenuItem_Click);
            // 
            // literaturaPortuguesaToolStripMenuItem
            // 
            this.literaturaPortuguesaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trovadorismoToolStripMenuItem,
            this.humanismoToolStripMenuItem,
            this.renascimentoToolStripMenuItem});
            this.literaturaPortuguesaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.literaturaPortuguesaToolStripMenuItem.Name = "literaturaPortuguesaToolStripMenuItem";
            this.literaturaPortuguesaToolStripMenuItem.Size = new System.Drawing.Size(299, 26);
            this.literaturaPortuguesaToolStripMenuItem.Text = "Literatura Portuguesa";
            // 
            // trovadorismoToolStripMenuItem
            // 
            this.trovadorismoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem1,
            this.cantigasToolStripMenuItem});
            this.trovadorismoToolStripMenuItem.Name = "trovadorismoToolStripMenuItem";
            this.trovadorismoToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.trovadorismoToolStripMenuItem.Text = "Trovadorismo";
            // 
            // introduçãoToolStripMenuItem1
            // 
            this.introduçãoToolStripMenuItem1.Name = "introduçãoToolStripMenuItem1";
            this.introduçãoToolStripMenuItem1.Size = new System.Drawing.Size(181, 26);
            this.introduçãoToolStripMenuItem1.Text = "Trovadorismo";
            this.introduçãoToolStripMenuItem1.Click += new System.EventHandler(this.introduçãoToolStripMenuItem1_Click);
            // 
            // cantigasToolStripMenuItem
            // 
            this.cantigasToolStripMenuItem.Name = "cantigasToolStripMenuItem";
            this.cantigasToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.cantigasToolStripMenuItem.Text = "Cantigas";
            this.cantigasToolStripMenuItem.Click += new System.EventHandler(this.cantigasToolStripMenuItem_Click);
            // 
            // humanismoToolStripMenuItem
            // 
            this.humanismoToolStripMenuItem.Name = "humanismoToolStripMenuItem";
            this.humanismoToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.humanismoToolStripMenuItem.Text = "Humanismo";
            this.humanismoToolStripMenuItem.Click += new System.EventHandler(this.humanismoToolStripMenuItem_Click);
            // 
            // renascimentoToolStripMenuItem
            // 
            this.renascimentoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem2,
            this.classicismoToolStripMenuItem});
            this.renascimentoToolStripMenuItem.Name = "renascimentoToolStripMenuItem";
            this.renascimentoToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.renascimentoToolStripMenuItem.Text = "Renascimento";
            // 
            // introduçãoToolStripMenuItem2
            // 
            this.introduçãoToolStripMenuItem2.Name = "introduçãoToolStripMenuItem2";
            this.introduçãoToolStripMenuItem2.Size = new System.Drawing.Size(183, 26);
            this.introduçãoToolStripMenuItem2.Text = "Renascimento";
            this.introduçãoToolStripMenuItem2.Click += new System.EventHandler(this.introduçãoToolStripMenuItem2_Click);
            // 
            // classicismoToolStripMenuItem
            // 
            this.classicismoToolStripMenuItem.Name = "classicismoToolStripMenuItem";
            this.classicismoToolStripMenuItem.Size = new System.Drawing.Size(183, 26);
            this.classicismoToolStripMenuItem.Text = "Classicismo";
            this.classicismoToolStripMenuItem.Click += new System.EventHandler(this.classicismoToolStripMenuItem_Click);
            // 
            // perguntasToolStripMenuItem2
            // 
            this.perguntasToolStripMenuItem2.BackColor = System.Drawing.Color.Tomato;
            this.perguntasToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quinhentismoToolStripMenuItem1,
            this.toolStripMenuItem149,
            this.toolStripMenuItem150,
            this.toolStripMenuItem151,
            this.toolStripMenuItem155,
            this.toolStripMenuItem156,
            this.toolStripMenuItem157,
            this.toolStripMenuItem158,
            this.toolStripMenuItem159,
            this.toolStripMenuItem160,
            this.toolStripMenuItem161,
            this.toolStripMenuItem168,
            this.toolStripMenuItem173,
            this.toolStripMenuItem174});
            this.perguntasToolStripMenuItem2.Name = "perguntasToolStripMenuItem2";
            this.perguntasToolStripMenuItem2.Size = new System.Drawing.Size(299, 26);
            this.perguntasToolStripMenuItem2.Text = "Perguntas";
            // 
            // quinhentismoToolStripMenuItem1
            // 
            this.quinhentismoToolStripMenuItem1.ForeColor = System.Drawing.Color.Red;
            this.quinhentismoToolStripMenuItem1.Name = "quinhentismoToolStripMenuItem1";
            this.quinhentismoToolStripMenuItem1.Size = new System.Drawing.Size(299, 26);
            this.quinhentismoToolStripMenuItem1.Text = "Quinhentismo";
            this.quinhentismoToolStripMenuItem1.Click += new System.EventHandler(this.quinhentismoToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem149
            // 
            this.toolStripMenuItem149.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem149.Name = "toolStripMenuItem149";
            this.toolStripMenuItem149.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem149.Text = "Barroco";
            this.toolStripMenuItem149.Click += new System.EventHandler(this.toolStripMenuItem149_Click);
            // 
            // toolStripMenuItem150
            // 
            this.toolStripMenuItem150.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem150.Name = "toolStripMenuItem150";
            this.toolStripMenuItem150.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem150.Text = "Arcadismo";
            this.toolStripMenuItem150.Click += new System.EventHandler(this.toolStripMenuItem150_Click);
            // 
            // toolStripMenuItem151
            // 
            this.toolStripMenuItem151.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem153,
            this.toolStripMenuItem154});
            this.toolStripMenuItem151.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem151.Name = "toolStripMenuItem151";
            this.toolStripMenuItem151.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem151.Text = "Romantismo";
            // 
            // toolStripMenuItem153
            // 
            this.toolStripMenuItem153.Name = "toolStripMenuItem153";
            this.toolStripMenuItem153.Size = new System.Drawing.Size(126, 26);
            this.toolStripMenuItem153.Text = "Poesia";
            this.toolStripMenuItem153.Click += new System.EventHandler(this.toolStripMenuItem153_Click);
            // 
            // toolStripMenuItem154
            // 
            this.toolStripMenuItem154.Name = "toolStripMenuItem154";
            this.toolStripMenuItem154.Size = new System.Drawing.Size(126, 26);
            this.toolStripMenuItem154.Text = "Prosa";
            this.toolStripMenuItem154.Click += new System.EventHandler(this.toolStripMenuItem154_Click);
            // 
            // toolStripMenuItem155
            // 
            this.toolStripMenuItem155.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem155.Name = "toolStripMenuItem155";
            this.toolStripMenuItem155.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem155.Text = "Realismo";
            this.toolStripMenuItem155.Click += new System.EventHandler(this.toolStripMenuItem155_Click);
            // 
            // toolStripMenuItem156
            // 
            this.toolStripMenuItem156.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem156.Name = "toolStripMenuItem156";
            this.toolStripMenuItem156.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem156.Text = "Naturalismo / Impressionismo";
            this.toolStripMenuItem156.Click += new System.EventHandler(this.toolStripMenuItem156_Click);
            // 
            // toolStripMenuItem157
            // 
            this.toolStripMenuItem157.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem157.Name = "toolStripMenuItem157";
            this.toolStripMenuItem157.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem157.Text = "Parnasianismo";
            this.toolStripMenuItem157.Click += new System.EventHandler(this.toolStripMenuItem157_Click);
            // 
            // toolStripMenuItem158
            // 
            this.toolStripMenuItem158.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem158.Name = "toolStripMenuItem158";
            this.toolStripMenuItem158.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem158.Text = "Simbolismo";
            this.toolStripMenuItem158.Click += new System.EventHandler(this.toolStripMenuItem158_Click);
            // 
            // toolStripMenuItem159
            // 
            this.toolStripMenuItem159.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem159.Name = "toolStripMenuItem159";
            this.toolStripMenuItem159.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem159.Text = "Pré-Modernismo";
            this.toolStripMenuItem159.Click += new System.EventHandler(this.toolStripMenuItem159_Click);
            // 
            // toolStripMenuItem160
            // 
            this.toolStripMenuItem160.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem160.Name = "toolStripMenuItem160";
            this.toolStripMenuItem160.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem160.Text = "Semana de Arte Moderna";
            this.toolStripMenuItem160.Click += new System.EventHandler(this.toolStripMenuItem160_Click);
            // 
            // toolStripMenuItem161
            // 
            this.toolStripMenuItem161.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem162,
            this.toolStripMenuItem163,
            this.toolStripMenuItem164,
            this.toolStripMenuItem165,
            this.toolStripMenuItem166,
            this.toolStripMenuItem167});
            this.toolStripMenuItem161.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem161.Name = "toolStripMenuItem161";
            this.toolStripMenuItem161.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem161.Text = "Vanguardas Europeias";
            // 
            // toolStripMenuItem162
            // 
            this.toolStripMenuItem162.Name = "toolStripMenuItem162";
            this.toolStripMenuItem162.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem162.Text = "Cubismo";
            this.toolStripMenuItem162.Click += new System.EventHandler(this.toolStripMenuItem162_Click);
            // 
            // toolStripMenuItem163
            // 
            this.toolStripMenuItem163.Name = "toolStripMenuItem163";
            this.toolStripMenuItem163.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem163.Text = "Dadaísmo";
            this.toolStripMenuItem163.Click += new System.EventHandler(this.toolStripMenuItem163_Click);
            // 
            // toolStripMenuItem164
            // 
            this.toolStripMenuItem164.Name = "toolStripMenuItem164";
            this.toolStripMenuItem164.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem164.Text = "Expressionismo";
            this.toolStripMenuItem164.Click += new System.EventHandler(this.toolStripMenuItem164_Click);
            // 
            // toolStripMenuItem165
            // 
            this.toolStripMenuItem165.Name = "toolStripMenuItem165";
            this.toolStripMenuItem165.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem165.Text = "Fauvismo";
            this.toolStripMenuItem165.Click += new System.EventHandler(this.toolStripMenuItem165_Click);
            // 
            // toolStripMenuItem166
            // 
            this.toolStripMenuItem166.Name = "toolStripMenuItem166";
            this.toolStripMenuItem166.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem166.Text = "Futurismo";
            this.toolStripMenuItem166.Click += new System.EventHandler(this.toolStripMenuItem166_Click);
            // 
            // toolStripMenuItem167
            // 
            this.toolStripMenuItem167.Name = "toolStripMenuItem167";
            this.toolStripMenuItem167.Size = new System.Drawing.Size(193, 26);
            this.toolStripMenuItem167.Text = "Surrealismo";
            // 
            // toolStripMenuItem168
            // 
            this.toolStripMenuItem168.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem169,
            this.toolStripMenuItem170,
            this.toolStripMenuItem171,
            this.toolStripMenuItem172});
            this.toolStripMenuItem168.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem168.Name = "toolStripMenuItem168";
            this.toolStripMenuItem168.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem168.Text = "Modernismo ";
            // 
            // toolStripMenuItem169
            // 
            this.toolStripMenuItem169.Name = "toolStripMenuItem169";
            this.toolStripMenuItem169.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem169.Text = "1ª fase - Heroica/Experimental";
            this.toolStripMenuItem169.Click += new System.EventHandler(this.toolStripMenuItem169_Click);
            // 
            // toolStripMenuItem170
            // 
            this.toolStripMenuItem170.Name = "toolStripMenuItem170";
            this.toolStripMenuItem170.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem170.Text = "2ª fase - Poesia Moderna";
            this.toolStripMenuItem170.Click += new System.EventHandler(this.toolStripMenuItem170_Click);
            // 
            // toolStripMenuItem171
            // 
            this.toolStripMenuItem171.Name = "toolStripMenuItem171";
            this.toolStripMenuItem171.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem171.Text = "2ª fase - Romance de 30";
            this.toolStripMenuItem171.Click += new System.EventHandler(this.toolStripMenuItem171_Click);
            // 
            // toolStripMenuItem172
            // 
            this.toolStripMenuItem172.Name = "toolStripMenuItem172";
            this.toolStripMenuItem172.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem172.Text = "3ª fase - Geração de 45";
            this.toolStripMenuItem172.Click += new System.EventHandler(this.toolStripMenuItem172_Click);
            // 
            // toolStripMenuItem173
            // 
            this.toolStripMenuItem173.Name = "toolStripMenuItem173";
            this.toolStripMenuItem173.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem173.Text = "Concretismo";
            this.toolStripMenuItem173.Click += new System.EventHandler(this.toolStripMenuItem173_Click);
            // 
            // toolStripMenuItem174
            // 
            this.toolStripMenuItem174.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem175,
            this.toolStripMenuItem178,
            this.toolStripMenuItem179});
            this.toolStripMenuItem174.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem174.Name = "toolStripMenuItem174";
            this.toolStripMenuItem174.Size = new System.Drawing.Size(299, 26);
            this.toolStripMenuItem174.Text = "Literatura Portuguesa";
            // 
            // toolStripMenuItem175
            // 
            this.toolStripMenuItem175.Name = "toolStripMenuItem175";
            this.toolStripMenuItem175.Size = new System.Drawing.Size(183, 26);
            this.toolStripMenuItem175.Text = "Trovadorismo";
            this.toolStripMenuItem175.Click += new System.EventHandler(this.toolStripMenuItem175_Click);
            // 
            // toolStripMenuItem178
            // 
            this.toolStripMenuItem178.Name = "toolStripMenuItem178";
            this.toolStripMenuItem178.Size = new System.Drawing.Size(183, 26);
            this.toolStripMenuItem178.Text = "Humanismo";
            this.toolStripMenuItem178.Click += new System.EventHandler(this.toolStripMenuItem178_Click);
            // 
            // toolStripMenuItem179
            // 
            this.toolStripMenuItem179.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem180,
            this.toolStripMenuItem181});
            this.toolStripMenuItem179.Name = "toolStripMenuItem179";
            this.toolStripMenuItem179.Size = new System.Drawing.Size(183, 26);
            this.toolStripMenuItem179.Text = "Renascimento";
            // 
            // toolStripMenuItem180
            // 
            this.toolStripMenuItem180.Name = "toolStripMenuItem180";
            this.toolStripMenuItem180.Size = new System.Drawing.Size(183, 26);
            this.toolStripMenuItem180.Text = "Renascimento";
            // 
            // toolStripMenuItem181
            // 
            this.toolStripMenuItem181.Name = "toolStripMenuItem181";
            this.toolStripMenuItem181.Size = new System.Drawing.Size(183, 26);
            this.toolStripMenuItem181.Text = "Classicismo";
            // 
            // siteCompletoMenuItem
            // 
            this.siteCompletoMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.asDivisõesDaGramáticaToolStripMenuItem,
            this.morfologiaToolStripMenuItem,
            this.classesGramaticaisToolStripMenuItem,
            this.semânticaToolStripMenuItem,
            this.fonéticaToolStripMenuItem,
            this.craseToolStripMenuItem,
            this.toolStripMenuItem15,
            this.ortografiaToolStripMenuItem,
            this.fonologiaEAcentuaçãoToolStripMenuItem,
            this.ortografiaAcentuaçãoToolStripMenuItem,
            this.sintaxeToolStripMenuItem,
            this.concordânciaToolStripMenuItem,
            this.predicaçãoVerbaToolStripMenuItem,
            this.colocaçãoPronominalToolStripMenuItem,
            this.pontuaçãoToolStripMenuItem,
            this.perguntasToolStripMenuItem1});
            this.siteCompletoMenuItem.Name = "siteCompletoMenuItem";
            this.siteCompletoMenuItem.Size = new System.Drawing.Size(109, 25);
            this.siteCompletoMenuItem.Text = "Gramática";
            // 
            // perguntasToolStripMenuItem1
            // 
            this.perguntasToolStripMenuItem1.BackColor = System.Drawing.Color.Tomato;
            this.perguntasToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem22,
            this.toolStripMenuItem36,
            this.toolStripMenuItem60,
            this.toolStripMenuItem65,
            this.toolStripMenuItem70,
            this.toolStripMenuItem75,
            this.toolStripMenuItem78,
            this.toolStripMenuItem81,
            this.toolStripMenuItem85,
            this.toolStripMenuItem89,
            this.toolStripMenuItem123,
            this.toolStripMenuItem135,
            this.toolStripMenuItem140,
            this.toolStripMenuItem144});
            this.perguntasToolStripMenuItem1.Name = "perguntasToolStripMenuItem1";
            this.perguntasToolStripMenuItem1.Size = new System.Drawing.Size(261, 26);
            this.perguntasToolStripMenuItem1.Text = "Perguntas";
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem23,
            this.toolStripMenuItem28,
            this.toolStripMenuItem29,
            this.toolStripMenuItem30,
            this.toolStripMenuItem31,
            this.toolStripMenuItem35});
            this.toolStripMenuItem22.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem22.Text = "Morfologia";
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(252, 26);
            this.toolStripMenuItem23.Text = "Substantivo";
            this.toolStripMenuItem23.Click += new System.EventHandler(this.toolStripMenuItem23_Click);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(252, 26);
            this.toolStripMenuItem28.Text = "Advérbios";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.toolStripMenuItem28_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(252, 26);
            this.toolStripMenuItem29.Text = "Artigo";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(252, 26);
            this.toolStripMenuItem30.Text = "Conjunções";
            this.toolStripMenuItem30.Click += new System.EventHandler(this.toolStripMenuItem30_Click);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(252, 26);
            this.toolStripMenuItem31.Text = "Adjetivos";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.toolStripMenuItem31_Click);
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(252, 26);
            this.toolStripMenuItem35.Text = "Numerais e Interjeições";
            this.toolStripMenuItem35.Click += new System.EventHandler(this.toolStripMenuItem35_Click);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem37,
            this.toolStripMenuItem46});
            this.toolStripMenuItem36.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem36.Text = "Classes Gramaticais";
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.ForeColor = System.Drawing.Color.Black;
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(154, 26);
            this.toolStripMenuItem37.Text = "Pronomes";
            this.toolStripMenuItem37.Click += new System.EventHandler(this.toolStripMenuItem37_Click);
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(154, 26);
            this.toolStripMenuItem46.Text = "Verbos";
            this.toolStripMenuItem46.Click += new System.EventHandler(this.toolStripMenuItem46_Click);
            // 
            // toolStripMenuItem60
            // 
            this.toolStripMenuItem60.Name = "toolStripMenuItem60";
            this.toolStripMenuItem60.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem60.Text = "Semântica";
            this.toolStripMenuItem60.Click += new System.EventHandler(this.toolStripMenuItem60_Click);
            // 
            // toolStripMenuItem65
            // 
            this.toolStripMenuItem65.Name = "toolStripMenuItem65";
            this.toolStripMenuItem65.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem65.Text = "Fonética";
            this.toolStripMenuItem65.Click += new System.EventHandler(this.toolStripMenuItem65_Click);
            // 
            // toolStripMenuItem70
            // 
            this.toolStripMenuItem70.Name = "toolStripMenuItem70";
            this.toolStripMenuItem70.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem70.Text = "Crase";
            this.toolStripMenuItem70.Click += new System.EventHandler(this.toolStripMenuItem70_Click);
            // 
            // toolStripMenuItem75
            // 
            this.toolStripMenuItem75.Name = "toolStripMenuItem75";
            this.toolStripMenuItem75.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem75.Text = "Acentuação";
            this.toolStripMenuItem75.Click += new System.EventHandler(this.toolStripMenuItem75_Click);
            // 
            // toolStripMenuItem78
            // 
            this.toolStripMenuItem78.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem78.Name = "toolStripMenuItem78";
            this.toolStripMenuItem78.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem78.Text = "Ortografia";
            this.toolStripMenuItem78.Click += new System.EventHandler(this.toolStripMenuItem78_Click);
            // 
            // toolStripMenuItem81
            // 
            this.toolStripMenuItem81.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem82});
            this.toolStripMenuItem81.Name = "toolStripMenuItem81";
            this.toolStripMenuItem81.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem81.Text = "Fonologia e Acentuação";
            // 
            // toolStripMenuItem82
            // 
            this.toolStripMenuItem82.Name = "toolStripMenuItem82";
            this.toolStripMenuItem82.Size = new System.Drawing.Size(166, 26);
            this.toolStripMenuItem82.Text = "Acentuação";
            this.toolStripMenuItem82.Click += new System.EventHandler(this.toolStripMenuItem82_Click);
            // 
            // toolStripMenuItem85
            // 
            this.toolStripMenuItem85.Name = "toolStripMenuItem85";
            this.toolStripMenuItem85.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem85.Text = "Ortografia/Acentuação";
            this.toolStripMenuItem85.Click += new System.EventHandler(this.toolStripMenuItem85_Click);
            // 
            // toolStripMenuItem89
            // 
            this.toolStripMenuItem89.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem89.Name = "toolStripMenuItem89";
            this.toolStripMenuItem89.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem89.Text = "Sintaxe";
            this.toolStripMenuItem89.Click += new System.EventHandler(this.toolStripMenuItem89_Click);
            // 
            // toolStripMenuItem123
            // 
            this.toolStripMenuItem123.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem124,
            this.toolStripMenuItem131});
            this.toolStripMenuItem123.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem123.Name = "toolStripMenuItem123";
            this.toolStripMenuItem123.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem123.Text = "Concordância";
            // 
            // toolStripMenuItem124
            // 
            this.toolStripMenuItem124.Name = "toolStripMenuItem124";
            this.toolStripMenuItem124.Size = new System.Drawing.Size(245, 26);
            this.toolStripMenuItem124.Text = "Concordância Verbal ";
            this.toolStripMenuItem124.Click += new System.EventHandler(this.toolStripMenuItem124_Click);
            // 
            // toolStripMenuItem131
            // 
            this.toolStripMenuItem131.Name = "toolStripMenuItem131";
            this.toolStripMenuItem131.Size = new System.Drawing.Size(245, 26);
            this.toolStripMenuItem131.Text = "Concordância Nominal";
            this.toolStripMenuItem131.Click += new System.EventHandler(this.toolStripMenuItem131_Click);
            // 
            // toolStripMenuItem135
            // 
            this.toolStripMenuItem135.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem136,
            this.toolStripMenuItem137,
            this.toolStripMenuItem138,
            this.toolStripMenuItem139});
            this.toolStripMenuItem135.Name = "toolStripMenuItem135";
            this.toolStripMenuItem135.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem135.Text = "Predicação Verbal";
            // 
            // toolStripMenuItem136
            // 
            this.toolStripMenuItem136.Name = "toolStripMenuItem136";
            this.toolStripMenuItem136.Size = new System.Drawing.Size(388, 26);
            this.toolStripMenuItem136.Text = "Verbos Transitivos Diretos";
            this.toolStripMenuItem136.Click += new System.EventHandler(this.toolStripMenuItem136_Click);
            // 
            // toolStripMenuItem137
            // 
            this.toolStripMenuItem137.Name = "toolStripMenuItem137";
            this.toolStripMenuItem137.Size = new System.Drawing.Size(388, 26);
            this.toolStripMenuItem137.Text = "Verbos Transitivos Indiretos e Bitransitivos";
            this.toolStripMenuItem137.Click += new System.EventHandler(this.toolStripMenuItem137_Click);
            // 
            // toolStripMenuItem138
            // 
            this.toolStripMenuItem138.Name = "toolStripMenuItem138";
            this.toolStripMenuItem138.Size = new System.Drawing.Size(388, 26);
            this.toolStripMenuItem138.Text = "Verbos Intransitivos";
            this.toolStripMenuItem138.Click += new System.EventHandler(this.toolStripMenuItem138_Click);
            // 
            // toolStripMenuItem139
            // 
            this.toolStripMenuItem139.Name = "toolStripMenuItem139";
            this.toolStripMenuItem139.Size = new System.Drawing.Size(388, 26);
            this.toolStripMenuItem139.Text = "Verbos de Ligação";
            this.toolStripMenuItem139.Click += new System.EventHandler(this.toolStripMenuItem139_Click);
            // 
            // toolStripMenuItem140
            // 
            this.toolStripMenuItem140.Name = "toolStripMenuItem140";
            this.toolStripMenuItem140.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem140.Text = "Colocação Pronominal";
            this.toolStripMenuItem140.Click += new System.EventHandler(this.toolStripMenuItem140_Click);
            // 
            // toolStripMenuItem144
            // 
            this.toolStripMenuItem144.Name = "toolStripMenuItem144";
            this.toolStripMenuItem144.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem144.Text = "Pontuação";
            this.toolStripMenuItem144.Click += new System.EventHandler(this.toolStripMenuItem144_Click);
            // 
            // asDivisõesDaGramáticaToolStripMenuItem
            // 
            this.asDivisõesDaGramáticaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.asDivisõesDaGramáticaToolStripMenuItem.Name = "asDivisõesDaGramáticaToolStripMenuItem";
            this.asDivisõesDaGramáticaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.asDivisõesDaGramáticaToolStripMenuItem.Text = "As Divisões da Gramática";
            this.asDivisõesDaGramáticaToolStripMenuItem.Click += new System.EventHandler(this.asDivisõesDaGramáticaToolStripMenuItem_Click);
            // 
            // morfologiaToolStripMenuItem
            // 
            this.morfologiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.substantivoToolStripMenuItem,
            this.advérbiosToolStripMenuItem,
            this.artigoToolStripMenuItem,
            this.conjunçõesToolStripMenuItem1,
            this.toolStripMenuItem11,
            this.numeraisEInterjeiçõesToolStripMenuItem});
            this.morfologiaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.morfologiaToolStripMenuItem.Name = "morfologiaToolStripMenuItem";
            this.morfologiaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.morfologiaToolStripMenuItem.Text = "Morfologia";
            // 
            // substantivoToolStripMenuItem
            // 
            this.substantivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.parteIIVToolStripMenuItem});
            this.substantivoToolStripMenuItem.Name = "substantivoToolStripMenuItem";
            this.substantivoToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.substantivoToolStripMenuItem.Text = "Substantivo";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem8.Text = "Parte I";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem9.Text = "Parte II";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem10.Text = "Parte III";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // parteIIVToolStripMenuItem
            // 
            this.parteIIVToolStripMenuItem.Name = "parteIIVToolStripMenuItem";
            this.parteIIVToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parteIIVToolStripMenuItem.Text = "Parte IV";
            this.parteIIVToolStripMenuItem.Click += new System.EventHandler(this.parteIIVToolStripMenuItem_Click);
            // 
            // advérbiosToolStripMenuItem
            // 
            this.advérbiosToolStripMenuItem.Name = "advérbiosToolStripMenuItem";
            this.advérbiosToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.advérbiosToolStripMenuItem.Text = "Advérbios";
            this.advérbiosToolStripMenuItem.Click += new System.EventHandler(this.advérbiosToolStripMenuItem_Click);
            // 
            // artigoToolStripMenuItem
            // 
            this.artigoToolStripMenuItem.Name = "artigoToolStripMenuItem";
            this.artigoToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.artigoToolStripMenuItem.Text = "Artigo";
            this.artigoToolStripMenuItem.Click += new System.EventHandler(this.artigoToolStripMenuItem_Click);
            // 
            // conjunçõesToolStripMenuItem1
            // 
            this.conjunçõesToolStripMenuItem1.Name = "conjunçõesToolStripMenuItem1";
            this.conjunçõesToolStripMenuItem1.Size = new System.Drawing.Size(252, 26);
            this.conjunçõesToolStripMenuItem1.Text = "Conjunções";
            this.conjunçõesToolStripMenuItem1.Click += new System.EventHandler(this.conjunçõesToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(252, 26);
            this.toolStripMenuItem11.Text = "Adjetivos";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem12.Text = "Parte I";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem13.Text = "Parte II";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem14.Text = "Parte III";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // numeraisEInterjeiçõesToolStripMenuItem
            // 
            this.numeraisEInterjeiçõesToolStripMenuItem.Name = "numeraisEInterjeiçõesToolStripMenuItem";
            this.numeraisEInterjeiçõesToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.numeraisEInterjeiçõesToolStripMenuItem.Text = "Numerais e Interjeições";
            this.numeraisEInterjeiçõesToolStripMenuItem.Click += new System.EventHandler(this.numeraisEInterjeiçõesToolStripMenuItem_Click);
            // 
            // classesGramaticaisToolStripMenuItem
            // 
            this.classesGramaticaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pronomesToolStripMenuItem,
            this.verbosToolStripMenuItem});
            this.classesGramaticaisToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.classesGramaticaisToolStripMenuItem.Name = "classesGramaticaisToolStripMenuItem";
            this.classesGramaticaisToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.classesGramaticaisToolStripMenuItem.Text = "Classes Gramaticais";
            // 
            // pronomesToolStripMenuItem
            // 
            this.pronomesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem4,
            this.toolStripMenuItem7,
            this.toolStripMenuItem6,
            this.toolStripMenuItem5,
            this.toolStripMenuItem4,
            this.toolStripMenuItem3,
            this.toolStripMenuItem2,
            this.toolStripMenuItem1});
            this.pronomesToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.pronomesToolStripMenuItem.Name = "pronomesToolStripMenuItem";
            this.pronomesToolStripMenuItem.Size = new System.Drawing.Size(154, 26);
            this.pronomesToolStripMenuItem.Text = "Pronomes";
            // 
            // parteIToolStripMenuItem4
            // 
            this.parteIToolStripMenuItem4.Name = "parteIToolStripMenuItem4";
            this.parteIToolStripMenuItem4.Size = new System.Drawing.Size(147, 26);
            this.parteIToolStripMenuItem4.Text = "Parte I";
            this.parteIToolStripMenuItem4.Click += new System.EventHandler(this.parteIToolStripMenuItem4_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem7.Text = "Parte II";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem6.Text = "Parte III";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem5.Text = "Parte IV";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem4.Text = "Parte V";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem3.Text = "Parte VI";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem2.Text = "Parte VII";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(147, 26);
            this.toolStripMenuItem1.Text = "Parte VIII";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // verbosToolStripMenuItem
            // 
            this.verbosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem3,
            this.parteIIToolStripMenuItem3,
            this.parteIIIToolStripMenuItem3,
            this.parteIVToolStripMenuItem2,
            this.parteVToolStripMenuItem2,
            this.parteVIToolStripMenuItem1,
            this.parteVIIToolStripMenuItem,
            this.parteVIIIToolStripMenuItem,
            this.parteIXToolStripMenuItem,
            this.parteXIToolStripMenuItem,
            this.parteXIIToolStripMenuItem,
            this.parteXIIIToolStripMenuItem,
            this.parteXIVToolStripMenuItem});
            this.verbosToolStripMenuItem.Name = "verbosToolStripMenuItem";
            this.verbosToolStripMenuItem.Size = new System.Drawing.Size(154, 26);
            this.verbosToolStripMenuItem.Text = "Verbos";
            // 
            // parteIToolStripMenuItem3
            // 
            this.parteIToolStripMenuItem3.Name = "parteIToolStripMenuItem3";
            this.parteIToolStripMenuItem3.Size = new System.Drawing.Size(147, 26);
            this.parteIToolStripMenuItem3.Text = "Parte I";
            this.parteIToolStripMenuItem3.Click += new System.EventHandler(this.parteIToolStripMenuItem3_Click);
            // 
            // parteIIToolStripMenuItem3
            // 
            this.parteIIToolStripMenuItem3.Name = "parteIIToolStripMenuItem3";
            this.parteIIToolStripMenuItem3.Size = new System.Drawing.Size(147, 26);
            this.parteIIToolStripMenuItem3.Text = "Parte II";
            this.parteIIToolStripMenuItem3.Click += new System.EventHandler(this.parteIIToolStripMenuItem3_Click);
            // 
            // parteIIIToolStripMenuItem3
            // 
            this.parteIIIToolStripMenuItem3.Name = "parteIIIToolStripMenuItem3";
            this.parteIIIToolStripMenuItem3.Size = new System.Drawing.Size(147, 26);
            this.parteIIIToolStripMenuItem3.Text = "Parte III";
            this.parteIIIToolStripMenuItem3.Click += new System.EventHandler(this.parteIIIToolStripMenuItem3_Click);
            // 
            // parteIVToolStripMenuItem2
            // 
            this.parteIVToolStripMenuItem2.Name = "parteIVToolStripMenuItem2";
            this.parteIVToolStripMenuItem2.Size = new System.Drawing.Size(147, 26);
            this.parteIVToolStripMenuItem2.Text = "Parte IV";
            this.parteIVToolStripMenuItem2.Click += new System.EventHandler(this.parteIVToolStripMenuItem2_Click);
            // 
            // parteVToolStripMenuItem2
            // 
            this.parteVToolStripMenuItem2.Name = "parteVToolStripMenuItem2";
            this.parteVToolStripMenuItem2.Size = new System.Drawing.Size(147, 26);
            this.parteVToolStripMenuItem2.Text = "Parte V";
            this.parteVToolStripMenuItem2.Click += new System.EventHandler(this.parteVToolStripMenuItem2_Click);
            // 
            // parteVIToolStripMenuItem1
            // 
            this.parteVIToolStripMenuItem1.Name = "parteVIToolStripMenuItem1";
            this.parteVIToolStripMenuItem1.Size = new System.Drawing.Size(147, 26);
            this.parteVIToolStripMenuItem1.Text = "Parte VI";
            this.parteVIToolStripMenuItem1.Click += new System.EventHandler(this.parteVIToolStripMenuItem1_Click);
            // 
            // parteVIIToolStripMenuItem
            // 
            this.parteVIIToolStripMenuItem.Name = "parteVIIToolStripMenuItem";
            this.parteVIIToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.parteVIIToolStripMenuItem.Text = "Parte VII";
            this.parteVIIToolStripMenuItem.Click += new System.EventHandler(this.parteVIIToolStripMenuItem_Click);
            // 
            // parteVIIIToolStripMenuItem
            // 
            this.parteVIIIToolStripMenuItem.Name = "parteVIIIToolStripMenuItem";
            this.parteVIIIToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.parteVIIIToolStripMenuItem.Text = "Parte VIII";
            this.parteVIIIToolStripMenuItem.Click += new System.EventHandler(this.parteVIIIToolStripMenuItem_Click);
            // 
            // parteIXToolStripMenuItem
            // 
            this.parteIXToolStripMenuItem.Name = "parteIXToolStripMenuItem";
            this.parteIXToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.parteIXToolStripMenuItem.Text = "Parte IX";
            this.parteIXToolStripMenuItem.Click += new System.EventHandler(this.parteIXToolStripMenuItem_Click);
            // 
            // parteXIToolStripMenuItem
            // 
            this.parteXIToolStripMenuItem.Name = "parteXIToolStripMenuItem";
            this.parteXIToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.parteXIToolStripMenuItem.Text = "Parte XI";
            this.parteXIToolStripMenuItem.Click += new System.EventHandler(this.parteXIToolStripMenuItem_Click);
            // 
            // parteXIIToolStripMenuItem
            // 
            this.parteXIIToolStripMenuItem.Name = "parteXIIToolStripMenuItem";
            this.parteXIIToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.parteXIIToolStripMenuItem.Text = "Parte XII";
            this.parteXIIToolStripMenuItem.Click += new System.EventHandler(this.parteXIIToolStripMenuItem_Click);
            // 
            // parteXIIIToolStripMenuItem
            // 
            this.parteXIIIToolStripMenuItem.Name = "parteXIIIToolStripMenuItem";
            this.parteXIIIToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.parteXIIIToolStripMenuItem.Text = "Parte XIII";
            this.parteXIIIToolStripMenuItem.Click += new System.EventHandler(this.parteXIIIToolStripMenuItem_Click);
            // 
            // parteXIVToolStripMenuItem
            // 
            this.parteXIVToolStripMenuItem.Name = "parteXIVToolStripMenuItem";
            this.parteXIVToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.parteXIVToolStripMenuItem.Text = "Parte XIV";
            this.parteXIVToolStripMenuItem.Click += new System.EventHandler(this.parteXIVToolStripMenuItem_Click);
            // 
            // semânticaToolStripMenuItem
            // 
            this.semânticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem,
            this.parte02ToolStripMenuItem,
            this.parte03ToolStripMenuItem,
            this.parte04ToolStripMenuItem});
            this.semânticaToolStripMenuItem.Name = "semânticaToolStripMenuItem";
            this.semânticaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.semânticaToolStripMenuItem.Text = "Semântica";
            // 
            // parte01ToolStripMenuItem
            // 
            this.parte01ToolStripMenuItem.Name = "parte01ToolStripMenuItem";
            this.parte01ToolStripMenuItem.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem.Text = "Parte 01";
            this.parte01ToolStripMenuItem.Click += new System.EventHandler(this.parte01ToolStripMenuItem_Click);
            // 
            // parte02ToolStripMenuItem
            // 
            this.parte02ToolStripMenuItem.Name = "parte02ToolStripMenuItem";
            this.parte02ToolStripMenuItem.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem.Text = "Parte 02";
            this.parte02ToolStripMenuItem.Click += new System.EventHandler(this.parte02ToolStripMenuItem_Click);
            // 
            // parte03ToolStripMenuItem
            // 
            this.parte03ToolStripMenuItem.Name = "parte03ToolStripMenuItem";
            this.parte03ToolStripMenuItem.Size = new System.Drawing.Size(140, 26);
            this.parte03ToolStripMenuItem.Text = "Parte 03";
            this.parte03ToolStripMenuItem.Click += new System.EventHandler(this.parte03ToolStripMenuItem_Click);
            // 
            // parte04ToolStripMenuItem
            // 
            this.parte04ToolStripMenuItem.Name = "parte04ToolStripMenuItem";
            this.parte04ToolStripMenuItem.Size = new System.Drawing.Size(140, 26);
            this.parte04ToolStripMenuItem.Text = "Parte 04";
            this.parte04ToolStripMenuItem.Click += new System.EventHandler(this.parte04ToolStripMenuItem_Click);
            // 
            // fonéticaToolStripMenuItem
            // 
            this.fonéticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem1,
            this.parte02ToolStripMenuItem1,
            this.parte03ToolStripMenuItem1,
            this.parte04ToolStripMenuItem1});
            this.fonéticaToolStripMenuItem.Name = "fonéticaToolStripMenuItem";
            this.fonéticaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.fonéticaToolStripMenuItem.Text = "Fonética";
            // 
            // parte01ToolStripMenuItem1
            // 
            this.parte01ToolStripMenuItem1.Name = "parte01ToolStripMenuItem1";
            this.parte01ToolStripMenuItem1.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem1.Text = "Parte 01";
            this.parte01ToolStripMenuItem1.Click += new System.EventHandler(this.parte01ToolStripMenuItem1_Click);
            // 
            // parte02ToolStripMenuItem1
            // 
            this.parte02ToolStripMenuItem1.Name = "parte02ToolStripMenuItem1";
            this.parte02ToolStripMenuItem1.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem1.Text = "Parte 02";
            this.parte02ToolStripMenuItem1.Click += new System.EventHandler(this.parte02ToolStripMenuItem1_Click);
            // 
            // parte03ToolStripMenuItem1
            // 
            this.parte03ToolStripMenuItem1.Name = "parte03ToolStripMenuItem1";
            this.parte03ToolStripMenuItem1.Size = new System.Drawing.Size(140, 26);
            this.parte03ToolStripMenuItem1.Text = "Parte 03";
            this.parte03ToolStripMenuItem1.Click += new System.EventHandler(this.parte03ToolStripMenuItem1_Click);
            // 
            // parte04ToolStripMenuItem1
            // 
            this.parte04ToolStripMenuItem1.Name = "parte04ToolStripMenuItem1";
            this.parte04ToolStripMenuItem1.Size = new System.Drawing.Size(140, 26);
            this.parte04ToolStripMenuItem1.Text = "Parte 04";
            this.parte04ToolStripMenuItem1.Click += new System.EventHandler(this.parte04ToolStripMenuItem1_Click);
            // 
            // craseToolStripMenuItem
            // 
            this.craseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem2,
            this.parte02ToolStripMenuItem2,
            this.parte03ToolStripMenuItem2,
            this.parte04ToolStripMenuItem2});
            this.craseToolStripMenuItem.Name = "craseToolStripMenuItem";
            this.craseToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.craseToolStripMenuItem.Text = "Crase";
            // 
            // parte01ToolStripMenuItem2
            // 
            this.parte01ToolStripMenuItem2.Name = "parte01ToolStripMenuItem2";
            this.parte01ToolStripMenuItem2.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem2.Text = "Parte 01";
            this.parte01ToolStripMenuItem2.Click += new System.EventHandler(this.parte01ToolStripMenuItem2_Click);
            // 
            // parte02ToolStripMenuItem2
            // 
            this.parte02ToolStripMenuItem2.Name = "parte02ToolStripMenuItem2";
            this.parte02ToolStripMenuItem2.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem2.Text = "Parte 02";
            this.parte02ToolStripMenuItem2.Click += new System.EventHandler(this.parte02ToolStripMenuItem2_Click);
            // 
            // parte03ToolStripMenuItem2
            // 
            this.parte03ToolStripMenuItem2.Name = "parte03ToolStripMenuItem2";
            this.parte03ToolStripMenuItem2.Size = new System.Drawing.Size(140, 26);
            this.parte03ToolStripMenuItem2.Text = "Parte 03";
            this.parte03ToolStripMenuItem2.Click += new System.EventHandler(this.parte03ToolStripMenuItem2_Click);
            // 
            // parte04ToolStripMenuItem2
            // 
            this.parte04ToolStripMenuItem2.Name = "parte04ToolStripMenuItem2";
            this.parte04ToolStripMenuItem2.Size = new System.Drawing.Size(140, 26);
            this.parte04ToolStripMenuItem2.Text = "Parte 04";
            this.parte04ToolStripMenuItem2.Click += new System.EventHandler(this.parte04ToolStripMenuItem2_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem9,
            this.parte02ToolStripMenuItem8});
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(261, 26);
            this.toolStripMenuItem15.Text = "Acentuação";
            // 
            // parte01ToolStripMenuItem9
            // 
            this.parte01ToolStripMenuItem9.Name = "parte01ToolStripMenuItem9";
            this.parte01ToolStripMenuItem9.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem9.Text = "Parte 01";
            this.parte01ToolStripMenuItem9.Click += new System.EventHandler(this.parte01ToolStripMenuItem9_Click);
            // 
            // parte02ToolStripMenuItem8
            // 
            this.parte02ToolStripMenuItem8.Name = "parte02ToolStripMenuItem8";
            this.parte02ToolStripMenuItem8.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem8.Text = "Parte 02";
            this.parte02ToolStripMenuItem8.Click += new System.EventHandler(this.parte02ToolStripMenuItem8_Click);
            // 
            // ortografiaToolStripMenuItem
            // 
            this.ortografiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem8,
            this.parte02ToolStripMenuItem7});
            this.ortografiaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.ortografiaToolStripMenuItem.Name = "ortografiaToolStripMenuItem";
            this.ortografiaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.ortografiaToolStripMenuItem.Text = "Ortografia";
            // 
            // parte01ToolStripMenuItem8
            // 
            this.parte01ToolStripMenuItem8.Name = "parte01ToolStripMenuItem8";
            this.parte01ToolStripMenuItem8.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem8.Text = "Parte 01";
            this.parte01ToolStripMenuItem8.Click += new System.EventHandler(this.parte01ToolStripMenuItem8_Click);
            // 
            // parte02ToolStripMenuItem7
            // 
            this.parte02ToolStripMenuItem7.Name = "parte02ToolStripMenuItem7";
            this.parte02ToolStripMenuItem7.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem7.Text = "Parte 02";
            this.parte02ToolStripMenuItem7.Click += new System.EventHandler(this.parte02ToolStripMenuItem7_Click);
            // 
            // fonologiaEAcentuaçãoToolStripMenuItem
            // 
            this.fonologiaEAcentuaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acentuaçãoToolStripMenuItem});
            this.fonologiaEAcentuaçãoToolStripMenuItem.Name = "fonologiaEAcentuaçãoToolStripMenuItem";
            this.fonologiaEAcentuaçãoToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.fonologiaEAcentuaçãoToolStripMenuItem.Text = "Fonologia e Acentuação";
            // 
            // acentuaçãoToolStripMenuItem
            // 
            this.acentuaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem7,
            this.parte02ToolStripMenuItem6});
            this.acentuaçãoToolStripMenuItem.Name = "acentuaçãoToolStripMenuItem";
            this.acentuaçãoToolStripMenuItem.Size = new System.Drawing.Size(166, 26);
            this.acentuaçãoToolStripMenuItem.Text = "Acentuação";
            // 
            // parte01ToolStripMenuItem7
            // 
            this.parte01ToolStripMenuItem7.Name = "parte01ToolStripMenuItem7";
            this.parte01ToolStripMenuItem7.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem7.Text = "Parte 01";
            this.parte01ToolStripMenuItem7.Click += new System.EventHandler(this.parte01ToolStripMenuItem7_Click);
            // 
            // parte02ToolStripMenuItem6
            // 
            this.parte02ToolStripMenuItem6.Name = "parte02ToolStripMenuItem6";
            this.parte02ToolStripMenuItem6.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem6.Text = "Parte 02";
            this.parte02ToolStripMenuItem6.Click += new System.EventHandler(this.parte02ToolStripMenuItem6_Click);
            // 
            // ortografiaAcentuaçãoToolStripMenuItem
            // 
            this.ortografiaAcentuaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem3,
            this.parte02ToolStripMenuItem3,
            this.parte03ToolStripMenuItem3});
            this.ortografiaAcentuaçãoToolStripMenuItem.Name = "ortografiaAcentuaçãoToolStripMenuItem";
            this.ortografiaAcentuaçãoToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.ortografiaAcentuaçãoToolStripMenuItem.Text = "Ortografia/Acentuação";
            // 
            // parte01ToolStripMenuItem3
            // 
            this.parte01ToolStripMenuItem3.Name = "parte01ToolStripMenuItem3";
            this.parte01ToolStripMenuItem3.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem3.Text = "Parte 01";
            this.parte01ToolStripMenuItem3.Click += new System.EventHandler(this.parte01ToolStripMenuItem3_Click);
            // 
            // parte02ToolStripMenuItem3
            // 
            this.parte02ToolStripMenuItem3.Name = "parte02ToolStripMenuItem3";
            this.parte02ToolStripMenuItem3.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem3.Text = "Parte 02";
            this.parte02ToolStripMenuItem3.Click += new System.EventHandler(this.parte02ToolStripMenuItem3_Click);
            // 
            // parte03ToolStripMenuItem3
            // 
            this.parte03ToolStripMenuItem3.Name = "parte03ToolStripMenuItem3";
            this.parte03ToolStripMenuItem3.Size = new System.Drawing.Size(140, 26);
            this.parte03ToolStripMenuItem3.Text = "Parte 03";
            this.parte03ToolStripMenuItem3.Click += new System.EventHandler(this.parte03ToolStripMenuItem3_Click);
            // 
            // sintaxeToolStripMenuItem
            // 
            this.sintaxeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tiposDeSujeitoToolStripMenuItem,
            this.osTermosDaOraçãoToolStripMenuItem,
            this.oraçãoFormaçãoEPeríodoToolStripMenuItem,
            this.períodoSimplesToolStripMenuItem1,
            this.períodoCompostoToolStripMenuItem1,
            this.regênciaNominalToolStripMenuItem,
            this.regênciaVerbalToolStripMenuItem});
            this.sintaxeToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.sintaxeToolStripMenuItem.Name = "sintaxeToolStripMenuItem";
            this.sintaxeToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.sintaxeToolStripMenuItem.Text = "Sintaxe";
            // 
            // tiposDeSujeitoToolStripMenuItem
            // 
            this.tiposDeSujeitoToolStripMenuItem.Name = "tiposDeSujeitoToolStripMenuItem";
            this.tiposDeSujeitoToolStripMenuItem.Size = new System.Drawing.Size(286, 26);
            this.tiposDeSujeitoToolStripMenuItem.Text = "Tipos de Sujeito";
            this.tiposDeSujeitoToolStripMenuItem.Click += new System.EventHandler(this.tiposDeSujeitoToolStripMenuItem_Click);
            // 
            // osTermosDaOraçãoToolStripMenuItem
            // 
            this.osTermosDaOraçãoToolStripMenuItem.Name = "osTermosDaOraçãoToolStripMenuItem";
            this.osTermosDaOraçãoToolStripMenuItem.Size = new System.Drawing.Size(286, 26);
            this.osTermosDaOraçãoToolStripMenuItem.Text = "Os Termos da Oração";
            this.osTermosDaOraçãoToolStripMenuItem.Click += new System.EventHandler(this.osTermosDaOraçãoToolStripMenuItem_Click);
            // 
            // oraçãoFormaçãoEPeríodoToolStripMenuItem
            // 
            this.oraçãoFormaçãoEPeríodoToolStripMenuItem.Name = "oraçãoFormaçãoEPeríodoToolStripMenuItem";
            this.oraçãoFormaçãoEPeríodoToolStripMenuItem.Size = new System.Drawing.Size(286, 26);
            this.oraçãoFormaçãoEPeríodoToolStripMenuItem.Text = "Oração, Formação e Período";
            this.oraçãoFormaçãoEPeríodoToolStripMenuItem.Click += new System.EventHandler(this.oraçãoFormaçãoEPeríodoToolStripMenuItem_Click);
            // 
            // períodoSimplesToolStripMenuItem1
            // 
            this.períodoSimplesToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adjuntoAdnominalToolStripMenuItem,
            this.oSSToolStripMenuItem1,
            this.complementosNominaisToolStripMenuItem,
            this.apostoEVocativoToolStripMenuItem,
            this.complementosVerbaisToolStripMenuItem});
            this.períodoSimplesToolStripMenuItem1.Name = "períodoSimplesToolStripMenuItem1";
            this.períodoSimplesToolStripMenuItem1.Size = new System.Drawing.Size(286, 26);
            this.períodoSimplesToolStripMenuItem1.Text = "Período Simples";
            // 
            // adjuntoAdnominalToolStripMenuItem
            // 
            this.adjuntoAdnominalToolStripMenuItem.Name = "adjuntoAdnominalToolStripMenuItem";
            this.adjuntoAdnominalToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.adjuntoAdnominalToolStripMenuItem.Text = "Adjunto Adnominal";
            this.adjuntoAdnominalToolStripMenuItem.Click += new System.EventHandler(this.adjuntoAdnominalToolStripMenuItem_Click);
            // 
            // oSSToolStripMenuItem1
            // 
            this.oSSToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem6,
            this.parte2ToolStripMenuItem});
            this.oSSToolStripMenuItem1.Name = "oSSToolStripMenuItem1";
            this.oSSToolStripMenuItem1.Size = new System.Drawing.Size(264, 26);
            this.oSSToolStripMenuItem1.Text = "OSS";
            // 
            // parte01ToolStripMenuItem6
            // 
            this.parte01ToolStripMenuItem6.Name = "parte01ToolStripMenuItem6";
            this.parte01ToolStripMenuItem6.Size = new System.Drawing.Size(137, 26);
            this.parte01ToolStripMenuItem6.Text = "Parte 01";
            this.parte01ToolStripMenuItem6.Click += new System.EventHandler(this.parte01ToolStripMenuItem6_Click);
            // 
            // parte2ToolStripMenuItem
            // 
            this.parte2ToolStripMenuItem.Name = "parte2ToolStripMenuItem";
            this.parte2ToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parte2ToolStripMenuItem.Text = "Parte 2";
            this.parte2ToolStripMenuItem.Click += new System.EventHandler(this.parte2ToolStripMenuItem_Click);
            // 
            // complementosNominaisToolStripMenuItem
            // 
            this.complementosNominaisToolStripMenuItem.Name = "complementosNominaisToolStripMenuItem";
            this.complementosNominaisToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.complementosNominaisToolStripMenuItem.Text = "Complementos Nominais";
            this.complementosNominaisToolStripMenuItem.Click += new System.EventHandler(this.complementosNominaisToolStripMenuItem_Click);
            // 
            // apostoEVocativoToolStripMenuItem
            // 
            this.apostoEVocativoToolStripMenuItem.Name = "apostoEVocativoToolStripMenuItem";
            this.apostoEVocativoToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.apostoEVocativoToolStripMenuItem.Text = "Aposto e Vocativo";
            this.apostoEVocativoToolStripMenuItem.Click += new System.EventHandler(this.apostoEVocativoToolStripMenuItem_Click);
            // 
            // complementosVerbaisToolStripMenuItem
            // 
            this.complementosVerbaisToolStripMenuItem.Name = "complementosVerbaisToolStripMenuItem";
            this.complementosVerbaisToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.complementosVerbaisToolStripMenuItem.Text = "Complementos Verbais";
            this.complementosVerbaisToolStripMenuItem.Click += new System.EventHandler(this.complementosVerbaisToolStripMenuItem_Click);
            // 
            // períodoCompostoToolStripMenuItem1
            // 
            this.períodoCompostoToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oSSToolStripMenuItem,
            this.oSAToolStripMenuItem1,
            this.oSADToolStripMenuItem,
            this.oCAToolStripMenuItem,
            this.oCSToolStripMenuItem});
            this.períodoCompostoToolStripMenuItem1.Name = "períodoCompostoToolStripMenuItem1";
            this.períodoCompostoToolStripMenuItem1.Size = new System.Drawing.Size(286, 26);
            this.períodoCompostoToolStripMenuItem1.Text = "Período Composto";
            // 
            // oSSToolStripMenuItem
            // 
            this.oSSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem4,
            this.parte02ToolStripMenuItem4,
            this.parte03ToolStripMenuItem4});
            this.oSSToolStripMenuItem.Name = "oSSToolStripMenuItem";
            this.oSSToolStripMenuItem.Size = new System.Drawing.Size(123, 26);
            this.oSSToolStripMenuItem.Text = "OSS";
            // 
            // parte01ToolStripMenuItem4
            // 
            this.parte01ToolStripMenuItem4.Name = "parte01ToolStripMenuItem4";
            this.parte01ToolStripMenuItem4.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem4.Text = "Parte 01";
            // 
            // parte02ToolStripMenuItem4
            // 
            this.parte02ToolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oSAToolStripMenuItem});
            this.parte02ToolStripMenuItem4.Name = "parte02ToolStripMenuItem4";
            this.parte02ToolStripMenuItem4.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem4.Text = "Parte 02";
            // 
            // oSAToolStripMenuItem
            // 
            this.oSAToolStripMenuItem.Name = "oSAToolStripMenuItem";
            this.oSAToolStripMenuItem.Size = new System.Drawing.Size(112, 26);
            this.oSAToolStripMenuItem.Text = "OSA";
            // 
            // parte03ToolStripMenuItem4
            // 
            this.parte03ToolStripMenuItem4.Name = "parte03ToolStripMenuItem4";
            this.parte03ToolStripMenuItem4.Size = new System.Drawing.Size(140, 26);
            this.parte03ToolStripMenuItem4.Text = "Parte 03";
            // 
            // oSAToolStripMenuItem1
            // 
            this.oSAToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte01ToolStripMenuItem5,
            this.parte02ToolStripMenuItem5});
            this.oSAToolStripMenuItem1.Name = "oSAToolStripMenuItem1";
            this.oSAToolStripMenuItem1.Size = new System.Drawing.Size(123, 26);
            this.oSAToolStripMenuItem1.Text = "OSA";
            // 
            // parte01ToolStripMenuItem5
            // 
            this.parte01ToolStripMenuItem5.Name = "parte01ToolStripMenuItem5";
            this.parte01ToolStripMenuItem5.Size = new System.Drawing.Size(140, 26);
            this.parte01ToolStripMenuItem5.Text = "Parte 01";
            // 
            // parte02ToolStripMenuItem5
            // 
            this.parte02ToolStripMenuItem5.Name = "parte02ToolStripMenuItem5";
            this.parte02ToolStripMenuItem5.Size = new System.Drawing.Size(140, 26);
            this.parte02ToolStripMenuItem5.Text = "Parte 02";
            // 
            // oSADToolStripMenuItem
            // 
            this.oSADToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parte1ToolStripMenuItem,
            this.parte2ToolStripMenuItem1});
            this.oSADToolStripMenuItem.Name = "oSADToolStripMenuItem";
            this.oSADToolStripMenuItem.Size = new System.Drawing.Size(123, 26);
            this.oSADToolStripMenuItem.Text = "OSAD";
            // 
            // parte1ToolStripMenuItem
            // 
            this.parte1ToolStripMenuItem.Name = "parte1ToolStripMenuItem";
            this.parte1ToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.parte1ToolStripMenuItem.Text = "Parte 1";
            // 
            // parte2ToolStripMenuItem1
            // 
            this.parte2ToolStripMenuItem1.Name = "parte2ToolStripMenuItem1";
            this.parte2ToolStripMenuItem1.Size = new System.Drawing.Size(131, 26);
            this.parte2ToolStripMenuItem1.Text = "Parte 2";
            // 
            // oCAToolStripMenuItem
            // 
            this.oCAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eRRADOToolStripMenuItem});
            this.oCAToolStripMenuItem.Name = "oCAToolStripMenuItem";
            this.oCAToolStripMenuItem.Size = new System.Drawing.Size(123, 26);
            this.oCAToolStripMenuItem.Text = "OCA";
            // 
            // eRRADOToolStripMenuItem
            // 
            this.eRRADOToolStripMenuItem.Name = "eRRADOToolStripMenuItem";
            this.eRRADOToolStripMenuItem.Size = new System.Drawing.Size(142, 26);
            this.eRRADOToolStripMenuItem.Text = "ERRADO";
            // 
            // oCSToolStripMenuItem
            // 
            this.oCSToolStripMenuItem.Name = "oCSToolStripMenuItem";
            this.oCSToolStripMenuItem.Size = new System.Drawing.Size(123, 26);
            this.oCSToolStripMenuItem.Text = "OCS";
            // 
            // regênciaNominalToolStripMenuItem
            // 
            this.regênciaNominalToolStripMenuItem.Name = "regênciaNominalToolStripMenuItem";
            this.regênciaNominalToolStripMenuItem.Size = new System.Drawing.Size(286, 26);
            this.regênciaNominalToolStripMenuItem.Text = "Regência Nominal";
            // 
            // regênciaVerbalToolStripMenuItem
            // 
            this.regênciaVerbalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem,
            this.parteIIToolStripMenuItem,
            this.parteIIIToolStripMenuItem,
            this.parteIVToolStripMenuItem,
            this.parteVToolStripMenuItem});
            this.regênciaVerbalToolStripMenuItem.Name = "regênciaVerbalToolStripMenuItem";
            this.regênciaVerbalToolStripMenuItem.Size = new System.Drawing.Size(286, 26);
            this.regênciaVerbalToolStripMenuItem.Text = "Regência Verbal";
            // 
            // parteIToolStripMenuItem
            // 
            this.parteIToolStripMenuItem.Name = "parteIToolStripMenuItem";
            this.parteIToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parteIToolStripMenuItem.Text = "Parte I";
            // 
            // parteIIToolStripMenuItem
            // 
            this.parteIIToolStripMenuItem.Name = "parteIIToolStripMenuItem";
            this.parteIIToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parteIIToolStripMenuItem.Text = "Parte II";
            // 
            // parteIIIToolStripMenuItem
            // 
            this.parteIIIToolStripMenuItem.Name = "parteIIIToolStripMenuItem";
            this.parteIIIToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parteIIIToolStripMenuItem.Text = "Parte III";
            // 
            // parteIVToolStripMenuItem
            // 
            this.parteIVToolStripMenuItem.Name = "parteIVToolStripMenuItem";
            this.parteIVToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parteIVToolStripMenuItem.Text = "Parte IV";
            // 
            // parteVToolStripMenuItem
            // 
            this.parteVToolStripMenuItem.Name = "parteVToolStripMenuItem";
            this.parteVToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parteVToolStripMenuItem.Text = "Parte V";
            // 
            // concordânciaToolStripMenuItem
            // 
            this.concordânciaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.concordânciaVerbalToolStripMenuItem,
            this.concordânciaNominalToolStripMenuItem});
            this.concordânciaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.concordânciaToolStripMenuItem.Name = "concordânciaToolStripMenuItem";
            this.concordânciaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.concordânciaToolStripMenuItem.Text = "Concordância";
            // 
            // concordânciaVerbalToolStripMenuItem
            // 
            this.concordânciaVerbalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem1,
            this.parteIIToolStripMenuItem1,
            this.parteIIIToolStripMenuItem1,
            this.parteIVToolStripMenuItem1,
            this.parteVToolStripMenuItem1,
            this.parteVIToolStripMenuItem});
            this.concordânciaVerbalToolStripMenuItem.Name = "concordânciaVerbalToolStripMenuItem";
            this.concordânciaVerbalToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.concordânciaVerbalToolStripMenuItem.Text = "Concordância Verbal ";
            // 
            // parteIToolStripMenuItem1
            // 
            this.parteIToolStripMenuItem1.Name = "parteIToolStripMenuItem1";
            this.parteIToolStripMenuItem1.Size = new System.Drawing.Size(137, 26);
            this.parteIToolStripMenuItem1.Text = "Parte I";
            // 
            // parteIIToolStripMenuItem1
            // 
            this.parteIIToolStripMenuItem1.Name = "parteIIToolStripMenuItem1";
            this.parteIIToolStripMenuItem1.Size = new System.Drawing.Size(137, 26);
            this.parteIIToolStripMenuItem1.Text = "Parte II";
            // 
            // parteIIIToolStripMenuItem1
            // 
            this.parteIIIToolStripMenuItem1.Name = "parteIIIToolStripMenuItem1";
            this.parteIIIToolStripMenuItem1.Size = new System.Drawing.Size(137, 26);
            this.parteIIIToolStripMenuItem1.Text = "Parte III";
            // 
            // parteIVToolStripMenuItem1
            // 
            this.parteIVToolStripMenuItem1.Name = "parteIVToolStripMenuItem1";
            this.parteIVToolStripMenuItem1.Size = new System.Drawing.Size(137, 26);
            this.parteIVToolStripMenuItem1.Text = "Parte IV";
            // 
            // parteVToolStripMenuItem1
            // 
            this.parteVToolStripMenuItem1.Name = "parteVToolStripMenuItem1";
            this.parteVToolStripMenuItem1.Size = new System.Drawing.Size(137, 26);
            this.parteVToolStripMenuItem1.Text = "Parte V";
            // 
            // parteVIToolStripMenuItem
            // 
            this.parteVIToolStripMenuItem.Name = "parteVIToolStripMenuItem";
            this.parteVIToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.parteVIToolStripMenuItem.Text = "Parte VI";
            // 
            // concordânciaNominalToolStripMenuItem
            // 
            this.concordânciaNominalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem2,
            this.parteIIToolStripMenuItem2,
            this.parteIIIToolStripMenuItem2});
            this.concordânciaNominalToolStripMenuItem.Name = "concordânciaNominalToolStripMenuItem";
            this.concordânciaNominalToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.concordânciaNominalToolStripMenuItem.Text = "Concordância Nominal";
            // 
            // parteIToolStripMenuItem2
            // 
            this.parteIToolStripMenuItem2.Name = "parteIToolStripMenuItem2";
            this.parteIToolStripMenuItem2.Size = new System.Drawing.Size(137, 26);
            this.parteIToolStripMenuItem2.Text = "Parte I";
            // 
            // parteIIToolStripMenuItem2
            // 
            this.parteIIToolStripMenuItem2.Name = "parteIIToolStripMenuItem2";
            this.parteIIToolStripMenuItem2.Size = new System.Drawing.Size(137, 26);
            this.parteIIToolStripMenuItem2.Text = "Parte II";
            // 
            // parteIIIToolStripMenuItem2
            // 
            this.parteIIIToolStripMenuItem2.Name = "parteIIIToolStripMenuItem2";
            this.parteIIIToolStripMenuItem2.Size = new System.Drawing.Size(137, 26);
            this.parteIIIToolStripMenuItem2.Text = "Parte III";
            // 
            // predicaçãoVerbaToolStripMenuItem
            // 
            this.predicaçãoVerbaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verbosTransitivosDiretosToolStripMenuItem,
            this.verbosTransitivosIndiretosEBitransitivosToolStripMenuItem,
            this.verbosIntransitivosToolStripMenuItem,
            this.verbosDeLigaçãoToolStripMenuItem});
            this.predicaçãoVerbaToolStripMenuItem.Name = "predicaçãoVerbaToolStripMenuItem";
            this.predicaçãoVerbaToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.predicaçãoVerbaToolStripMenuItem.Text = "Predicação Verbal";
            // 
            // verbosTransitivosDiretosToolStripMenuItem
            // 
            this.verbosTransitivosDiretosToolStripMenuItem.Name = "verbosTransitivosDiretosToolStripMenuItem";
            this.verbosTransitivosDiretosToolStripMenuItem.Size = new System.Drawing.Size(388, 26);
            this.verbosTransitivosDiretosToolStripMenuItem.Text = "Verbos Transitivos Diretos";
            // 
            // verbosTransitivosIndiretosEBitransitivosToolStripMenuItem
            // 
            this.verbosTransitivosIndiretosEBitransitivosToolStripMenuItem.Name = "verbosTransitivosIndiretosEBitransitivosToolStripMenuItem";
            this.verbosTransitivosIndiretosEBitransitivosToolStripMenuItem.Size = new System.Drawing.Size(388, 26);
            this.verbosTransitivosIndiretosEBitransitivosToolStripMenuItem.Text = "Verbos Transitivos Indiretos e Bitransitivos";
            // 
            // verbosIntransitivosToolStripMenuItem
            // 
            this.verbosIntransitivosToolStripMenuItem.Name = "verbosIntransitivosToolStripMenuItem";
            this.verbosIntransitivosToolStripMenuItem.Size = new System.Drawing.Size(388, 26);
            this.verbosIntransitivosToolStripMenuItem.Text = "Verbos Intransitivos";
            // 
            // verbosDeLigaçãoToolStripMenuItem
            // 
            this.verbosDeLigaçãoToolStripMenuItem.Name = "verbosDeLigaçãoToolStripMenuItem";
            this.verbosDeLigaçãoToolStripMenuItem.Size = new System.Drawing.Size(388, 26);
            this.verbosDeLigaçãoToolStripMenuItem.Text = "Verbos de Ligação";
            // 
            // colocaçãoPronominalToolStripMenuItem
            // 
            this.colocaçãoPronominalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem16,
            this.toolStripMenuItem17,
            this.parte03ToolStripMenuItem5});
            this.colocaçãoPronominalToolStripMenuItem.Name = "colocaçãoPronominalToolStripMenuItem";
            this.colocaçãoPronominalToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.colocaçãoPronominalToolStripMenuItem.Text = "Colocação Pronominal";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(140, 26);
            this.toolStripMenuItem16.Text = "Parte 01";
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(140, 26);
            this.toolStripMenuItem17.Text = "Parte 02";
            // 
            // parte03ToolStripMenuItem5
            // 
            this.parte03ToolStripMenuItem5.Name = "parte03ToolStripMenuItem5";
            this.parte03ToolStripMenuItem5.Size = new System.Drawing.Size(140, 26);
            this.parte03ToolStripMenuItem5.Text = "Parte 03";
            // 
            // pontuaçãoToolStripMenuItem
            // 
            this.pontuaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem18,
            this.toolStripMenuItem19,
            this.toolStripMenuItem20,
            this.toolStripMenuItem21});
            this.pontuaçãoToolStripMenuItem.Name = "pontuaçãoToolStripMenuItem";
            this.pontuaçãoToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.pontuaçãoToolStripMenuItem.Text = "Pontuação";
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem18.Text = "Parte I";
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem19.Text = "Parte II";
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem20.Text = "Parte III";
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem21.Text = "Parte IV";
            // 
            // redaçãoToolStripMenuItem
            // 
            this.redaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dissertaçãoToolStripMenuItem});
            this.redaçãoToolStripMenuItem.Name = "redaçãoToolStripMenuItem";
            this.redaçãoToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.redaçãoToolStripMenuItem.Text = "Redação";
            // 
            // dissertaçãoToolStripMenuItem
            // 
            this.dissertaçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem6,
            this.parteIIToolStripMenuItem5,
            this.parteIIIToolStripMenuItem5,
            this.parteIVToolStripMenuItem3,
            this.parteVToolStripMenuItem3,
            this.tópicosFrasaisToolStripMenuItem});
            this.dissertaçãoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.dissertaçãoToolStripMenuItem.Name = "dissertaçãoToolStripMenuItem";
            this.dissertaçãoToolStripMenuItem.Size = new System.Drawing.Size(164, 26);
            this.dissertaçãoToolStripMenuItem.Text = "Dissertação";
            // 
            // parteIToolStripMenuItem6
            // 
            this.parteIToolStripMenuItem6.Name = "parteIToolStripMenuItem6";
            this.parteIToolStripMenuItem6.Size = new System.Drawing.Size(188, 26);
            this.parteIToolStripMenuItem6.Text = "Parte I";
            // 
            // parteIIToolStripMenuItem5
            // 
            this.parteIIToolStripMenuItem5.Name = "parteIIToolStripMenuItem5";
            this.parteIIToolStripMenuItem5.Size = new System.Drawing.Size(188, 26);
            this.parteIIToolStripMenuItem5.Text = "Parte II";
            // 
            // parteIIIToolStripMenuItem5
            // 
            this.parteIIIToolStripMenuItem5.Name = "parteIIIToolStripMenuItem5";
            this.parteIIIToolStripMenuItem5.Size = new System.Drawing.Size(188, 26);
            this.parteIIIToolStripMenuItem5.Text = "Parte III";
            // 
            // parteIVToolStripMenuItem3
            // 
            this.parteIVToolStripMenuItem3.Name = "parteIVToolStripMenuItem3";
            this.parteIVToolStripMenuItem3.Size = new System.Drawing.Size(188, 26);
            this.parteIVToolStripMenuItem3.Text = "Parte IV";
            // 
            // parteVToolStripMenuItem3
            // 
            this.parteVToolStripMenuItem3.Name = "parteVToolStripMenuItem3";
            this.parteVToolStripMenuItem3.Size = new System.Drawing.Size(188, 26);
            this.parteVToolStripMenuItem3.Text = "Parte V";
            // 
            // tópicosFrasaisToolStripMenuItem
            // 
            this.tópicosFrasaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem5,
            this.parteIIToolStripMenuItem4,
            this.parteIIIToolStripMenuItem4});
            this.tópicosFrasaisToolStripMenuItem.Name = "tópicosFrasaisToolStripMenuItem";
            this.tópicosFrasaisToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.tópicosFrasaisToolStripMenuItem.Text = "Tópicos Frasais";
            // 
            // parteIToolStripMenuItem5
            // 
            this.parteIToolStripMenuItem5.Name = "parteIToolStripMenuItem5";
            this.parteIToolStripMenuItem5.Size = new System.Drawing.Size(137, 26);
            this.parteIToolStripMenuItem5.Text = "Parte I";
            // 
            // parteIIToolStripMenuItem4
            // 
            this.parteIIToolStripMenuItem4.Name = "parteIIToolStripMenuItem4";
            this.parteIIToolStripMenuItem4.Size = new System.Drawing.Size(137, 26);
            this.parteIIToolStripMenuItem4.Text = "Parte II";
            // 
            // parteIIIToolStripMenuItem4
            // 
            this.parteIIIToolStripMenuItem4.Name = "parteIIIToolStripMenuItem4";
            this.parteIIIToolStripMenuItem4.Size = new System.Drawing.Size(137, 26);
            this.parteIIIToolStripMenuItem4.Text = "Parte III";
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(914, 612);
            this.sfoPlayer.TabIndex = 38;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(914, 612);
            this.PictureCSharp.TabIndex = 39;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(914, 612);
            this.panelQuiz.TabIndex = 65;
            // 
            // FrmPort
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPort";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmHtml";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fecharMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cursoEmVídeoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem históriaDaInternetToolItem;
        private System.Windows.Forms.ToolStripMenuItem interpretaçãoDeTextosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem literaturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arcadismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem barrocoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oRomantismoNoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem préModernismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quinhentismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simbolismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redaçãoToolStripMenuItem;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem siteCompletoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asDivisõesDaGramáticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem semânticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte03ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte04ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fonéticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parte03ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parte04ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem craseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parte03ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parte04ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ortografiaAcentuaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem parte03ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem sintaxeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposDeSujeitoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem osTermosDaOraçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oraçãoFormaçãoEPeríodoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoSimplesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem adjuntoAdnominalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oSSToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem parte2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem complementosNominaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem apostoEVocativoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem complementosVerbaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoCompostoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem oSSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem oSAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte03ToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem oSAToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem oSADToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem oCAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eRRADOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oCSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regênciaNominalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regênciaVerbalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem concordânciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem concordânciaVerbalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fonologiaEAcentuaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classesGramaticaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parteIIToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parteIIIToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parteIVToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parteVToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parteVIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem concordânciaNominalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parteIIToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parteIIIToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem acentuaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem figurasDeLinguagemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aula01ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aula02ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem morfologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem substantivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem parteIIVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem advérbiosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem artigoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conjunçõesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem numeraisEInterjeiçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem ortografiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parte01ToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem parte02ToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem predicaçãoVerbaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verbosTransitivosDiretosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verbosTransitivosIndiretosEBitransitivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verbosIntransitivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verbosDeLigaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colocaçãoPronominalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem parte03ToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem pontuaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem dissertaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem parteIIToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem parteIIIToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem parteIVToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem parteVToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem tópicosFrasaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem parteIIToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem parteIIIToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem pronomesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem verbosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem parteIIToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem parteIIIToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem parteIVToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parteVToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem parteVIToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem parteVIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteVIIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteXIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteXIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteXIIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteXIVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoÀLiteraturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poesiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prosaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem realismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem naturalismoImpressionismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parnasianismoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem semanaDeArteModernaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modernismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ªFaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ªFasePoesiaModernaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ªFaseRomanceDe30ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ªFaseGeraçãoDe45ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem literaturaPortuguesaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trovadorismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cantigasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem humanismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renascimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem classicismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vanguardasEuropeiasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cubismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dadaísmoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expressionismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fauvismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem futurismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem surrealismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem concretismoToolStripMenuItem;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem perguntasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interpretaçãoDeTextosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem figurasDeLinguagemToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem perguntasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem60;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem65;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem70;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem75;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem78;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem81;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem82;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem85;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem89;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem123;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem124;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem131;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem135;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem136;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem137;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem138;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem139;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem140;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem144;
        private System.Windows.Forms.ToolStripMenuItem perguntasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem quinhentismoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem149;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem150;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem151;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem153;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem154;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem155;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem156;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem157;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem158;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem159;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem160;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem161;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem162;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem163;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem164;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem165;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem166;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem167;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem168;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem169;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem170;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem171;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem172;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem173;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem174;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem175;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem178;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem179;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem180;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem181;
    }
}