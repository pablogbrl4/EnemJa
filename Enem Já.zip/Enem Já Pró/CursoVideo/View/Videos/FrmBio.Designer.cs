﻿namespace CursoVideo.View.Videos
{
    partial class FrmBiologia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBiologia));
            this.tsmiBiologia = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.impérioBiológicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionamentoDeUmEcossistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoresBióticosEAbióticosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.habitatNichoEcológicoEcótonoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.cadeiasXTeiasAlimentaresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sucessãoEcológicaPrimáriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sucessãoEcológicaSecundáriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.ecologiaDePopulaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.ciclosBiogeoquímicosÁguaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ciclosBiogeoquímicosCarbonoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ciclosBiogeoquímicosOxigênioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ciclosBiogeoquímicosNitrogênioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.pirâmideDeNúmerosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pirâmidesDeBiomassaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pirâmidesDeEnergiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pirâmideDeFluxoDeEnergiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem52 = new System.Windows.Forms.ToolStripMenuItem();
            this.principaisBiomasBrasileiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem53 = new System.Windows.Forms.ToolStripMenuItem();
            this.biodiversidadeAmeaçadaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.biodiversidadeAmeaçadaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.efeitoEstufaXAquecimentoGlobalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poluiçãoSonoraETérmicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poluiçãoAtmosféricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extinçãoDeEspéciesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eutrofizaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poluiçãoPorDerramamentoDePetróleoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem55 = new System.Windows.Forms.ToolStripMenuItem();
            this.relaçõesDoHomemComANaturezaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem56 = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoVerdeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem57 = new System.Windows.Forms.ToolStripMenuItem();
            this.oQueÉSaneamentoBásicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vertentesDeSaneamentoBásicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem58 = new System.Windows.Forms.ToolStripMenuItem();
            this.legislaçãoAmbientalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem59 = new System.Windows.Forms.ToolStripMenuItem();
            this.oQueÉBiodiversidadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.membranaPlasmáticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transporteCelularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.membranaPlasmáticaespecializaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.organelasCitoplasmáticas1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.organelasCitoplasmáticas2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.núcleoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.núcleoReplicaçãoDoDNAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.núcleoRNAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.interfaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mitoseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.meioseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.águaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proteinasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.carboidratosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lipídiosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.metabolismoCelularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.respiraçãoCelularGlicóliseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.respiraçãoCelularCicloDeKrebsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fermentaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fotossínteseIFaseClaraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fotossínteseIIFaseEscuraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.códigoGenéticoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.sínteseDeProteínasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.diferenciaçãoCelularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tecidoEpitelialDeRevestimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tecidoEpitelialGlandularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tecidoConjuntivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tecidoConjuntivoPropriamenteDitoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tecidoMuscularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.origemdascélulaseucarióticasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.célulasTroncoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClonagemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dNARecombinanteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.biotecnologiaESuasAplicaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oQueÉBiotecnologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.genéticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ªLeiDeMendelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.heredogramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaABOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polialeliaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ªLeiDeMendelToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.poliibridismoEPleiotropiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interaçãoGênicaComplementarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interaçãoGênicaEpistasiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interaçãoGênicaQuantitativaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.herançaSexualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.determinaçãoDoSexoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.botânicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.reinoPlantaeReproduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.florECicloDeVidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frutoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.nToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taxonomiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.reinoMoneraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reinoMoneraIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reinoMoneraIIToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.vírusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reinoProtistaProtozoáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reinoFungiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem60 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem61 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem62 = new System.Windows.Forms.ToolStripMenuItem();
            this.origemDaVidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem63 = new System.Windows.Forms.ToolStripMenuItem();
            this.teoriasEvolutivasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem65 = new System.Windows.Forms.ToolStripMenuItem();
            this.seleçãoNaturalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.especiaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cladogêneseEAnagêneseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.isolamentoReprodutivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.embriologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gametogêneseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fecundaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposDeOvosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.embriogêneseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anexosEmbrionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipoDeReproduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fisiologiaHumanaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaUrinárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaNervosoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaDigestórioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaRespiratórioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaCirculatórioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.perguntasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ecologiaECiênciasAmbientaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ecossistemasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem72 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem74 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem76 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem78 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem85 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem87 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem94 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem96 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem98 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem101 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem108 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem113 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem117 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem118 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem119 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem122 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem123 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem124 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem125 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem126 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem130 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem132 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem133 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem136 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem137 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem138 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem145 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem146 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem147 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem148 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem149 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem150 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem38 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem66 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem68 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem69 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem70 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem71 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem73 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem79 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem88 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem109 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem110 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // tsmiBiologia
            // 
            this.tsmiBiologia.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tsmiBiologia.Checked = true;
            this.tsmiBiologia.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsmiBiologia.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem42,
            this.toolStripMenuItem3,
            this.genéticaToolStripMenuItem,
            this.botânicaToolStripMenuItem,
            this.toolStripMenuItem30,
            this.toolStripMenuItem60,
            this.embriologiaToolStripMenuItem,
            this.fisiologiaHumanaToolStripMenuItem});
            this.tsmiBiologia.ForeColor = System.Drawing.Color.Black;
            this.tsmiBiologia.Name = "tsmiBiologia";
            this.tsmiBiologia.Size = new System.Drawing.Size(109, 25);
            this.tsmiBiologia.Text = "Biologia";
            this.tsmiBiologia.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem43,
            this.toolStripMenuItem44,
            this.toolStripMenuItem45,
            this.toolStripMenuItem46,
            this.toolStripMenuItem47,
            this.toolStripMenuItem48,
            this.toolStripMenuItem49,
            this.toolStripMenuItem50,
            this.toolStripMenuItem51,
            this.toolStripMenuItem52,
            this.toolStripMenuItem53,
            this.toolStripMenuItem54,
            this.toolStripMenuItem55,
            this.toolStripMenuItem56,
            this.toolStripMenuItem57,
            this.toolStripMenuItem58,
            this.toolStripMenuItem59});
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem42.Text = "Ecologia e Ciências Ambientais";
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.impérioBiológicoToolStripMenuItem,
            this.funcionamentoDeUmEcossistemaToolStripMenuItem});
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem43.Text = "Ecossistemas";
            // 
            // impérioBiológicoToolStripMenuItem
            // 
            this.impérioBiológicoToolStripMenuItem.Name = "impérioBiológicoToolStripMenuItem";
            this.impérioBiológicoToolStripMenuItem.Size = new System.Drawing.Size(340, 26);
            this.impérioBiológicoToolStripMenuItem.Text = "Império Biológico";
            this.impérioBiológicoToolStripMenuItem.Click += new System.EventHandler(this.impérioBiológicoToolStripMenuItem_Click);
            // 
            // funcionamentoDeUmEcossistemaToolStripMenuItem
            // 
            this.funcionamentoDeUmEcossistemaToolStripMenuItem.Name = "funcionamentoDeUmEcossistemaToolStripMenuItem";
            this.funcionamentoDeUmEcossistemaToolStripMenuItem.Size = new System.Drawing.Size(340, 26);
            this.funcionamentoDeUmEcossistemaToolStripMenuItem.Text = "Funcionamento de  um ecossistema";
            this.funcionamentoDeUmEcossistemaToolStripMenuItem.Click += new System.EventHandler(this.funcionamentoDeUmEcossistemaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fatoresBióticosEAbióticosToolStripMenuItem});
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem44.Text = "Fatores Bióticos e Abióticos";
            // 
            // fatoresBióticosEAbióticosToolStripMenuItem
            // 
            this.fatoresBióticosEAbióticosToolStripMenuItem.Name = "fatoresBióticosEAbióticosToolStripMenuItem";
            this.fatoresBióticosEAbióticosToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.fatoresBióticosEAbióticosToolStripMenuItem.Text = "Fatores bióticos e abióticos";
            this.fatoresBióticosEAbióticosToolStripMenuItem.Click += new System.EventHandler(this.fatoresBióticosEAbióticosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.habitatNichoEcológicoEcótonoToolStripMenuItem});
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem45.Text = "Habitat e Nicho Ecológico";
            // 
            // habitatNichoEcológicoEcótonoToolStripMenuItem
            // 
            this.habitatNichoEcológicoEcótonoToolStripMenuItem.Name = "habitatNichoEcológicoEcótonoToolStripMenuItem";
            this.habitatNichoEcológicoEcótonoToolStripMenuItem.Size = new System.Drawing.Size(330, 26);
            this.habitatNichoEcológicoEcótonoToolStripMenuItem.Text = "Habitat. Nicho Ecológico, Ecótono";
            this.habitatNichoEcológicoEcótonoToolStripMenuItem.Click += new System.EventHandler(this.habitatNichoEcológicoEcótonoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadeiasXTeiasAlimentaresToolStripMenuItem,
            this.sucessãoEcológicaPrimáriaToolStripMenuItem,
            this.sucessãoEcológicaSecundáriaToolStripMenuItem});
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem46.Text = "A Comunidade Biológica: Teia Alimentar, Sucessão e Comunidade Clímax";
            // 
            // cadeiasXTeiasAlimentaresToolStripMenuItem
            // 
            this.cadeiasXTeiasAlimentaresToolStripMenuItem.Name = "cadeiasXTeiasAlimentaresToolStripMenuItem";
            this.cadeiasXTeiasAlimentaresToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.cadeiasXTeiasAlimentaresToolStripMenuItem.Text = "Cadeias x Teias alimentares";
            this.cadeiasXTeiasAlimentaresToolStripMenuItem.Click += new System.EventHandler(this.cadeiasXTeiasAlimentaresToolStripMenuItem_Click);
            // 
            // sucessãoEcológicaPrimáriaToolStripMenuItem
            // 
            this.sucessãoEcológicaPrimáriaToolStripMenuItem.Name = "sucessãoEcológicaPrimáriaToolStripMenuItem";
            this.sucessãoEcológicaPrimáriaToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.sucessãoEcológicaPrimáriaToolStripMenuItem.Text = "Sucessão ecológica: primária";
            this.sucessãoEcológicaPrimáriaToolStripMenuItem.Click += new System.EventHandler(this.sucessãoEcológicaPrimáriaToolStripMenuItem_Click);
            // 
            // sucessãoEcológicaSecundáriaToolStripMenuItem
            // 
            this.sucessãoEcológicaSecundáriaToolStripMenuItem.Name = "sucessãoEcológicaSecundáriaToolStripMenuItem";
            this.sucessãoEcológicaSecundáriaToolStripMenuItem.Size = new System.Drawing.Size(308, 26);
            this.sucessãoEcológicaSecundáriaToolStripMenuItem.Text = "Sucessão ecológica: secundária";
            this.sucessãoEcológicaSecundáriaToolStripMenuItem.Click += new System.EventHandler(this.sucessãoEcológicaSecundáriaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ecologiaDePopulaçõesToolStripMenuItem});
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem47.Text = "Dinâmica das Populações";
            // 
            // ecologiaDePopulaçõesToolStripMenuItem
            // 
            this.ecologiaDePopulaçõesToolStripMenuItem.Name = "ecologiaDePopulaçõesToolStripMenuItem";
            this.ecologiaDePopulaçõesToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.ecologiaDePopulaçõesToolStripMenuItem.Text = "Ecologia de Populações";
            this.ecologiaDePopulaçõesToolStripMenuItem.Click += new System.EventHandler(this.ecologiaDePopulaçõesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem,
            this.nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem,
            this.interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem});
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem48.Text = "Interações entre os Seres Vivos";
            // 
            // relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem
            // 
            this.relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem.Name = "relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuIt" +
    "em";
            this.relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem.Size = new System.Drawing.Size(637, 26);
            this.relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem.Text = "Relações ecológicas INTRAespecífica x INTERespecífica, sociedade e colônia";
            this.relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem.Click += new System.EventHandler(this.relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem_Click);
            // 
            // nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem
            // 
            this.nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem.Name = "nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem";
            this.nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem.Size = new System.Drawing.Size(637, 26);
            this.nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem.Text = "nterespecíficas harmônicas: Comensalismo, inquilinismo, e forésia";
            this.nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem.Click += new System.EventHandler(this.nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem_Click);
            // 
            // interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem
            // 
            this.interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem.Name = "interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem";
            this.interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem.Size = new System.Drawing.Size(637, 26);
            this.interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem.Text = "Interespecíficas desarmônicas: Amensalismo, predatismo e competição";
            this.interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem.Click += new System.EventHandler(this.interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ciclosBiogeoquímicosÁguaToolStripMenuItem,
            this.ciclosBiogeoquímicosCarbonoToolStripMenuItem,
            this.ciclosBiogeoquímicosOxigênioToolStripMenuItem,
            this.ciclosBiogeoquímicosNitrogênioToolStripMenuItem});
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem49.Text = "Ciclos Biogeoquímicos";
            // 
            // ciclosBiogeoquímicosÁguaToolStripMenuItem
            // 
            this.ciclosBiogeoquímicosÁguaToolStripMenuItem.Name = "ciclosBiogeoquímicosÁguaToolStripMenuItem";
            this.ciclosBiogeoquímicosÁguaToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.ciclosBiogeoquímicosÁguaToolStripMenuItem.Text = "Água";
            this.ciclosBiogeoquímicosÁguaToolStripMenuItem.Click += new System.EventHandler(this.ciclosBiogeoquímicosÁguaToolStripMenuItem_Click);
            // 
            // ciclosBiogeoquímicosCarbonoToolStripMenuItem
            // 
            this.ciclosBiogeoquímicosCarbonoToolStripMenuItem.Name = "ciclosBiogeoquímicosCarbonoToolStripMenuItem";
            this.ciclosBiogeoquímicosCarbonoToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.ciclosBiogeoquímicosCarbonoToolStripMenuItem.Text = "Carbono";
            this.ciclosBiogeoquímicosCarbonoToolStripMenuItem.Click += new System.EventHandler(this.ciclosBiogeoquímicosCarbonoToolStripMenuItem_Click);
            // 
            // ciclosBiogeoquímicosOxigênioToolStripMenuItem
            // 
            this.ciclosBiogeoquímicosOxigênioToolStripMenuItem.Name = "ciclosBiogeoquímicosOxigênioToolStripMenuItem";
            this.ciclosBiogeoquímicosOxigênioToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.ciclosBiogeoquímicosOxigênioToolStripMenuItem.Text = "Oxigênio";
            this.ciclosBiogeoquímicosOxigênioToolStripMenuItem.Click += new System.EventHandler(this.ciclosBiogeoquímicosOxigênioToolStripMenuItem_Click);
            // 
            // ciclosBiogeoquímicosNitrogênioToolStripMenuItem
            // 
            this.ciclosBiogeoquímicosNitrogênioToolStripMenuItem.Name = "ciclosBiogeoquímicosNitrogênioToolStripMenuItem";
            this.ciclosBiogeoquímicosNitrogênioToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.ciclosBiogeoquímicosNitrogênioToolStripMenuItem.Text = "Nitrogênio";
            this.ciclosBiogeoquímicosNitrogênioToolStripMenuItem.Click += new System.EventHandler(this.ciclosBiogeoquímicosNitrogênioToolStripMenuItem_Click);
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pirâmideDeNúmerosToolStripMenuItem,
            this.pirâmidesDeBiomassaToolStripMenuItem,
            this.pirâmidesDeEnergiaToolStripMenuItem,
            this.pirâmideDeFluxoDeEnergiaToolStripMenuItem});
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem50.Text = "Fluxo de Energia no Ecossistema";
            // 
            // pirâmideDeNúmerosToolStripMenuItem
            // 
            this.pirâmideDeNúmerosToolStripMenuItem.Name = "pirâmideDeNúmerosToolStripMenuItem";
            this.pirâmideDeNúmerosToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.pirâmideDeNúmerosToolStripMenuItem.Text = "Pirâmide de números";
            this.pirâmideDeNúmerosToolStripMenuItem.Click += new System.EventHandler(this.pirâmideDeNúmerosToolStripMenuItem_Click);
            // 
            // pirâmidesDeBiomassaToolStripMenuItem
            // 
            this.pirâmidesDeBiomassaToolStripMenuItem.Name = "pirâmidesDeBiomassaToolStripMenuItem";
            this.pirâmidesDeBiomassaToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.pirâmidesDeBiomassaToolStripMenuItem.Text = "Pirâmides de biomassa";
            this.pirâmidesDeBiomassaToolStripMenuItem.Click += new System.EventHandler(this.pirâmidesDeBiomassaToolStripMenuItem_Click);
            // 
            // pirâmidesDeEnergiaToolStripMenuItem
            // 
            this.pirâmidesDeEnergiaToolStripMenuItem.Name = "pirâmidesDeEnergiaToolStripMenuItem";
            this.pirâmidesDeEnergiaToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.pirâmidesDeEnergiaToolStripMenuItem.Text = "Pirâmides de energia";
            this.pirâmidesDeEnergiaToolStripMenuItem.Click += new System.EventHandler(this.pirâmidesDeEnergiaToolStripMenuItem_Click);
            // 
            // pirâmideDeFluxoDeEnergiaToolStripMenuItem
            // 
            this.pirâmideDeFluxoDeEnergiaToolStripMenuItem.Name = "pirâmideDeFluxoDeEnergiaToolStripMenuItem";
            this.pirâmideDeFluxoDeEnergiaToolStripMenuItem.Size = new System.Drawing.Size(290, 26);
            this.pirâmideDeFluxoDeEnergiaToolStripMenuItem.Text = "Pirâmide de fluxo de energia";
            this.pirâmideDeFluxoDeEnergiaToolStripMenuItem.Click += new System.EventHandler(this.pirâmideDeFluxoDeEnergiaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem51.Text = "Biogeografia";
            // 
            // toolStripMenuItem52
            // 
            this.toolStripMenuItem52.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.principaisBiomasBrasileiroToolStripMenuItem});
            this.toolStripMenuItem52.Name = "toolStripMenuItem52";
            this.toolStripMenuItem52.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem52.Text = "Biomas Brasileiros";
            // 
            // principaisBiomasBrasileiroToolStripMenuItem
            // 
            this.principaisBiomasBrasileiroToolStripMenuItem.Name = "principaisBiomasBrasileiroToolStripMenuItem";
            this.principaisBiomasBrasileiroToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.principaisBiomasBrasileiroToolStripMenuItem.Text = "Principais Biomas Brasileiro";
            this.principaisBiomasBrasileiroToolStripMenuItem.Click += new System.EventHandler(this.principaisBiomasBrasileiroToolStripMenuItem_Click);
            // 
            // toolStripMenuItem53
            // 
            this.toolStripMenuItem53.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.biodiversidadeAmeaçadaIToolStripMenuItem,
            this.biodiversidadeAmeaçadaIIToolStripMenuItem,
            this.espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem,
            this.caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem});
            this.toolStripMenuItem53.Name = "toolStripMenuItem53";
            this.toolStripMenuItem53.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem53.Text = "Exploração e uso de Recursos Naturais";
            // 
            // biodiversidadeAmeaçadaIToolStripMenuItem
            // 
            this.biodiversidadeAmeaçadaIToolStripMenuItem.Name = "biodiversidadeAmeaçadaIToolStripMenuItem";
            this.biodiversidadeAmeaçadaIToolStripMenuItem.Size = new System.Drawing.Size(439, 26);
            this.biodiversidadeAmeaçadaIToolStripMenuItem.Text = "Biodiversidade Ameaçada I";
            this.biodiversidadeAmeaçadaIToolStripMenuItem.Click += new System.EventHandler(this.biodiversidadeAmeaçadaIToolStripMenuItem_Click);
            // 
            // biodiversidadeAmeaçadaIIToolStripMenuItem
            // 
            this.biodiversidadeAmeaçadaIIToolStripMenuItem.Name = "biodiversidadeAmeaçadaIIToolStripMenuItem";
            this.biodiversidadeAmeaçadaIIToolStripMenuItem.Size = new System.Drawing.Size(439, 26);
            this.biodiversidadeAmeaçadaIIToolStripMenuItem.Text = "Biodiversidade Ameaçada II";
            this.biodiversidadeAmeaçadaIIToolStripMenuItem.Click += new System.EventHandler(this.biodiversidadeAmeaçadaIIToolStripMenuItem_Click);
            // 
            // espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem
            // 
            this.espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem.Name = "espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem";
            this.espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem.Size = new System.Drawing.Size(439, 26);
            this.espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem.Text = "Espécies exóticas e Espécies exóticas invasoras";
            this.espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem.Click += new System.EventHandler(this.espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem_Click);
            // 
            // caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem
            // 
            this.caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem.Name = "caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem";
            this.caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem.Size = new System.Drawing.Size(439, 26);
            this.caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem.Text = "Caça e Exploração Excessiva de Recursos Naturais";
            this.caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem.Click += new System.EventHandler(this.caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem_Click);
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.efeitoEstufaXAquecimentoGlobalToolStripMenuItem,
            this.poluiçãoSonoraETérmicaToolStripMenuItem,
            this.poluiçãoAtmosféricaToolStripMenuItem,
            this.extinçãoDeEspéciesToolStripMenuItem,
            this.eutrofizaçãoToolStripMenuItem,
            this.poluiçãoPorDerramamentoDePetróleoToolStripMenuItem});
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem54.Text = "Problemas Ambientais";
            // 
            // efeitoEstufaXAquecimentoGlobalToolStripMenuItem
            // 
            this.efeitoEstufaXAquecimentoGlobalToolStripMenuItem.Name = "efeitoEstufaXAquecimentoGlobalToolStripMenuItem";
            this.efeitoEstufaXAquecimentoGlobalToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.efeitoEstufaXAquecimentoGlobalToolStripMenuItem.Text = "Efeito estufa x Aquecimento Global";
            this.efeitoEstufaXAquecimentoGlobalToolStripMenuItem.Click += new System.EventHandler(this.efeitoEstufaXAquecimentoGlobalToolStripMenuItem_Click);
            // 
            // poluiçãoSonoraETérmicaToolStripMenuItem
            // 
            this.poluiçãoSonoraETérmicaToolStripMenuItem.Name = "poluiçãoSonoraETérmicaToolStripMenuItem";
            this.poluiçãoSonoraETérmicaToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.poluiçãoSonoraETérmicaToolStripMenuItem.Text = "Poluição sonora e térmica";
            this.poluiçãoSonoraETérmicaToolStripMenuItem.Click += new System.EventHandler(this.poluiçãoSonoraETérmicaToolStripMenuItem_Click);
            // 
            // poluiçãoAtmosféricaToolStripMenuItem
            // 
            this.poluiçãoAtmosféricaToolStripMenuItem.Name = "poluiçãoAtmosféricaToolStripMenuItem";
            this.poluiçãoAtmosféricaToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.poluiçãoAtmosféricaToolStripMenuItem.Text = "Poluição atmosférica";
            this.poluiçãoAtmosféricaToolStripMenuItem.Click += new System.EventHandler(this.poluiçãoAtmosféricaToolStripMenuItem_Click);
            // 
            // extinçãoDeEspéciesToolStripMenuItem
            // 
            this.extinçãoDeEspéciesToolStripMenuItem.Name = "extinçãoDeEspéciesToolStripMenuItem";
            this.extinçãoDeEspéciesToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.extinçãoDeEspéciesToolStripMenuItem.Text = "Extinção de espécies";
            this.extinçãoDeEspéciesToolStripMenuItem.Click += new System.EventHandler(this.extinçãoDeEspéciesToolStripMenuItem_Click);
            // 
            // eutrofizaçãoToolStripMenuItem
            // 
            this.eutrofizaçãoToolStripMenuItem.Name = "eutrofizaçãoToolStripMenuItem";
            this.eutrofizaçãoToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.eutrofizaçãoToolStripMenuItem.Text = "Eutrofização";
            this.eutrofizaçãoToolStripMenuItem.Click += new System.EventHandler(this.eutrofizaçãoToolStripMenuItem_Click);
            // 
            // poluiçãoPorDerramamentoDePetróleoToolStripMenuItem
            // 
            this.poluiçãoPorDerramamentoDePetróleoToolStripMenuItem.Name = "poluiçãoPorDerramamentoDePetróleoToolStripMenuItem";
            this.poluiçãoPorDerramamentoDePetróleoToolStripMenuItem.Size = new System.Drawing.Size(375, 26);
            this.poluiçãoPorDerramamentoDePetróleoToolStripMenuItem.Text = "Poluição por derramamento de petróleo";
            this.poluiçãoPorDerramamentoDePetróleoToolStripMenuItem.Click += new System.EventHandler(this.poluiçãoPorDerramamentoDePetróleoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem55
            // 
            this.toolStripMenuItem55.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.relaçõesDoHomemComANaturezaToolStripMenuItem});
            this.toolStripMenuItem55.Name = "toolStripMenuItem55";
            this.toolStripMenuItem55.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem55.Text = "Conservação da Biodiversidade";
            // 
            // relaçõesDoHomemComANaturezaToolStripMenuItem
            // 
            this.relaçõesDoHomemComANaturezaToolStripMenuItem.Name = "relaçõesDoHomemComANaturezaToolStripMenuItem";
            this.relaçõesDoHomemComANaturezaToolStripMenuItem.Size = new System.Drawing.Size(343, 26);
            this.relaçõesDoHomemComANaturezaToolStripMenuItem.Text = "Relações do homem com a natureza";
            this.relaçõesDoHomemComANaturezaToolStripMenuItem.Click += new System.EventHandler(this.relaçõesDoHomemComANaturezaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem56
            // 
            this.toolStripMenuItem56.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revoluçãoVerdeToolStripMenuItem});
            this.toolStripMenuItem56.Name = "toolStripMenuItem56";
            this.toolStripMenuItem56.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem56.Text = "Tecnologias Ambientais";
            // 
            // revoluçãoVerdeToolStripMenuItem
            // 
            this.revoluçãoVerdeToolStripMenuItem.Name = "revoluçãoVerdeToolStripMenuItem";
            this.revoluçãoVerdeToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.revoluçãoVerdeToolStripMenuItem.Text = "Revolução verde";
            this.revoluçãoVerdeToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoVerdeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem57
            // 
            this.toolStripMenuItem57.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oQueÉSaneamentoBásicoToolStripMenuItem,
            this.vertentesDeSaneamentoBásicoToolStripMenuItem});
            this.toolStripMenuItem57.Name = "toolStripMenuItem57";
            this.toolStripMenuItem57.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem57.Text = "Noções de Saneamento Básico";
            // 
            // oQueÉSaneamentoBásicoToolStripMenuItem
            // 
            this.oQueÉSaneamentoBásicoToolStripMenuItem.Name = "oQueÉSaneamentoBásicoToolStripMenuItem";
            this.oQueÉSaneamentoBásicoToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.oQueÉSaneamentoBásicoToolStripMenuItem.Text = "o que é Saneamento Básico";
            this.oQueÉSaneamentoBásicoToolStripMenuItem.Click += new System.EventHandler(this.oQueÉSaneamentoBásicoToolStripMenuItem_Click);
            // 
            // vertentesDeSaneamentoBásicoToolStripMenuItem
            // 
            this.vertentesDeSaneamentoBásicoToolStripMenuItem.Name = "vertentesDeSaneamentoBásicoToolStripMenuItem";
            this.vertentesDeSaneamentoBásicoToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.vertentesDeSaneamentoBásicoToolStripMenuItem.Text = "4 vertentes de saneamento básico";
            this.vertentesDeSaneamentoBásicoToolStripMenuItem.Click += new System.EventHandler(this.vertentesDeSaneamentoBásicoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem58
            // 
            this.toolStripMenuItem58.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.legislaçãoAmbientalToolStripMenuItem});
            this.toolStripMenuItem58.Name = "toolStripMenuItem58";
            this.toolStripMenuItem58.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem58.Text = "Noções de Legislação Ambiental";
            // 
            // legislaçãoAmbientalToolStripMenuItem
            // 
            this.legislaçãoAmbientalToolStripMenuItem.Name = "legislaçãoAmbientalToolStripMenuItem";
            this.legislaçãoAmbientalToolStripMenuItem.Size = new System.Drawing.Size(235, 26);
            this.legislaçãoAmbientalToolStripMenuItem.Text = "Legislação Ambiental";
            this.legislaçãoAmbientalToolStripMenuItem.Click += new System.EventHandler(this.legislaçãoAmbientalToolStripMenuItem_Click);
            // 
            // toolStripMenuItem59
            // 
            this.toolStripMenuItem59.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oQueÉBiodiversidadeToolStripMenuItem});
            this.toolStripMenuItem59.Name = "toolStripMenuItem59";
            this.toolStripMenuItem59.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem59.Text = "Biodiversidade";
            // 
            // oQueÉBiodiversidadeToolStripMenuItem
            // 
            this.oQueÉBiodiversidadeToolStripMenuItem.Name = "oQueÉBiodiversidadeToolStripMenuItem";
            this.oQueÉBiodiversidadeToolStripMenuItem.Size = new System.Drawing.Size(257, 26);
            this.oQueÉBiodiversidadeToolStripMenuItem.Text = "O que é Biodiversidade?";
            this.oQueÉBiodiversidadeToolStripMenuItem.Click += new System.EventHandler(this.oQueÉBiodiversidadeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.toolStripMenuItem18});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem3.Text = "Moléculas, Células e Tecidos";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.membranaPlasmáticaToolStripMenuItem,
            this.transporteCelularToolStripMenuItem,
            this.membranaPlasmáticaespecializaçõesToolStripMenuItem,
            this.organelasCitoplasmáticas1ToolStripMenuItem,
            this.organelasCitoplasmáticas2ToolStripMenuItem,
            this.núcleoToolStripMenuItem,
            this.núcleoReplicaçãoDoDNAToolStripMenuItem,
            this.núcleoRNAToolStripMenuItem});
            this.toolStripMenuItem4.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem4.Text = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            // 
            // membranaPlasmáticaToolStripMenuItem
            // 
            this.membranaPlasmáticaToolStripMenuItem.Name = "membranaPlasmáticaToolStripMenuItem";
            this.membranaPlasmáticaToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.membranaPlasmáticaToolStripMenuItem.Text = "Membrana Plasmática";
            this.membranaPlasmáticaToolStripMenuItem.Click += new System.EventHandler(this.membranaPlasmáticaToolStripMenuItem_Click);
            // 
            // transporteCelularToolStripMenuItem
            // 
            this.transporteCelularToolStripMenuItem.Name = "transporteCelularToolStripMenuItem";
            this.transporteCelularToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.transporteCelularToolStripMenuItem.Text = "Transporte Celular";
            this.transporteCelularToolStripMenuItem.Click += new System.EventHandler(this.transporteCelularToolStripMenuItem_Click);
            // 
            // membranaPlasmáticaespecializaçõesToolStripMenuItem
            // 
            this.membranaPlasmáticaespecializaçõesToolStripMenuItem.Name = "membranaPlasmáticaespecializaçõesToolStripMenuItem";
            this.membranaPlasmáticaespecializaçõesToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.membranaPlasmáticaespecializaçõesToolStripMenuItem.Text = "Membrana plasmática (especializações)";
            this.membranaPlasmáticaespecializaçõesToolStripMenuItem.Click += new System.EventHandler(this.membranaPlasmáticaespecializaçõesToolStripMenuItem_Click);
            // 
            // organelasCitoplasmáticas1ToolStripMenuItem
            // 
            this.organelasCitoplasmáticas1ToolStripMenuItem.Name = "organelasCitoplasmáticas1ToolStripMenuItem";
            this.organelasCitoplasmáticas1ToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.organelasCitoplasmáticas1ToolStripMenuItem.Text = "Organelas Citoplasmáticas 1";
            this.organelasCitoplasmáticas1ToolStripMenuItem.Click += new System.EventHandler(this.organelasCitoplasmáticas1ToolStripMenuItem_Click);
            // 
            // organelasCitoplasmáticas2ToolStripMenuItem
            // 
            this.organelasCitoplasmáticas2ToolStripMenuItem.Name = "organelasCitoplasmáticas2ToolStripMenuItem";
            this.organelasCitoplasmáticas2ToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.organelasCitoplasmáticas2ToolStripMenuItem.Text = "Organelas Citoplasmáticas 2";
            this.organelasCitoplasmáticas2ToolStripMenuItem.Click += new System.EventHandler(this.organelasCitoplasmáticas2ToolStripMenuItem_Click);
            // 
            // núcleoToolStripMenuItem
            // 
            this.núcleoToolStripMenuItem.Name = "núcleoToolStripMenuItem";
            this.núcleoToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.núcleoToolStripMenuItem.Text = "Núcleo";
            this.núcleoToolStripMenuItem.Click += new System.EventHandler(this.núcleoToolStripMenuItem_Click);
            // 
            // núcleoReplicaçãoDoDNAToolStripMenuItem
            // 
            this.núcleoReplicaçãoDoDNAToolStripMenuItem.Name = "núcleoReplicaçãoDoDNAToolStripMenuItem";
            this.núcleoReplicaçãoDoDNAToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.núcleoReplicaçãoDoDNAToolStripMenuItem.Text = "Núcleo - Replicação do DNA";
            this.núcleoReplicaçãoDoDNAToolStripMenuItem.Click += new System.EventHandler(this.núcleoReplicaçãoDoDNAToolStripMenuItem_Click);
            // 
            // núcleoRNAToolStripMenuItem
            // 
            this.núcleoRNAToolStripMenuItem.Name = "núcleoRNAToolStripMenuItem";
            this.núcleoRNAToolStripMenuItem.Size = new System.Drawing.Size(366, 26);
            this.núcleoRNAToolStripMenuItem.Text = "Núcleo - RNA";
            this.núcleoRNAToolStripMenuItem.Click += new System.EventHandler(this.núcleoRNAToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.interfaseToolStripMenuItem,
            this.mitoseToolStripMenuItem,
            this.meioseToolStripMenuItem});
            this.toolStripMenuItem5.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem5.Text = "Divisão Celular";
            // 
            // interfaseToolStripMenuItem
            // 
            this.interfaseToolStripMenuItem.Name = "interfaseToolStripMenuItem";
            this.interfaseToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.interfaseToolStripMenuItem.Text = "Interfase";
            this.interfaseToolStripMenuItem.Click += new System.EventHandler(this.interfaseToolStripMenuItem_Click);
            // 
            // mitoseToolStripMenuItem
            // 
            this.mitoseToolStripMenuItem.Name = "mitoseToolStripMenuItem";
            this.mitoseToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.mitoseToolStripMenuItem.Text = "Mitose";
            this.mitoseToolStripMenuItem.Click += new System.EventHandler(this.mitoseToolStripMenuItem_Click);
            // 
            // meioseToolStripMenuItem
            // 
            this.meioseToolStripMenuItem.Name = "meioseToolStripMenuItem";
            this.meioseToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.meioseToolStripMenuItem.Text = "Meiose";
            this.meioseToolStripMenuItem.Click += new System.EventHandler(this.meioseToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.águaToolStripMenuItem,
            this.proteinasToolStripMenuItem,
            this.carboidratosToolStripMenuItem,
            this.lipídiosToolStripMenuItem});
            this.toolStripMenuItem6.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem6.Text = "Aspectos Bioquímicos das Estruturas Celulares";
            // 
            // águaToolStripMenuItem
            // 
            this.águaToolStripMenuItem.Name = "águaToolStripMenuItem";
            this.águaToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.águaToolStripMenuItem.Text = "Água";
            this.águaToolStripMenuItem.Click += new System.EventHandler(this.águaToolStripMenuItem_Click);
            // 
            // proteinasToolStripMenuItem
            // 
            this.proteinasToolStripMenuItem.Name = "proteinasToolStripMenuItem";
            this.proteinasToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.proteinasToolStripMenuItem.Text = "Proteínas";
            this.proteinasToolStripMenuItem.Click += new System.EventHandler(this.proteinasToolStripMenuItem_Click);
            // 
            // carboidratosToolStripMenuItem
            // 
            this.carboidratosToolStripMenuItem.Name = "carboidratosToolStripMenuItem";
            this.carboidratosToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.carboidratosToolStripMenuItem.Text = "Carboidratos";
            this.carboidratosToolStripMenuItem.Click += new System.EventHandler(this.carboidratosToolStripMenuItem_Click);
            // 
            // lipídiosToolStripMenuItem
            // 
            this.lipídiosToolStripMenuItem.Name = "lipídiosToolStripMenuItem";
            this.lipídiosToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.lipídiosToolStripMenuItem.Text = "Lipídios";
            this.lipídiosToolStripMenuItem.Click += new System.EventHandler(this.lipídiosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.metabolismoCelularToolStripMenuItem});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem7.Text = "Aspectos Gerais do Metabolismo Celular";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // metabolismoCelularToolStripMenuItem
            // 
            this.metabolismoCelularToolStripMenuItem.Name = "metabolismoCelularToolStripMenuItem";
            this.metabolismoCelularToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.metabolismoCelularToolStripMenuItem.Text = "Metabolismo Celular";
            this.metabolismoCelularToolStripMenuItem.Click += new System.EventHandler(this.metabolismoCelularToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.respiraçãoCelularGlicóliseToolStripMenuItem,
            this.respiraçãoCelularCicloDeKrebsToolStripMenuItem,
            this.respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem,
            this.fermentaçãoToolStripMenuItem,
            this.fotossínteseIFaseClaraToolStripMenuItem,
            this.fotossínteseIIFaseEscuraToolStripMenuItem});
            this.toolStripMenuItem8.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem8.Text = "Metabolismo Energético: Fotossíntese e Respiração";
            // 
            // respiraçãoCelularGlicóliseToolStripMenuItem
            // 
            this.respiraçãoCelularGlicóliseToolStripMenuItem.Name = "respiraçãoCelularGlicóliseToolStripMenuItem";
            this.respiraçãoCelularGlicóliseToolStripMenuItem.Size = new System.Drawing.Size(364, 26);
            this.respiraçãoCelularGlicóliseToolStripMenuItem.Text = "Respiração Celular (Glicólise)";
            this.respiraçãoCelularGlicóliseToolStripMenuItem.Click += new System.EventHandler(this.respiraçãoCelularGlicóliseToolStripMenuItem_Click);
            // 
            // respiraçãoCelularCicloDeKrebsToolStripMenuItem
            // 
            this.respiraçãoCelularCicloDeKrebsToolStripMenuItem.Name = "respiraçãoCelularCicloDeKrebsToolStripMenuItem";
            this.respiraçãoCelularCicloDeKrebsToolStripMenuItem.Size = new System.Drawing.Size(364, 26);
            this.respiraçãoCelularCicloDeKrebsToolStripMenuItem.Text = "Respiração Celular (Ciclo de Krebs)";
            this.respiraçãoCelularCicloDeKrebsToolStripMenuItem.Click += new System.EventHandler(this.respiraçãoCelularCicloDeKrebsToolStripMenuItem_Click);
            // 
            // respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem
            // 
            this.respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem.Name = "respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem";
            this.respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem.Size = new System.Drawing.Size(364, 26);
            this.respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem.Text = "Respiração Celular (Cadeia Respiratória";
            this.respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem.Click += new System.EventHandler(this.respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem_Click);
            // 
            // fermentaçãoToolStripMenuItem
            // 
            this.fermentaçãoToolStripMenuItem.Name = "fermentaçãoToolStripMenuItem";
            this.fermentaçãoToolStripMenuItem.Size = new System.Drawing.Size(364, 26);
            this.fermentaçãoToolStripMenuItem.Text = "Fermentação";
            this.fermentaçãoToolStripMenuItem.Click += new System.EventHandler(this.fermentaçãoToolStripMenuItem_Click);
            // 
            // fotossínteseIFaseClaraToolStripMenuItem
            // 
            this.fotossínteseIFaseClaraToolStripMenuItem.Name = "fotossínteseIFaseClaraToolStripMenuItem";
            this.fotossínteseIFaseClaraToolStripMenuItem.Size = new System.Drawing.Size(364, 26);
            this.fotossínteseIFaseClaraToolStripMenuItem.Text = "Fotossíntese I - fase clara";
            this.fotossínteseIFaseClaraToolStripMenuItem.Click += new System.EventHandler(this.fotossínteseIFaseClaraToolStripMenuItem_Click);
            // 
            // fotossínteseIIFaseEscuraToolStripMenuItem
            // 
            this.fotossínteseIIFaseEscuraToolStripMenuItem.Name = "fotossínteseIIFaseEscuraToolStripMenuItem";
            this.fotossínteseIIFaseEscuraToolStripMenuItem.Size = new System.Drawing.Size(364, 26);
            this.fotossínteseIIFaseEscuraToolStripMenuItem.Text = "Fotossíntese II - Fase Escura";
            this.fotossínteseIIFaseEscuraToolStripMenuItem.Click += new System.EventHandler(this.fotossínteseIIFaseEscuraToolStripMenuItem_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.códigoGenéticoToolStripMenuItem1});
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem9.Text = "Codificação da Informação Genética";
            // 
            // códigoGenéticoToolStripMenuItem1
            // 
            this.códigoGenéticoToolStripMenuItem1.Name = "códigoGenéticoToolStripMenuItem1";
            this.códigoGenéticoToolStripMenuItem1.Size = new System.Drawing.Size(204, 26);
            this.códigoGenéticoToolStripMenuItem1.Text = "Código Genético";
            this.códigoGenéticoToolStripMenuItem1.Click += new System.EventHandler(this.códigoGenéticoToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sínteseDeProteínasToolStripMenuItem});
            this.toolStripMenuItem10.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem10.Text = "Síntese Protética";
            // 
            // sínteseDeProteínasToolStripMenuItem
            // 
            this.sínteseDeProteínasToolStripMenuItem.Name = "sínteseDeProteínasToolStripMenuItem";
            this.sínteseDeProteínasToolStripMenuItem.Size = new System.Drawing.Size(228, 26);
            this.sínteseDeProteínasToolStripMenuItem.Text = "Síntese de Proteínas";
            this.sínteseDeProteínasToolStripMenuItem.Click += new System.EventHandler(this.sínteseDeProteínasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.diferenciaçãoCelularToolStripMenuItem});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem11.Text = "Diferenciação Celular";
            // 
            // diferenciaçãoCelularToolStripMenuItem
            // 
            this.diferenciaçãoCelularToolStripMenuItem.Name = "diferenciaçãoCelularToolStripMenuItem";
            this.diferenciaçãoCelularToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.diferenciaçãoCelularToolStripMenuItem.Text = "Diferenciação Celular";
            this.diferenciaçãoCelularToolStripMenuItem.Click += new System.EventHandler(this.diferenciaçãoCelularToolStripMenuItem_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem1,
            this.tecidoEpitelialDeRevestimentoToolStripMenuItem,
            this.tecidoEpitelialGlandularToolStripMenuItem,
            this.tecidoConjuntivoToolStripMenuItem,
            this.tecidoConjuntivoPropriamenteDitoToolStripMenuItem,
            this.tecidoMuscularToolStripMenuItem});
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem12.Text = "Principais Tecidos Animais e Vegetais";
            // 
            // introduçãoToolStripMenuItem1
            // 
            this.introduçãoToolStripMenuItem1.Name = "introduçãoToolStripMenuItem1";
            this.introduçãoToolStripMenuItem1.Size = new System.Drawing.Size(350, 26);
            this.introduçãoToolStripMenuItem1.Text = "Introdução";
            // 
            // tecidoEpitelialDeRevestimentoToolStripMenuItem
            // 
            this.tecidoEpitelialDeRevestimentoToolStripMenuItem.Name = "tecidoEpitelialDeRevestimentoToolStripMenuItem";
            this.tecidoEpitelialDeRevestimentoToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.tecidoEpitelialDeRevestimentoToolStripMenuItem.Text = "Tecido Epitelial de Revestimento";
            // 
            // tecidoEpitelialGlandularToolStripMenuItem
            // 
            this.tecidoEpitelialGlandularToolStripMenuItem.Name = "tecidoEpitelialGlandularToolStripMenuItem";
            this.tecidoEpitelialGlandularToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.tecidoEpitelialGlandularToolStripMenuItem.Text = "Tecido Epitelial Glandular";
            // 
            // tecidoConjuntivoToolStripMenuItem
            // 
            this.tecidoConjuntivoToolStripMenuItem.Name = "tecidoConjuntivoToolStripMenuItem";
            this.tecidoConjuntivoToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.tecidoConjuntivoToolStripMenuItem.Text = "Tecido Conjuntivo";
            this.tecidoConjuntivoToolStripMenuItem.Click += new System.EventHandler(this.tecidoConjuntivoToolStripMenuItem_Click);
            // 
            // tecidoConjuntivoPropriamenteDitoToolStripMenuItem
            // 
            this.tecidoConjuntivoPropriamenteDitoToolStripMenuItem.Name = "tecidoConjuntivoPropriamenteDitoToolStripMenuItem";
            this.tecidoConjuntivoPropriamenteDitoToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.tecidoConjuntivoPropriamenteDitoToolStripMenuItem.Text = "Tecido Conjuntivo Propriamente Dito";
            // 
            // tecidoMuscularToolStripMenuItem
            // 
            this.tecidoMuscularToolStripMenuItem.Name = "tecidoMuscularToolStripMenuItem";
            this.tecidoMuscularToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.tecidoMuscularToolStripMenuItem.Text = "Tecido Muscular";
            this.tecidoMuscularToolStripMenuItem.Click += new System.EventHandler(this.tecidoMuscularToolStripMenuItem_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.origemdascélulaseucarióticasToolStripMenuItem});
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem13.Text = "Origem e Evolução das Células";
            // 
            // origemdascélulaseucarióticasToolStripMenuItem
            // 
            this.origemdascélulaseucarióticasToolStripMenuItem.Name = "origemdascélulaseucarióticasToolStripMenuItem";
            this.origemdascélulaseucarióticasToolStripMenuItem.Size = new System.Drawing.Size(312, 26);
            this.origemdascélulaseucarióticasToolStripMenuItem.Text = "Origem das células eucarióticas ";
            this.origemdascélulaseucarióticasToolStripMenuItem.Click += new System.EventHandler(this.origemdascélulaseucarióticasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.célulasTroncoToolStripMenuItem,
            this.ClonagemToolStripMenuItem,
            this.dNARecombinanteToolStripMenuItem});
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem14.Text = "Células-tronco, Clonagem e Tecnologia do DNA Recombinante";
            // 
            // célulasTroncoToolStripMenuItem
            // 
            this.célulasTroncoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.célulasTroncoToolStripMenuItem.Name = "célulasTroncoToolStripMenuItem";
            this.célulasTroncoToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.célulasTroncoToolStripMenuItem.Text = "Células Tronco";
            this.célulasTroncoToolStripMenuItem.Click += new System.EventHandler(this.célulasTroncoToolStripMenuItem_Click);
            // 
            // ClonagemToolStripMenuItem
            // 
            this.ClonagemToolStripMenuItem.Name = "ClonagemToolStripMenuItem";
            this.ClonagemToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.ClonagemToolStripMenuItem.Text = "Clonagem";
            this.ClonagemToolStripMenuItem.Click += new System.EventHandler(this.ClonagemToolStripMenuItem_Click);
            // 
            // dNARecombinanteToolStripMenuItem
            // 
            this.dNARecombinanteToolStripMenuItem.Name = "dNARecombinanteToolStripMenuItem";
            this.dNARecombinanteToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.dNARecombinanteToolStripMenuItem.Text = "DNA recombinante";
            this.dNARecombinanteToolStripMenuItem.Click += new System.EventHandler(this.dNARecombinanteToolStripMenuItem_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.biotecnologiaESuasAplicaçõesToolStripMenuItem,
            this.oQueÉBiotecnologiaToolStripMenuItem});
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem18.Text = "Biotecnologia e Sustentabilidade";
            // 
            // biotecnologiaESuasAplicaçõesToolStripMenuItem
            // 
            this.biotecnologiaESuasAplicaçõesToolStripMenuItem.Name = "biotecnologiaESuasAplicaçõesToolStripMenuItem";
            this.biotecnologiaESuasAplicaçõesToolStripMenuItem.Size = new System.Drawing.Size(310, 26);
            this.biotecnologiaESuasAplicaçõesToolStripMenuItem.Text = "Biotecnologia e suas aplicações";
            this.biotecnologiaESuasAplicaçõesToolStripMenuItem.Click += new System.EventHandler(this.biotecnologiaESuasAplicaçõesToolStripMenuItem_Click);
            // 
            // oQueÉBiotecnologiaToolStripMenuItem
            // 
            this.oQueÉBiotecnologiaToolStripMenuItem.Name = "oQueÉBiotecnologiaToolStripMenuItem";
            this.oQueÉBiotecnologiaToolStripMenuItem.Size = new System.Drawing.Size(310, 26);
            this.oQueÉBiotecnologiaToolStripMenuItem.Text = "O que é biotecnologia?";
            this.oQueÉBiotecnologiaToolStripMenuItem.Click += new System.EventHandler(this.oQueÉBiotecnologiaToolStripMenuItem_Click);
            // 
            // genéticaToolStripMenuItem
            // 
            this.genéticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem,
            this.ªLeiDeMendelToolStripMenuItem,
            this.heredogramaToolStripMenuItem,
            this.sistemaABOToolStripMenuItem,
            this.exercíciosToolStripMenuItem,
            this.polialeliaToolStripMenuItem,
            this.ªLeiDeMendelToolStripMenuItem1,
            this.poliibridismoEPleiotropiaToolStripMenuItem,
            this.interaçãoGênicaComplementarToolStripMenuItem,
            this.interaçãoGênicaEpistasiaToolStripMenuItem,
            this.interaçãoGênicaQuantitativaToolStripMenuItem,
            this.herançaSexualToolStripMenuItem,
            this.determinaçãoDoSexoToolStripMenuItem});
            this.genéticaToolStripMenuItem.Name = "genéticaToolStripMenuItem";
            this.genéticaToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.genéticaToolStripMenuItem.Text = "Genética";
            // 
            // introduçãoToolStripMenuItem
            // 
            this.introduçãoToolStripMenuItem.Name = "introduçãoToolStripMenuItem";
            this.introduçãoToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.introduçãoToolStripMenuItem.Text = "Introdução";
            this.introduçãoToolStripMenuItem.Click += new System.EventHandler(this.introduçãoToolStripMenuItem_Click_1);
            // 
            // ªLeiDeMendelToolStripMenuItem
            // 
            this.ªLeiDeMendelToolStripMenuItem.Name = "ªLeiDeMendelToolStripMenuItem";
            this.ªLeiDeMendelToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.ªLeiDeMendelToolStripMenuItem.Text = "1ª Lei de Mendel";
            this.ªLeiDeMendelToolStripMenuItem.Click += new System.EventHandler(this.ªLeiDeMendelToolStripMenuItem_Click);
            // 
            // heredogramaToolStripMenuItem
            // 
            this.heredogramaToolStripMenuItem.Name = "heredogramaToolStripMenuItem";
            this.heredogramaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.heredogramaToolStripMenuItem.Text = "Heredograma";
            this.heredogramaToolStripMenuItem.Click += new System.EventHandler(this.heredogramaToolStripMenuItem_Click);
            // 
            // sistemaABOToolStripMenuItem
            // 
            this.sistemaABOToolStripMenuItem.Name = "sistemaABOToolStripMenuItem";
            this.sistemaABOToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.sistemaABOToolStripMenuItem.Text = "Sistema ABO";
            this.sistemaABOToolStripMenuItem.Click += new System.EventHandler(this.sistemaABOToolStripMenuItem_Click);
            // 
            // exercíciosToolStripMenuItem
            // 
            this.exercíciosToolStripMenuItem.Name = "exercíciosToolStripMenuItem";
            this.exercíciosToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.exercíciosToolStripMenuItem.Text = "Exercícios";
            this.exercíciosToolStripMenuItem.Click += new System.EventHandler(this.exercíciosToolStripMenuItem_Click);
            // 
            // polialeliaToolStripMenuItem
            // 
            this.polialeliaToolStripMenuItem.Name = "polialeliaToolStripMenuItem";
            this.polialeliaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.polialeliaToolStripMenuItem.Text = "Polialelia";
            this.polialeliaToolStripMenuItem.Click += new System.EventHandler(this.polialeliaToolStripMenuItem_Click);
            // 
            // ªLeiDeMendelToolStripMenuItem1
            // 
            this.ªLeiDeMendelToolStripMenuItem1.Name = "ªLeiDeMendelToolStripMenuItem1";
            this.ªLeiDeMendelToolStripMenuItem1.Size = new System.Drawing.Size(314, 26);
            this.ªLeiDeMendelToolStripMenuItem1.Text = "2ª Lei de Mendel";
            this.ªLeiDeMendelToolStripMenuItem1.Click += new System.EventHandler(this.ªLeiDeMendelToolStripMenuItem1_Click);
            // 
            // poliibridismoEPleiotropiaToolStripMenuItem
            // 
            this.poliibridismoEPleiotropiaToolStripMenuItem.Name = "poliibridismoEPleiotropiaToolStripMenuItem";
            this.poliibridismoEPleiotropiaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.poliibridismoEPleiotropiaToolStripMenuItem.Text = "Poliibridismo e Pleiotropia";
            this.poliibridismoEPleiotropiaToolStripMenuItem.Click += new System.EventHandler(this.poliibridismoEPleiotropiaToolStripMenuItem_Click);
            // 
            // interaçãoGênicaComplementarToolStripMenuItem
            // 
            this.interaçãoGênicaComplementarToolStripMenuItem.Name = "interaçãoGênicaComplementarToolStripMenuItem";
            this.interaçãoGênicaComplementarToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.interaçãoGênicaComplementarToolStripMenuItem.Text = "Interação gênica Complementar";
            this.interaçãoGênicaComplementarToolStripMenuItem.Click += new System.EventHandler(this.interaçãoGênicaComplementarToolStripMenuItem_Click);
            // 
            // interaçãoGênicaEpistasiaToolStripMenuItem
            // 
            this.interaçãoGênicaEpistasiaToolStripMenuItem.Name = "interaçãoGênicaEpistasiaToolStripMenuItem";
            this.interaçãoGênicaEpistasiaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.interaçãoGênicaEpistasiaToolStripMenuItem.Text = "Interação Gênica: Epistasia";
            this.interaçãoGênicaEpistasiaToolStripMenuItem.Click += new System.EventHandler(this.interaçãoGênicaEpistasiaToolStripMenuItem_Click);
            // 
            // interaçãoGênicaQuantitativaToolStripMenuItem
            // 
            this.interaçãoGênicaQuantitativaToolStripMenuItem.Name = "interaçãoGênicaQuantitativaToolStripMenuItem";
            this.interaçãoGênicaQuantitativaToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.interaçãoGênicaQuantitativaToolStripMenuItem.Text = "Interação Gênica: Quantitativa";
            this.interaçãoGênicaQuantitativaToolStripMenuItem.Click += new System.EventHandler(this.interaçãoGênicaQuantitativaToolStripMenuItem_Click);
            // 
            // herançaSexualToolStripMenuItem
            // 
            this.herançaSexualToolStripMenuItem.Name = "herançaSexualToolStripMenuItem";
            this.herançaSexualToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.herançaSexualToolStripMenuItem.Text = "Herança Sexual";
            this.herançaSexualToolStripMenuItem.Click += new System.EventHandler(this.herançaSexualToolStripMenuItem_Click);
            // 
            // determinaçãoDoSexoToolStripMenuItem
            // 
            this.determinaçãoDoSexoToolStripMenuItem.Name = "determinaçãoDoSexoToolStripMenuItem";
            this.determinaçãoDoSexoToolStripMenuItem.Size = new System.Drawing.Size(314, 26);
            this.determinaçãoDoSexoToolStripMenuItem.Text = "Determinação do Sexo";
            this.determinaçãoDoSexoToolStripMenuItem.Click += new System.EventHandler(this.determinaçãoDoSexoToolStripMenuItem_Click);
            // 
            // botânicaToolStripMenuItem
            // 
            this.botânicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem2,
            this.reinoPlantaeReproduçãoToolStripMenuItem,
            this.florECicloDeVidaToolStripMenuItem,
            this.frutoToolStripMenuItem});
            this.botânicaToolStripMenuItem.Name = "botânicaToolStripMenuItem";
            this.botânicaToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.botânicaToolStripMenuItem.Text = "Botânica";
            // 
            // introduçãoToolStripMenuItem2
            // 
            this.introduçãoToolStripMenuItem2.Name = "introduçãoToolStripMenuItem2";
            this.introduçãoToolStripMenuItem2.Size = new System.Drawing.Size(279, 26);
            this.introduçãoToolStripMenuItem2.Text = "Introdução";
            this.introduçãoToolStripMenuItem2.Click += new System.EventHandler(this.introduçãoToolStripMenuItem2_Click);
            // 
            // reinoPlantaeReproduçãoToolStripMenuItem
            // 
            this.reinoPlantaeReproduçãoToolStripMenuItem.Name = "reinoPlantaeReproduçãoToolStripMenuItem";
            this.reinoPlantaeReproduçãoToolStripMenuItem.Size = new System.Drawing.Size(279, 26);
            this.reinoPlantaeReproduçãoToolStripMenuItem.Text = "Reino Plantae - reprodução";
            this.reinoPlantaeReproduçãoToolStripMenuItem.Click += new System.EventHandler(this.reinoPlantaeReproduçãoToolStripMenuItem_Click);
            // 
            // florECicloDeVidaToolStripMenuItem
            // 
            this.florECicloDeVidaToolStripMenuItem.Name = "florECicloDeVidaToolStripMenuItem";
            this.florECicloDeVidaToolStripMenuItem.Size = new System.Drawing.Size(279, 26);
            this.florECicloDeVidaToolStripMenuItem.Text = "Flor e Ciclo de Vida";
            this.florECicloDeVidaToolStripMenuItem.Click += new System.EventHandler(this.florECicloDeVidaToolStripMenuItem_Click);
            // 
            // frutoToolStripMenuItem
            // 
            this.frutoToolStripMenuItem.Name = "frutoToolStripMenuItem";
            this.frutoToolStripMenuItem.Size = new System.Drawing.Size(279, 26);
            this.frutoToolStripMenuItem.Text = "Fruto";
            this.frutoToolStripMenuItem.Click += new System.EventHandler(this.frutoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem31,
            this.toolStripMenuItem34,
            this.toolStripMenuItem33,
            this.reinoMoneraToolStripMenuItem,
            this.toolStripMenuItem32});
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem30.Text = "Identidade dos Seres Vivos";
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nToolStripMenuItem,
            this.taxonomiaToolStripMenuItem});
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem31.Text = "Níveis de Organização dos Seres Vivos";
            // 
            // nToolStripMenuItem
            // 
            this.nToolStripMenuItem.Name = "nToolStripMenuItem";
            this.nToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.nToolStripMenuItem.Text = "Níveis de Organização";
            this.nToolStripMenuItem.Click += new System.EventHandler(this.nToolStripMenuItem_Click);
            // 
            // taxonomiaToolStripMenuItem
            // 
            this.taxonomiaToolStripMenuItem.Name = "taxonomiaToolStripMenuItem";
            this.taxonomiaToolStripMenuItem.Size = new System.Drawing.Size(241, 26);
            this.taxonomiaToolStripMenuItem.Text = "Taxonomia";
            this.taxonomiaToolStripMenuItem.Click += new System.EventHandler(this.taxonomiaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem34.Text = "Seres Unicelulares e Pluricelulares";
            this.toolStripMenuItem34.Click += new System.EventHandler(this.toolStripMenuItem34_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem33.Text = "Autótrofos e Heterótrofos";
            this.toolStripMenuItem33.Click += new System.EventHandler(this.toolStripMenuItem33_Click);
            // 
            // reinoMoneraToolStripMenuItem
            // 
            this.reinoMoneraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reinoMoneraIToolStripMenuItem,
            this.reinoMoneraIIToolStripMenuItem1});
            this.reinoMoneraToolStripMenuItem.Name = "reinoMoneraToolStripMenuItem";
            this.reinoMoneraToolStripMenuItem.Size = new System.Drawing.Size(359, 26);
            this.reinoMoneraToolStripMenuItem.Text = "Reino Monera";
            // 
            // reinoMoneraIToolStripMenuItem
            // 
            this.reinoMoneraIToolStripMenuItem.Name = "reinoMoneraIToolStripMenuItem";
            this.reinoMoneraIToolStripMenuItem.Size = new System.Drawing.Size(197, 26);
            this.reinoMoneraIToolStripMenuItem.Text = "Reino Monera I";
            this.reinoMoneraIToolStripMenuItem.Click += new System.EventHandler(this.reinoMoneraIToolStripMenuItem_Click);
            // 
            // reinoMoneraIIToolStripMenuItem1
            // 
            this.reinoMoneraIIToolStripMenuItem1.Name = "reinoMoneraIIToolStripMenuItem1";
            this.reinoMoneraIIToolStripMenuItem1.Size = new System.Drawing.Size(197, 26);
            this.reinoMoneraIIToolStripMenuItem1.Text = "Reino Monera II";
            this.reinoMoneraIIToolStripMenuItem1.Click += new System.EventHandler(this.reinoMoneraIIToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vírusToolStripMenuItem,
            this.reinoProtistaProtozoáriosToolStripMenuItem,
            this.reinoFungiToolStripMenuItem});
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem32.Text = "Vírus, Procariontes e Eucariontes";
            // 
            // vírusToolStripMenuItem
            // 
            this.vírusToolStripMenuItem.Name = "vírusToolStripMenuItem";
            this.vírusToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.vírusToolStripMenuItem.Text = "Vírus";
            this.vírusToolStripMenuItem.Click += new System.EventHandler(this.vírusToolStripMenuItem_Click);
            // 
            // reinoProtistaProtozoáriosToolStripMenuItem
            // 
            this.reinoProtistaProtozoáriosToolStripMenuItem.Name = "reinoProtistaProtozoáriosToolStripMenuItem";
            this.reinoProtistaProtozoáriosToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.reinoProtistaProtozoáriosToolStripMenuItem.Text = "Reino Protista - Protozoários";
            this.reinoProtistaProtozoáriosToolStripMenuItem.Click += new System.EventHandler(this.reinoProtistaProtozoáriosToolStripMenuItem_Click);
            // 
            // reinoFungiToolStripMenuItem
            // 
            this.reinoFungiToolStripMenuItem.Name = "reinoFungiToolStripMenuItem";
            this.reinoFungiToolStripMenuItem.Size = new System.Drawing.Size(289, 26);
            this.reinoFungiToolStripMenuItem.Text = "Reino Fungi";
            this.reinoFungiToolStripMenuItem.Click += new System.EventHandler(this.reinoFungiToolStripMenuItem_Click);
            // 
            // toolStripMenuItem60
            // 
            this.toolStripMenuItem60.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem61,
            this.toolStripMenuItem62,
            this.toolStripMenuItem63,
            this.toolStripMenuItem64,
            this.toolStripMenuItem65,
            this.cladogêneseEAnagêneseToolStripMenuItem,
            this.isolamentoReprodutivoToolStripMenuItem});
            this.toolStripMenuItem60.Name = "toolStripMenuItem60";
            this.toolStripMenuItem60.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem60.Text = "Origem e Evolução da Vida";
            // 
            // toolStripMenuItem61
            // 
            this.toolStripMenuItem61.Name = "toolStripMenuItem61";
            this.toolStripMenuItem61.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem61.Text = "A Biologia como Ciência: História, Métodos, Técnicas e Experimentação";
            // 
            // toolStripMenuItem62
            // 
            this.toolStripMenuItem62.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.origemDaVidaToolStripMenuItem});
            this.toolStripMenuItem62.Name = "toolStripMenuItem62";
            this.toolStripMenuItem62.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem62.Text = "Hipóteses sobre a Origem do Universo, da Terra e dos Seres Vivos";
            // 
            // origemDaVidaToolStripMenuItem
            // 
            this.origemDaVidaToolStripMenuItem.Name = "origemDaVidaToolStripMenuItem";
            this.origemDaVidaToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.origemDaVidaToolStripMenuItem.Text = "Origem da Vida";
            this.origemDaVidaToolStripMenuItem.Click += new System.EventHandler(this.origemDaVidaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem63
            // 
            this.toolStripMenuItem63.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.teoriasEvolutivasToolStripMenuItem});
            this.toolStripMenuItem63.Name = "toolStripMenuItem63";
            this.toolStripMenuItem63.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem63.Text = "Teorias da Evolução";
            // 
            // teoriasEvolutivasToolStripMenuItem
            // 
            this.teoriasEvolutivasToolStripMenuItem.Name = "teoriasEvolutivasToolStripMenuItem";
            this.teoriasEvolutivasToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.teoriasEvolutivasToolStripMenuItem.Text = "Darwin X Lamarck";
            this.teoriasEvolutivasToolStripMenuItem.Click += new System.EventHandler(this.teoriasEvolutivasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem64.Text = "Explicações Pré-darwinistas para a Modificação das Espécies";
            // 
            // toolStripMenuItem65
            // 
            this.toolStripMenuItem65.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.seleçãoNaturalToolStripMenuItem,
            this.especiaçãoToolStripMenuItem});
            this.toolStripMenuItem65.Name = "toolStripMenuItem65";
            this.toolStripMenuItem65.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem65.Text = "A Teoria Evolutiva de Charles Darwin";
            // 
            // seleçãoNaturalToolStripMenuItem
            // 
            this.seleçãoNaturalToolStripMenuItem.Name = "seleçãoNaturalToolStripMenuItem";
            this.seleçãoNaturalToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.seleçãoNaturalToolStripMenuItem.Text = "Seleção Natural";
            this.seleçãoNaturalToolStripMenuItem.Click += new System.EventHandler(this.seleçãoNaturalToolStripMenuItem_Click);
            // 
            // especiaçãoToolStripMenuItem
            // 
            this.especiaçãoToolStripMenuItem.Name = "especiaçãoToolStripMenuItem";
            this.especiaçãoToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.especiaçãoToolStripMenuItem.Text = "Especiação";
            this.especiaçãoToolStripMenuItem.Click += new System.EventHandler(this.especiaçãoToolStripMenuItem_Click);
            // 
            // cladogêneseEAnagêneseToolStripMenuItem
            // 
            this.cladogêneseEAnagêneseToolStripMenuItem.Name = "cladogêneseEAnagêneseToolStripMenuItem";
            this.cladogêneseEAnagêneseToolStripMenuItem.Size = new System.Drawing.Size(599, 26);
            this.cladogêneseEAnagêneseToolStripMenuItem.Text = "Cladogênese e Anagênese";
            this.cladogêneseEAnagêneseToolStripMenuItem.Click += new System.EventHandler(this.cladogêneseEAnagêneseToolStripMenuItem_Click);
            // 
            // isolamentoReprodutivoToolStripMenuItem
            // 
            this.isolamentoReprodutivoToolStripMenuItem.Name = "isolamentoReprodutivoToolStripMenuItem";
            this.isolamentoReprodutivoToolStripMenuItem.Size = new System.Drawing.Size(599, 26);
            this.isolamentoReprodutivoToolStripMenuItem.Text = "Isolamento Reprodutivo";
            this.isolamentoReprodutivoToolStripMenuItem.Click += new System.EventHandler(this.isolamentoReprodutivoToolStripMenuItem_Click);
            // 
            // embriologiaToolStripMenuItem
            // 
            this.embriologiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gametogêneseToolStripMenuItem,
            this.fecundaçãoToolStripMenuItem,
            this.tiposDeOvosToolStripMenuItem,
            this.embriogêneseToolStripMenuItem,
            this.anexosEmbrionáriosToolStripMenuItem,
            this.tipoDeReproduçãoToolStripMenuItem});
            this.embriologiaToolStripMenuItem.Name = "embriologiaToolStripMenuItem";
            this.embriologiaToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.embriologiaToolStripMenuItem.Text = "Embriologia";
            // 
            // gametogêneseToolStripMenuItem
            // 
            this.gametogêneseToolStripMenuItem.Name = "gametogêneseToolStripMenuItem";
            this.gametogêneseToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.gametogêneseToolStripMenuItem.Text = "Gametogênese";
            this.gametogêneseToolStripMenuItem.Click += new System.EventHandler(this.gametogêneseToolStripMenuItem_Click);
            // 
            // fecundaçãoToolStripMenuItem
            // 
            this.fecundaçãoToolStripMenuItem.Name = "fecundaçãoToolStripMenuItem";
            this.fecundaçãoToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.fecundaçãoToolStripMenuItem.Text = "Fecundação";
            this.fecundaçãoToolStripMenuItem.Click += new System.EventHandler(this.fecundaçãoToolStripMenuItem_Click);
            // 
            // tiposDeOvosToolStripMenuItem
            // 
            this.tiposDeOvosToolStripMenuItem.Name = "tiposDeOvosToolStripMenuItem";
            this.tiposDeOvosToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.tiposDeOvosToolStripMenuItem.Text = "Tipos de Ovos";
            this.tiposDeOvosToolStripMenuItem.Click += new System.EventHandler(this.tiposDeOvosToolStripMenuItem_Click);
            // 
            // embriogêneseToolStripMenuItem
            // 
            this.embriogêneseToolStripMenuItem.Name = "embriogêneseToolStripMenuItem";
            this.embriogêneseToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.embriogêneseToolStripMenuItem.Text = "Embriogênese";
            this.embriogêneseToolStripMenuItem.Click += new System.EventHandler(this.embriogêneseToolStripMenuItem_Click);
            // 
            // anexosEmbrionáriosToolStripMenuItem
            // 
            this.anexosEmbrionáriosToolStripMenuItem.Name = "anexosEmbrionáriosToolStripMenuItem";
            this.anexosEmbrionáriosToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.anexosEmbrionáriosToolStripMenuItem.Text = "Anexos Embrionários";
            this.anexosEmbrionáriosToolStripMenuItem.Click += new System.EventHandler(this.anexosEmbrionáriosToolStripMenuItem_Click);
            // 
            // tipoDeReproduçãoToolStripMenuItem
            // 
            this.tipoDeReproduçãoToolStripMenuItem.Name = "tipoDeReproduçãoToolStripMenuItem";
            this.tipoDeReproduçãoToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.tipoDeReproduçãoToolStripMenuItem.Text = "Tipo de Reprodução";
            this.tipoDeReproduçãoToolStripMenuItem.Click += new System.EventHandler(this.tipoDeReproduçãoToolStripMenuItem_Click);
            // 
            // fisiologiaHumanaToolStripMenuItem
            // 
            this.fisiologiaHumanaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sistemaUrinárioToolStripMenuItem,
            this.sistemaNervosoToolStripMenuItem,
            this.sistemaDigestórioToolStripMenuItem,
            this.sistemaRespiratórioToolStripMenuItem,
            this.sistemaCirculatórioToolStripMenuItem});
            this.fisiologiaHumanaToolStripMenuItem.Name = "fisiologiaHumanaToolStripMenuItem";
            this.fisiologiaHumanaToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.fisiologiaHumanaToolStripMenuItem.Text = "Fisiologia Humana";
            // 
            // sistemaUrinárioToolStripMenuItem
            // 
            this.sistemaUrinárioToolStripMenuItem.Name = "sistemaUrinárioToolStripMenuItem";
            this.sistemaUrinárioToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.sistemaUrinárioToolStripMenuItem.Text = "Sistema Urinário";
            this.sistemaUrinárioToolStripMenuItem.Click += new System.EventHandler(this.sistemaUrinárioToolStripMenuItem_Click);
            // 
            // sistemaNervosoToolStripMenuItem
            // 
            this.sistemaNervosoToolStripMenuItem.Name = "sistemaNervosoToolStripMenuItem";
            this.sistemaNervosoToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.sistemaNervosoToolStripMenuItem.Text = "Sistema Nervoso";
            this.sistemaNervosoToolStripMenuItem.Click += new System.EventHandler(this.sistemaNervosoToolStripMenuItem_Click);
            // 
            // sistemaDigestórioToolStripMenuItem
            // 
            this.sistemaDigestórioToolStripMenuItem.Name = "sistemaDigestórioToolStripMenuItem";
            this.sistemaDigestórioToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.sistemaDigestórioToolStripMenuItem.Text = "Sistema Digestório";
            this.sistemaDigestórioToolStripMenuItem.Click += new System.EventHandler(this.sistemaDigestórioToolStripMenuItem_Click);
            // 
            // sistemaRespiratórioToolStripMenuItem
            // 
            this.sistemaRespiratórioToolStripMenuItem.Name = "sistemaRespiratórioToolStripMenuItem";
            this.sistemaRespiratórioToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.sistemaRespiratórioToolStripMenuItem.Text = "Sistema Respiratório";
            this.sistemaRespiratórioToolStripMenuItem.Click += new System.EventHandler(this.sistemaRespiratórioToolStripMenuItem_Click);
            // 
            // sistemaCirculatórioToolStripMenuItem
            // 
            this.sistemaCirculatórioToolStripMenuItem.Name = "sistemaCirculatórioToolStripMenuItem";
            this.sistemaCirculatórioToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.sistemaCirculatórioToolStripMenuItem.Text = "Sistema Circulatório";
            this.sistemaCirculatórioToolStripMenuItem.Click += new System.EventHandler(this.sistemaCirculatórioToolStripMenuItem_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.tsmiBiologia,
            this.perguntasToolStripMenuItem});
            this.menuStrip2.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip2.Size = new System.Drawing.Size(122, 612);
            this.menuStrip2.TabIndex = 59;
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripMenuItem1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(109, 39);
            this.toolStripMenuItem1.Text = "FECHAR";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // perguntasToolStripMenuItem
            // 
            this.perguntasToolStripMenuItem.BackColor = System.Drawing.Color.Tomato;
            this.perguntasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ecologiaECiênciasAmbientaisToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolStripMenuItem94,
            this.toolStripMenuItem108,
            this.toolStripMenuItem113,
            this.toolStripMenuItem126,
            this.toolStripMenuItem138,
            this.toolStripMenuItem145});
            this.perguntasToolStripMenuItem.Name = "perguntasToolStripMenuItem";
            this.perguntasToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.perguntasToolStripMenuItem.Text = "Perguntas";
            // 
            // ecologiaECiênciasAmbientaisToolStripMenuItem
            // 
            this.ecologiaECiênciasAmbientaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ecossistemasToolStripMenuItem,
            this.toolStripMenuItem16,
            this.toolStripMenuItem19,
            this.toolStripMenuItem21,
            this.toolStripMenuItem26,
            this.toolStripMenuItem28,
            this.toolStripMenuItem38,
            this.toolStripMenuItem69,
            this.toolStripMenuItem79,
            this.toolStripMenuItem88,
            this.toolStripMenuItem109});
            this.ecologiaECiênciasAmbientaisToolStripMenuItem.Name = "ecologiaECiênciasAmbientaisToolStripMenuItem";
            this.ecologiaECiênciasAmbientaisToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.ecologiaECiênciasAmbientaisToolStripMenuItem.Text = "Ecologia e Ciências Ambientais";
            // 
            // ecossistemasToolStripMenuItem
            // 
            this.ecossistemasToolStripMenuItem.Name = "ecossistemasToolStripMenuItem";
            this.ecossistemasToolStripMenuItem.Size = new System.Drawing.Size(607, 26);
            this.ecossistemasToolStripMenuItem.Text = "Ecossistemas";
            this.ecossistemasToolStripMenuItem.Click += new System.EventHandler(this.ecossistemasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem15,
            this.toolStripMenuItem25,
            this.toolStripMenuItem29,
            this.toolStripMenuItem39,
            this.toolStripMenuItem41,
            this.toolStripMenuItem72,
            this.toolStripMenuItem74,
            this.toolStripMenuItem76,
            this.toolStripMenuItem78,
            this.toolStripMenuItem85,
            this.toolStripMenuItem87});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem2.Text = "Moléculas, Células e Tecidos";
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem15.Text = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem25.Text = "Divisão Celular";
            this.toolStripMenuItem25.Click += new System.EventHandler(this.toolStripMenuItem25_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem29.Text = "Aspectos Bioquímicos das Estruturas Celulares";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem39.Text = "Aspectos Gerais do Metabolismo Celular";
            this.toolStripMenuItem39.Click += new System.EventHandler(this.toolStripMenuItem39_Click);
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem41.Text = "Metabolismo Energético: Fotossíntese e Respiração";
            this.toolStripMenuItem41.Click += new System.EventHandler(this.toolStripMenuItem41_Click);
            // 
            // toolStripMenuItem72
            // 
            this.toolStripMenuItem72.Name = "toolStripMenuItem72";
            this.toolStripMenuItem72.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem72.Text = "Codificação da Informação Genética";
            this.toolStripMenuItem72.Click += new System.EventHandler(this.toolStripMenuItem72_Click);
            // 
            // toolStripMenuItem74
            // 
            this.toolStripMenuItem74.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem74.Name = "toolStripMenuItem74";
            this.toolStripMenuItem74.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem74.Text = "Síntese Protética";
            this.toolStripMenuItem74.Click += new System.EventHandler(this.toolStripMenuItem74_Click);
            // 
            // toolStripMenuItem76
            // 
            this.toolStripMenuItem76.Name = "toolStripMenuItem76";
            this.toolStripMenuItem76.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem76.Text = "Diferenciação Celular";
            this.toolStripMenuItem76.Click += new System.EventHandler(this.toolStripMenuItem76_Click);
            // 
            // toolStripMenuItem78
            // 
            this.toolStripMenuItem78.Name = "toolStripMenuItem78";
            this.toolStripMenuItem78.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem78.Text = "Principais Tecidos Animais e Vegetais";
            this.toolStripMenuItem78.Click += new System.EventHandler(this.toolStripMenuItem78_Click);
            // 
            // toolStripMenuItem85
            // 
            this.toolStripMenuItem85.Name = "toolStripMenuItem85";
            this.toolStripMenuItem85.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem85.Text = "Origem e Evolução das Células";
            this.toolStripMenuItem85.Click += new System.EventHandler(this.toolStripMenuItem85_Click);
            // 
            // toolStripMenuItem87
            // 
            this.toolStripMenuItem87.Name = "toolStripMenuItem87";
            this.toolStripMenuItem87.Size = new System.Drawing.Size(536, 26);
            this.toolStripMenuItem87.Text = "Células-tronco, Clonagem e Tecnologia do DNA Recombinante";
            this.toolStripMenuItem87.Click += new System.EventHandler(this.toolStripMenuItem87_Click);
            // 
            // toolStripMenuItem94
            // 
            this.toolStripMenuItem94.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem96,
            this.toolStripMenuItem98,
            this.toolStripMenuItem101});
            this.toolStripMenuItem94.Name = "toolStripMenuItem94";
            this.toolStripMenuItem94.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem94.Text = "Genética";
            // 
            // toolStripMenuItem96
            // 
            this.toolStripMenuItem96.Name = "toolStripMenuItem96";
            this.toolStripMenuItem96.Size = new System.Drawing.Size(272, 26);
            this.toolStripMenuItem96.Text = "1ª Lei de Mendel";
            this.toolStripMenuItem96.Click += new System.EventHandler(this.toolStripMenuItem96_Click);
            // 
            // toolStripMenuItem98
            // 
            this.toolStripMenuItem98.Name = "toolStripMenuItem98";
            this.toolStripMenuItem98.Size = new System.Drawing.Size(272, 26);
            this.toolStripMenuItem98.Text = "Sistema ABO";
            this.toolStripMenuItem98.Click += new System.EventHandler(this.toolStripMenuItem98_Click);
            // 
            // toolStripMenuItem101
            // 
            this.toolStripMenuItem101.Name = "toolStripMenuItem101";
            this.toolStripMenuItem101.Size = new System.Drawing.Size(272, 26);
            this.toolStripMenuItem101.Text = "2ª Lei de Mendel";
            this.toolStripMenuItem101.Click += new System.EventHandler(this.toolStripMenuItem101_Click);
            // 
            // toolStripMenuItem108
            // 
            this.toolStripMenuItem108.Name = "toolStripMenuItem108";
            this.toolStripMenuItem108.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem108.Text = "Botânica";
            this.toolStripMenuItem108.Click += new System.EventHandler(this.toolStripMenuItem108_Click);
            // 
            // toolStripMenuItem113
            // 
            this.toolStripMenuItem113.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem117,
            this.toolStripMenuItem118,
            this.toolStripMenuItem119,
            this.toolStripMenuItem122});
            this.toolStripMenuItem113.Name = "toolStripMenuItem113";
            this.toolStripMenuItem113.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem113.Text = "Identidade dos Seres Vivos";
            // 
            // toolStripMenuItem117
            // 
            this.toolStripMenuItem117.Name = "toolStripMenuItem117";
            this.toolStripMenuItem117.Size = new System.Drawing.Size(325, 26);
            this.toolStripMenuItem117.Text = "Seres Unicelulares e Pluricelulares";
            this.toolStripMenuItem117.Click += new System.EventHandler(this.toolStripMenuItem117_Click);
            // 
            // toolStripMenuItem118
            // 
            this.toolStripMenuItem118.Name = "toolStripMenuItem118";
            this.toolStripMenuItem118.Size = new System.Drawing.Size(325, 26);
            this.toolStripMenuItem118.Text = "Autótrofos e Heterótrofos";
            this.toolStripMenuItem118.Click += new System.EventHandler(this.toolStripMenuItem118_Click);
            // 
            // toolStripMenuItem119
            // 
            this.toolStripMenuItem119.Name = "toolStripMenuItem119";
            this.toolStripMenuItem119.Size = new System.Drawing.Size(325, 26);
            this.toolStripMenuItem119.Text = "Reino Monera";
            this.toolStripMenuItem119.Click += new System.EventHandler(this.toolStripMenuItem119_Click);
            // 
            // toolStripMenuItem122
            // 
            this.toolStripMenuItem122.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem123,
            this.toolStripMenuItem124,
            this.toolStripMenuItem125});
            this.toolStripMenuItem122.Name = "toolStripMenuItem122";
            this.toolStripMenuItem122.Size = new System.Drawing.Size(325, 26);
            this.toolStripMenuItem122.Text = "Vírus, Procariontes e Eucariontes";
            // 
            // toolStripMenuItem123
            // 
            this.toolStripMenuItem123.Name = "toolStripMenuItem123";
            this.toolStripMenuItem123.Size = new System.Drawing.Size(289, 26);
            this.toolStripMenuItem123.Text = "Vírus";
            this.toolStripMenuItem123.Click += new System.EventHandler(this.toolStripMenuItem123_Click);
            // 
            // toolStripMenuItem124
            // 
            this.toolStripMenuItem124.Name = "toolStripMenuItem124";
            this.toolStripMenuItem124.Size = new System.Drawing.Size(289, 26);
            this.toolStripMenuItem124.Text = "Reino Protista - Protozoários";
            this.toolStripMenuItem124.Click += new System.EventHandler(this.toolStripMenuItem124_Click);
            // 
            // toolStripMenuItem125
            // 
            this.toolStripMenuItem125.Name = "toolStripMenuItem125";
            this.toolStripMenuItem125.Size = new System.Drawing.Size(289, 26);
            this.toolStripMenuItem125.Text = "Reino Fungi";
            this.toolStripMenuItem125.Click += new System.EventHandler(this.toolStripMenuItem125_Click);
            // 
            // toolStripMenuItem126
            // 
            this.toolStripMenuItem126.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem130,
            this.toolStripMenuItem132,
            this.toolStripMenuItem133,
            this.toolStripMenuItem136,
            this.toolStripMenuItem137});
            this.toolStripMenuItem126.Name = "toolStripMenuItem126";
            this.toolStripMenuItem126.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem126.Text = "Origem e Evolução da Vida";
            // 
            // toolStripMenuItem130
            // 
            this.toolStripMenuItem130.Name = "toolStripMenuItem130";
            this.toolStripMenuItem130.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem130.Text = "Teorias da Evolução";
            this.toolStripMenuItem130.Click += new System.EventHandler(this.toolStripMenuItem130_Click);
            // 
            // toolStripMenuItem132
            // 
            this.toolStripMenuItem132.Name = "toolStripMenuItem132";
            this.toolStripMenuItem132.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem132.Text = "Explicações Pré-darwinistas para a Modificação das Espécies";
            this.toolStripMenuItem132.Click += new System.EventHandler(this.toolStripMenuItem132_Click);
            // 
            // toolStripMenuItem133
            // 
            this.toolStripMenuItem133.Name = "toolStripMenuItem133";
            this.toolStripMenuItem133.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem133.Text = "A Teoria Evolutiva de Charles Darwin";
            this.toolStripMenuItem133.Click += new System.EventHandler(this.toolStripMenuItem133_Click);
            // 
            // toolStripMenuItem136
            // 
            this.toolStripMenuItem136.Name = "toolStripMenuItem136";
            this.toolStripMenuItem136.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem136.Text = "Cladogênese e Anagênese";
            this.toolStripMenuItem136.Click += new System.EventHandler(this.toolStripMenuItem136_Click);
            // 
            // toolStripMenuItem137
            // 
            this.toolStripMenuItem137.Name = "toolStripMenuItem137";
            this.toolStripMenuItem137.Size = new System.Drawing.Size(599, 26);
            this.toolStripMenuItem137.Text = "Isolamento Reprodutivo";
            this.toolStripMenuItem137.Click += new System.EventHandler(this.toolStripMenuItem137_Click);
            // 
            // toolStripMenuItem138
            // 
            this.toolStripMenuItem138.Name = "toolStripMenuItem138";
            this.toolStripMenuItem138.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem138.Text = "Embriologia";
            this.toolStripMenuItem138.Click += new System.EventHandler(this.toolStripMenuItem138_Click);
            // 
            // toolStripMenuItem145
            // 
            this.toolStripMenuItem145.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem146,
            this.toolStripMenuItem147,
            this.toolStripMenuItem148,
            this.toolStripMenuItem149,
            this.toolStripMenuItem150});
            this.toolStripMenuItem145.Name = "toolStripMenuItem145";
            this.toolStripMenuItem145.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem145.Text = "Fisiologia Humana";
            // 
            // toolStripMenuItem146
            // 
            this.toolStripMenuItem146.Name = "toolStripMenuItem146";
            this.toolStripMenuItem146.Size = new System.Drawing.Size(231, 26);
            this.toolStripMenuItem146.Text = "Sistema Urinário";
            this.toolStripMenuItem146.Click += new System.EventHandler(this.toolStripMenuItem146_Click);
            // 
            // toolStripMenuItem147
            // 
            this.toolStripMenuItem147.Name = "toolStripMenuItem147";
            this.toolStripMenuItem147.Size = new System.Drawing.Size(231, 26);
            this.toolStripMenuItem147.Text = "Sistema Nervoso";
            this.toolStripMenuItem147.Click += new System.EventHandler(this.toolStripMenuItem147_Click);
            // 
            // toolStripMenuItem148
            // 
            this.toolStripMenuItem148.Name = "toolStripMenuItem148";
            this.toolStripMenuItem148.Size = new System.Drawing.Size(231, 26);
            this.toolStripMenuItem148.Text = "Sistema Digestório";
            this.toolStripMenuItem148.Click += new System.EventHandler(this.toolStripMenuItem148_Click);
            // 
            // toolStripMenuItem149
            // 
            this.toolStripMenuItem149.Name = "toolStripMenuItem149";
            this.toolStripMenuItem149.Size = new System.Drawing.Size(231, 26);
            this.toolStripMenuItem149.Text = "Sistema Respiratório";
            this.toolStripMenuItem149.Click += new System.EventHandler(this.toolStripMenuItem149_Click);
            // 
            // toolStripMenuItem150
            // 
            this.toolStripMenuItem150.Name = "toolStripMenuItem150";
            this.toolStripMenuItem150.Size = new System.Drawing.Size(231, 26);
            this.toolStripMenuItem150.Text = "Sistema Circulatório";
            this.toolStripMenuItem150.Click += new System.EventHandler(this.toolStripMenuItem150_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(914, 612);
            this.sfoPlayer.TabIndex = 60;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(914, 612);
            this.PictureCSharp.TabIndex = 61;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(914, 612);
            this.panelQuiz.TabIndex = 62;
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem16.Text = "Fatores Bióticos e Abióticos";
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem19.Text = "Habitat e Nicho Ecológico";
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem21.Text = "A Comunidade Biológica: Teia Alimentar, Sucessão e Comunidade Clímax";
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem26.Text = "Dinâmica das Populações";
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem35,
            this.toolStripMenuItem36,
            this.toolStripMenuItem37});
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem28.Text = "Interações entre os Seres Vivos";
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(637, 26);
            this.toolStripMenuItem35.Text = "Relações ecológicas INTRAespecífica x INTERespecífica, sociedade e colônia";
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(637, 26);
            this.toolStripMenuItem36.Text = "Interespecíficas harmônicas: Comensalismo, inquilinismo, e forésia";
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(637, 26);
            this.toolStripMenuItem37.Text = "Interespecíficas desarmônicas: Amensalismo, predatismo e competição";
            // 
            // toolStripMenuItem38
            // 
            this.toolStripMenuItem38.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem40,
            this.toolStripMenuItem66,
            this.toolStripMenuItem67,
            this.toolStripMenuItem68});
            this.toolStripMenuItem38.Name = "toolStripMenuItem38";
            this.toolStripMenuItem38.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem38.Text = "Ciclos Biogeoquímicos";
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(160, 26);
            this.toolStripMenuItem40.Text = "Água";
            // 
            // toolStripMenuItem66
            // 
            this.toolStripMenuItem66.Name = "toolStripMenuItem66";
            this.toolStripMenuItem66.Size = new System.Drawing.Size(160, 26);
            this.toolStripMenuItem66.Text = "Carbono";
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(160, 26);
            this.toolStripMenuItem67.Text = "Oxigênio";
            // 
            // toolStripMenuItem68
            // 
            this.toolStripMenuItem68.Name = "toolStripMenuItem68";
            this.toolStripMenuItem68.Size = new System.Drawing.Size(160, 26);
            this.toolStripMenuItem68.Text = "Nitrogênio";
            // 
            // toolStripMenuItem69
            // 
            this.toolStripMenuItem69.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem70,
            this.toolStripMenuItem71,
            this.toolStripMenuItem73});
            this.toolStripMenuItem69.Name = "toolStripMenuItem69";
            this.toolStripMenuItem69.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem69.Text = "Fluxo de Energia no Ecossistema";
            // 
            // toolStripMenuItem70
            // 
            this.toolStripMenuItem70.Name = "toolStripMenuItem70";
            this.toolStripMenuItem70.Size = new System.Drawing.Size(246, 26);
            this.toolStripMenuItem70.Text = "Pirâmide de números";
            // 
            // toolStripMenuItem71
            // 
            this.toolStripMenuItem71.Name = "toolStripMenuItem71";
            this.toolStripMenuItem71.Size = new System.Drawing.Size(246, 26);
            this.toolStripMenuItem71.Text = "Pirâmides de biomassa";
            // 
            // toolStripMenuItem73
            // 
            this.toolStripMenuItem73.Name = "toolStripMenuItem73";
            this.toolStripMenuItem73.Size = new System.Drawing.Size(246, 26);
            this.toolStripMenuItem73.Text = "Pirâmides de energia";
            // 
            // toolStripMenuItem79
            // 
            this.toolStripMenuItem79.Name = "toolStripMenuItem79";
            this.toolStripMenuItem79.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem79.Text = "Biomas Brasileiros";
            // 
            // toolStripMenuItem88
            // 
            this.toolStripMenuItem88.Name = "toolStripMenuItem88";
            this.toolStripMenuItem88.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem88.Text = "Problemas Ambientais";
            // 
            // toolStripMenuItem109
            // 
            this.toolStripMenuItem109.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem110});
            this.toolStripMenuItem109.Name = "toolStripMenuItem109";
            this.toolStripMenuItem109.Size = new System.Drawing.Size(607, 26);
            this.toolStripMenuItem109.Text = "Tecnologias Ambientais";
            // 
            // toolStripMenuItem110
            // 
            this.toolStripMenuItem110.Name = "toolStripMenuItem110";
            this.toolStripMenuItem110.Size = new System.Drawing.Size(202, 26);
            this.toolStripMenuItem110.Text = "Revolução verde";
            // 
            // FrmBiologia
            // 
            this.AccessibleDescription = "FrmBiologia";
            this.AccessibleName = "FrmBiologia";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmBiologia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsmiBiologia;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem53;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem57;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem58;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem59;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem60;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem61;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem62;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem63;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem65;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.ToolStripMenuItem interfaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mitoseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meioseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem águaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem proteinasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem carboidratosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lipídiosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem membranaPlasmáticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transporteCelularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem membranaPlasmáticaespecializaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem organelasCitoplasmáticas1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem organelasCitoplasmáticas2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem núcleoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem núcleoReplicaçãoDoDNAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem núcleoRNAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sínteseDeProteínasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem metabolismoCelularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem respiraçãoCelularGlicóliseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem respiraçãoCelularCicloDeKrebsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fermentaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fotossínteseIFaseClaraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fotossínteseIIFaseEscuraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem origemDaVidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teoriasEvolutivasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seleçãoNaturalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tecidoEpitelialDeRevestimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tecidoEpitelialGlandularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tecidoConjuntivoPropriamenteDitoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vírusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reinoMoneraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reinoMoneraIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reinoMoneraIIToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tecidoConjuntivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tecidoMuscularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem códigoGenéticoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem origemdascélulaseucarióticasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impérioBiológicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadeiasXTeiasAlimentaresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem efeitoEstufaXAquecimentoGlobalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poluiçãoSonoraETérmicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poluiçãoAtmosféricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extinçãoDeEspéciesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eutrofizaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poluiçãoPorDerramamentoDePetróleoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoresBióticosEAbióticosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionamentoDeUmEcossistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sucessãoEcológicaPrimáriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sucessãoEcológicaSecundáriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ciclosBiogeoquímicosÁguaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ciclosBiogeoquímicosCarbonoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ciclosBiogeoquímicosOxigênioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ciclosBiogeoquímicosNitrogênioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pirâmideDeNúmerosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pirâmidesDeBiomassaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pirâmidesDeEnergiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pirâmideDeFluxoDeEnergiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem principaisBiomasBrasileiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oQueÉBiodiversidadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem habitatNichoEcológicoEcótonoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ecologiaDePopulaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biodiversidadeAmeaçadaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biodiversidadeAmeaçadaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaçõesDoHomemComANaturezaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoVerdeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oQueÉSaneamentoBásicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vertentesDeSaneamentoBásicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem legislaçãoAmbientalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diferenciaçãoCelularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem célulasTroncoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ClonagemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dNARecombinanteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biotecnologiaESuasAplicaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oQueÉBiotecnologiaToolStripMenuItem;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem genéticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ªLeiDeMendelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem heredogramaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaABOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercíciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polialeliaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ªLeiDeMendelToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem poliibridismoEPleiotropiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interaçãoGênicaComplementarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interaçãoGênicaEpistasiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interaçãoGênicaQuantitativaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem herançaSexualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem determinaçãoDoSexoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taxonomiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reinoProtistaProtozoáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reinoFungiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem botânicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem reinoPlantaeReproduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem florECicloDeVidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frutoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem embriologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gametogêneseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fecundaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposDeOvosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem embriogêneseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anexosEmbrionáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tipoDeReproduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem especiaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cladogêneseEAnagêneseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem isolamentoReprodutivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fisiologiaHumanaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaUrinárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaNervosoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaDigestórioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaRespiratórioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaCirculatórioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem perguntasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ecologiaECiênciasAmbientaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ecossistemasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem72;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem74;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem76;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem78;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem85;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem87;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem94;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem96;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem98;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem101;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem108;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem113;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem117;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem118;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem119;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem122;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem123;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem124;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem125;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem126;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem130;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem132;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem133;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem136;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem137;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem138;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem145;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem146;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem147;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem148;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem149;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem150;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem66;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem68;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem69;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem70;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem71;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem73;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem79;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem88;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem109;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem110;
    }
}