﻿namespace CursoVideo.View.Videos
{
    partial class FrmSocio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSocio));
            this.msSocio = new System.Windows.Forms.MenuStrip();
            this.timiFecharMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timiSociologia = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoEOrigemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoÀSociologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autoresClássicosDaSociologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emileDurkheimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.augusteComteEOPositivismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maxWeberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.karlMarxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novasRelaçõesDeTrabalhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relaçãoEntreIndivíduoESociedadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitosFundamentaisIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.democraciaEDireitosHumanosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.democraciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.direitosHumanosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociedadeMidiáticaComunicaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociedadeDeConsumoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociedadeMidiáticaLinguagemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitosFundamentaisIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociologiaNoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.escolaDeFrankfurtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDialéticaDoEsclarecimentoParteIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDialéticaDoEsclarecimentoParteIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.culturasContemporâneasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiPerg = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.msSocio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // msSocio
            // 
            this.msSocio.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.msSocio.Dock = System.Windows.Forms.DockStyle.Left;
            this.msSocio.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.msSocio.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.msSocio.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.timiFecharMenuItem,
            this.timiSociologia,
            this.tsmiPerg});
            this.msSocio.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.msSocio.Location = new System.Drawing.Point(0, 0);
            this.msSocio.Name = "msSocio";
            this.msSocio.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.msSocio.Size = new System.Drawing.Size(122, 631);
            this.msSocio.TabIndex = 38;
            // 
            // timiFecharMenuItem
            // 
            this.timiFecharMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.timiFecharMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.timiFecharMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("timiFecharMenuItem.Image")));
            this.timiFecharMenuItem.Name = "timiFecharMenuItem";
            this.timiFecharMenuItem.Size = new System.Drawing.Size(109, 39);
            this.timiFecharMenuItem.Text = "FECHAR";
            this.timiFecharMenuItem.Click += new System.EventHandler(this.fecharMenuItem_Click);
            // 
            // timiSociologia
            // 
            this.timiSociologia.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoEOrigemToolStripMenuItem,
            this.conceitosFundamentaisIToolStripMenuItem,
            this.conceitosFundamentaisIIToolStripMenuItem});
            this.timiSociologia.Name = "timiSociologia";
            this.timiSociologia.Size = new System.Drawing.Size(109, 25);
            this.timiSociologia.Text = "Sociologia";
            // 
            // introduçãoEOrigemToolStripMenuItem
            // 
            this.introduçãoEOrigemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoÀSociologiaToolStripMenuItem,
            this.autoresClássicosDaSociologiaToolStripMenuItem,
            this.emileDurkheimToolStripMenuItem,
            this.augusteComteEOPositivismoToolStripMenuItem,
            this.maxWeberToolStripMenuItem,
            this.karlMarxToolStripMenuItem,
            this.novasRelaçõesDeTrabalhoToolStripMenuItem,
            this.relaçãoEntreIndivíduoESociedadeToolStripMenuItem});
            this.introduçãoEOrigemToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.introduçãoEOrigemToolStripMenuItem.Name = "introduçãoEOrigemToolStripMenuItem";
            this.introduçãoEOrigemToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.introduçãoEOrigemToolStripMenuItem.Text = "Introdução e Origem";
            // 
            // introduçãoÀSociologiaToolStripMenuItem
            // 
            this.introduçãoÀSociologiaToolStripMenuItem.Name = "introduçãoÀSociologiaToolStripMenuItem";
            this.introduçãoÀSociologiaToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.introduçãoÀSociologiaToolStripMenuItem.Text = "Introdução à Sociologia";
            this.introduçãoÀSociologiaToolStripMenuItem.Click += new System.EventHandler(this.introduçãoÀSociologiaToolStripMenuItem_Click);
            // 
            // autoresClássicosDaSociologiaToolStripMenuItem
            // 
            this.autoresClássicosDaSociologiaToolStripMenuItem.Name = "autoresClássicosDaSociologiaToolStripMenuItem";
            this.autoresClássicosDaSociologiaToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.autoresClássicosDaSociologiaToolStripMenuItem.Text = "Autores Clássicos da Sociologia";
            this.autoresClássicosDaSociologiaToolStripMenuItem.Click += new System.EventHandler(this.autoresClássicosDaSociologiaToolStripMenuItem_Click);
            // 
            // emileDurkheimToolStripMenuItem
            // 
            this.emileDurkheimToolStripMenuItem.Name = "emileDurkheimToolStripMenuItem";
            this.emileDurkheimToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.emileDurkheimToolStripMenuItem.Text = "Emile Durkheim";
            this.emileDurkheimToolStripMenuItem.Click += new System.EventHandler(this.emileDurkheimToolStripMenuItem_Click);
            // 
            // augusteComteEOPositivismoToolStripMenuItem
            // 
            this.augusteComteEOPositivismoToolStripMenuItem.Name = "augusteComteEOPositivismoToolStripMenuItem";
            this.augusteComteEOPositivismoToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.augusteComteEOPositivismoToolStripMenuItem.Text = "Auguste Comte e o Positivismo";
            this.augusteComteEOPositivismoToolStripMenuItem.Click += new System.EventHandler(this.augusteComteEOPositivismoToolStripMenuItem_Click);
            // 
            // maxWeberToolStripMenuItem
            // 
            this.maxWeberToolStripMenuItem.Name = "maxWeberToolStripMenuItem";
            this.maxWeberToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.maxWeberToolStripMenuItem.Text = "Max Weber";
            this.maxWeberToolStripMenuItem.Click += new System.EventHandler(this.maxWeberToolStripMenuItem_Click);
            // 
            // karlMarxToolStripMenuItem
            // 
            this.karlMarxToolStripMenuItem.Name = "karlMarxToolStripMenuItem";
            this.karlMarxToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.karlMarxToolStripMenuItem.Text = "Karl Marx";
            this.karlMarxToolStripMenuItem.Click += new System.EventHandler(this.karlMarxToolStripMenuItem_Click);
            // 
            // novasRelaçõesDeTrabalhoToolStripMenuItem
            // 
            this.novasRelaçõesDeTrabalhoToolStripMenuItem.Name = "novasRelaçõesDeTrabalhoToolStripMenuItem";
            this.novasRelaçõesDeTrabalhoToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.novasRelaçõesDeTrabalhoToolStripMenuItem.Text = "Novas Relações de Trabalho";
            this.novasRelaçõesDeTrabalhoToolStripMenuItem.Click += new System.EventHandler(this.novasRelaçõesDeTrabalhoToolStripMenuItem_Click);
            // 
            // relaçãoEntreIndivíduoESociedadeToolStripMenuItem
            // 
            this.relaçãoEntreIndivíduoESociedadeToolStripMenuItem.Name = "relaçãoEntreIndivíduoESociedadeToolStripMenuItem";
            this.relaçãoEntreIndivíduoESociedadeToolStripMenuItem.Size = new System.Drawing.Size(347, 26);
            this.relaçãoEntreIndivíduoESociedadeToolStripMenuItem.Text = "Relação entre Indivíduo e Sociedade";
            this.relaçãoEntreIndivíduoESociedadeToolStripMenuItem.Click += new System.EventHandler(this.relaçãoEntreIndivíduoESociedadeToolStripMenuItem_Click);
            // 
            // conceitosFundamentaisIToolStripMenuItem
            // 
            this.conceitosFundamentaisIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.democraciaEDireitosHumanosToolStripMenuItem,
            this.sociedadeMidiáticaComunicaçãoToolStripMenuItem,
            this.sociedadeDeConsumoToolStripMenuItem,
            this.sociedadeMidiáticaLinguagemToolStripMenuItem});
            this.conceitosFundamentaisIToolStripMenuItem.Name = "conceitosFundamentaisIToolStripMenuItem";
            this.conceitosFundamentaisIToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.conceitosFundamentaisIToolStripMenuItem.Text = "Conceitos fundamentais I";
            // 
            // democraciaEDireitosHumanosToolStripMenuItem
            // 
            this.democraciaEDireitosHumanosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.democraciaToolStripMenuItem,
            this.direitosHumanosToolStripMenuItem});
            this.democraciaEDireitosHumanosToolStripMenuItem.Name = "democraciaEDireitosHumanosToolStripMenuItem";
            this.democraciaEDireitosHumanosToolStripMenuItem.Size = new System.Drawing.Size(339, 26);
            this.democraciaEDireitosHumanosToolStripMenuItem.Text = "Democracia e direitos humanos";
            // 
            // democraciaToolStripMenuItem
            // 
            this.democraciaToolStripMenuItem.Name = "democraciaToolStripMenuItem";
            this.democraciaToolStripMenuItem.Size = new System.Drawing.Size(207, 26);
            this.democraciaToolStripMenuItem.Text = "Democracia";
            this.democraciaToolStripMenuItem.Click += new System.EventHandler(this.democraciaToolStripMenuItem_Click);
            // 
            // direitosHumanosToolStripMenuItem
            // 
            this.direitosHumanosToolStripMenuItem.Name = "direitosHumanosToolStripMenuItem";
            this.direitosHumanosToolStripMenuItem.Size = new System.Drawing.Size(207, 26);
            this.direitosHumanosToolStripMenuItem.Text = "Direitos humanos";
            this.direitosHumanosToolStripMenuItem.Click += new System.EventHandler(this.direitosHumanosToolStripMenuItem_Click);
            // 
            // sociedadeMidiáticaComunicaçãoToolStripMenuItem
            // 
            this.sociedadeMidiáticaComunicaçãoToolStripMenuItem.Name = "sociedadeMidiáticaComunicaçãoToolStripMenuItem";
            this.sociedadeMidiáticaComunicaçãoToolStripMenuItem.Size = new System.Drawing.Size(339, 26);
            this.sociedadeMidiáticaComunicaçãoToolStripMenuItem.Text = "Sociedade midiática - Comunicação";
            this.sociedadeMidiáticaComunicaçãoToolStripMenuItem.Click += new System.EventHandler(this.sociedadeMidiáticaComunicaçãoToolStripMenuItem_Click);
            // 
            // sociedadeDeConsumoToolStripMenuItem
            // 
            this.sociedadeDeConsumoToolStripMenuItem.Name = "sociedadeDeConsumoToolStripMenuItem";
            this.sociedadeDeConsumoToolStripMenuItem.Size = new System.Drawing.Size(339, 26);
            this.sociedadeDeConsumoToolStripMenuItem.Text = "Sociedade de consumo";
            this.sociedadeDeConsumoToolStripMenuItem.Click += new System.EventHandler(this.sociedadeDeConsumoToolStripMenuItem_Click);
            // 
            // sociedadeMidiáticaLinguagemToolStripMenuItem
            // 
            this.sociedadeMidiáticaLinguagemToolStripMenuItem.Name = "sociedadeMidiáticaLinguagemToolStripMenuItem";
            this.sociedadeMidiáticaLinguagemToolStripMenuItem.Size = new System.Drawing.Size(339, 26);
            this.sociedadeMidiáticaLinguagemToolStripMenuItem.Text = "Sociedade midiática - Linguagem";
            this.sociedadeMidiáticaLinguagemToolStripMenuItem.Click += new System.EventHandler(this.sociedadeMidiáticaLinguagemToolStripMenuItem_Click);
            // 
            // conceitosFundamentaisIIToolStripMenuItem
            // 
            this.conceitosFundamentaisIIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sociologiaNoBrasilToolStripMenuItem,
            this.escolaDeFrankfurtToolStripMenuItem,
            this.culturasContemporâneasToolStripMenuItem});
            this.conceitosFundamentaisIIToolStripMenuItem.Name = "conceitosFundamentaisIIToolStripMenuItem";
            this.conceitosFundamentaisIIToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.conceitosFundamentaisIIToolStripMenuItem.Text = "Conceitos fundamentais II";
            // 
            // sociologiaNoBrasilToolStripMenuItem
            // 
            this.sociologiaNoBrasilToolStripMenuItem.Name = "sociologiaNoBrasilToolStripMenuItem";
            this.sociologiaNoBrasilToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.sociologiaNoBrasilToolStripMenuItem.Text = "Sociologia no Brasil";
            this.sociologiaNoBrasilToolStripMenuItem.Click += new System.EventHandler(this.sociologiaNoBrasilToolStripMenuItem_Click);
            // 
            // escolaDeFrankfurtToolStripMenuItem
            // 
            this.escolaDeFrankfurtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDialéticaDoEsclarecimentoParteIToolStripMenuItem,
            this.aDialéticaDoEsclarecimentoParteIIToolStripMenuItem});
            this.escolaDeFrankfurtToolStripMenuItem.Name = "escolaDeFrankfurtToolStripMenuItem";
            this.escolaDeFrankfurtToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.escolaDeFrankfurtToolStripMenuItem.Text = "Escola de Frankfurt";
            // 
            // aDialéticaDoEsclarecimentoParteIToolStripMenuItem
            // 
            this.aDialéticaDoEsclarecimentoParteIToolStripMenuItem.Name = "aDialéticaDoEsclarecimentoParteIToolStripMenuItem";
            this.aDialéticaDoEsclarecimentoParteIToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.aDialéticaDoEsclarecimentoParteIToolStripMenuItem.Text = "A Dialética do Esclarecimento - Parte I";
            this.aDialéticaDoEsclarecimentoParteIToolStripMenuItem.Click += new System.EventHandler(this.aDialéticaDoEsclarecimentoParteIToolStripMenuItem_Click);
            // 
            // aDialéticaDoEsclarecimentoParteIIToolStripMenuItem
            // 
            this.aDialéticaDoEsclarecimentoParteIIToolStripMenuItem.Name = "aDialéticaDoEsclarecimentoParteIIToolStripMenuItem";
            this.aDialéticaDoEsclarecimentoParteIIToolStripMenuItem.Size = new System.Drawing.Size(361, 26);
            this.aDialéticaDoEsclarecimentoParteIIToolStripMenuItem.Text = "A Dialética do Esclarecimento - Parte II";
            this.aDialéticaDoEsclarecimentoParteIIToolStripMenuItem.Click += new System.EventHandler(this.aDialéticaDoEsclarecimentoParteIIToolStripMenuItem_Click);
            // 
            // culturasContemporâneasToolStripMenuItem
            // 
            this.culturasContemporâneasToolStripMenuItem.Name = "culturasContemporâneasToolStripMenuItem";
            this.culturasContemporâneasToolStripMenuItem.Size = new System.Drawing.Size(266, 26);
            this.culturasContemporâneasToolStripMenuItem.Text = "Culturas contemporâneas";
            this.culturasContemporâneasToolStripMenuItem.Click += new System.EventHandler(this.culturasContemporâneasToolStripMenuItem_Click);
            // 
            // tsmiPerg
            // 
            this.tsmiPerg.BackColor = System.Drawing.Color.Tomato;
            this.tsmiPerg.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem11,
            this.toolStripMenuItem16});
            this.tsmiPerg.Name = "tsmiPerg";
            this.tsmiPerg.Size = new System.Drawing.Size(109, 25);
            this.tsmiPerg.Text = "Perguntas";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10});
            this.toolStripMenuItem2.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(270, 26);
            this.toolStripMenuItem2.Text = "Introdução e Origem";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(347, 26);
            this.toolStripMenuItem5.Text = "Emile Durkheim";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(347, 26);
            this.toolStripMenuItem6.Text = "Auguste Comte e o Positivismo";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(347, 26);
            this.toolStripMenuItem7.Text = "Max Weber";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(347, 26);
            this.toolStripMenuItem8.Text = "Karl Marx";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(347, 26);
            this.toolStripMenuItem9.Text = "Novas Relações de Trabalho";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(347, 26);
            this.toolStripMenuItem10.Text = "Relação entre Indivíduo e Sociedade";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.toolStripMenuItem15});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(270, 26);
            this.toolStripMenuItem11.Text = "Conceitos fundamentais I";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(339, 26);
            this.toolStripMenuItem12.Text = "Democracia e direitos humanos";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(339, 26);
            this.toolStripMenuItem13.Text = "Sociedade midiática - Comunicação";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(339, 26);
            this.toolStripMenuItem14.Text = "Sociedade de consumo";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(339, 26);
            this.toolStripMenuItem15.Text = "Sociedade midiática - Linguagem";
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem17,
            this.toolStripMenuItem18,
            this.toolStripMenuItem19});
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(270, 26);
            this.toolStripMenuItem16.Text = "Conceitos fundamentais II";
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(266, 26);
            this.toolStripMenuItem17.Text = "Sociologia no Brasil";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(266, 26);
            this.toolStripMenuItem18.Text = "Escola de Frankfurt";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(266, 26);
            this.toolStripMenuItem19.Text = "Culturas contemporâneas";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(987, 631);
            this.sfoPlayer.TabIndex = 40;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(987, 631);
            this.PictureCSharp.TabIndex = 41;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(987, 631);
            this.panelQuiz.TabIndex = 63;
            // 
            // FrmSocio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1109, 631);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.msSocio);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSocio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmPhp";
            this.msSocio.ResumeLayout(false);
            this.msSocio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip msSocio;
        private System.Windows.Forms.ToolStripMenuItem timiFecharMenuItem;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem timiSociologia;
        private System.Windows.Forms.ToolStripMenuItem introduçãoEOrigemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoÀSociologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maxWeberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitosFundamentaisIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem democraciaEDireitosHumanosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociedadeMidiáticaComunicaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociedadeDeConsumoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociedadeMidiáticaLinguagemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceitosFundamentaisIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociologiaNoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem escolaDeFrankfurtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem culturasContemporâneasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autoresClássicosDaSociologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emileDurkheimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem karlMarxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem augusteComteEOPositivismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem novasRelaçõesDeTrabalhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaçãoEntreIndivíduoESociedadeToolStripMenuItem;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem tsmiPerg;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem democraciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem direitosHumanosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDialéticaDoEsclarecimentoParteIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDialéticaDoEsclarecimentoParteIIToolStripMenuItem;
    }
}