﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmBiologia : Form
    {
        public FrmBiologia()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }
        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }
        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.


        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
              MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }
        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Biologia";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }
        private void interfaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ep1FD0FtHrk&index=15");
        }

        private void mitoseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pd2tpb-fK-Q&index=16");

        }

        private void meioseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=G1uC6Vy5vgE&index=17");
        }

        private void águaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3Yvgb_3-GHU&index=2");
        }

        private void proteinasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YLSUkfB2dMA&index=3");
        }

        private void carboidratosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LkEtsEa5LyM&index=4");
        }

        private void lipídiosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9hyGXTUk7AU&index=5");
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wQLFDx4M6lQ");
        }

        private void membranaPlasmáticaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GGx51r5QnIQ&index=6");
        }

        private void transporteCelularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8oFmkWqnJeQ");
        }

        private void membranaPlasmáticaespecializaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Srh-_PwNumE");
        }

        private void organelasCitoplasmáticas1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=RdzGuw4YNNQ");
        }

        private void organelasCitoplasmáticas2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vKS1hE9bEbA");
        }

        private void núcleoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9wtSzH8NE30");
        }

        private void núcleoReplicaçãoDoDNAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PmMJQvl254o");
        }

        private void núcleoRNAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vi40M7PGwRk");
        }

        private void sínteseDeProteínasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GGx51r5QnIQ&index=6");

        }

        private void metabolismoCelularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wQLFDx4M6lQ");

        }

        private void respiraçãoCelularGlicóliseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=p9mq1Om1xs4&index=71");

        }

        private void respiraçãoCelularCicloDeKrebsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=kFeDF1fOIJY");
        }

        private void respiraçãoCelularCadeiaRespiratóriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=T65q6Ym-nx8&index=73");

        }

        private void fermentaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Pj_rNnD9ZJY&index=74");
        }

        private void fotossínteseIFaseClaraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=AjcW8f9o1SM&index=75");
        }

        private void fotossínteseIIFaseEscuraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BFfEidPWpeM");
        }

        private void origemDaVidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=DVNey_bnbHA&index=60");
        }

        private void teoriasEvolutivasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=X7W232HkbKI");
        }

        private void seleçãoNaturalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=mD6WC3JMbp0");
        }

        private void vírusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=37KKIt4V7Lc");
        }

        private void nToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0SRBL-ETDjU");
        }

        private void reinoMoneraIToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=ensoDxeHZLU&index=20");


        }

        private void reinoMoneraIIToolStripMenuItem1_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=oV5RCU4mRh0&index=21");


        }

        private void tecidoConjuntivoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=b1Udn9b9sxs&index=11");



        }

        private void tecidoMuscularToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=84FOwNu0kjg&index=12");


        }

        private void códigoGenéticoToolStripMenuItem1_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=RrKZBsIef-U");


        }

        private void origemdascélulaseucarióticasToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=XJxchy76BIA");


        }

        private void impérioBiológicoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=xfB1jOp0XiI");


        }

        private void fatoresBióticosEAbióticosToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=k4A0HXt1NhI&index=13");



        }

        private void funcionamentoDeUmEcossistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=_d0mo6MK4TE");


        }

        private void cadeiasXTeiasAlimentaresToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=YFIuyz5Fi1E");


        }

        private void sucessãoEcológicaPrimáriaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=NmX-daIfeY4&index=19");


        }

        private void sucessãoEcológicaSecundáriaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=n-VhNT5cxgM");


        }

        private void relaçõesEcológicasINTRAespecíficaXINTERespecíficaSociedadeEColôniaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=2viw--7icQo");


        }

        private void nterespecíficasHarmônicasComensalismoInquilinismoEForésiaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=qg8mB-HvSIQ");


        }

        private void interespecíficasDesarmônicasAmensalismoPredatismoECompetiçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=6uI7xRDYUMw");


        }

        private void ciclosBiogeoquímicosÁguaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=yCwzJiYIm9M");


        }

        private void ciclosBiogeoquímicosCarbonoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=rCuHiRzgQB8");


        }

        private void ciclosBiogeoquímicosOxigênioToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=LG48H_6LEDg&index=26");


        }

        private void ciclosBiogeoquímicosNitrogênioToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=tqaSRf3rhgg&index=27");


        }

        private void pirâmideDeNúmerosToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=KSVcm0NJ4aI&index=15");


        }

        private void pirâmidesDeBiomassaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=Zm94E5JFkT0");


        }

        private void pirâmidesDeEnergiaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=mm4aBd2p4Hs");


        }

        private void pirâmideDeFluxoDeEnergiaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=f-l83HXPBRA&index=18");


        }

        private void efeitoEstufaXAquecimentoGlobalToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=PXZ2f77Mtzg");


        }

        private void poluiçãoSonoraETérmicaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=6GTzHZY3YD4");


        }

        private void poluiçãoAtmosféricaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=mx_MFSBPYKg&index=3");


        }

        private void extinçãoDeEspéciesToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=Yvd9uoIpNWI");


        }

        private void eutrofizaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=KGOU9sT6hVA");


        }

        private void poluiçãoPorDerramamentoDePetróleoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=8FUKwsDDl5c&index=7");


        }

        private void principaisBiomasBrasileiroToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=kLzrUumMQCE");


        }

        private void oQueÉBiodiversidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=il4rnY3qXyc");


        }

        private void habitatNichoEcológicoEcótonoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=uKGY6aR43C8");


        }

        private void ecologiaDePopulaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=9vTAfByJ-OY");



        }

        private void caçaEExploraçãoExcessivaDeRecursosNaturaisToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=9vTAfByJ-OY");


        }

        private void biodiversidadeAmeaçadaIToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=LnXmdAtM4zM");


        }

        private void biodiversidadeAmeaçadaIIToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=CAUsPrPCF4A");


        }

        private void espéciesExóticasEEspéciesExóticasInvasorasToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=ayDUGNa3wE4");


        }

        private void relaçõesDoHomemComANaturezaToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=PptucP6bJYo");


        }

        private void revoluçãoVerdeToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=i_440publWE");


        }

        private void oQueÉSaneamentoBásicoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=_6-4cgx3BR4");


        }

        private void vertentesDeSaneamentoBásicoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=Smqp18lPCU0");


        }

        private void legislaçãoAmbientalToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=R3G_hWBqqyw");



        }

        private void diferenciaçãoCelularToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=VWGraEyijbU");


        }

        private void célulasTroncoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=rSfKsJcWuB0");


        }

        private void ClonagemToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=4-V1NPzvZYs");


        }

        private void dNARecombinanteToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=1DHQFDldgrI");


        }

        private void biotecnologiaESuasAplicaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {


            LeitorCodigo("https://www.youtube.com/watch?v=bNE8CyYF0q0");


        }

        private void oQueÉBiotecnologiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bDKOreHgQP4");

        }

        private void introduçãoToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GKP84G9lAFE");
        }

        private void ªLeiDeMendelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bwnyUP2TDkw");
        }

        private void heredogramaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SDhORsYStrM");
        }

        private void sistemaABOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=fY8k8ZzoqJ4");
        }

        private void exercíciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=lNTNASs4rc4");
        }

        private void polialeliaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4nMIH4VC4Nc");
        }

        private void ªLeiDeMendelToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PoOiozVVUfQ");
        }

        private void poliibridismoEPleiotropiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=E6H9aFM5psA");
        }

        private void interaçãoGênicaComplementarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qKqQJmVceCc");
        }

        private void interaçãoGênicaEpistasiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=h3bq_TKIQ_M");
        }

        private void interaçãoGênicaQuantitativaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=iala9QoJ80w");
        }

        private void herançaSexualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LpB3UyroX0E");
        }

        private void determinaçãoDoSexoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6VtHNu81HZU");
        }

        private void taxonomiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=M2_1305ayxM");
        }

        private void reinoProtistaProtozoáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5Aty7MrKwP8");

        }

        private void reinoFungiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nRWzbq6Iftg");
        }

        private void toolStripMenuItem33_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=he18uiupCdU");
        }

        private void toolStripMenuItem34_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=F9c8jjsR_ZE");
        }

        private void introduçãoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=R4fsfKH0at0");
        }

        private void reinoPlantaeReproduçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ysTnaNgrGpA");
        }

        private void florECicloDeVidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=sXE3KNfCSZI");
        }

        private void frutoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PWedm2sdlbw");
        }

        private void gametogêneseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pF9zpPYd81U");
        }

        private void fecundaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Btc71Lxjkko");
        }

        private void tiposDeOvosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YqTd5Eznz0E");
        }

        private void embriogêneseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7SrgNZ35TmY");
        }

        private void anexosEmbrionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=FXu5Yo3aeqg");
        }

        private void tipoDeReproduçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=itrPwjHu698");
        }

        private void especiaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Mj8Hc2U8Edo");
        }

        private void cladogêneseEAnagêneseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CNWCQLNF1KM");
        }

        private void isolamentoReprodutivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HWRfxkr759U");
        }

        private void sistemaRespiratórioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vmVl1631iRo");
        }

        private void sistemaCirculatórioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6kcFMer1gzQ");
        }

        private void sistemaNervosoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YPBw22Os2_4&index=8");
        }

        private void sistemaDigestórioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=J4IVHqIrdWw&index=4");
        }

        private void sistemaUrinárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=osRt8I0WkXI&index=23");
        }
        private void ecossistemasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Ecossistemas";

            ChamarQuiz();            
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();
       
        }

        private void toolStripMenuItem25_Click(object sender, EventArgs e)
        {

            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();

        }

        private void toolStripMenuItem29_Click(object sender, EventArgs e)
        {



            

            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem39_Click(object sender, EventArgs e)
        {



            

            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem41_Click(object sender, EventArgs e)
        {



            

            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem72_Click(object sender, EventArgs e)
        {


            


            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem74_Click(object sender, EventArgs e)
        {



           

            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem76_Click(object sender, EventArgs e)
        {



          

            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem78_Click(object sender, EventArgs e)
        {


            


            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem85_Click(object sender, EventArgs e)
        {

            



            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem87_Click(object sender, EventArgs e)
        {


            


            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem91_Click(object sender, EventArgs e)
        {


          


            
            PergDTO.TEMA = "Estrutura e Fisiologia Celular: Membrana, Citoplasma e Núcleo";
            ChamarQuiz();





        }

        private void toolStripMenuItem96_Click(object sender, EventArgs e)
        {


          


            
            PergDTO.TEMA = "1ª Lei de Mendel";
            ChamarQuiz();





        }

        private void toolStripMenuItem97_Click(object sender, EventArgs e)
        {



           

            
            PergDTO.TEMA = "Heredograma";
            ChamarQuiz();





        }

        private void toolStripMenuItem98_Click(object sender, EventArgs e)
        {





            
            PergDTO.TEMA = "Sistema ABO";
            ChamarQuiz();





        }

        private void toolStripMenuItem100_Click(object sender, EventArgs e)
        {




            
            PergDTO.TEMA = "Polialelia";
            ChamarQuiz();





        }

        private void toolStripMenuItem101_Click(object sender, EventArgs e)
        {

            PergDTO.TEMA = "2ª Lei de Mendel";
            ChamarQuiz();

        }

        private void toolStripMenuItem102_Click(object sender, EventArgs e)
        {





            
            PergDTO.TEMA = "Poliibridismo e Pleiotropia";
            ChamarQuiz();





        }

        private void toolStripMenuItem104_Click(object sender, EventArgs e)
        {




            
            PergDTO.TEMA = "Interação Gênica";
            ChamarQuiz();





        }

        private void toolStripMenuItem106_Click(object sender, EventArgs e)
        {




           
            
            PergDTO.TEMA = "Herança Sexual";

            ChamarQuiz();




        }

        private void toolStripMenuItem107_Click(object sender, EventArgs e)
        {




            
            
            PergDTO.TEMA = "Determinação do Sexo";

            ChamarQuiz();




        }

        private void toolStripMenuItem108_Click(object sender, EventArgs e)
        {





            
            PergDTO.TEMA = "Botânica";
            ChamarQuiz();





        }


        private void toolStripMenuItem117_Click(object sender, EventArgs e)
        {




           
            
            PergDTO.TEMA = "Seres Unicelulares e Pluricelulares";
            ChamarQuiz();





        }

        private void toolStripMenuItem118_Click(object sender, EventArgs e)
        {


            PergDTO.TEMA = "Autótrofos e Heterótrofos";

            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem119_Click(object sender, EventArgs e)
        {


            PergDTO.TEMA = "Reino Monera";

            ChamarQuiz();
            
        






        }

        private void toolStripMenuItem123_Click(object sender, EventArgs e)
        {


            PergDTO.TEMA = "Vírus";

            ChamarQuiz();
            
           






        }

        private void toolStripMenuItem124_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Reino Protista - Protozoários";
            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem125_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Reino Fungi";
            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem127_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "A Biologia como Ciência: História, Métodos, Técnicas e Experimentação";
            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem128_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Hipóteses sobre a Origem do Universo, da Terra e dos Seres Vivos";
            ChamarQuiz();
            
           






        }

        private void toolStripMenuItem130_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Teorias da Evolução";
            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem132_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Explicações Pré-darwinistas para a Modificação das Espécies";
            ChamarQuiz();
            
           






        }

        private void toolStripMenuItem133_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "A Teoria Evolutiva de Charles Darwin";
            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem136_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Cladogênese e Anagênese";
            ChamarQuiz();
            
           






        }

        private void toolStripMenuItem137_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Isolamento Reprodutivo";
            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem138_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Embriologia";
            ChamarQuiz();
            
            






        }

        private void toolStripMenuItem146_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Sistema Urinário";
            ChamarQuiz();
        }

        private void toolStripMenuItem147_Click(object sender, EventArgs e)
        {



            PergDTO.TEMA = "Sistema Nervoso";
            ChamarQuiz();
            
           






        }

        private void toolStripMenuItem148_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = "Sistema Digestório";
            ChamarQuiz();
        }

        private void toolStripMenuItem149_Click(object sender, EventArgs e)
        {




           
            
            PergDTO.TEMA = "Sistema Respiratório";
            ChamarQuiz();





        }

        private void toolStripMenuItem150_Click(object sender, EventArgs e)
        {




            
            PergDTO.TEMA = "Sistema Circulatório";

            ChamarQuiz();





        }
    }
}

