﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmPort : Form
    {
        public FrmPort()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }
        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }
        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }
        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Literatura";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }
        public void ChamarQuizP()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Português";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }
        public void ChamarQuizG()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Gramática";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }
        private void fecharMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
             MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }

        private void aula01ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=n0e75nRstcU");
        }

        private void aula02ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Hi-2LNNg4SE");
        }

        private void introduçãoÀLiteraturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=POalSeti9cA");
        }

        private void quinhentismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=aHh_4CMFhPQ");
        }

        private void barrocoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=N6jXwPXGTeM");
        }

        private void arcadismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SwuEXi4Bfuo");
        }

        private void introduçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9I2wMm6ZFe4");
        }

        private void poesiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XVfl-p3KaQ0");
        }

        private void prosaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=b0unw_9cx9k");
        }

        private void realismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6vPf_HsWB8c");
        }

        private void naturalismoImpressionismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pJaoD1nelMs");
        }

        private void parnasianismoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jXIujnBiuhw");
        }

        private void simbolismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5CpcAxEi2BQ");
        }

        private void préModernismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CX4UzqnZgD8");
        }

        private void semanaDeArteModernaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=lpDeeHKS20A");
        }

        private void cubismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=DfaYUFTGaO4&index=23");
        }

        private void dadaísmoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nn4ebQ2X86g");
        }

        private void expressionismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZAES7MxcOBY");
        }

        private void fauvismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NxCcyl7x9Og&index=26");
        }

        private void futurismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=QUHE0Sp0YNA&index=29");
        }

        private void surrealismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TmK3Rbrj1ig&index=30");
        }

        private void ªFaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=mTle-Sw9T4A&index=14");
        }

        private void ªFasePoesiaModernaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ri83bT49bKI&index=15");
        }

        private void ªFaseRomanceDe30ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8aAIQ57L3Zk&index=16");
        }

        private void ªFaseGeraçãoDe45ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=b3cbBmPWT9o&index=17");
        }

        private void concretismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ri49CNslcUI");
        }

        private void introduçãoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Tal3Ll0Rd1w");
        }

        private void cantigasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=AnuhzGgD2Zo");
        }

        private void humanismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6BqSjA4gagA");
        }

        private void introduçãoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=A1WRr9E5c4g");
        }

        private void classicismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=sECD3XFVcnA");
        }

        private void asDivisõesDaGramáticaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=E3N0LKv4GIQ&index=66");
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteIIVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void advérbiosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void artigoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void conjunçõesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void numeraisEInterjeiçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteIToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteIToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteIIToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteIIIToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteIVToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteVToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteVIToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteVIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteVIIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteIXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteXIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteXIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteXIIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parteXIVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte02ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte03ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte04ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte02ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte03ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte04ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte02ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte03ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte04ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem9_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte02ToolStripMenuItem8_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem8_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte02ToolStripMenuItem7_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem7_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte02ToolStripMenuItem6_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte02ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte03ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void tiposDeSujeitoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void osTermosDaOraçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void oraçãoFormaçãoEPeríodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void adjuntoAdnominalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte01ToolStripMenuItem6_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void parte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void complementosNominaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void apostoEVocativoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void complementosVerbaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("");
        }

        private void interpretaçãoDeTextosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = interpretaçãoDeTextosToolStripMenuItem1.Text;
            ChamarQuizP();
        }

        private void figurasDeLinguagemToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = figurasDeLinguagemToolStripMenuItem1.Text;
            ChamarQuizP();
        }

        private void toolStripMenuItem23_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem23.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem28_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem29_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem29.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem30_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem30.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem31_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem31.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem35_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem35.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem37_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem37.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem46_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem46.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem60_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem60.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem65_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem65.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem70_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem70.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem75_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem75.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem78_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem78.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem82_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem82.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem85_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem85.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem89_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem89.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem124_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem124.Text;
            ChamarQuizG();
        }

        private void quinhentismoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = quinhentismoToolStripMenuItem1.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem149_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem149.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem150_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem150.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem153_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem153.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem154_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem154.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem155_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem155.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem156_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem156.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem157_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem157.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem158_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem158.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem159_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem159.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem160_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem160.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem162_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem162.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem163_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem163.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem164_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem164.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem165_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem165.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem166_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem166.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem169_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem169.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem171_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem171.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem170_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem170.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem172_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem172.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem173_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem173.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem175_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem175.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem178_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem178.Text;
            ChamarQuiz();
        }

        private void interpretaçãoDeTextosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GUNjrcFywsY");
        }

        private void toolStripMenuItem131_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem131.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem136_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem136.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem137_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem137.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem138_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem138.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem139_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem139.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem140_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem140.Text;
            ChamarQuizG();
        }

        private void toolStripMenuItem144_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem144.Text;
            ChamarQuizG();
        }
    }
}
