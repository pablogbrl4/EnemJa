﻿namespace CursoVideo.View.Videos
{
    partial class FrmHist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHist));
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.históriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.históriaGeralToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoAoEstudoHistóricoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linhaDoTempoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.préHistóriaDefiniçãoEEstudoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.antiguidadeClássicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mesopotâmiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gréciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.romaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.idadeMédiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impérioBizantinoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impérioDosFrancosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.civilizaçãoIslâmicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feudalismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aBaixaIdadeMédiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cruzadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renascimentoComercialEUrbanoFatoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pesteNegraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monarquiasNacionaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.igrejaMedievalInquisiçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renascimentoCulturalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reformaProtestanteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.absolutismoEMercantilismoIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.absolutismoEMercantilismoIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expansãoMarítimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aConquistaDaAméricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.séculoXVIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dinastiaStuartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.absolutismoNaInglaterraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visãoAlémDoAlcanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.economiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anglicanosEPuritanosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reiXParlamentoEAGuerraCivilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iluminismoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoFrancesaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoFrancesaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoNapoleônicoIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoNapoleônicoIiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçõesLiberaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.primeiraFaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.segundaRevoluçãoIndustrialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doutrinasDoSéculoXIXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imperialismoEPrimeiraGuerraMundialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imperialismoNeocolonialismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.áfricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eurocentrismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.primeiraGuerraMundialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoEntreGuerrasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tratadoDeVersalhesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoRussaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoRussaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trotskyXStalinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.criseDe1929ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.regimesTotalitáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fascismoItalianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.históriaNazismoAlemãoIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.históriaNazismoAlemãoIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.segundaGuerraMundialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parteIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoÀGuerraFriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conflitosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descolonizaçãoDaÁfricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoChinesaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guerrasDaCoreiaEVietnãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conflitosNoOrienteMédioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uRSSESeusEstadistasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quedaDoMuroDeBerlimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oBrasilNaGuerraFriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quedaDaURSSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.direitosHumanosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mundoAtualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.históriaDaAméricaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conquistaDaAméricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maiasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aSTECASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colonizaçãoEspanholaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colonizaçãoInglesaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoAmericanaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expansãoDosEUAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estaodsUnidosNoSéculoXIXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guerraDeSecessãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadosUnidosNoSéculoXIXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.criseDe1929ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadosUnidosPósSegundaGuerraMundialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regimesMilitaresETransiçãoDemocráticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ditadurasDaAMÉRICALATINAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aRevoluçãoCubanaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aRevoluçãoMexicanaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.independênciaDaAméricaLatinaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadosNacionaisLatinosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaçãoDosEstadosNacionaisIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaçãoDosEstadosNacionaisIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.populismoNaAméricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.américaAtualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.históriaDoBrasilToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.préHistóriaNoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aMontagemDoSistemaColonialNoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descobrimentoDoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoPréColonialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ciclosEconômicosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.capitaniasHereditáriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governosGeraisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.economiaDoAçúcarColonialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uniãoIbéricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.presençaHolandesaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.economiaMineradoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.escravidãoNoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociedadesQuilombolasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bandeirantismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aCriseDoSistemaColonialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.criseDoSistemaColonialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revisãoDoPeríodoColonialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoJoaninoIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoJoaninoIToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoJoaninoIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.primeiroReinadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.independênciaDoBrasilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.primeiroReinadoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoRegencialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoRegencialParteIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoRegencialParteIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaRegenciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.segundoReinadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.segundoReinadoParteIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.segundoReinadoParteIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guerrasDoPrataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aCriseDoSegundoReinadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.osPartidosPoliticosNoBrasilImpérioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leisAbolicionistasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oProcessoDeIndependênciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aReúblicaVelhaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.repúblicaDaEspadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.repúblicaOligárquicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentosERevoltasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaDaArmadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaFederalistaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaDeCanudosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaDaVacinaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaDaChibataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaDeJuazeiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoltaContestadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoDe1923ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoOperárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revoluçãoDe1930ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.eraVargasIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eraVargasEstadoNovo19371945ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eraVargasIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.períodoDemocrático19451964ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.populismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eríodoDemocráticoPopulistaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoDutraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoVargasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aMorteDeVargasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transiçãoDeVargasParaJKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoJKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoJânioQuadrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoJoãoGoulartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoDaLegalidadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regimeMilitarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.golpeDe1964ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linhaDoTempoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.governoCasteloBrancoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoCostaESilvaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoMédiciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoGeiselToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.governoFigueiredoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diretasJáToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNovaReplúblicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem52 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem53 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem55 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem56 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem58 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem59 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem61 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem62 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem63 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem65 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem70 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem71 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem72 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem73 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem74 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem75 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem76 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem77 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem79 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem80 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem82 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem83 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem84 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem85 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem86 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem87 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem88 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem89 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem90 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem91 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem92 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem93 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem94 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem95 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem98 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem99 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem100 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem101 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem102 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem103 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem104 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem105 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem106 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem109 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem110 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem111 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem112 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem113 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem114 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem115 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem116 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem117 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem118 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem120 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem121 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem122 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem123 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem124 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem125 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem126 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem127 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem128 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem129 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem131 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem132 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem135 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem136 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem137 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem138 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem139 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem141 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem142 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem143 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem145 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem146 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem147 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem148 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem149 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem150 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem152 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem153 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem154 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem155 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem156 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem157 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem158 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem159 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem160 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem161 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem162 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem163 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem164 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem165 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem166 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem169 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem171 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem172 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem174 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem175 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem176 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem178 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem179 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem180 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem181 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem182 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem183 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem185 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem186 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem187 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem188 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem189 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem190 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem191 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.históriaToolStripMenuItem,
            this.toolStripMenuItem2});
            this.menuStrip2.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip2.Size = new System.Drawing.Size(126, 612);
            this.menuStrip2.TabIndex = 60;
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.Transparent;
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(113, 39);
            this.toolStripMenuItem1.Text = "FECHAR";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // históriaToolStripMenuItem
            // 
            this.históriaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.históriaGeralToolStripMenuItem,
            this.históriaDaAméricaToolStripMenuItem1,
            this.históriaDoBrasilToolStripMenuItem1});
            this.históriaToolStripMenuItem.Name = "históriaToolStripMenuItem";
            this.históriaToolStripMenuItem.Size = new System.Drawing.Size(113, 25);
            this.históriaToolStripMenuItem.Text = "História";
            // 
            // históriaGeralToolStripMenuItem
            // 
            this.históriaGeralToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoAoEstudoHistóricoToolStripMenuItem,
            this.antiguidadeClássicaToolStripMenuItem,
            this.idadeMédiaToolStripMenuItem,
            this.aBaixaIdadeMédiaToolStripMenuItem,
            this.trToolStripMenuItem,
            this.absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem,
            this.revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem,
            this.revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem,
            this.revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem,
            this.imperialismoEPrimeiraGuerraMundialToolStripMenuItem,
            this.períodoEntreGuerrasToolStripMenuItem,
            this.segundaGuerraMundialToolStripMenuItem,
            this.guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem,
            this.mundoAtualToolStripMenuItem});
            this.históriaGeralToolStripMenuItem.Name = "históriaGeralToolStripMenuItem";
            this.históriaGeralToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.históriaGeralToolStripMenuItem.Text = "História Geral ";
            // 
            // introduçãoAoEstudoHistóricoToolStripMenuItem
            // 
            this.introduçãoAoEstudoHistóricoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.linhaDoTempoToolStripMenuItem,
            this.préHistóriaDefiniçãoEEstudoToolStripMenuItem});
            this.introduçãoAoEstudoHistóricoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.introduçãoAoEstudoHistóricoToolStripMenuItem.Name = "introduçãoAoEstudoHistóricoToolStripMenuItem";
            this.introduçãoAoEstudoHistóricoToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.introduçãoAoEstudoHistóricoToolStripMenuItem.Text = "Introdução ao Estudo Histórico";
            // 
            // linhaDoTempoToolStripMenuItem
            // 
            this.linhaDoTempoToolStripMenuItem.Name = "linhaDoTempoToolStripMenuItem";
            this.linhaDoTempoToolStripMenuItem.Size = new System.Drawing.Size(317, 26);
            this.linhaDoTempoToolStripMenuItem.Text = "Linha do Tempo";
            this.linhaDoTempoToolStripMenuItem.Click += new System.EventHandler(this.linhaDoTempoToolStripMenuItem_Click);
            // 
            // préHistóriaDefiniçãoEEstudoToolStripMenuItem
            // 
            this.préHistóriaDefiniçãoEEstudoToolStripMenuItem.Name = "préHistóriaDefiniçãoEEstudoToolStripMenuItem";
            this.préHistóriaDefiniçãoEEstudoToolStripMenuItem.Size = new System.Drawing.Size(317, 26);
            this.préHistóriaDefiniçãoEEstudoToolStripMenuItem.Text = "Pré-História - Definição e Estudo";
            this.préHistóriaDefiniçãoEEstudoToolStripMenuItem.Click += new System.EventHandler(this.préHistóriaDefiniçãoEEstudoToolStripMenuItem_Click);
            // 
            // antiguidadeClássicaToolStripMenuItem
            // 
            this.antiguidadeClássicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mesopotâmiaToolStripMenuItem,
            this.gréciaToolStripMenuItem,
            this.romaToolStripMenuItem});
            this.antiguidadeClássicaToolStripMenuItem.Name = "antiguidadeClássicaToolStripMenuItem";
            this.antiguidadeClássicaToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.antiguidadeClássicaToolStripMenuItem.Text = "Antiguidade Clássica";
            // 
            // mesopotâmiaToolStripMenuItem
            // 
            this.mesopotâmiaToolStripMenuItem.Name = "mesopotâmiaToolStripMenuItem";
            this.mesopotâmiaToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.mesopotâmiaToolStripMenuItem.Text = "Mesopotâmia";
            this.mesopotâmiaToolStripMenuItem.Click += new System.EventHandler(this.mesopotâmiaToolStripMenuItem_Click);
            // 
            // gréciaToolStripMenuItem
            // 
            this.gréciaToolStripMenuItem.Name = "gréciaToolStripMenuItem";
            this.gréciaToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.gréciaToolStripMenuItem.Text = "Grécia ";
            this.gréciaToolStripMenuItem.Click += new System.EventHandler(this.gréciaToolStripMenuItem_Click);
            // 
            // romaToolStripMenuItem
            // 
            this.romaToolStripMenuItem.Name = "romaToolStripMenuItem";
            this.romaToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.romaToolStripMenuItem.Text = "Roma";
            this.romaToolStripMenuItem.Click += new System.EventHandler(this.romaToolStripMenuItem_Click);
            // 
            // idadeMédiaToolStripMenuItem
            // 
            this.idadeMédiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.impérioBizantinoToolStripMenuItem,
            this.impérioDosFrancosToolStripMenuItem,
            this.civilizaçãoIslâmicaToolStripMenuItem,
            this.feudalismoToolStripMenuItem});
            this.idadeMédiaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.idadeMédiaToolStripMenuItem.Name = "idadeMédiaToolStripMenuItem";
            this.idadeMédiaToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.idadeMédiaToolStripMenuItem.Text = "Idade Média";
            // 
            // impérioBizantinoToolStripMenuItem
            // 
            this.impérioBizantinoToolStripMenuItem.Name = "impérioBizantinoToolStripMenuItem";
            this.impérioBizantinoToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.impérioBizantinoToolStripMenuItem.Text = "Império Bizantino";
            this.impérioBizantinoToolStripMenuItem.Click += new System.EventHandler(this.impérioBizantinoToolStripMenuItem_Click);
            // 
            // impérioDosFrancosToolStripMenuItem
            // 
            this.impérioDosFrancosToolStripMenuItem.Name = "impérioDosFrancosToolStripMenuItem";
            this.impérioDosFrancosToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.impérioDosFrancosToolStripMenuItem.Text = "Império dos Francos";
            this.impérioDosFrancosToolStripMenuItem.Click += new System.EventHandler(this.impérioDosFrancosToolStripMenuItem_Click);
            // 
            // civilizaçãoIslâmicaToolStripMenuItem
            // 
            this.civilizaçãoIslâmicaToolStripMenuItem.Name = "civilizaçãoIslâmicaToolStripMenuItem";
            this.civilizaçãoIslâmicaToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.civilizaçãoIslâmicaToolStripMenuItem.Text = "Civilização Islâmica";
            this.civilizaçãoIslâmicaToolStripMenuItem.Click += new System.EventHandler(this.civilizaçãoIslâmicaToolStripMenuItem_Click);
            // 
            // feudalismoToolStripMenuItem
            // 
            this.feudalismoToolStripMenuItem.Name = "feudalismoToolStripMenuItem";
            this.feudalismoToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.feudalismoToolStripMenuItem.Text = "Feudalismo";
            this.feudalismoToolStripMenuItem.Click += new System.EventHandler(this.feudalismoToolStripMenuItem_Click);
            // 
            // aBaixaIdadeMédiaToolStripMenuItem
            // 
            this.aBaixaIdadeMédiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cruzadasToolStripMenuItem,
            this.renascimentoComercialEUrbanoFatoresToolStripMenuItem,
            this.pesteNegraToolStripMenuItem,
            this.monarquiasNacionaisToolStripMenuItem});
            this.aBaixaIdadeMédiaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aBaixaIdadeMédiaToolStripMenuItem.Name = "aBaixaIdadeMédiaToolStripMenuItem";
            this.aBaixaIdadeMédiaToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.aBaixaIdadeMédiaToolStripMenuItem.Text = "A Baixa Idade Média";
            // 
            // cruzadasToolStripMenuItem
            // 
            this.cruzadasToolStripMenuItem.Name = "cruzadasToolStripMenuItem";
            this.cruzadasToolStripMenuItem.Size = new System.Drawing.Size(398, 26);
            this.cruzadasToolStripMenuItem.Text = "Cruzadas ";
            this.cruzadasToolStripMenuItem.Click += new System.EventHandler(this.cruzadasToolStripMenuItem_Click);
            // 
            // renascimentoComercialEUrbanoFatoresToolStripMenuItem
            // 
            this.renascimentoComercialEUrbanoFatoresToolStripMenuItem.Name = "renascimentoComercialEUrbanoFatoresToolStripMenuItem";
            this.renascimentoComercialEUrbanoFatoresToolStripMenuItem.Size = new System.Drawing.Size(398, 26);
            this.renascimentoComercialEUrbanoFatoresToolStripMenuItem.Text = "Renascimento Comercial e Urbano - Fatores";
            this.renascimentoComercialEUrbanoFatoresToolStripMenuItem.Click += new System.EventHandler(this.renascimentoComercialEUrbanoFatoresToolStripMenuItem_Click);
            // 
            // pesteNegraToolStripMenuItem
            // 
            this.pesteNegraToolStripMenuItem.Name = "pesteNegraToolStripMenuItem";
            this.pesteNegraToolStripMenuItem.Size = new System.Drawing.Size(398, 26);
            this.pesteNegraToolStripMenuItem.Text = "Peste Negra";
            this.pesteNegraToolStripMenuItem.Click += new System.EventHandler(this.pesteNegraToolStripMenuItem_Click);
            // 
            // monarquiasNacionaisToolStripMenuItem
            // 
            this.monarquiasNacionaisToolStripMenuItem.Name = "monarquiasNacionaisToolStripMenuItem";
            this.monarquiasNacionaisToolStripMenuItem.Size = new System.Drawing.Size(398, 26);
            this.monarquiasNacionaisToolStripMenuItem.Text = "Monarquias Nacionais";
            this.monarquiasNacionaisToolStripMenuItem.Click += new System.EventHandler(this.monarquiasNacionaisToolStripMenuItem_Click);
            // 
            // trToolStripMenuItem
            // 
            this.trToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.igrejaMedievalInquisiçãoToolStripMenuItem,
            this.renascimentoCulturalToolStripMenuItem1,
            this.reformaProtestanteToolStripMenuItem});
            this.trToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.trToolStripMenuItem.Name = "trToolStripMenuItem";
            this.trToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.trToolStripMenuItem.Text = "Transição da Idade Média para Idade Moderna";
            // 
            // igrejaMedievalInquisiçãoToolStripMenuItem
            // 
            this.igrejaMedievalInquisiçãoToolStripMenuItem.Name = "igrejaMedievalInquisiçãoToolStripMenuItem";
            this.igrejaMedievalInquisiçãoToolStripMenuItem.Size = new System.Drawing.Size(281, 26);
            this.igrejaMedievalInquisiçãoToolStripMenuItem.Text = "Igreja Medieval - Inquisição";
            this.igrejaMedievalInquisiçãoToolStripMenuItem.Click += new System.EventHandler(this.igrejaMedievalInquisiçãoToolStripMenuItem_Click);
            // 
            // renascimentoCulturalToolStripMenuItem1
            // 
            this.renascimentoCulturalToolStripMenuItem1.Name = "renascimentoCulturalToolStripMenuItem1";
            this.renascimentoCulturalToolStripMenuItem1.Size = new System.Drawing.Size(281, 26);
            this.renascimentoCulturalToolStripMenuItem1.Text = "Renascimento Cultural";
            this.renascimentoCulturalToolStripMenuItem1.Click += new System.EventHandler(this.renascimentoCulturalToolStripMenuItem1_Click);
            // 
            // reformaProtestanteToolStripMenuItem
            // 
            this.reformaProtestanteToolStripMenuItem.Name = "reformaProtestanteToolStripMenuItem";
            this.reformaProtestanteToolStripMenuItem.Size = new System.Drawing.Size(281, 26);
            this.reformaProtestanteToolStripMenuItem.Text = "Reforma Protestante";
            this.reformaProtestanteToolStripMenuItem.Click += new System.EventHandler(this.reformaProtestanteToolStripMenuItem_Click);
            // 
            // absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem
            // 
            this.absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.absolutismoEMercantilismoIToolStripMenuItem,
            this.absolutismoEMercantilismoIIToolStripMenuItem,
            this.expansãoMarítimaToolStripMenuItem,
            this.aConquistaDaAméricaToolStripMenuItem});
            this.absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem.Name = "absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem";
            this.absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem.Text = "Absolutismo Monárquico Europeu e Mercantilismo";
            // 
            // absolutismoEMercantilismoIToolStripMenuItem
            // 
            this.absolutismoEMercantilismoIToolStripMenuItem.Name = "absolutismoEMercantilismoIToolStripMenuItem";
            this.absolutismoEMercantilismoIToolStripMenuItem.Size = new System.Drawing.Size(307, 26);
            this.absolutismoEMercantilismoIToolStripMenuItem.Text = "Absolutismo e Mercantilismo I";
            this.absolutismoEMercantilismoIToolStripMenuItem.Click += new System.EventHandler(this.absolutismoEMercantilismoIToolStripMenuItem_Click);
            // 
            // absolutismoEMercantilismoIIToolStripMenuItem
            // 
            this.absolutismoEMercantilismoIIToolStripMenuItem.Name = "absolutismoEMercantilismoIIToolStripMenuItem";
            this.absolutismoEMercantilismoIIToolStripMenuItem.Size = new System.Drawing.Size(307, 26);
            this.absolutismoEMercantilismoIIToolStripMenuItem.Text = "Absolutismo e Mercantilismo II";
            this.absolutismoEMercantilismoIIToolStripMenuItem.Click += new System.EventHandler(this.absolutismoEMercantilismoIIToolStripMenuItem_Click);
            // 
            // expansãoMarítimaToolStripMenuItem
            // 
            this.expansãoMarítimaToolStripMenuItem.Name = "expansãoMarítimaToolStripMenuItem";
            this.expansãoMarítimaToolStripMenuItem.Size = new System.Drawing.Size(307, 26);
            this.expansãoMarítimaToolStripMenuItem.Text = "Expansão Marítima";
            this.expansãoMarítimaToolStripMenuItem.Click += new System.EventHandler(this.expansãoMarítimaToolStripMenuItem_Click);
            // 
            // aConquistaDaAméricaToolStripMenuItem
            // 
            this.aConquistaDaAméricaToolStripMenuItem.Name = "aConquistaDaAméricaToolStripMenuItem";
            this.aConquistaDaAméricaToolStripMenuItem.Size = new System.Drawing.Size(307, 26);
            this.aConquistaDaAméricaToolStripMenuItem.Text = "A Conquista da América";
            this.aConquistaDaAméricaToolStripMenuItem.Click += new System.EventHandler(this.aConquistaDaAméricaToolStripMenuItem_Click);
            // 
            // revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem
            // 
            this.revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.séculoXVIIToolStripMenuItem,
            this.dinastiaStuartToolStripMenuItem,
            this.absolutismoNaInglaterraToolStripMenuItem,
            this.visãoAlémDoAlcanceToolStripMenuItem,
            this.economiaToolStripMenuItem,
            this.anglicanosEPuritanosToolStripMenuItem,
            this.reiXParlamentoEAGuerraCivilToolStripMenuItem,
            this.repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem,
            this.iluminismoToolStripMenuItem1});
            this.revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem.Name = "revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem";
            this.revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem.Text = "Revoluções Inglesas do Século XVII e Iluminismo";
            // 
            // séculoXVIIToolStripMenuItem
            // 
            this.séculoXVIIToolStripMenuItem.Name = "séculoXVIIToolStripMenuItem";
            this.séculoXVIIToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.séculoXVIIToolStripMenuItem.Text = "século XVII";
            this.séculoXVIIToolStripMenuItem.Click += new System.EventHandler(this.séculoXVIIToolStripMenuItem_Click);
            // 
            // dinastiaStuartToolStripMenuItem
            // 
            this.dinastiaStuartToolStripMenuItem.Name = "dinastiaStuartToolStripMenuItem";
            this.dinastiaStuartToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.dinastiaStuartToolStripMenuItem.Text = "Dinastia Stuart";
            this.dinastiaStuartToolStripMenuItem.Click += new System.EventHandler(this.dinastiaStuartToolStripMenuItem_Click);
            // 
            // absolutismoNaInglaterraToolStripMenuItem
            // 
            this.absolutismoNaInglaterraToolStripMenuItem.Name = "absolutismoNaInglaterraToolStripMenuItem";
            this.absolutismoNaInglaterraToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.absolutismoNaInglaterraToolStripMenuItem.Text = "Absolutismo na Inglaterra";
            this.absolutismoNaInglaterraToolStripMenuItem.Click += new System.EventHandler(this.absolutismoNaInglaterraToolStripMenuItem_Click);
            // 
            // visãoAlémDoAlcanceToolStripMenuItem
            // 
            this.visãoAlémDoAlcanceToolStripMenuItem.Name = "visãoAlémDoAlcanceToolStripMenuItem";
            this.visãoAlémDoAlcanceToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.visãoAlémDoAlcanceToolStripMenuItem.Text = "Visão Além do Alcance";
            this.visãoAlémDoAlcanceToolStripMenuItem.Click += new System.EventHandler(this.visãoAlémDoAlcanceToolStripMenuItem_Click);
            // 
            // economiaToolStripMenuItem
            // 
            this.economiaToolStripMenuItem.Name = "economiaToolStripMenuItem";
            this.economiaToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.economiaToolStripMenuItem.Text = "Economia";
            this.economiaToolStripMenuItem.Click += new System.EventHandler(this.economiaToolStripMenuItem_Click);
            // 
            // anglicanosEPuritanosToolStripMenuItem
            // 
            this.anglicanosEPuritanosToolStripMenuItem.Name = "anglicanosEPuritanosToolStripMenuItem";
            this.anglicanosEPuritanosToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.anglicanosEPuritanosToolStripMenuItem.Text = "Anglicanos e Puritanos";
            this.anglicanosEPuritanosToolStripMenuItem.Click += new System.EventHandler(this.anglicanosEPuritanosToolStripMenuItem_Click);
            // 
            // reiXParlamentoEAGuerraCivilToolStripMenuItem
            // 
            this.reiXParlamentoEAGuerraCivilToolStripMenuItem.Name = "reiXParlamentoEAGuerraCivilToolStripMenuItem";
            this.reiXParlamentoEAGuerraCivilToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.reiXParlamentoEAGuerraCivilToolStripMenuItem.Text = "Rei X Parlamento e a Guerra Civil";
            this.reiXParlamentoEAGuerraCivilToolStripMenuItem.Click += new System.EventHandler(this.reiXParlamentoEAGuerraCivilToolStripMenuItem_Click);
            // 
            // repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem
            // 
            this.repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem.Name = "repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem";
            this.repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem.Size = new System.Drawing.Size(372, 26);
            this.repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem.Text = "República Puritana e Revolução Gloriosa";
            this.repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem.Click += new System.EventHandler(this.repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem_Click);
            // 
            // iluminismoToolStripMenuItem1
            // 
            this.iluminismoToolStripMenuItem1.Name = "iluminismoToolStripMenuItem1";
            this.iluminismoToolStripMenuItem1.Size = new System.Drawing.Size(372, 26);
            this.iluminismoToolStripMenuItem1.Text = "Iluminismo";
            this.iluminismoToolStripMenuItem1.Click += new System.EventHandler(this.iluminismoToolStripMenuItem1_Click);
            // 
            // revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem
            // 
            this.revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revoluçãoFrancesaIToolStripMenuItem,
            this.revoluçãoFrancesaIIToolStripMenuItem,
            this.períodoNapoleônicoIToolStripMenuItem,
            this.períodoNapoleônicoIiToolStripMenuItem,
            this.revoluçõesLiberaisToolStripMenuItem});
            this.revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem.Name = "revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem";
            this.revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem.Text = "Revolução Francesa e Era Napoleônica";
            // 
            // revoluçãoFrancesaIToolStripMenuItem
            // 
            this.revoluçãoFrancesaIToolStripMenuItem.Name = "revoluçãoFrancesaIToolStripMenuItem";
            this.revoluçãoFrancesaIToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.revoluçãoFrancesaIToolStripMenuItem.Text = "Revolução Francesa I";
            this.revoluçãoFrancesaIToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoFrancesaIToolStripMenuItem_Click);
            // 
            // revoluçãoFrancesaIIToolStripMenuItem
            // 
            this.revoluçãoFrancesaIIToolStripMenuItem.Name = "revoluçãoFrancesaIIToolStripMenuItem";
            this.revoluçãoFrancesaIIToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.revoluçãoFrancesaIIToolStripMenuItem.Text = "Revolução Francesa II";
            this.revoluçãoFrancesaIIToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoFrancesaIIToolStripMenuItem_Click);
            // 
            // períodoNapoleônicoIToolStripMenuItem
            // 
            this.períodoNapoleônicoIToolStripMenuItem.Name = "períodoNapoleônicoIToolStripMenuItem";
            this.períodoNapoleônicoIToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.períodoNapoleônicoIToolStripMenuItem.Text = "Período Napoleônico I";
            this.períodoNapoleônicoIToolStripMenuItem.Click += new System.EventHandler(this.períodoNapoleônicoIToolStripMenuItem_Click);
            // 
            // períodoNapoleônicoIiToolStripMenuItem
            // 
            this.períodoNapoleônicoIiToolStripMenuItem.Name = "períodoNapoleônicoIiToolStripMenuItem";
            this.períodoNapoleônicoIiToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.períodoNapoleônicoIiToolStripMenuItem.Text = "Período Napoleônico II";
            this.períodoNapoleônicoIiToolStripMenuItem.Click += new System.EventHandler(this.períodoNapoleônicoIiToolStripMenuItem_Click);
            // 
            // revoluçõesLiberaisToolStripMenuItem
            // 
            this.revoluçõesLiberaisToolStripMenuItem.Name = "revoluçõesLiberaisToolStripMenuItem";
            this.revoluçõesLiberaisToolStripMenuItem.Size = new System.Drawing.Size(249, 26);
            this.revoluçõesLiberaisToolStripMenuItem.Text = "Revoluções Liberais";
            this.revoluçõesLiberaisToolStripMenuItem.Click += new System.EventHandler(this.revoluçõesLiberaisToolStripMenuItem_Click);
            // 
            // revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem
            // 
            this.revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.primeiraFaseToolStripMenuItem,
            this.segundaRevoluçãoIndustrialToolStripMenuItem,
            this.doutrinasDoSéculoXIXToolStripMenuItem});
            this.revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem.Name = "revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem";
            this.revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem.Text = "Revolução Industrial e Ideias Sociais do Século XIX";
            // 
            // primeiraFaseToolStripMenuItem
            // 
            this.primeiraFaseToolStripMenuItem.Name = "primeiraFaseToolStripMenuItem";
            this.primeiraFaseToolStripMenuItem.Size = new System.Drawing.Size(296, 26);
            this.primeiraFaseToolStripMenuItem.Text = "Primeira Revolução Industria";
            this.primeiraFaseToolStripMenuItem.Click += new System.EventHandler(this.primeiraFaseToolStripMenuItem_Click);
            // 
            // segundaRevoluçãoIndustrialToolStripMenuItem
            // 
            this.segundaRevoluçãoIndustrialToolStripMenuItem.Name = "segundaRevoluçãoIndustrialToolStripMenuItem";
            this.segundaRevoluçãoIndustrialToolStripMenuItem.Size = new System.Drawing.Size(296, 26);
            this.segundaRevoluçãoIndustrialToolStripMenuItem.Text = "Segunda Revolução Industrial";
            this.segundaRevoluçãoIndustrialToolStripMenuItem.Click += new System.EventHandler(this.segundaRevoluçãoIndustrialToolStripMenuItem_Click);
            // 
            // doutrinasDoSéculoXIXToolStripMenuItem
            // 
            this.doutrinasDoSéculoXIXToolStripMenuItem.Name = "doutrinasDoSéculoXIXToolStripMenuItem";
            this.doutrinasDoSéculoXIXToolStripMenuItem.Size = new System.Drawing.Size(296, 26);
            this.doutrinasDoSéculoXIXToolStripMenuItem.Text = "Doutrinas do Século XIX";
            this.doutrinasDoSéculoXIXToolStripMenuItem.Click += new System.EventHandler(this.doutrinasDoSéculoXIXToolStripMenuItem_Click);
            // 
            // imperialismoEPrimeiraGuerraMundialToolStripMenuItem
            // 
            this.imperialismoEPrimeiraGuerraMundialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.imperialismoNeocolonialismoToolStripMenuItem,
            this.áfricaToolStripMenuItem,
            this.eurocentrismoToolStripMenuItem,
            this.primeiraGuerraMundialToolStripMenuItem,
            this.primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem});
            this.imperialismoEPrimeiraGuerraMundialToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.imperialismoEPrimeiraGuerraMundialToolStripMenuItem.Name = "imperialismoEPrimeiraGuerraMundialToolStripMenuItem";
            this.imperialismoEPrimeiraGuerraMundialToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.imperialismoEPrimeiraGuerraMundialToolStripMenuItem.Text = "Imperialismo e Primeira Guerra Mundial";
            // 
            // imperialismoNeocolonialismoToolStripMenuItem
            // 
            this.imperialismoNeocolonialismoToolStripMenuItem.Name = "imperialismoNeocolonialismoToolStripMenuItem";
            this.imperialismoNeocolonialismoToolStripMenuItem.Size = new System.Drawing.Size(424, 26);
            this.imperialismoNeocolonialismoToolStripMenuItem.Text = "Imperialismo / Neocolonialismo";
            this.imperialismoNeocolonialismoToolStripMenuItem.Click += new System.EventHandler(this.imperialismoNeocolonialismoToolStripMenuItem_Click);
            // 
            // áfricaToolStripMenuItem
            // 
            this.áfricaToolStripMenuItem.Name = "áfricaToolStripMenuItem";
            this.áfricaToolStripMenuItem.Size = new System.Drawing.Size(424, 26);
            this.áfricaToolStripMenuItem.Text = "África";
            this.áfricaToolStripMenuItem.Click += new System.EventHandler(this.áfricaToolStripMenuItem_Click);
            // 
            // eurocentrismoToolStripMenuItem
            // 
            this.eurocentrismoToolStripMenuItem.Name = "eurocentrismoToolStripMenuItem";
            this.eurocentrismoToolStripMenuItem.Size = new System.Drawing.Size(424, 26);
            this.eurocentrismoToolStripMenuItem.Text = "Eurocentrismo";
            this.eurocentrismoToolStripMenuItem.Click += new System.EventHandler(this.eurocentrismoToolStripMenuItem_Click);
            // 
            // primeiraGuerraMundialToolStripMenuItem
            // 
            this.primeiraGuerraMundialToolStripMenuItem.Name = "primeiraGuerraMundialToolStripMenuItem";
            this.primeiraGuerraMundialToolStripMenuItem.Size = new System.Drawing.Size(424, 26);
            this.primeiraGuerraMundialToolStripMenuItem.Text = "Primeira Guerra Mundial";
            this.primeiraGuerraMundialToolStripMenuItem.Click += new System.EventHandler(this.primeiraGuerraMundialToolStripMenuItem_Click);
            // 
            // primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem
            // 
            this.primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem.Name = "primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem";
            this.primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem.Size = new System.Drawing.Size(424, 26);
            this.primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem.Text = "Primeira Guerra Mundial: participação brasileira";
            this.primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem.Click += new System.EventHandler(this.primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem_Click);
            // 
            // períodoEntreGuerrasToolStripMenuItem
            // 
            this.períodoEntreGuerrasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem,
            this.tratadoDeVersalhesToolStripMenuItem,
            this.revoluçãoRussaIToolStripMenuItem,
            this.revoluçãoRussaIIToolStripMenuItem,
            this.trotskyXStalinToolStripMenuItem,
            this.criseDe1929ToolStripMenuItem1,
            this.regimesTotalitáriosToolStripMenuItem,
            this.fascismoItalianoToolStripMenuItem,
            this.históriaNazismoAlemãoIToolStripMenuItem,
            this.históriaNazismoAlemãoIIToolStripMenuItem});
            this.períodoEntreGuerrasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.períodoEntreGuerrasToolStripMenuItem.Name = "períodoEntreGuerrasToolStripMenuItem";
            this.períodoEntreGuerrasToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.períodoEntreGuerrasToolStripMenuItem.Text = "Período entre Guerras";
            // 
            // introduçãoToolStripMenuItem
            // 
            this.introduçãoToolStripMenuItem.Name = "introduçãoToolStripMenuItem";
            this.introduçãoToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.introduçãoToolStripMenuItem.Text = "Introdução";
            this.introduçãoToolStripMenuItem.Click += new System.EventHandler(this.introduçãoToolStripMenuItem_Click);
            // 
            // tratadoDeVersalhesToolStripMenuItem
            // 
            this.tratadoDeVersalhesToolStripMenuItem.Name = "tratadoDeVersalhesToolStripMenuItem";
            this.tratadoDeVersalhesToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.tratadoDeVersalhesToolStripMenuItem.Text = "Tratado de Versalhes";
            this.tratadoDeVersalhesToolStripMenuItem.Click += new System.EventHandler(this.tratadoDeVersalhesToolStripMenuItem_Click);
            // 
            // revoluçãoRussaIToolStripMenuItem
            // 
            this.revoluçãoRussaIToolStripMenuItem.Name = "revoluçãoRussaIToolStripMenuItem";
            this.revoluçãoRussaIToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.revoluçãoRussaIToolStripMenuItem.Text = "Revolução Russa I";
            this.revoluçãoRussaIToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoRussaIToolStripMenuItem_Click);
            // 
            // revoluçãoRussaIIToolStripMenuItem
            // 
            this.revoluçãoRussaIIToolStripMenuItem.Name = "revoluçãoRussaIIToolStripMenuItem";
            this.revoluçãoRussaIIToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.revoluçãoRussaIIToolStripMenuItem.Text = "Revolução Russa II";
            this.revoluçãoRussaIIToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoRussaIIToolStripMenuItem_Click);
            // 
            // trotskyXStalinToolStripMenuItem
            // 
            this.trotskyXStalinToolStripMenuItem.Name = "trotskyXStalinToolStripMenuItem";
            this.trotskyXStalinToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.trotskyXStalinToolStripMenuItem.Text = "Trotsky X Stalin";
            this.trotskyXStalinToolStripMenuItem.Click += new System.EventHandler(this.trotskyXStalinToolStripMenuItem_Click);
            // 
            // criseDe1929ToolStripMenuItem1
            // 
            this.criseDe1929ToolStripMenuItem1.Name = "criseDe1929ToolStripMenuItem1";
            this.criseDe1929ToolStripMenuItem1.Size = new System.Drawing.Size(278, 26);
            this.criseDe1929ToolStripMenuItem1.Text = "Crise de 1929";
            this.criseDe1929ToolStripMenuItem1.Click += new System.EventHandler(this.criseDe1929ToolStripMenuItem1_Click);
            // 
            // regimesTotalitáriosToolStripMenuItem
            // 
            this.regimesTotalitáriosToolStripMenuItem.Name = "regimesTotalitáriosToolStripMenuItem";
            this.regimesTotalitáriosToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.regimesTotalitáriosToolStripMenuItem.Text = "Regimes Totalitários";
            this.regimesTotalitáriosToolStripMenuItem.Click += new System.EventHandler(this.regimesTotalitáriosToolStripMenuItem_Click);
            // 
            // fascismoItalianoToolStripMenuItem
            // 
            this.fascismoItalianoToolStripMenuItem.Name = "fascismoItalianoToolStripMenuItem";
            this.fascismoItalianoToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.fascismoItalianoToolStripMenuItem.Text = "Fascismo Italiano";
            this.fascismoItalianoToolStripMenuItem.Click += new System.EventHandler(this.fascismoItalianoToolStripMenuItem_Click);
            // 
            // históriaNazismoAlemãoIToolStripMenuItem
            // 
            this.históriaNazismoAlemãoIToolStripMenuItem.Name = "históriaNazismoAlemãoIToolStripMenuItem";
            this.históriaNazismoAlemãoIToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.históriaNazismoAlemãoIToolStripMenuItem.Text = "História: Nazismo alemão I";
            this.históriaNazismoAlemãoIToolStripMenuItem.Click += new System.EventHandler(this.históriaNazismoAlemãoIToolStripMenuItem_Click);
            // 
            // históriaNazismoAlemãoIIToolStripMenuItem
            // 
            this.históriaNazismoAlemãoIIToolStripMenuItem.Name = "históriaNazismoAlemãoIIToolStripMenuItem";
            this.históriaNazismoAlemãoIIToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.históriaNazismoAlemãoIIToolStripMenuItem.Text = "História: Nazismo alemão II";
            this.históriaNazismoAlemãoIIToolStripMenuItem.Click += new System.EventHandler(this.históriaNazismoAlemãoIIToolStripMenuItem_Click);
            // 
            // segundaGuerraMundialToolStripMenuItem
            // 
            this.segundaGuerraMundialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parteIToolStripMenuItem,
            this.parteIIToolStripMenuItem});
            this.segundaGuerraMundialToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.segundaGuerraMundialToolStripMenuItem.Name = "segundaGuerraMundialToolStripMenuItem";
            this.segundaGuerraMundialToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.segundaGuerraMundialToolStripMenuItem.Text = "Segunda Guerra Mundial";
            // 
            // parteIToolStripMenuItem
            // 
            this.parteIToolStripMenuItem.Name = "parteIToolStripMenuItem";
            this.parteIToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.parteIToolStripMenuItem.Text = "Parte I";
            this.parteIToolStripMenuItem.Click += new System.EventHandler(this.parteIToolStripMenuItem_Click);
            // 
            // parteIIToolStripMenuItem
            // 
            this.parteIIToolStripMenuItem.Name = "parteIIToolStripMenuItem";
            this.parteIIToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.parteIIToolStripMenuItem.Text = "Parte II";
            this.parteIIToolStripMenuItem.Click += new System.EventHandler(this.parteIIToolStripMenuItem_Click);
            // 
            // guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem
            // 
            this.guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoÀGuerraFriaToolStripMenuItem,
            this.conflitosToolStripMenuItem,
            this.descolonizaçãoDaÁfricaToolStripMenuItem,
            this.revoluçãoChinesaToolStripMenuItem,
            this.guerrasDaCoreiaEVietnãToolStripMenuItem,
            this.conflitosNoOrienteMédioToolStripMenuItem,
            this.uRSSESeusEstadistasToolStripMenuItem,
            this.quedaDoMuroDeBerlimToolStripMenuItem,
            this.oBrasilNaGuerraFriaToolStripMenuItem,
            this.quedaDaURSSToolStripMenuItem,
            this.direitosHumanosToolStripMenuItem});
            this.guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem.Name = "guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem";
            this.guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem.Text = "Guerra Fria e Descolonização Afro Asiática";
            // 
            // introduçãoÀGuerraFriaToolStripMenuItem
            // 
            this.introduçãoÀGuerraFriaToolStripMenuItem.Name = "introduçãoÀGuerraFriaToolStripMenuItem";
            this.introduçãoÀGuerraFriaToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.introduçãoÀGuerraFriaToolStripMenuItem.Text = "Introdução à Guerra Fria";
            this.introduçãoÀGuerraFriaToolStripMenuItem.Click += new System.EventHandler(this.introduçãoÀGuerraFriaToolStripMenuItem_Click);
            // 
            // conflitosToolStripMenuItem
            // 
            this.conflitosToolStripMenuItem.Name = "conflitosToolStripMenuItem";
            this.conflitosToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.conflitosToolStripMenuItem.Text = "Conflitos";
            this.conflitosToolStripMenuItem.Click += new System.EventHandler(this.conflitosToolStripMenuItem_Click);
            // 
            // descolonizaçãoDaÁfricaToolStripMenuItem
            // 
            this.descolonizaçãoDaÁfricaToolStripMenuItem.Name = "descolonizaçãoDaÁfricaToolStripMenuItem";
            this.descolonizaçãoDaÁfricaToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.descolonizaçãoDaÁfricaToolStripMenuItem.Text = "Descolonização da África";
            this.descolonizaçãoDaÁfricaToolStripMenuItem.Click += new System.EventHandler(this.descolonizaçãoDaÁfricaToolStripMenuItem_Click);
            // 
            // revoluçãoChinesaToolStripMenuItem
            // 
            this.revoluçãoChinesaToolStripMenuItem.Name = "revoluçãoChinesaToolStripMenuItem";
            this.revoluçãoChinesaToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.revoluçãoChinesaToolStripMenuItem.Text = "Revolução Chinesa";
            this.revoluçãoChinesaToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoChinesaToolStripMenuItem_Click);
            // 
            // guerrasDaCoreiaEVietnãToolStripMenuItem
            // 
            this.guerrasDaCoreiaEVietnãToolStripMenuItem.Name = "guerrasDaCoreiaEVietnãToolStripMenuItem";
            this.guerrasDaCoreiaEVietnãToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.guerrasDaCoreiaEVietnãToolStripMenuItem.Text = "Guerras da Coreia e Vietnã";
            this.guerrasDaCoreiaEVietnãToolStripMenuItem.Click += new System.EventHandler(this.guerrasDaCoreiaEVietnãToolStripMenuItem_Click);
            // 
            // conflitosNoOrienteMédioToolStripMenuItem
            // 
            this.conflitosNoOrienteMédioToolStripMenuItem.Name = "conflitosNoOrienteMédioToolStripMenuItem";
            this.conflitosNoOrienteMédioToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.conflitosNoOrienteMédioToolStripMenuItem.Text = "Conflitos no Oriente Médio";
            this.conflitosNoOrienteMédioToolStripMenuItem.Click += new System.EventHandler(this.conflitosNoOrienteMédioToolStripMenuItem_Click);
            // 
            // uRSSESeusEstadistasToolStripMenuItem
            // 
            this.uRSSESeusEstadistasToolStripMenuItem.Name = "uRSSESeusEstadistasToolStripMenuItem";
            this.uRSSESeusEstadistasToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.uRSSESeusEstadistasToolStripMenuItem.Text = "URSS e seus estadistas";
            this.uRSSESeusEstadistasToolStripMenuItem.Click += new System.EventHandler(this.uRSSESeusEstadistasToolStripMenuItem_Click);
            // 
            // quedaDoMuroDeBerlimToolStripMenuItem
            // 
            this.quedaDoMuroDeBerlimToolStripMenuItem.Name = "quedaDoMuroDeBerlimToolStripMenuItem";
            this.quedaDoMuroDeBerlimToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.quedaDoMuroDeBerlimToolStripMenuItem.Text = "Queda do muro de Berlim";
            this.quedaDoMuroDeBerlimToolStripMenuItem.Click += new System.EventHandler(this.quedaDoMuroDeBerlimToolStripMenuItem_Click);
            // 
            // oBrasilNaGuerraFriaToolStripMenuItem
            // 
            this.oBrasilNaGuerraFriaToolStripMenuItem.Name = "oBrasilNaGuerraFriaToolStripMenuItem";
            this.oBrasilNaGuerraFriaToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.oBrasilNaGuerraFriaToolStripMenuItem.Text = "O Brasil na Guerra Fria";
            this.oBrasilNaGuerraFriaToolStripMenuItem.Click += new System.EventHandler(this.oBrasilNaGuerraFriaToolStripMenuItem_Click);
            // 
            // quedaDaURSSToolStripMenuItem
            // 
            this.quedaDaURSSToolStripMenuItem.Name = "quedaDaURSSToolStripMenuItem";
            this.quedaDaURSSToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.quedaDaURSSToolStripMenuItem.Text = "Queda da URSS";
            this.quedaDaURSSToolStripMenuItem.Click += new System.EventHandler(this.quedaDaURSSToolStripMenuItem_Click);
            // 
            // direitosHumanosToolStripMenuItem
            // 
            this.direitosHumanosToolStripMenuItem.Name = "direitosHumanosToolStripMenuItem";
            this.direitosHumanosToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.direitosHumanosToolStripMenuItem.Text = "Direitos Humanos";
            this.direitosHumanosToolStripMenuItem.Click += new System.EventHandler(this.direitosHumanosToolStripMenuItem_Click);
            // 
            // mundoAtualToolStripMenuItem
            // 
            this.mundoAtualToolStripMenuItem.Name = "mundoAtualToolStripMenuItem";
            this.mundoAtualToolStripMenuItem.Size = new System.Drawing.Size(451, 26);
            this.mundoAtualToolStripMenuItem.Text = "Mundo Atual";
            this.mundoAtualToolStripMenuItem.Click += new System.EventHandler(this.mundoAtualToolStripMenuItem_Click);
            // 
            // históriaDaAméricaToolStripMenuItem1
            // 
            this.históriaDaAméricaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem,
            this.aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem,
            this.colonizaçãoEspanholaToolStripMenuItem,
            this.colonizaçãoInglesaToolStripMenuItem,
            this.construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem,
            this.estaodsUnidosNoSéculoXIXToolStripMenuItem,
            this.criseDe1929ToolStripMenuItem,
            this.estadosUnidosPósSegundaGuerraMundialToolStripMenuItem,
            this.regimesMilitaresETransiçãoDemocráticaToolStripMenuItem,
            this.aRevoluçãoCubanaToolStripMenuItem,
            this.aRevoluçãoMexicanaToolStripMenuItem,
            this.revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem,
            this.independênciaDaAméricaLatinaToolStripMenuItem,
            this.estadosNacionaisLatinosToolStripMenuItem,
            this.populismoNaAméricaToolStripMenuItem,
            this.américaAtualToolStripMenuItem});
            this.históriaDaAméricaToolStripMenuItem1.Name = "históriaDaAméricaToolStripMenuItem1";
            this.históriaDaAméricaToolStripMenuItem1.Size = new System.Drawing.Size(223, 26);
            this.históriaDaAméricaToolStripMenuItem1.Text = "História da América";
            // 
            // expansãoMarítimaEComercialEuropeiaToolStripMenuItem
            // 
            this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem.Name = "expansãoMarítimaEComercialEuropeiaToolStripMenuItem";
            this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem.Text = "Expansão Marítima e Comercial Europeia";
            this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem.Click += new System.EventHandler(this.expansãoMarítimaEComercialEuropeiaToolStripMenuItem_Click);
            // 
            // aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem
            // 
            this.aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conquistaDaAméricaToolStripMenuItem,
            this.maiasToolStripMenuItem,
            this.aSTECASToolStripMenuItem,
            this.incasToolStripMenuItem});
            this.aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem.Name = "aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem";
            this.aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem.Text = "A Conquista da América e os Povos Pré-Colombianos";
            // 
            // conquistaDaAméricaToolStripMenuItem
            // 
            this.conquistaDaAméricaToolStripMenuItem.Name = "conquistaDaAméricaToolStripMenuItem";
            this.conquistaDaAméricaToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.conquistaDaAméricaToolStripMenuItem.Text = "Conquista da América";
            this.conquistaDaAméricaToolStripMenuItem.Click += new System.EventHandler(this.conquistaDaAméricaToolStripMenuItem_Click);
            // 
            // maiasToolStripMenuItem
            // 
            this.maiasToolStripMenuItem.Name = "maiasToolStripMenuItem";
            this.maiasToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.maiasToolStripMenuItem.Text = "Maias";
            this.maiasToolStripMenuItem.Click += new System.EventHandler(this.maiasToolStripMenuItem_Click);
            // 
            // aSTECASToolStripMenuItem
            // 
            this.aSTECASToolStripMenuItem.Name = "aSTECASToolStripMenuItem";
            this.aSTECASToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.aSTECASToolStripMenuItem.Text = "Astecas";
            this.aSTECASToolStripMenuItem.Click += new System.EventHandler(this.aSTECASToolStripMenuItem_Click);
            // 
            // incasToolStripMenuItem
            // 
            this.incasToolStripMenuItem.Name = "incasToolStripMenuItem";
            this.incasToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.incasToolStripMenuItem.Text = "Incas";
            this.incasToolStripMenuItem.Click += new System.EventHandler(this.incasToolStripMenuItem_Click);
            // 
            // colonizaçãoEspanholaToolStripMenuItem
            // 
            this.colonizaçãoEspanholaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.colonizaçãoEspanholaToolStripMenuItem.Name = "colonizaçãoEspanholaToolStripMenuItem";
            this.colonizaçãoEspanholaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.colonizaçãoEspanholaToolStripMenuItem.Text = "Colonização Espanhola";
            this.colonizaçãoEspanholaToolStripMenuItem.Click += new System.EventHandler(this.colonizaçãoEspanholaToolStripMenuItem_Click);
            // 
            // colonizaçãoInglesaToolStripMenuItem
            // 
            this.colonizaçãoInglesaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.colonizaçãoInglesaToolStripMenuItem.Name = "colonizaçãoInglesaToolStripMenuItem";
            this.colonizaçãoInglesaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.colonizaçãoInglesaToolStripMenuItem.Text = "Colonização Inglesa";
            this.colonizaçãoInglesaToolStripMenuItem.Click += new System.EventHandler(this.colonizaçãoInglesaToolStripMenuItem_Click);
            // 
            // construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem
            // 
            this.construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revoluçãoAmericanaToolStripMenuItem,
            this.expansãoDosEUAToolStripMenuItem});
            this.construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem.Name = "construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem";
            this.construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem.Text = "Construção do Estado Norte Americano: A Independência das Treze Colônias";
            // 
            // revoluçãoAmericanaToolStripMenuItem
            // 
            this.revoluçãoAmericanaToolStripMenuItem.Name = "revoluçãoAmericanaToolStripMenuItem";
            this.revoluçãoAmericanaToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.revoluçãoAmericanaToolStripMenuItem.Text = "Revolução Americana";
            this.revoluçãoAmericanaToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoAmericanaToolStripMenuItem_Click);
            // 
            // expansãoDosEUAToolStripMenuItem
            // 
            this.expansãoDosEUAToolStripMenuItem.Name = "expansãoDosEUAToolStripMenuItem";
            this.expansãoDosEUAToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.expansãoDosEUAToolStripMenuItem.Text = "Expansão dos EUA";
            this.expansãoDosEUAToolStripMenuItem.Click += new System.EventHandler(this.expansãoDosEUAToolStripMenuItem_Click);
            // 
            // estaodsUnidosNoSéculoXIXToolStripMenuItem
            // 
            this.estaodsUnidosNoSéculoXIXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.guerraDeSecessãoToolStripMenuItem,
            this.estadosUnidosNoSéculoXIXToolStripMenuItem});
            this.estaodsUnidosNoSéculoXIXToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.estaodsUnidosNoSéculoXIXToolStripMenuItem.Name = "estaodsUnidosNoSéculoXIXToolStripMenuItem";
            this.estaodsUnidosNoSéculoXIXToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.estaodsUnidosNoSéculoXIXToolStripMenuItem.Text = "Estados Unidos no Século XIX";
            // 
            // guerraDeSecessãoToolStripMenuItem
            // 
            this.guerraDeSecessãoToolStripMenuItem.Name = "guerraDeSecessãoToolStripMenuItem";
            this.guerraDeSecessãoToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.guerraDeSecessãoToolStripMenuItem.Text = "Guerra de Secessão";
            this.guerraDeSecessãoToolStripMenuItem.Click += new System.EventHandler(this.guerraDeSecessãoToolStripMenuItem_Click);
            // 
            // estadosUnidosNoSéculoXIXToolStripMenuItem
            // 
            this.estadosUnidosNoSéculoXIXToolStripMenuItem.Name = "estadosUnidosNoSéculoXIXToolStripMenuItem";
            this.estadosUnidosNoSéculoXIXToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.estadosUnidosNoSéculoXIXToolStripMenuItem.Text = "Estados Unidos no século XIX";
            this.estadosUnidosNoSéculoXIXToolStripMenuItem.Click += new System.EventHandler(this.estadosUnidosNoSéculoXIXToolStripMenuItem_Click);
            // 
            // criseDe1929ToolStripMenuItem
            // 
            this.criseDe1929ToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.criseDe1929ToolStripMenuItem.Name = "criseDe1929ToolStripMenuItem";
            this.criseDe1929ToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.criseDe1929ToolStripMenuItem.Text = "Crise de 1929";
            this.criseDe1929ToolStripMenuItem.Click += new System.EventHandler(this.criseDe1929ToolStripMenuItem_Click);
            // 
            // estadosUnidosPósSegundaGuerraMundialToolStripMenuItem
            // 
            this.estadosUnidosPósSegundaGuerraMundialToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.estadosUnidosPósSegundaGuerraMundialToolStripMenuItem.Name = "estadosUnidosPósSegundaGuerraMundialToolStripMenuItem";
            this.estadosUnidosPósSegundaGuerraMundialToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.estadosUnidosPósSegundaGuerraMundialToolStripMenuItem.Text = "Estados Unidos Pós Segunda Guerra Mundial";
            // 
            // regimesMilitaresETransiçãoDemocráticaToolStripMenuItem
            // 
            this.regimesMilitaresETransiçãoDemocráticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ditadurasDaAMÉRICALATINAToolStripMenuItem});
            this.regimesMilitaresETransiçãoDemocráticaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.regimesMilitaresETransiçãoDemocráticaToolStripMenuItem.Name = "regimesMilitaresETransiçãoDemocráticaToolStripMenuItem";
            this.regimesMilitaresETransiçãoDemocráticaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.regimesMilitaresETransiçãoDemocráticaToolStripMenuItem.Text = "Regimes Militares e Transição Democrática";
            // 
            // ditadurasDaAMÉRICALATINAToolStripMenuItem
            // 
            this.ditadurasDaAMÉRICALATINAToolStripMenuItem.Name = "ditadurasDaAMÉRICALATINAToolStripMenuItem";
            this.ditadurasDaAMÉRICALATINAToolStripMenuItem.Size = new System.Drawing.Size(304, 26);
            this.ditadurasDaAMÉRICALATINAToolStripMenuItem.Text = "Ditaduras da AMÉRICA LATINA";
            this.ditadurasDaAMÉRICALATINAToolStripMenuItem.Click += new System.EventHandler(this.ditadurasDaAMÉRICALATINAToolStripMenuItem_Click);
            // 
            // aRevoluçãoCubanaToolStripMenuItem
            // 
            this.aRevoluçãoCubanaToolStripMenuItem.Name = "aRevoluçãoCubanaToolStripMenuItem";
            this.aRevoluçãoCubanaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.aRevoluçãoCubanaToolStripMenuItem.Text = "A Revolução Cubana";
            this.aRevoluçãoCubanaToolStripMenuItem.Click += new System.EventHandler(this.aRevoluçãoCubanaToolStripMenuItem_Click);
            // 
            // aRevoluçãoMexicanaToolStripMenuItem
            // 
            this.aRevoluçãoMexicanaToolStripMenuItem.Name = "aRevoluçãoMexicanaToolStripMenuItem";
            this.aRevoluçãoMexicanaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.aRevoluçãoMexicanaToolStripMenuItem.Text = "A Revolução Mexicana";
            this.aRevoluçãoMexicanaToolStripMenuItem.Click += new System.EventHandler(this.aRevoluçãoMexicanaToolStripMenuItem_Click);
            // 
            // revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem
            // 
            this.revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem.Name = "revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem";
            this.revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem.Text = "Revoluções na América Latina – Chile e Nicarágua";
            this.revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem.Click += new System.EventHandler(this.revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem_Click);
            // 
            // independênciaDaAméricaLatinaToolStripMenuItem
            // 
            this.independênciaDaAméricaLatinaToolStripMenuItem.Name = "independênciaDaAméricaLatinaToolStripMenuItem";
            this.independênciaDaAméricaLatinaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.independênciaDaAméricaLatinaToolStripMenuItem.Text = "Independência da América Latina";
            this.independênciaDaAméricaLatinaToolStripMenuItem.Click += new System.EventHandler(this.independênciaDaAméricaLatinaToolStripMenuItem_Click);
            // 
            // estadosNacionaisLatinosToolStripMenuItem
            // 
            this.estadosNacionaisLatinosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formaçãoDosEstadosNacionaisIToolStripMenuItem,
            this.formaçãoDosEstadosNacionaisIIToolStripMenuItem});
            this.estadosNacionaisLatinosToolStripMenuItem.Name = "estadosNacionaisLatinosToolStripMenuItem";
            this.estadosNacionaisLatinosToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.estadosNacionaisLatinosToolStripMenuItem.Text = "Estados Nacionais Latinos";
            // 
            // formaçãoDosEstadosNacionaisIToolStripMenuItem
            // 
            this.formaçãoDosEstadosNacionaisIToolStripMenuItem.Name = "formaçãoDosEstadosNacionaisIToolStripMenuItem";
            this.formaçãoDosEstadosNacionaisIToolStripMenuItem.Size = new System.Drawing.Size(331, 26);
            this.formaçãoDosEstadosNacionaisIToolStripMenuItem.Text = "Formação dos Estados Nacionais I";
            this.formaçãoDosEstadosNacionaisIToolStripMenuItem.Click += new System.EventHandler(this.formaçãoDosEstadosNacionaisIToolStripMenuItem_Click);
            // 
            // formaçãoDosEstadosNacionaisIIToolStripMenuItem
            // 
            this.formaçãoDosEstadosNacionaisIIToolStripMenuItem.Name = "formaçãoDosEstadosNacionaisIIToolStripMenuItem";
            this.formaçãoDosEstadosNacionaisIIToolStripMenuItem.Size = new System.Drawing.Size(331, 26);
            this.formaçãoDosEstadosNacionaisIIToolStripMenuItem.Text = "Formação dos Estados Nacionais II";
            this.formaçãoDosEstadosNacionaisIIToolStripMenuItem.Click += new System.EventHandler(this.formaçãoDosEstadosNacionaisIIToolStripMenuItem_Click);
            // 
            // populismoNaAméricaToolStripMenuItem
            // 
            this.populismoNaAméricaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.populismoNaAméricaToolStripMenuItem.Name = "populismoNaAméricaToolStripMenuItem";
            this.populismoNaAméricaToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.populismoNaAméricaToolStripMenuItem.Text = "Populismo na América";
            this.populismoNaAméricaToolStripMenuItem.Click += new System.EventHandler(this.populismoNaAméricaToolStripMenuItem_Click);
            // 
            // américaAtualToolStripMenuItem
            // 
            this.américaAtualToolStripMenuItem.Name = "américaAtualToolStripMenuItem";
            this.américaAtualToolStripMenuItem.Size = new System.Drawing.Size(640, 26);
            this.américaAtualToolStripMenuItem.Text = "América Atual";
            // 
            // históriaDoBrasilToolStripMenuItem1
            // 
            this.históriaDoBrasilToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.préHistóriaNoBrasilToolStripMenuItem,
            this.aMontagemDoSistemaColonialNoBrasilToolStripMenuItem,
            this.aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem,
            this.aCriseDoSistemaColonialToolStripMenuItem,
            this.períodoJoaninoIToolStripMenuItem,
            this.primeiroReinadoToolStripMenuItem,
            this.períodoRegencialToolStripMenuItem,
            this.segundoReinadoToolStripMenuItem,
            this.aCriseDoSegundoReinadoToolStripMenuItem,
            this.oProcessoDeIndependênciaToolStripMenuItem,
            this.aReúblicaVelhaToolStripMenuItem,
            this.aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem,
            this.eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem,
            this.eraVargasEstadoNovo19371945ToolStripMenuItem,
            this.períodoDemocrático19451964ToolStripMenuItem,
            this.movimentoDaLegalidadeToolStripMenuItem,
            this.regimeMilitarToolStripMenuItem,
            this.diretasJáToolStripMenuItem,
            this.aNovaReplúblicaToolStripMenuItem});
            this.históriaDoBrasilToolStripMenuItem1.Name = "históriaDoBrasilToolStripMenuItem1";
            this.históriaDoBrasilToolStripMenuItem1.Size = new System.Drawing.Size(223, 26);
            this.históriaDoBrasilToolStripMenuItem1.Text = "História do Brasil";
            // 
            // préHistóriaNoBrasilToolStripMenuItem
            // 
            this.préHistóriaNoBrasilToolStripMenuItem.Name = "préHistóriaNoBrasilToolStripMenuItem";
            this.préHistóriaNoBrasilToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.préHistóriaNoBrasilToolStripMenuItem.Text = "Pré-História no Brasil";
            this.préHistóriaNoBrasilToolStripMenuItem.Click += new System.EventHandler(this.préHistóriaNoBrasilToolStripMenuItem_Click);
            // 
            // aMontagemDoSistemaColonialNoBrasilToolStripMenuItem
            // 
            this.aMontagemDoSistemaColonialNoBrasilToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.descobrimentoDoBrasilToolStripMenuItem,
            this.períodoPréColonialToolStripMenuItem});
            this.aMontagemDoSistemaColonialNoBrasilToolStripMenuItem.Name = "aMontagemDoSistemaColonialNoBrasilToolStripMenuItem";
            this.aMontagemDoSistemaColonialNoBrasilToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.aMontagemDoSistemaColonialNoBrasilToolStripMenuItem.Text = "A Montagem do Sistema Colonial no Brasil";
            // 
            // descobrimentoDoBrasilToolStripMenuItem
            // 
            this.descobrimentoDoBrasilToolStripMenuItem.Name = "descobrimentoDoBrasilToolStripMenuItem";
            this.descobrimentoDoBrasilToolStripMenuItem.Size = new System.Drawing.Size(260, 26);
            this.descobrimentoDoBrasilToolStripMenuItem.Text = "Descobrimento do Brasil";
            this.descobrimentoDoBrasilToolStripMenuItem.Click += new System.EventHandler(this.descobrimentoDoBrasilToolStripMenuItem_Click);
            // 
            // períodoPréColonialToolStripMenuItem
            // 
            this.períodoPréColonialToolStripMenuItem.Name = "períodoPréColonialToolStripMenuItem";
            this.períodoPréColonialToolStripMenuItem.Size = new System.Drawing.Size(260, 26);
            this.períodoPréColonialToolStripMenuItem.Text = "Período Pré- colonial";
            this.períodoPréColonialToolStripMenuItem.Click += new System.EventHandler(this.períodoPréColonialToolStripMenuItem_Click);
            // 
            // aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem
            // 
            this.aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ciclosEconômicosToolStripMenuItem,
            this.capitaniasHereditáriasToolStripMenuItem,
            this.governosGeraisToolStripMenuItem,
            this.economiaDoAçúcarColonialToolStripMenuItem,
            this.uniãoIbéricaToolStripMenuItem,
            this.presençaHolandesaToolStripMenuItem,
            this.economiaMineradoraToolStripMenuItem,
            this.escravidãoNoBrasilToolStripMenuItem,
            this.sociedadesQuilombolasToolStripMenuItem,
            this.bandeirantismoToolStripMenuItem});
            this.aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem.Name = "aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem";
            this.aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem.Text = "A Administração Colonial e a Expansão Territorial";
            // 
            // ciclosEconômicosToolStripMenuItem
            // 
            this.ciclosEconômicosToolStripMenuItem.Name = "ciclosEconômicosToolStripMenuItem";
            this.ciclosEconômicosToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.ciclosEconômicosToolStripMenuItem.Text = "Ciclos Econômicos";
            this.ciclosEconômicosToolStripMenuItem.Click += new System.EventHandler(this.ciclosEconômicosToolStripMenuItem_Click);
            // 
            // capitaniasHereditáriasToolStripMenuItem
            // 
            this.capitaniasHereditáriasToolStripMenuItem.Name = "capitaniasHereditáriasToolStripMenuItem";
            this.capitaniasHereditáriasToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.capitaniasHereditáriasToolStripMenuItem.Text = "Capitanias Hereditárias";
            this.capitaniasHereditáriasToolStripMenuItem.Click += new System.EventHandler(this.capitaniasHereditáriasToolStripMenuItem_Click);
            // 
            // governosGeraisToolStripMenuItem
            // 
            this.governosGeraisToolStripMenuItem.Name = "governosGeraisToolStripMenuItem";
            this.governosGeraisToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.governosGeraisToolStripMenuItem.Text = "Governos Gerais";
            this.governosGeraisToolStripMenuItem.Click += new System.EventHandler(this.governosGeraisToolStripMenuItem_Click);
            // 
            // economiaDoAçúcarColonialToolStripMenuItem
            // 
            this.economiaDoAçúcarColonialToolStripMenuItem.Name = "economiaDoAçúcarColonialToolStripMenuItem";
            this.economiaDoAçúcarColonialToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.economiaDoAçúcarColonialToolStripMenuItem.Text = "Economia do açúcar colonial";
            this.economiaDoAçúcarColonialToolStripMenuItem.Click += new System.EventHandler(this.economiaDoAçúcarColonialToolStripMenuItem_Click);
            // 
            // uniãoIbéricaToolStripMenuItem
            // 
            this.uniãoIbéricaToolStripMenuItem.Name = "uniãoIbéricaToolStripMenuItem";
            this.uniãoIbéricaToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.uniãoIbéricaToolStripMenuItem.Text = "União Ibérica";
            this.uniãoIbéricaToolStripMenuItem.Click += new System.EventHandler(this.uniãoIbéricaToolStripMenuItem_Click);
            // 
            // presençaHolandesaToolStripMenuItem
            // 
            this.presençaHolandesaToolStripMenuItem.Name = "presençaHolandesaToolStripMenuItem";
            this.presençaHolandesaToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.presençaHolandesaToolStripMenuItem.Text = "Presença Holandesa";
            this.presençaHolandesaToolStripMenuItem.Click += new System.EventHandler(this.presençaHolandesaToolStripMenuItem_Click);
            // 
            // economiaMineradoraToolStripMenuItem
            // 
            this.economiaMineradoraToolStripMenuItem.Name = "economiaMineradoraToolStripMenuItem";
            this.economiaMineradoraToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.economiaMineradoraToolStripMenuItem.Text = "Economia Mineradora";
            this.economiaMineradoraToolStripMenuItem.Click += new System.EventHandler(this.economiaMineradoraToolStripMenuItem_Click);
            // 
            // escravidãoNoBrasilToolStripMenuItem
            // 
            this.escravidãoNoBrasilToolStripMenuItem.Name = "escravidãoNoBrasilToolStripMenuItem";
            this.escravidãoNoBrasilToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.escravidãoNoBrasilToolStripMenuItem.Text = "Escravidão no Brasil";
            this.escravidãoNoBrasilToolStripMenuItem.Click += new System.EventHandler(this.escravidãoNoBrasilToolStripMenuItem_Click);
            // 
            // sociedadesQuilombolasToolStripMenuItem
            // 
            this.sociedadesQuilombolasToolStripMenuItem.Name = "sociedadesQuilombolasToolStripMenuItem";
            this.sociedadesQuilombolasToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.sociedadesQuilombolasToolStripMenuItem.Text = "Sociedades Quilombolas";
            this.sociedadesQuilombolasToolStripMenuItem.Click += new System.EventHandler(this.sociedadesQuilombolasToolStripMenuItem_Click);
            // 
            // bandeirantismoToolStripMenuItem
            // 
            this.bandeirantismoToolStripMenuItem.Name = "bandeirantismoToolStripMenuItem";
            this.bandeirantismoToolStripMenuItem.Size = new System.Drawing.Size(287, 26);
            this.bandeirantismoToolStripMenuItem.Text = "Bandeirantismo";
            this.bandeirantismoToolStripMenuItem.Click += new System.EventHandler(this.bandeirantismoToolStripMenuItem_Click);
            // 
            // aCriseDoSistemaColonialToolStripMenuItem
            // 
            this.aCriseDoSistemaColonialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.criseDoSistemaColonialToolStripMenuItem,
            this.inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem,
            this.inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem,
            this.revisãoDoPeríodoColonialToolStripMenuItem});
            this.aCriseDoSistemaColonialToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aCriseDoSistemaColonialToolStripMenuItem.Name = "aCriseDoSistemaColonialToolStripMenuItem";
            this.aCriseDoSistemaColonialToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.aCriseDoSistemaColonialToolStripMenuItem.Text = "A Crise do Sistema Colonial";
            // 
            // criseDoSistemaColonialToolStripMenuItem
            // 
            this.criseDoSistemaColonialToolStripMenuItem.Name = "criseDoSistemaColonialToolStripMenuItem";
            this.criseDoSistemaColonialToolStripMenuItem.Size = new System.Drawing.Size(402, 26);
            this.criseDoSistemaColonialToolStripMenuItem.Text = "Crise do Sistema Colonial";
            this.criseDoSistemaColonialToolStripMenuItem.Click += new System.EventHandler(this.criseDoSistemaColonialToolStripMenuItem_Click);
            // 
            // inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem
            // 
            this.inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem.Name = "inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem";
            this.inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem.Size = new System.Drawing.Size(402, 26);
            this.inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem.Text = "Inconfidência Mineira e Conjuração Baiana I";
            this.inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem.Click += new System.EventHandler(this.inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem_Click);
            // 
            // inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem
            // 
            this.inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem.Name = "inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem";
            this.inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem.Size = new System.Drawing.Size(402, 26);
            this.inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem.Text = "Inconfidência Mineira e Conjuração Baiana II";
            this.inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem.Click += new System.EventHandler(this.inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem_Click);
            // 
            // revisãoDoPeríodoColonialToolStripMenuItem
            // 
            this.revisãoDoPeríodoColonialToolStripMenuItem.Name = "revisãoDoPeríodoColonialToolStripMenuItem";
            this.revisãoDoPeríodoColonialToolStripMenuItem.Size = new System.Drawing.Size(402, 26);
            this.revisãoDoPeríodoColonialToolStripMenuItem.Text = "Revisão do Período Colonial";
            this.revisãoDoPeríodoColonialToolStripMenuItem.Click += new System.EventHandler(this.revisãoDoPeríodoColonialToolStripMenuItem_Click);
            // 
            // períodoJoaninoIToolStripMenuItem
            // 
            this.períodoJoaninoIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.períodoJoaninoIToolStripMenuItem1,
            this.períodoJoaninoIIToolStripMenuItem});
            this.períodoJoaninoIToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.períodoJoaninoIToolStripMenuItem.Name = "períodoJoaninoIToolStripMenuItem";
            this.períodoJoaninoIToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.períodoJoaninoIToolStripMenuItem.Text = "Período Joanino";
            // 
            // períodoJoaninoIToolStripMenuItem1
            // 
            this.períodoJoaninoIToolStripMenuItem1.Name = "períodoJoaninoIToolStripMenuItem1";
            this.períodoJoaninoIToolStripMenuItem1.Size = new System.Drawing.Size(211, 26);
            this.períodoJoaninoIToolStripMenuItem1.Text = "Período Joanino I";
            this.períodoJoaninoIToolStripMenuItem1.Click += new System.EventHandler(this.períodoJoaninoIToolStripMenuItem1_Click);
            // 
            // períodoJoaninoIIToolStripMenuItem
            // 
            this.períodoJoaninoIIToolStripMenuItem.Name = "períodoJoaninoIIToolStripMenuItem";
            this.períodoJoaninoIIToolStripMenuItem.Size = new System.Drawing.Size(211, 26);
            this.períodoJoaninoIIToolStripMenuItem.Text = "Período Joanino II";
            this.períodoJoaninoIIToolStripMenuItem.Click += new System.EventHandler(this.períodoJoaninoIIToolStripMenuItem_Click);
            // 
            // primeiroReinadoToolStripMenuItem
            // 
            this.primeiroReinadoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.independênciaDoBrasilToolStripMenuItem,
            this.primeiroReinadoToolStripMenuItem1});
            this.primeiroReinadoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.primeiroReinadoToolStripMenuItem.Name = "primeiroReinadoToolStripMenuItem";
            this.primeiroReinadoToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.primeiroReinadoToolStripMenuItem.Text = "Primeiro Reinado";
            // 
            // independênciaDoBrasilToolStripMenuItem
            // 
            this.independênciaDoBrasilToolStripMenuItem.Name = "independênciaDoBrasilToolStripMenuItem";
            this.independênciaDoBrasilToolStripMenuItem.Size = new System.Drawing.Size(256, 26);
            this.independênciaDoBrasilToolStripMenuItem.Text = "Independência do Brasil";
            this.independênciaDoBrasilToolStripMenuItem.Click += new System.EventHandler(this.independênciaDoBrasilToolStripMenuItem_Click);
            // 
            // primeiroReinadoToolStripMenuItem1
            // 
            this.primeiroReinadoToolStripMenuItem1.Name = "primeiroReinadoToolStripMenuItem1";
            this.primeiroReinadoToolStripMenuItem1.Size = new System.Drawing.Size(256, 26);
            this.primeiroReinadoToolStripMenuItem1.Text = "Primeiro Reinado";
            this.primeiroReinadoToolStripMenuItem1.Click += new System.EventHandler(this.primeiroReinadoToolStripMenuItem1_Click);
            // 
            // períodoRegencialToolStripMenuItem
            // 
            this.períodoRegencialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.períodoRegencialParteIToolStripMenuItem,
            this.períodoRegencialParteIIToolStripMenuItem,
            this.revoltaRegenciaisToolStripMenuItem});
            this.períodoRegencialToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.períodoRegencialToolStripMenuItem.Name = "períodoRegencialToolStripMenuItem";
            this.períodoRegencialToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.períodoRegencialToolStripMenuItem.Text = "Período Regencial";
            // 
            // períodoRegencialParteIToolStripMenuItem
            // 
            this.períodoRegencialParteIToolStripMenuItem.Name = "períodoRegencialParteIToolStripMenuItem";
            this.períodoRegencialParteIToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.períodoRegencialParteIToolStripMenuItem.Text = "Período Regencial - Parte I";
            this.períodoRegencialParteIToolStripMenuItem.Click += new System.EventHandler(this.períodoRegencialParteIToolStripMenuItem_Click);
            // 
            // períodoRegencialParteIIToolStripMenuItem
            // 
            this.períodoRegencialParteIIToolStripMenuItem.Name = "períodoRegencialParteIIToolStripMenuItem";
            this.períodoRegencialParteIIToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.períodoRegencialParteIIToolStripMenuItem.Text = "Período Regencial - Parte II";
            this.períodoRegencialParteIIToolStripMenuItem.Click += new System.EventHandler(this.períodoRegencialParteIIToolStripMenuItem_Click);
            // 
            // revoltaRegenciaisToolStripMenuItem
            // 
            this.revoltaRegenciaisToolStripMenuItem.Name = "revoltaRegenciaisToolStripMenuItem";
            this.revoltaRegenciaisToolStripMenuItem.Size = new System.Drawing.Size(278, 26);
            this.revoltaRegenciaisToolStripMenuItem.Text = "Revoltas Regenciais";
            this.revoltaRegenciaisToolStripMenuItem.Click += new System.EventHandler(this.revoltaRegenciaisToolStripMenuItem_Click);
            // 
            // segundoReinadoToolStripMenuItem
            // 
            this.segundoReinadoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.segundoReinadoParteIToolStripMenuItem,
            this.segundoReinadoParteIIToolStripMenuItem,
            this.guerrasDoPrataToolStripMenuItem});
            this.segundoReinadoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.segundoReinadoToolStripMenuItem.Name = "segundoReinadoToolStripMenuItem";
            this.segundoReinadoToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.segundoReinadoToolStripMenuItem.Text = "Segundo Reinado";
            // 
            // segundoReinadoParteIToolStripMenuItem
            // 
            this.segundoReinadoParteIToolStripMenuItem.Name = "segundoReinadoParteIToolStripMenuItem";
            this.segundoReinadoParteIToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.segundoReinadoParteIToolStripMenuItem.Text = "Segundo Reinado: Parte I";
            this.segundoReinadoParteIToolStripMenuItem.Click += new System.EventHandler(this.segundoReinadoParteIToolStripMenuItem_Click);
            // 
            // segundoReinadoParteIIToolStripMenuItem
            // 
            this.segundoReinadoParteIIToolStripMenuItem.Name = "segundoReinadoParteIIToolStripMenuItem";
            this.segundoReinadoParteIIToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.segundoReinadoParteIIToolStripMenuItem.Text = "Segundo Reinado: Parte II";
            this.segundoReinadoParteIIToolStripMenuItem.Click += new System.EventHandler(this.segundoReinadoParteIIToolStripMenuItem_Click);
            // 
            // guerrasDoPrataToolStripMenuItem
            // 
            this.guerrasDoPrataToolStripMenuItem.Name = "guerrasDoPrataToolStripMenuItem";
            this.guerrasDoPrataToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.guerrasDoPrataToolStripMenuItem.Text = "Guerras do Prata";
            this.guerrasDoPrataToolStripMenuItem.Click += new System.EventHandler(this.guerrasDoPrataToolStripMenuItem_Click);
            // 
            // aCriseDoSegundoReinadoToolStripMenuItem
            // 
            this.aCriseDoSegundoReinadoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.osPartidosPoliticosNoBrasilImpérioToolStripMenuItem,
            this.leisAbolicionistasToolStripMenuItem});
            this.aCriseDoSegundoReinadoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aCriseDoSegundoReinadoToolStripMenuItem.Name = "aCriseDoSegundoReinadoToolStripMenuItem";
            this.aCriseDoSegundoReinadoToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.aCriseDoSegundoReinadoToolStripMenuItem.Text = "A Crise do Segundo Reinado";
            // 
            // osPartidosPoliticosNoBrasilImpérioToolStripMenuItem
            // 
            this.osPartidosPoliticosNoBrasilImpérioToolStripMenuItem.Name = "osPartidosPoliticosNoBrasilImpérioToolStripMenuItem";
            this.osPartidosPoliticosNoBrasilImpérioToolStripMenuItem.Size = new System.Drawing.Size(359, 26);
            this.osPartidosPoliticosNoBrasilImpérioToolStripMenuItem.Text = "Os partidos politicos no Brasil Império";
            this.osPartidosPoliticosNoBrasilImpérioToolStripMenuItem.Click += new System.EventHandler(this.osPartidosPoliticosNoBrasilImpérioToolStripMenuItem_Click);
            // 
            // leisAbolicionistasToolStripMenuItem
            // 
            this.leisAbolicionistasToolStripMenuItem.Name = "leisAbolicionistasToolStripMenuItem";
            this.leisAbolicionistasToolStripMenuItem.Size = new System.Drawing.Size(359, 26);
            this.leisAbolicionistasToolStripMenuItem.Text = "Leis Abolicionistas";
            this.leisAbolicionistasToolStripMenuItem.Click += new System.EventHandler(this.leisAbolicionistasToolStripMenuItem_Click_1);
            // 
            // oProcessoDeIndependênciaToolStripMenuItem
            // 
            this.oProcessoDeIndependênciaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.oProcessoDeIndependênciaToolStripMenuItem.Name = "oProcessoDeIndependênciaToolStripMenuItem";
            this.oProcessoDeIndependênciaToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.oProcessoDeIndependênciaToolStripMenuItem.Text = "Proclamação da República";
            this.oProcessoDeIndependênciaToolStripMenuItem.Click += new System.EventHandler(this.oProcessoDeIndependênciaToolStripMenuItem_Click);
            // 
            // aReúblicaVelhaToolStripMenuItem
            // 
            this.aReúblicaVelhaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem1,
            this.repúblicaDaEspadaToolStripMenuItem,
            this.repúblicaOligárquicaToolStripMenuItem});
            this.aReúblicaVelhaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aReúblicaVelhaToolStripMenuItem.Name = "aReúblicaVelhaToolStripMenuItem";
            this.aReúblicaVelhaToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.aReúblicaVelhaToolStripMenuItem.Text = "A República Velha";
            // 
            // introduçãoToolStripMenuItem1
            // 
            this.introduçãoToolStripMenuItem1.Name = "introduçãoToolStripMenuItem1";
            this.introduçãoToolStripMenuItem1.Size = new System.Drawing.Size(239, 26);
            this.introduçãoToolStripMenuItem1.Text = "Introdução";
            this.introduçãoToolStripMenuItem1.Click += new System.EventHandler(this.introduçãoToolStripMenuItem1_Click);
            // 
            // repúblicaDaEspadaToolStripMenuItem
            // 
            this.repúblicaDaEspadaToolStripMenuItem.Name = "repúblicaDaEspadaToolStripMenuItem";
            this.repúblicaDaEspadaToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.repúblicaDaEspadaToolStripMenuItem.Text = "República da Espada";
            this.repúblicaDaEspadaToolStripMenuItem.Click += new System.EventHandler(this.repúblicaDaEspadaToolStripMenuItem_Click);
            // 
            // repúblicaOligárquicaToolStripMenuItem
            // 
            this.repúblicaOligárquicaToolStripMenuItem.Name = "repúblicaOligárquicaToolStripMenuItem";
            this.repúblicaOligárquicaToolStripMenuItem.Size = new System.Drawing.Size(239, 26);
            this.repúblicaOligárquicaToolStripMenuItem.Text = "República Oligárquica";
            this.repúblicaOligárquicaToolStripMenuItem.Click += new System.EventHandler(this.repúblicaOligárquicaToolStripMenuItem_Click);
            // 
            // aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem
            // 
            this.aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.movimentosERevoltasToolStripMenuItem,
            this.revoltaDaArmadaToolStripMenuItem,
            this.revoltaFederalistaToolStripMenuItem,
            this.revoltaDeCanudosToolStripMenuItem,
            this.revoltaDaVacinaToolStripMenuItem,
            this.revoltaDaChibataToolStripMenuItem,
            this.revoltaDeJuazeiroToolStripMenuItem,
            this.revoltaContestadoToolStripMenuItem,
            this.revoluçãoDe1923ToolStripMenuItem,
            this.movimentoOperárioToolStripMenuItem,
            this.revoluçãoDe1930ToolStripMenuItem});
            this.aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem.Name = "aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem";
            this.aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem.Text = "A Crise da Primeira República (os Anos 20)";
            // 
            // movimentosERevoltasToolStripMenuItem
            // 
            this.movimentosERevoltasToolStripMenuItem.Name = "movimentosERevoltasToolStripMenuItem";
            this.movimentosERevoltasToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.movimentosERevoltasToolStripMenuItem.Text = "Movimentos e Revoltas";
            this.movimentosERevoltasToolStripMenuItem.Click += new System.EventHandler(this.movimentosERevoltasToolStripMenuItem_Click);
            // 
            // revoltaDaArmadaToolStripMenuItem
            // 
            this.revoltaDaArmadaToolStripMenuItem.Name = "revoltaDaArmadaToolStripMenuItem";
            this.revoltaDaArmadaToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoltaDaArmadaToolStripMenuItem.Text = "Revolta da Armada";
            this.revoltaDaArmadaToolStripMenuItem.Click += new System.EventHandler(this.revoltaDaArmadaToolStripMenuItem_Click);
            // 
            // revoltaFederalistaToolStripMenuItem
            // 
            this.revoltaFederalistaToolStripMenuItem.Name = "revoltaFederalistaToolStripMenuItem";
            this.revoltaFederalistaToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoltaFederalistaToolStripMenuItem.Text = "Revolta Federalista";
            this.revoltaFederalistaToolStripMenuItem.Click += new System.EventHandler(this.revoltaFederalistaToolStripMenuItem_Click);
            // 
            // revoltaDeCanudosToolStripMenuItem
            // 
            this.revoltaDeCanudosToolStripMenuItem.Name = "revoltaDeCanudosToolStripMenuItem";
            this.revoltaDeCanudosToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoltaDeCanudosToolStripMenuItem.Text = "Revolta de Canudos";
            this.revoltaDeCanudosToolStripMenuItem.Click += new System.EventHandler(this.revoltaDeCanudosToolStripMenuItem_Click);
            // 
            // revoltaDaVacinaToolStripMenuItem
            // 
            this.revoltaDaVacinaToolStripMenuItem.Name = "revoltaDaVacinaToolStripMenuItem";
            this.revoltaDaVacinaToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoltaDaVacinaToolStripMenuItem.Text = "Revolta da Vacina";
            this.revoltaDaVacinaToolStripMenuItem.Click += new System.EventHandler(this.revoltaDaVacinaToolStripMenuItem_Click);
            // 
            // revoltaDaChibataToolStripMenuItem
            // 
            this.revoltaDaChibataToolStripMenuItem.Name = "revoltaDaChibataToolStripMenuItem";
            this.revoltaDaChibataToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoltaDaChibataToolStripMenuItem.Text = "Revolta da Chibata";
            this.revoltaDaChibataToolStripMenuItem.Click += new System.EventHandler(this.revoltaDaChibataToolStripMenuItem_Click);
            // 
            // revoltaDeJuazeiroToolStripMenuItem
            // 
            this.revoltaDeJuazeiroToolStripMenuItem.Name = "revoltaDeJuazeiroToolStripMenuItem";
            this.revoltaDeJuazeiroToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoltaDeJuazeiroToolStripMenuItem.Text = "Revolta de Juazeiro";
            this.revoltaDeJuazeiroToolStripMenuItem.Click += new System.EventHandler(this.revoltaDeJuazeiroToolStripMenuItem_Click);
            // 
            // revoltaContestadoToolStripMenuItem
            // 
            this.revoltaContestadoToolStripMenuItem.Name = "revoltaContestadoToolStripMenuItem";
            this.revoltaContestadoToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoltaContestadoToolStripMenuItem.Text = "Revolta Contestado";
            this.revoltaContestadoToolStripMenuItem.Click += new System.EventHandler(this.revoltaContestadoToolStripMenuItem_Click);
            // 
            // revoluçãoDe1923ToolStripMenuItem
            // 
            this.revoluçãoDe1923ToolStripMenuItem.Name = "revoluçãoDe1923ToolStripMenuItem";
            this.revoluçãoDe1923ToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoluçãoDe1923ToolStripMenuItem.Text = "Revolução de 1923";
            this.revoluçãoDe1923ToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoDe1923ToolStripMenuItem_Click);
            // 
            // movimentoOperárioToolStripMenuItem
            // 
            this.movimentoOperárioToolStripMenuItem.Name = "movimentoOperárioToolStripMenuItem";
            this.movimentoOperárioToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.movimentoOperárioToolStripMenuItem.Text = "Movimento Operário";
            this.movimentoOperárioToolStripMenuItem.Click += new System.EventHandler(this.movimentoOperárioToolStripMenuItem_Click);
            // 
            // revoluçãoDe1930ToolStripMenuItem
            // 
            this.revoluçãoDe1930ToolStripMenuItem.Name = "revoluçãoDe1930ToolStripMenuItem";
            this.revoluçãoDe1930ToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.revoluçãoDe1930ToolStripMenuItem.Text = "Revolução de 1930";
            this.revoluçãoDe1930ToolStripMenuItem.Click += new System.EventHandler(this.revoluçãoDe1930ToolStripMenuItem_Click);
            // 
            // eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem
            // 
            this.eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem2,
            this.eraVargasIToolStripMenuItem});
            this.eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem.Name = "eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem";
            this.eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem.Text = "Era Vargas: Governo Provisório e Governo Constitucional";
            // 
            // introduçãoToolStripMenuItem2
            // 
            this.introduçãoToolStripMenuItem2.Name = "introduçãoToolStripMenuItem2";
            this.introduçãoToolStripMenuItem2.Size = new System.Drawing.Size(163, 26);
            this.introduçãoToolStripMenuItem2.Text = "Introdução";
            this.introduçãoToolStripMenuItem2.Click += new System.EventHandler(this.introduçãoToolStripMenuItem2_Click);
            // 
            // eraVargasIToolStripMenuItem
            // 
            this.eraVargasIToolStripMenuItem.Name = "eraVargasIToolStripMenuItem";
            this.eraVargasIToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.eraVargasIToolStripMenuItem.Text = "Era Vargas I";
            this.eraVargasIToolStripMenuItem.Click += new System.EventHandler(this.eraVargasIToolStripMenuItem_Click);
            // 
            // eraVargasEstadoNovo19371945ToolStripMenuItem
            // 
            this.eraVargasEstadoNovo19371945ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eraVargasIIToolStripMenuItem});
            this.eraVargasEstadoNovo19371945ToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.eraVargasEstadoNovo19371945ToolStripMenuItem.Name = "eraVargasEstadoNovo19371945ToolStripMenuItem";
            this.eraVargasEstadoNovo19371945ToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.eraVargasEstadoNovo19371945ToolStripMenuItem.Text = "Era Vargas: Estado Novo (1937-1945)";
            // 
            // eraVargasIIToolStripMenuItem
            // 
            this.eraVargasIIToolStripMenuItem.Name = "eraVargasIIToolStripMenuItem";
            this.eraVargasIIToolStripMenuItem.Size = new System.Drawing.Size(168, 26);
            this.eraVargasIIToolStripMenuItem.Text = "Era Vargas II";
            this.eraVargasIIToolStripMenuItem.Click += new System.EventHandler(this.eraVargasIIToolStripMenuItem_Click);
            // 
            // períodoDemocrático19451964ToolStripMenuItem
            // 
            this.períodoDemocrático19451964ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.populismoToolStripMenuItem,
            this.eríodoDemocráticoPopulistaToolStripMenuItem,
            this.governoDutraToolStripMenuItem,
            this.governoVargasToolStripMenuItem,
            this.aMorteDeVargasToolStripMenuItem,
            this.transiçãoDeVargasParaJKToolStripMenuItem,
            this.governoJKToolStripMenuItem,
            this.governoJânioQuadrosToolStripMenuItem,
            this.governoJoãoGoulartToolStripMenuItem});
            this.períodoDemocrático19451964ToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.períodoDemocrático19451964ToolStripMenuItem.Name = "períodoDemocrático19451964ToolStripMenuItem";
            this.períodoDemocrático19451964ToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.períodoDemocrático19451964ToolStripMenuItem.Text = "Período Democrático (1945-1964)";
            // 
            // populismoToolStripMenuItem
            // 
            this.populismoToolStripMenuItem.Name = "populismoToolStripMenuItem";
            this.populismoToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.populismoToolStripMenuItem.Text = "Populismo";
            this.populismoToolStripMenuItem.Click += new System.EventHandler(this.populismoToolStripMenuItem_Click);
            // 
            // eríodoDemocráticoPopulistaToolStripMenuItem
            // 
            this.eríodoDemocráticoPopulistaToolStripMenuItem.Name = "eríodoDemocráticoPopulistaToolStripMenuItem";
            this.eríodoDemocráticoPopulistaToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.eríodoDemocráticoPopulistaToolStripMenuItem.Text = "Período Democrático Populista";
            this.eríodoDemocráticoPopulistaToolStripMenuItem.Click += new System.EventHandler(this.eríodoDemocráticoPopulistaToolStripMenuItem_Click);
            // 
            // governoDutraToolStripMenuItem
            // 
            this.governoDutraToolStripMenuItem.Name = "governoDutraToolStripMenuItem";
            this.governoDutraToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.governoDutraToolStripMenuItem.Text = "Governo Dutra";
            this.governoDutraToolStripMenuItem.Click += new System.EventHandler(this.governoDutraToolStripMenuItem_Click);
            // 
            // governoVargasToolStripMenuItem
            // 
            this.governoVargasToolStripMenuItem.Name = "governoVargasToolStripMenuItem";
            this.governoVargasToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.governoVargasToolStripMenuItem.Text = "Governo Vargas";
            this.governoVargasToolStripMenuItem.Click += new System.EventHandler(this.governoVargasToolStripMenuItem_Click);
            // 
            // aMorteDeVargasToolStripMenuItem
            // 
            this.aMorteDeVargasToolStripMenuItem.Name = "aMorteDeVargasToolStripMenuItem";
            this.aMorteDeVargasToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.aMorteDeVargasToolStripMenuItem.Text = "A morte de Vargas";
            this.aMorteDeVargasToolStripMenuItem.Click += new System.EventHandler(this.aMorteDeVargasToolStripMenuItem_Click);
            // 
            // transiçãoDeVargasParaJKToolStripMenuItem
            // 
            this.transiçãoDeVargasParaJKToolStripMenuItem.Name = "transiçãoDeVargasParaJKToolStripMenuItem";
            this.transiçãoDeVargasParaJKToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.transiçãoDeVargasParaJKToolStripMenuItem.Text = "Transição de Vargas para JK";
            this.transiçãoDeVargasParaJKToolStripMenuItem.Click += new System.EventHandler(this.transiçãoDeVargasParaJKToolStripMenuItem_Click);
            // 
            // governoJKToolStripMenuItem
            // 
            this.governoJKToolStripMenuItem.Name = "governoJKToolStripMenuItem";
            this.governoJKToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.governoJKToolStripMenuItem.Text = "Governo JK";
            this.governoJKToolStripMenuItem.Click += new System.EventHandler(this.governoJKToolStripMenuItem_Click);
            // 
            // governoJânioQuadrosToolStripMenuItem
            // 
            this.governoJânioQuadrosToolStripMenuItem.Name = "governoJânioQuadrosToolStripMenuItem";
            this.governoJânioQuadrosToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.governoJânioQuadrosToolStripMenuItem.Text = "Governo Jânio Quadros";
            this.governoJânioQuadrosToolStripMenuItem.Click += new System.EventHandler(this.governoJânioQuadrosToolStripMenuItem_Click);
            // 
            // governoJoãoGoulartToolStripMenuItem
            // 
            this.governoJoãoGoulartToolStripMenuItem.Name = "governoJoãoGoulartToolStripMenuItem";
            this.governoJoãoGoulartToolStripMenuItem.Size = new System.Drawing.Size(305, 26);
            this.governoJoãoGoulartToolStripMenuItem.Text = "Governo João Goulart";
            this.governoJoãoGoulartToolStripMenuItem.Click += new System.EventHandler(this.governoJoãoGoulartToolStripMenuItem_Click);
            // 
            // movimentoDaLegalidadeToolStripMenuItem
            // 
            this.movimentoDaLegalidadeToolStripMenuItem.Name = "movimentoDaLegalidadeToolStripMenuItem";
            this.movimentoDaLegalidadeToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.movimentoDaLegalidadeToolStripMenuItem.Text = "Movimento da Legalidade";
            this.movimentoDaLegalidadeToolStripMenuItem.Click += new System.EventHandler(this.movimentoDaLegalidadeToolStripMenuItem_Click);
            // 
            // regimeMilitarToolStripMenuItem
            // 
            this.regimeMilitarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.golpeDe1964ToolStripMenuItem,
            this.linhaDoTempoToolStripMenuItem1,
            this.governoCasteloBrancoToolStripMenuItem,
            this.governoCostaESilvaToolStripMenuItem,
            this.governoMédiciToolStripMenuItem,
            this.governoGeiselToolStripMenuItem,
            this.governoFigueiredoToolStripMenuItem});
            this.regimeMilitarToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.regimeMilitarToolStripMenuItem.Name = "regimeMilitarToolStripMenuItem";
            this.regimeMilitarToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.regimeMilitarToolStripMenuItem.Text = "Regime Militar";
            // 
            // golpeDe1964ToolStripMenuItem
            // 
            this.golpeDe1964ToolStripMenuItem.Name = "golpeDe1964ToolStripMenuItem";
            this.golpeDe1964ToolStripMenuItem.Size = new System.Drawing.Size(256, 26);
            this.golpeDe1964ToolStripMenuItem.Text = "Golpe de 1964";
            this.golpeDe1964ToolStripMenuItem.Click += new System.EventHandler(this.golpeDe1964ToolStripMenuItem_Click);
            // 
            // linhaDoTempoToolStripMenuItem1
            // 
            this.linhaDoTempoToolStripMenuItem1.Name = "linhaDoTempoToolStripMenuItem1";
            this.linhaDoTempoToolStripMenuItem1.Size = new System.Drawing.Size(256, 26);
            this.linhaDoTempoToolStripMenuItem1.Text = "Linha do Tempo ";
            // 
            // governoCasteloBrancoToolStripMenuItem
            // 
            this.governoCasteloBrancoToolStripMenuItem.Name = "governoCasteloBrancoToolStripMenuItem";
            this.governoCasteloBrancoToolStripMenuItem.Size = new System.Drawing.Size(256, 26);
            this.governoCasteloBrancoToolStripMenuItem.Text = "Governo Castelo Branco";
            this.governoCasteloBrancoToolStripMenuItem.Click += new System.EventHandler(this.governoCasteloBrancoToolStripMenuItem_Click);
            // 
            // governoCostaESilvaToolStripMenuItem
            // 
            this.governoCostaESilvaToolStripMenuItem.Name = "governoCostaESilvaToolStripMenuItem";
            this.governoCostaESilvaToolStripMenuItem.Size = new System.Drawing.Size(256, 26);
            this.governoCostaESilvaToolStripMenuItem.Text = "Governo Costa e Silva";
            this.governoCostaESilvaToolStripMenuItem.Click += new System.EventHandler(this.governoCostaESilvaToolStripMenuItem_Click);
            // 
            // governoMédiciToolStripMenuItem
            // 
            this.governoMédiciToolStripMenuItem.Name = "governoMédiciToolStripMenuItem";
            this.governoMédiciToolStripMenuItem.Size = new System.Drawing.Size(256, 26);
            this.governoMédiciToolStripMenuItem.Text = "Governo Médici";
            this.governoMédiciToolStripMenuItem.Click += new System.EventHandler(this.governoMédiciToolStripMenuItem_Click);
            // 
            // governoGeiselToolStripMenuItem
            // 
            this.governoGeiselToolStripMenuItem.Name = "governoGeiselToolStripMenuItem";
            this.governoGeiselToolStripMenuItem.Size = new System.Drawing.Size(256, 26);
            this.governoGeiselToolStripMenuItem.Text = "Governo Geisel";
            this.governoGeiselToolStripMenuItem.Click += new System.EventHandler(this.governoGeiselToolStripMenuItem_Click);
            // 
            // governoFigueiredoToolStripMenuItem
            // 
            this.governoFigueiredoToolStripMenuItem.Name = "governoFigueiredoToolStripMenuItem";
            this.governoFigueiredoToolStripMenuItem.Size = new System.Drawing.Size(256, 26);
            this.governoFigueiredoToolStripMenuItem.Text = "Governo Figueiredo";
            this.governoFigueiredoToolStripMenuItem.Click += new System.EventHandler(this.governoFigueiredoToolStripMenuItem_Click);
            // 
            // diretasJáToolStripMenuItem
            // 
            this.diretasJáToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.diretasJáToolStripMenuItem.Name = "diretasJáToolStripMenuItem";
            this.diretasJáToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.diretasJáToolStripMenuItem.Text = "Diretas Já";
            this.diretasJáToolStripMenuItem.Click += new System.EventHandler(this.diretasJáToolStripMenuItem_Click);
            // 
            // aNovaReplúblicaToolStripMenuItem
            // 
            this.aNovaReplúblicaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.aNovaReplúblicaToolStripMenuItem.Name = "aNovaReplúblicaToolStripMenuItem";
            this.aNovaReplúblicaToolStripMenuItem.Size = new System.Drawing.Size(491, 26);
            this.aNovaReplúblicaToolStripMenuItem.Text = "A nova Replública";
            this.aNovaReplúblicaToolStripMenuItem.Click += new System.EventHandler(this.aNovaReplúblicaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.BackColor = System.Drawing.Color.Tomato;
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem83,
            this.toolStripMenuItem111});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(113, 25);
            this.toolStripMenuItem2.Text = "Perguntas";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem11,
            this.toolStripMenuItem16,
            this.toolStripMenuItem21,
            this.toolStripMenuItem25,
            this.toolStripMenuItem30,
            this.toolStripMenuItem40,
            this.toolStripMenuItem46,
            this.toolStripMenuItem50,
            this.toolStripMenuItem56,
            this.toolStripMenuItem67,
            this.toolStripMenuItem70,
            this.toolStripMenuItem82});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem3.Text = "História Geral ";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem7.Text = "Antiguidade Clássica";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(181, 26);
            this.toolStripMenuItem8.Text = "Mesopotâmia";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(181, 26);
            this.toolStripMenuItem9.Text = "Grécia ";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(181, 26);
            this.toolStripMenuItem10.Text = "Roma";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.toolStripMenuItem15});
            this.toolStripMenuItem11.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem11.Text = "Idade Média";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(229, 26);
            this.toolStripMenuItem12.Text = "Império Bizantino";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(229, 26);
            this.toolStripMenuItem13.Text = "Império dos Francos";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(229, 26);
            this.toolStripMenuItem14.Text = "Civilização Islâmica";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(229, 26);
            this.toolStripMenuItem15.Text = "Feudalismo";
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem17,
            this.toolStripMenuItem18,
            this.toolStripMenuItem19,
            this.toolStripMenuItem20});
            this.toolStripMenuItem16.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem16.Text = "A Baixa Idade Média";
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(398, 26);
            this.toolStripMenuItem17.Text = "Cruzadas ";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(398, 26);
            this.toolStripMenuItem18.Text = "Renascimento Comercial e Urbano - Fatores";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(398, 26);
            this.toolStripMenuItem19.Text = "Peste Negra";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(398, 26);
            this.toolStripMenuItem20.Text = "Monarquias Nacionais";
            this.toolStripMenuItem20.Click += new System.EventHandler(this.toolStripMenuItem20_Click);
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem22,
            this.toolStripMenuItem23,
            this.toolStripMenuItem24});
            this.toolStripMenuItem21.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem21.Text = "Transição da Idade Média para Idade Moderna";
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(281, 26);
            this.toolStripMenuItem22.Text = "Igreja Medieval - Inquisição";
            this.toolStripMenuItem22.Click += new System.EventHandler(this.toolStripMenuItem22_Click);
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(281, 26);
            this.toolStripMenuItem23.Text = "Renascimento Cultural";
            this.toolStripMenuItem23.Click += new System.EventHandler(this.toolStripMenuItem23_Click);
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(281, 26);
            this.toolStripMenuItem24.Text = "Reforma Protestante";
            this.toolStripMenuItem24.Click += new System.EventHandler(this.toolStripMenuItem24_Click);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem26,
            this.toolStripMenuItem28,
            this.toolStripMenuItem29});
            this.toolStripMenuItem25.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem25.Text = "Absolutismo Monárquico Europeu e Mercantilismo";
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(293, 26);
            this.toolStripMenuItem26.Text = "Absolutismo e Mercantilismo";
            this.toolStripMenuItem26.Click += new System.EventHandler(this.toolStripMenuItem26_Click);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(293, 26);
            this.toolStripMenuItem28.Text = "Expansão Marítima";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.toolStripMenuItem28_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(293, 26);
            this.toolStripMenuItem29.Text = "A Conquista da América";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem32,
            this.toolStripMenuItem33,
            this.toolStripMenuItem36,
            this.toolStripMenuItem39});
            this.toolStripMenuItem30.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem30.Text = "Revoluções Inglesas do Século XVII e Iluminismo";
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(268, 26);
            this.toolStripMenuItem32.Text = "Dinastia Stuart";
            this.toolStripMenuItem32.Click += new System.EventHandler(this.toolStripMenuItem32_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(268, 26);
            this.toolStripMenuItem33.Text = "Absolutismo na Inglaterra";
            this.toolStripMenuItem33.Click += new System.EventHandler(this.toolStripMenuItem33_Click);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(268, 26);
            this.toolStripMenuItem36.Text = "Anglicanos e Puritanos";
            this.toolStripMenuItem36.Click += new System.EventHandler(this.toolStripMenuItem36_Click);
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(268, 26);
            this.toolStripMenuItem39.Text = "Iluminismo";
            this.toolStripMenuItem39.Click += new System.EventHandler(this.toolStripMenuItem39_Click);
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem42,
            this.toolStripMenuItem43,
            this.toolStripMenuItem45});
            this.toolStripMenuItem40.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem40.Text = "Revolução Francesa e Era Napoleônica";
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(235, 26);
            this.toolStripMenuItem42.Text = "Revolução Francesa";
            this.toolStripMenuItem42.Click += new System.EventHandler(this.toolStripMenuItem42_Click);
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(235, 26);
            this.toolStripMenuItem43.Text = "Período Napoleônico";
            this.toolStripMenuItem43.Click += new System.EventHandler(this.toolStripMenuItem43_Click);
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(235, 26);
            this.toolStripMenuItem45.Text = "Revoluções Liberais";
            this.toolStripMenuItem45.Click += new System.EventHandler(this.toolStripMenuItem45_Click);
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem47,
            this.toolStripMenuItem48,
            this.toolStripMenuItem49});
            this.toolStripMenuItem46.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem46.Text = "Revolução Industrial e Ideias Sociais do Século XIX";
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(296, 26);
            this.toolStripMenuItem47.Text = "Primeira Revolução Industria";
            this.toolStripMenuItem47.Click += new System.EventHandler(this.toolStripMenuItem47_Click);
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(296, 26);
            this.toolStripMenuItem48.Text = "Segunda Revolução Industrial";
            this.toolStripMenuItem48.Click += new System.EventHandler(this.toolStripMenuItem48_Click);
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(296, 26);
            this.toolStripMenuItem49.Text = "Doutrinas do Século XIX";
            this.toolStripMenuItem49.Click += new System.EventHandler(this.toolStripMenuItem49_Click);
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem51,
            this.toolStripMenuItem52,
            this.toolStripMenuItem53,
            this.toolStripMenuItem54,
            this.toolStripMenuItem55});
            this.toolStripMenuItem50.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem50.Text = "Imperialismo e Primeira Guerra Mundial";
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(424, 26);
            this.toolStripMenuItem51.Text = "Imperialismo / Neocolonialismo";
            this.toolStripMenuItem51.Click += new System.EventHandler(this.toolStripMenuItem51_Click);
            // 
            // toolStripMenuItem52
            // 
            this.toolStripMenuItem52.Name = "toolStripMenuItem52";
            this.toolStripMenuItem52.Size = new System.Drawing.Size(424, 26);
            this.toolStripMenuItem52.Text = "África";
            this.toolStripMenuItem52.Click += new System.EventHandler(this.toolStripMenuItem52_Click);
            // 
            // toolStripMenuItem53
            // 
            this.toolStripMenuItem53.Name = "toolStripMenuItem53";
            this.toolStripMenuItem53.Size = new System.Drawing.Size(424, 26);
            this.toolStripMenuItem53.Text = "Eurocentrismo";
            this.toolStripMenuItem53.Click += new System.EventHandler(this.toolStripMenuItem53_Click);
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(424, 26);
            this.toolStripMenuItem54.Text = "Primeira Guerra Mundial";
            this.toolStripMenuItem54.Click += new System.EventHandler(this.toolStripMenuItem54_Click);
            // 
            // toolStripMenuItem55
            // 
            this.toolStripMenuItem55.Name = "toolStripMenuItem55";
            this.toolStripMenuItem55.Size = new System.Drawing.Size(424, 26);
            this.toolStripMenuItem55.Text = "Primeira Guerra Mundial: participação brasileira";
            this.toolStripMenuItem55.Click += new System.EventHandler(this.toolStripMenuItem55_Click);
            // 
            // toolStripMenuItem56
            // 
            this.toolStripMenuItem56.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem58,
            this.toolStripMenuItem59,
            this.toolStripMenuItem61,
            this.toolStripMenuItem62,
            this.toolStripMenuItem63,
            this.toolStripMenuItem64,
            this.toolStripMenuItem65});
            this.toolStripMenuItem56.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem56.Name = "toolStripMenuItem56";
            this.toolStripMenuItem56.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem56.Text = "Período entre Guerras";
            // 
            // toolStripMenuItem58
            // 
            this.toolStripMenuItem58.Name = "toolStripMenuItem58";
            this.toolStripMenuItem58.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem58.Text = "Tratado de Versalhes";
            this.toolStripMenuItem58.Click += new System.EventHandler(this.toolStripMenuItem58_Click);
            // 
            // toolStripMenuItem59
            // 
            this.toolStripMenuItem59.Name = "toolStripMenuItem59";
            this.toolStripMenuItem59.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem59.Text = "Revolução Russa";
            this.toolStripMenuItem59.Click += new System.EventHandler(this.toolStripMenuItem59_Click);
            // 
            // toolStripMenuItem61
            // 
            this.toolStripMenuItem61.Name = "toolStripMenuItem61";
            this.toolStripMenuItem61.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem61.Text = "Trotsky X Stalin";
            this.toolStripMenuItem61.Click += new System.EventHandler(this.toolStripMenuItem61_Click);
            // 
            // toolStripMenuItem62
            // 
            this.toolStripMenuItem62.Name = "toolStripMenuItem62";
            this.toolStripMenuItem62.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem62.Text = "Crise de 1929";
            this.toolStripMenuItem62.Click += new System.EventHandler(this.toolStripMenuItem62_Click);
            // 
            // toolStripMenuItem63
            // 
            this.toolStripMenuItem63.Name = "toolStripMenuItem63";
            this.toolStripMenuItem63.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem63.Text = "Regimes Totalitários";
            this.toolStripMenuItem63.Click += new System.EventHandler(this.toolStripMenuItem63_Click);
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem64.Text = "Fascismo Italiano";
            this.toolStripMenuItem64.Click += new System.EventHandler(this.toolStripMenuItem64_Click);
            // 
            // toolStripMenuItem65
            // 
            this.toolStripMenuItem65.Name = "toolStripMenuItem65";
            this.toolStripMenuItem65.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem65.Text = "História: Nazismo alemão";
            this.toolStripMenuItem65.Click += new System.EventHandler(this.toolStripMenuItem65_Click);
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem67.Text = "Segunda Guerra Mundial";
            this.toolStripMenuItem67.Click += new System.EventHandler(this.toolStripMenuItem67_Click);
            // 
            // toolStripMenuItem70
            // 
            this.toolStripMenuItem70.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem71,
            this.toolStripMenuItem72,
            this.toolStripMenuItem73,
            this.toolStripMenuItem74,
            this.toolStripMenuItem75,
            this.toolStripMenuItem76,
            this.toolStripMenuItem77,
            this.toolStripMenuItem79,
            this.toolStripMenuItem80});
            this.toolStripMenuItem70.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem70.Name = "toolStripMenuItem70";
            this.toolStripMenuItem70.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem70.Text = "Guerra Fria e Descolonização Afro Asiática";
            // 
            // toolStripMenuItem71
            // 
            this.toolStripMenuItem71.Name = "toolStripMenuItem71";
            this.toolStripMenuItem71.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem71.Text = "Guerra Fria";
            this.toolStripMenuItem71.Click += new System.EventHandler(this.toolStripMenuItem71_Click);
            // 
            // toolStripMenuItem72
            // 
            this.toolStripMenuItem72.Name = "toolStripMenuItem72";
            this.toolStripMenuItem72.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem72.Text = "Conflitos";
            this.toolStripMenuItem72.Click += new System.EventHandler(this.toolStripMenuItem72_Click);
            // 
            // toolStripMenuItem73
            // 
            this.toolStripMenuItem73.Name = "toolStripMenuItem73";
            this.toolStripMenuItem73.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem73.Text = "Descolonização da África";
            this.toolStripMenuItem73.Click += new System.EventHandler(this.toolStripMenuItem73_Click);
            // 
            // toolStripMenuItem74
            // 
            this.toolStripMenuItem74.Name = "toolStripMenuItem74";
            this.toolStripMenuItem74.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem74.Text = "Revolução Chinesa";
            this.toolStripMenuItem74.Click += new System.EventHandler(this.toolStripMenuItem74_Click);
            // 
            // toolStripMenuItem75
            // 
            this.toolStripMenuItem75.Name = "toolStripMenuItem75";
            this.toolStripMenuItem75.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem75.Text = "Guerras da Coreia e Vietnã";
            this.toolStripMenuItem75.Click += new System.EventHandler(this.toolStripMenuItem75_Click);
            // 
            // toolStripMenuItem76
            // 
            this.toolStripMenuItem76.Name = "toolStripMenuItem76";
            this.toolStripMenuItem76.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem76.Text = "Conflitos no Oriente Médio";
            this.toolStripMenuItem76.Click += new System.EventHandler(this.toolStripMenuItem76_Click);
            // 
            // toolStripMenuItem77
            // 
            this.toolStripMenuItem77.Name = "toolStripMenuItem77";
            this.toolStripMenuItem77.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem77.Text = "URSS e seus estadistas";
            this.toolStripMenuItem77.Click += new System.EventHandler(this.toolStripMenuItem77_Click);
            // 
            // toolStripMenuItem79
            // 
            this.toolStripMenuItem79.Name = "toolStripMenuItem79";
            this.toolStripMenuItem79.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem79.Text = "O Brasil na Guerra Fria";
            this.toolStripMenuItem79.Click += new System.EventHandler(this.toolStripMenuItem79_Click);
            // 
            // toolStripMenuItem80
            // 
            this.toolStripMenuItem80.Name = "toolStripMenuItem80";
            this.toolStripMenuItem80.Size = new System.Drawing.Size(280, 26);
            this.toolStripMenuItem80.Text = "Queda da URSS";
            this.toolStripMenuItem80.Click += new System.EventHandler(this.toolStripMenuItem80_Click);
            // 
            // toolStripMenuItem82
            // 
            this.toolStripMenuItem82.Name = "toolStripMenuItem82";
            this.toolStripMenuItem82.Size = new System.Drawing.Size(451, 26);
            this.toolStripMenuItem82.Text = "Mundo Atual";
            this.toolStripMenuItem82.Click += new System.EventHandler(this.toolStripMenuItem82_Click);
            // 
            // toolStripMenuItem83
            // 
            this.toolStripMenuItem83.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem84,
            this.toolStripMenuItem85,
            this.toolStripMenuItem90,
            this.toolStripMenuItem91,
            this.toolStripMenuItem92,
            this.toolStripMenuItem95,
            this.toolStripMenuItem98,
            this.toolStripMenuItem99,
            this.toolStripMenuItem100,
            this.toolStripMenuItem102,
            this.toolStripMenuItem103,
            this.toolStripMenuItem104,
            this.toolStripMenuItem105,
            this.toolStripMenuItem106,
            this.toolStripMenuItem109,
            this.toolStripMenuItem110});
            this.toolStripMenuItem83.Name = "toolStripMenuItem83";
            this.toolStripMenuItem83.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem83.Text = "História da América";
            // 
            // toolStripMenuItem84
            // 
            this.toolStripMenuItem84.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem84.Name = "toolStripMenuItem84";
            this.toolStripMenuItem84.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem84.Text = "Expansão Marítima e Comercial Europeia";
            this.toolStripMenuItem84.Click += new System.EventHandler(this.toolStripMenuItem84_Click);
            // 
            // toolStripMenuItem85
            // 
            this.toolStripMenuItem85.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem86,
            this.toolStripMenuItem87,
            this.toolStripMenuItem88,
            this.toolStripMenuItem89});
            this.toolStripMenuItem85.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem85.Name = "toolStripMenuItem85";
            this.toolStripMenuItem85.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem85.Text = "A Conquista da América e os Povos Pré-Colombianos";
            // 
            // toolStripMenuItem86
            // 
            this.toolStripMenuItem86.Name = "toolStripMenuItem86";
            this.toolStripMenuItem86.Size = new System.Drawing.Size(239, 26);
            this.toolStripMenuItem86.Text = "Conquista da América";
            this.toolStripMenuItem86.Click += new System.EventHandler(this.toolStripMenuItem86_Click);
            // 
            // toolStripMenuItem87
            // 
            this.toolStripMenuItem87.Name = "toolStripMenuItem87";
            this.toolStripMenuItem87.Size = new System.Drawing.Size(239, 26);
            this.toolStripMenuItem87.Text = "Maias";
            this.toolStripMenuItem87.Click += new System.EventHandler(this.toolStripMenuItem87_Click);
            // 
            // toolStripMenuItem88
            // 
            this.toolStripMenuItem88.Name = "toolStripMenuItem88";
            this.toolStripMenuItem88.Size = new System.Drawing.Size(239, 26);
            this.toolStripMenuItem88.Text = "Astecas";
            this.toolStripMenuItem88.Click += new System.EventHandler(this.toolStripMenuItem88_Click);
            // 
            // toolStripMenuItem89
            // 
            this.toolStripMenuItem89.Name = "toolStripMenuItem89";
            this.toolStripMenuItem89.Size = new System.Drawing.Size(239, 26);
            this.toolStripMenuItem89.Text = "Incas";
            this.toolStripMenuItem89.Click += new System.EventHandler(this.toolStripMenuItem89_Click);
            // 
            // toolStripMenuItem90
            // 
            this.toolStripMenuItem90.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem90.Name = "toolStripMenuItem90";
            this.toolStripMenuItem90.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem90.Text = "Colonização Espanhola";
            this.toolStripMenuItem90.Click += new System.EventHandler(this.toolStripMenuItem90_Click);
            // 
            // toolStripMenuItem91
            // 
            this.toolStripMenuItem91.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem91.Name = "toolStripMenuItem91";
            this.toolStripMenuItem91.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem91.Text = "Colonização Inglesa";
            this.toolStripMenuItem91.Click += new System.EventHandler(this.toolStripMenuItem91_Click);
            // 
            // toolStripMenuItem92
            // 
            this.toolStripMenuItem92.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem93,
            this.toolStripMenuItem94});
            this.toolStripMenuItem92.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem92.Name = "toolStripMenuItem92";
            this.toolStripMenuItem92.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem92.Text = "Construção do Estado Norte Americano: A Independência das Treze Colônias";
            // 
            // toolStripMenuItem93
            // 
            this.toolStripMenuItem93.Name = "toolStripMenuItem93";
            this.toolStripMenuItem93.Size = new System.Drawing.Size(237, 26);
            this.toolStripMenuItem93.Text = "Revolução Americana";
            this.toolStripMenuItem93.Click += new System.EventHandler(this.toolStripMenuItem93_Click);
            // 
            // toolStripMenuItem94
            // 
            this.toolStripMenuItem94.Name = "toolStripMenuItem94";
            this.toolStripMenuItem94.Size = new System.Drawing.Size(237, 26);
            this.toolStripMenuItem94.Text = "Expansão dos EUA";
            this.toolStripMenuItem94.Click += new System.EventHandler(this.toolStripMenuItem94_Click);
            // 
            // toolStripMenuItem95
            // 
            this.toolStripMenuItem95.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem95.Name = "toolStripMenuItem95";
            this.toolStripMenuItem95.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem95.Text = "Estados Unidos no Século XIX";
            this.toolStripMenuItem95.Click += new System.EventHandler(this.toolStripMenuItem95_Click);
            // 
            // toolStripMenuItem98
            // 
            this.toolStripMenuItem98.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem98.Name = "toolStripMenuItem98";
            this.toolStripMenuItem98.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem98.Text = "Crise de 1929";
            this.toolStripMenuItem98.Click += new System.EventHandler(this.toolStripMenuItem98_Click);
            // 
            // toolStripMenuItem99
            // 
            this.toolStripMenuItem99.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem99.Name = "toolStripMenuItem99";
            this.toolStripMenuItem99.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem99.Text = "Estados Unidos Pós Segunda Guerra Mundial";
            this.toolStripMenuItem99.Click += new System.EventHandler(this.toolStripMenuItem99_Click);
            // 
            // toolStripMenuItem100
            // 
            this.toolStripMenuItem100.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem101});
            this.toolStripMenuItem100.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem100.Name = "toolStripMenuItem100";
            this.toolStripMenuItem100.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem100.Text = "Regimes Militares e Transição Democrática";
            // 
            // toolStripMenuItem101
            // 
            this.toolStripMenuItem101.Name = "toolStripMenuItem101";
            this.toolStripMenuItem101.Size = new System.Drawing.Size(304, 26);
            this.toolStripMenuItem101.Text = "Ditaduras da AMÉRICA LATINA";
            this.toolStripMenuItem101.Click += new System.EventHandler(this.toolStripMenuItem101_Click);
            // 
            // toolStripMenuItem102
            // 
            this.toolStripMenuItem102.Name = "toolStripMenuItem102";
            this.toolStripMenuItem102.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem102.Text = "A Revolução Cubana";
            this.toolStripMenuItem102.Click += new System.EventHandler(this.toolStripMenuItem102_Click);
            // 
            // toolStripMenuItem103
            // 
            this.toolStripMenuItem103.Name = "toolStripMenuItem103";
            this.toolStripMenuItem103.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem103.Text = "A Revolução Mexicana";
            this.toolStripMenuItem103.Click += new System.EventHandler(this.toolStripMenuItem103_Click);
            // 
            // toolStripMenuItem104
            // 
            this.toolStripMenuItem104.Name = "toolStripMenuItem104";
            this.toolStripMenuItem104.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem104.Text = "Revoluções na América Latina – Chile e Nicarágua";
            this.toolStripMenuItem104.Click += new System.EventHandler(this.toolStripMenuItem104_Click);
            // 
            // toolStripMenuItem105
            // 
            this.toolStripMenuItem105.Name = "toolStripMenuItem105";
            this.toolStripMenuItem105.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem105.Text = "Independência da América Latina";
            this.toolStripMenuItem105.Click += new System.EventHandler(this.toolStripMenuItem105_Click);
            // 
            // toolStripMenuItem106
            // 
            this.toolStripMenuItem106.Name = "toolStripMenuItem106";
            this.toolStripMenuItem106.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem106.Text = "Estados Nacionais Latinos";
            this.toolStripMenuItem106.Click += new System.EventHandler(this.toolStripMenuItem106_Click);
            // 
            // toolStripMenuItem109
            // 
            this.toolStripMenuItem109.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem109.Name = "toolStripMenuItem109";
            this.toolStripMenuItem109.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem109.Text = "Populismo na América";
            this.toolStripMenuItem109.Click += new System.EventHandler(this.toolStripMenuItem109_Click);
            // 
            // toolStripMenuItem110
            // 
            this.toolStripMenuItem110.Name = "toolStripMenuItem110";
            this.toolStripMenuItem110.Size = new System.Drawing.Size(640, 26);
            this.toolStripMenuItem110.Text = "América Atual";
            this.toolStripMenuItem110.Click += new System.EventHandler(this.toolStripMenuItem110_Click);
            // 
            // toolStripMenuItem111
            // 
            this.toolStripMenuItem111.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem112,
            this.toolStripMenuItem113,
            this.toolStripMenuItem116,
            this.toolStripMenuItem127,
            this.toolStripMenuItem132,
            this.toolStripMenuItem135,
            this.toolStripMenuItem138,
            this.toolStripMenuItem142,
            this.toolStripMenuItem146,
            this.toolStripMenuItem149,
            this.toolStripMenuItem150,
            this.toolStripMenuItem154,
            this.toolStripMenuItem166,
            this.toolStripMenuItem169,
            this.toolStripMenuItem171,
            this.toolStripMenuItem181,
            this.toolStripMenuItem182,
            this.toolStripMenuItem190,
            this.toolStripMenuItem191});
            this.toolStripMenuItem111.Name = "toolStripMenuItem111";
            this.toolStripMenuItem111.Size = new System.Drawing.Size(223, 26);
            this.toolStripMenuItem111.Text = "História do Brasil";
            // 
            // toolStripMenuItem112
            // 
            this.toolStripMenuItem112.Name = "toolStripMenuItem112";
            this.toolStripMenuItem112.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem112.Text = "Pré-História no Brasil";
            this.toolStripMenuItem112.Click += new System.EventHandler(this.toolStripMenuItem112_Click);
            // 
            // toolStripMenuItem113
            // 
            this.toolStripMenuItem113.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem114,
            this.toolStripMenuItem115});
            this.toolStripMenuItem113.Name = "toolStripMenuItem113";
            this.toolStripMenuItem113.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem113.Text = "A Montagem do Sistema Colonial no Brasil";
            // 
            // toolStripMenuItem114
            // 
            this.toolStripMenuItem114.Name = "toolStripMenuItem114";
            this.toolStripMenuItem114.Size = new System.Drawing.Size(260, 26);
            this.toolStripMenuItem114.Text = "Descobrimento do Brasil";
            this.toolStripMenuItem114.Click += new System.EventHandler(this.toolStripMenuItem114_Click);
            // 
            // toolStripMenuItem115
            // 
            this.toolStripMenuItem115.Name = "toolStripMenuItem115";
            this.toolStripMenuItem115.Size = new System.Drawing.Size(260, 26);
            this.toolStripMenuItem115.Text = "Período Pré- colonial";
            this.toolStripMenuItem115.Click += new System.EventHandler(this.toolStripMenuItem115_Click);
            // 
            // toolStripMenuItem116
            // 
            this.toolStripMenuItem116.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem117,
            this.toolStripMenuItem118,
            this.toolStripMenuItem120,
            this.toolStripMenuItem121,
            this.toolStripMenuItem122,
            this.toolStripMenuItem123,
            this.toolStripMenuItem124,
            this.toolStripMenuItem125,
            this.toolStripMenuItem126});
            this.toolStripMenuItem116.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem116.Name = "toolStripMenuItem116";
            this.toolStripMenuItem116.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem116.Text = "A Administração Colonial e a Expansão Territorial";
            // 
            // toolStripMenuItem117
            // 
            this.toolStripMenuItem117.Name = "toolStripMenuItem117";
            this.toolStripMenuItem117.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem117.Text = "Ciclos Econômicos";
            this.toolStripMenuItem117.Click += new System.EventHandler(this.toolStripMenuItem117_Click);
            // 
            // toolStripMenuItem118
            // 
            this.toolStripMenuItem118.Name = "toolStripMenuItem118";
            this.toolStripMenuItem118.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem118.Text = "Capitanias Hereditárias";
            this.toolStripMenuItem118.Click += new System.EventHandler(this.toolStripMenuItem118_Click);
            // 
            // toolStripMenuItem120
            // 
            this.toolStripMenuItem120.Name = "toolStripMenuItem120";
            this.toolStripMenuItem120.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem120.Text = "Economia do açúcar colonial";
            this.toolStripMenuItem120.Click += new System.EventHandler(this.toolStripMenuItem120_Click);
            // 
            // toolStripMenuItem121
            // 
            this.toolStripMenuItem121.Name = "toolStripMenuItem121";
            this.toolStripMenuItem121.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem121.Text = "União Ibérica";
            this.toolStripMenuItem121.Click += new System.EventHandler(this.toolStripMenuItem121_Click);
            // 
            // toolStripMenuItem122
            // 
            this.toolStripMenuItem122.Name = "toolStripMenuItem122";
            this.toolStripMenuItem122.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem122.Text = "Presença Holandesa";
            this.toolStripMenuItem122.Click += new System.EventHandler(this.toolStripMenuItem122_Click);
            // 
            // toolStripMenuItem123
            // 
            this.toolStripMenuItem123.Name = "toolStripMenuItem123";
            this.toolStripMenuItem123.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem123.Text = "Economia Mineradora";
            this.toolStripMenuItem123.Click += new System.EventHandler(this.toolStripMenuItem123_Click);
            // 
            // toolStripMenuItem124
            // 
            this.toolStripMenuItem124.Name = "toolStripMenuItem124";
            this.toolStripMenuItem124.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem124.Text = "Escravidão no Brasil";
            this.toolStripMenuItem124.Click += new System.EventHandler(this.toolStripMenuItem124_Click);
            // 
            // toolStripMenuItem125
            // 
            this.toolStripMenuItem125.Name = "toolStripMenuItem125";
            this.toolStripMenuItem125.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem125.Text = "Sociedades Quilombolas";
            this.toolStripMenuItem125.Click += new System.EventHandler(this.toolStripMenuItem125_Click);
            // 
            // toolStripMenuItem126
            // 
            this.toolStripMenuItem126.Name = "toolStripMenuItem126";
            this.toolStripMenuItem126.Size = new System.Drawing.Size(287, 26);
            this.toolStripMenuItem126.Text = "Bandeirantismo";
            this.toolStripMenuItem126.Click += new System.EventHandler(this.toolStripMenuItem126_Click);
            // 
            // toolStripMenuItem127
            // 
            this.toolStripMenuItem127.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem128,
            this.toolStripMenuItem129,
            this.toolStripMenuItem131});
            this.toolStripMenuItem127.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem127.Name = "toolStripMenuItem127";
            this.toolStripMenuItem127.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem127.Text = "A Crise do Sistema Colonial";
            // 
            // toolStripMenuItem128
            // 
            this.toolStripMenuItem128.Name = "toolStripMenuItem128";
            this.toolStripMenuItem128.Size = new System.Drawing.Size(388, 26);
            this.toolStripMenuItem128.Text = "Crise do Sistema Colonial";
            this.toolStripMenuItem128.Click += new System.EventHandler(this.toolStripMenuItem128_Click);
            // 
            // toolStripMenuItem129
            // 
            this.toolStripMenuItem129.Name = "toolStripMenuItem129";
            this.toolStripMenuItem129.Size = new System.Drawing.Size(388, 26);
            this.toolStripMenuItem129.Text = "Inconfidência Mineira e Conjuração Baiana";
            this.toolStripMenuItem129.Click += new System.EventHandler(this.toolStripMenuItem129_Click);
            // 
            // toolStripMenuItem131
            // 
            this.toolStripMenuItem131.Name = "toolStripMenuItem131";
            this.toolStripMenuItem131.Size = new System.Drawing.Size(388, 26);
            this.toolStripMenuItem131.Text = "Revisão do Período Colonial";
            this.toolStripMenuItem131.Click += new System.EventHandler(this.toolStripMenuItem131_Click);
            // 
            // toolStripMenuItem132
            // 
            this.toolStripMenuItem132.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem132.Name = "toolStripMenuItem132";
            this.toolStripMenuItem132.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem132.Text = "Período Joanino";
            this.toolStripMenuItem132.Click += new System.EventHandler(this.toolStripMenuItem132_Click);
            // 
            // toolStripMenuItem135
            // 
            this.toolStripMenuItem135.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem136,
            this.toolStripMenuItem137});
            this.toolStripMenuItem135.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem135.Name = "toolStripMenuItem135";
            this.toolStripMenuItem135.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem135.Text = "Primeiro Reinado";
            // 
            // toolStripMenuItem136
            // 
            this.toolStripMenuItem136.Name = "toolStripMenuItem136";
            this.toolStripMenuItem136.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem136.Text = "Independência do Brasil";
            this.toolStripMenuItem136.Click += new System.EventHandler(this.toolStripMenuItem136_Click);
            // 
            // toolStripMenuItem137
            // 
            this.toolStripMenuItem137.Name = "toolStripMenuItem137";
            this.toolStripMenuItem137.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem137.Text = "Primeiro Reinado";
            this.toolStripMenuItem137.Click += new System.EventHandler(this.toolStripMenuItem137_Click);
            // 
            // toolStripMenuItem138
            // 
            this.toolStripMenuItem138.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem139,
            this.toolStripMenuItem141});
            this.toolStripMenuItem138.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem138.Name = "toolStripMenuItem138";
            this.toolStripMenuItem138.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem138.Text = "Período Regencial";
            // 
            // toolStripMenuItem139
            // 
            this.toolStripMenuItem139.Name = "toolStripMenuItem139";
            this.toolStripMenuItem139.Size = new System.Drawing.Size(224, 26);
            this.toolStripMenuItem139.Text = "Período Regencial";
            this.toolStripMenuItem139.Click += new System.EventHandler(this.toolStripMenuItem139_Click);
            // 
            // toolStripMenuItem141
            // 
            this.toolStripMenuItem141.Name = "toolStripMenuItem141";
            this.toolStripMenuItem141.Size = new System.Drawing.Size(224, 26);
            this.toolStripMenuItem141.Text = "Revoltas Regenciais";
            this.toolStripMenuItem141.Click += new System.EventHandler(this.toolStripMenuItem141_Click);
            // 
            // toolStripMenuItem142
            // 
            this.toolStripMenuItem142.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem143,
            this.toolStripMenuItem145});
            this.toolStripMenuItem142.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem142.Name = "toolStripMenuItem142";
            this.toolStripMenuItem142.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem142.Text = "Segundo Reinado";
            // 
            // toolStripMenuItem143
            // 
            this.toolStripMenuItem143.Name = "toolStripMenuItem143";
            this.toolStripMenuItem143.Size = new System.Drawing.Size(210, 26);
            this.toolStripMenuItem143.Text = "Segundo Reinado";
            this.toolStripMenuItem143.Click += new System.EventHandler(this.toolStripMenuItem143_Click);
            // 
            // toolStripMenuItem145
            // 
            this.toolStripMenuItem145.Name = "toolStripMenuItem145";
            this.toolStripMenuItem145.Size = new System.Drawing.Size(210, 26);
            this.toolStripMenuItem145.Text = "Guerras do Prata";
            this.toolStripMenuItem145.Click += new System.EventHandler(this.toolStripMenuItem145_Click);
            // 
            // toolStripMenuItem146
            // 
            this.toolStripMenuItem146.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem147,
            this.toolStripMenuItem148});
            this.toolStripMenuItem146.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem146.Name = "toolStripMenuItem146";
            this.toolStripMenuItem146.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem146.Text = "A Crise do Segundo Reinado";
            // 
            // toolStripMenuItem147
            // 
            this.toolStripMenuItem147.Name = "toolStripMenuItem147";
            this.toolStripMenuItem147.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem147.Text = "Os partidos politicos no Brasil Império";
            this.toolStripMenuItem147.Click += new System.EventHandler(this.toolStripMenuItem147_Click);
            // 
            // toolStripMenuItem148
            // 
            this.toolStripMenuItem148.Name = "toolStripMenuItem148";
            this.toolStripMenuItem148.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem148.Text = "Leis Abolicionistas";
            this.toolStripMenuItem148.Click += new System.EventHandler(this.toolStripMenuItem148_Click);
            // 
            // toolStripMenuItem149
            // 
            this.toolStripMenuItem149.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem149.Name = "toolStripMenuItem149";
            this.toolStripMenuItem149.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem149.Text = "Proclamação da República";
            this.toolStripMenuItem149.Click += new System.EventHandler(this.toolStripMenuItem149_Click);
            // 
            // toolStripMenuItem150
            // 
            this.toolStripMenuItem150.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem152,
            this.toolStripMenuItem153});
            this.toolStripMenuItem150.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem150.Name = "toolStripMenuItem150";
            this.toolStripMenuItem150.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem150.Text = "A República Velha";
            // 
            // toolStripMenuItem152
            // 
            this.toolStripMenuItem152.Name = "toolStripMenuItem152";
            this.toolStripMenuItem152.Size = new System.Drawing.Size(239, 26);
            this.toolStripMenuItem152.Text = "República da Espada";
            this.toolStripMenuItem152.Click += new System.EventHandler(this.toolStripMenuItem152_Click);
            // 
            // toolStripMenuItem153
            // 
            this.toolStripMenuItem153.Name = "toolStripMenuItem153";
            this.toolStripMenuItem153.Size = new System.Drawing.Size(239, 26);
            this.toolStripMenuItem153.Text = "República Oligárquica";
            this.toolStripMenuItem153.Click += new System.EventHandler(this.toolStripMenuItem153_Click);
            // 
            // toolStripMenuItem154
            // 
            this.toolStripMenuItem154.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem155,
            this.toolStripMenuItem156,
            this.toolStripMenuItem157,
            this.toolStripMenuItem158,
            this.toolStripMenuItem159,
            this.toolStripMenuItem160,
            this.toolStripMenuItem161,
            this.toolStripMenuItem162,
            this.toolStripMenuItem163,
            this.toolStripMenuItem164,
            this.toolStripMenuItem165});
            this.toolStripMenuItem154.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem154.Name = "toolStripMenuItem154";
            this.toolStripMenuItem154.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem154.Text = "A Crise da Primeira República (os Anos 20)";
            // 
            // toolStripMenuItem155
            // 
            this.toolStripMenuItem155.Name = "toolStripMenuItem155";
            this.toolStripMenuItem155.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem155.Text = "Movimentos e Revoltas";
            this.toolStripMenuItem155.Click += new System.EventHandler(this.toolStripMenuItem155_Click);
            // 
            // toolStripMenuItem156
            // 
            this.toolStripMenuItem156.Name = "toolStripMenuItem156";
            this.toolStripMenuItem156.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem156.Text = "Revolta da Armada";
            this.toolStripMenuItem156.Click += new System.EventHandler(this.toolStripMenuItem156_Click);
            // 
            // toolStripMenuItem157
            // 
            this.toolStripMenuItem157.Name = "toolStripMenuItem157";
            this.toolStripMenuItem157.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem157.Text = "Revolta Federalista";
            this.toolStripMenuItem157.Click += new System.EventHandler(this.toolStripMenuItem157_Click);
            // 
            // toolStripMenuItem158
            // 
            this.toolStripMenuItem158.Name = "toolStripMenuItem158";
            this.toolStripMenuItem158.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem158.Text = "Revolta de Canudos";
            this.toolStripMenuItem158.Click += new System.EventHandler(this.toolStripMenuItem158_Click);
            // 
            // toolStripMenuItem159
            // 
            this.toolStripMenuItem159.Name = "toolStripMenuItem159";
            this.toolStripMenuItem159.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem159.Text = "Revolta da Vacina";
            this.toolStripMenuItem159.Click += new System.EventHandler(this.toolStripMenuItem159_Click);
            // 
            // toolStripMenuItem160
            // 
            this.toolStripMenuItem160.Name = "toolStripMenuItem160";
            this.toolStripMenuItem160.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem160.Text = "Revolta da Chibata";
            this.toolStripMenuItem160.Click += new System.EventHandler(this.toolStripMenuItem160_Click);
            // 
            // toolStripMenuItem161
            // 
            this.toolStripMenuItem161.Name = "toolStripMenuItem161";
            this.toolStripMenuItem161.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem161.Text = "Revolta de Juazeiro";
            this.toolStripMenuItem161.Click += new System.EventHandler(this.toolStripMenuItem161_Click);
            // 
            // toolStripMenuItem162
            // 
            this.toolStripMenuItem162.Name = "toolStripMenuItem162";
            this.toolStripMenuItem162.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem162.Text = "Revolta Contestado";
            this.toolStripMenuItem162.Click += new System.EventHandler(this.toolStripMenuItem162_Click);
            // 
            // toolStripMenuItem163
            // 
            this.toolStripMenuItem163.Name = "toolStripMenuItem163";
            this.toolStripMenuItem163.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem163.Text = "Revolução de 1923";
            this.toolStripMenuItem163.Click += new System.EventHandler(this.toolStripMenuItem163_Click);
            // 
            // toolStripMenuItem164
            // 
            this.toolStripMenuItem164.Name = "toolStripMenuItem164";
            this.toolStripMenuItem164.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem164.Text = "Movimento Operário";
            this.toolStripMenuItem164.Click += new System.EventHandler(this.toolStripMenuItem164_Click);
            // 
            // toolStripMenuItem165
            // 
            this.toolStripMenuItem165.Name = "toolStripMenuItem165";
            this.toolStripMenuItem165.Size = new System.Drawing.Size(251, 26);
            this.toolStripMenuItem165.Text = "Revolução de 1930";
            // 
            // toolStripMenuItem166
            // 
            this.toolStripMenuItem166.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem166.Name = "toolStripMenuItem166";
            this.toolStripMenuItem166.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem166.Text = "Era Vargas: Governo Provisório e Governo Constitucional";
            this.toolStripMenuItem166.Click += new System.EventHandler(this.toolStripMenuItem166_Click);
            // 
            // toolStripMenuItem169
            // 
            this.toolStripMenuItem169.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem169.Name = "toolStripMenuItem169";
            this.toolStripMenuItem169.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem169.Text = "Era Vargas: Estado Novo (1937-1945)";
            this.toolStripMenuItem169.Click += new System.EventHandler(this.toolStripMenuItem169_Click);
            // 
            // toolStripMenuItem171
            // 
            this.toolStripMenuItem171.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem172,
            this.toolStripMenuItem174,
            this.toolStripMenuItem175,
            this.toolStripMenuItem176,
            this.toolStripMenuItem178,
            this.toolStripMenuItem179,
            this.toolStripMenuItem180});
            this.toolStripMenuItem171.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem171.Name = "toolStripMenuItem171";
            this.toolStripMenuItem171.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem171.Text = "Período Democrático (1945-1964)";
            // 
            // toolStripMenuItem172
            // 
            this.toolStripMenuItem172.Name = "toolStripMenuItem172";
            this.toolStripMenuItem172.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem172.Text = "Populismo";
            this.toolStripMenuItem172.Click += new System.EventHandler(this.toolStripMenuItem172_Click);
            // 
            // toolStripMenuItem174
            // 
            this.toolStripMenuItem174.Name = "toolStripMenuItem174";
            this.toolStripMenuItem174.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem174.Text = "Governo Dutra";
            this.toolStripMenuItem174.Click += new System.EventHandler(this.toolStripMenuItem174_Click);
            // 
            // toolStripMenuItem175
            // 
            this.toolStripMenuItem175.Name = "toolStripMenuItem175";
            this.toolStripMenuItem175.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem175.Text = "Governo Vargas";
            this.toolStripMenuItem175.Click += new System.EventHandler(this.toolStripMenuItem175_Click);
            // 
            // toolStripMenuItem176
            // 
            this.toolStripMenuItem176.Name = "toolStripMenuItem176";
            this.toolStripMenuItem176.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem176.Text = "A morte de Vargas";
            this.toolStripMenuItem176.Click += new System.EventHandler(this.toolStripMenuItem176_Click);
            // 
            // toolStripMenuItem178
            // 
            this.toolStripMenuItem178.Name = "toolStripMenuItem178";
            this.toolStripMenuItem178.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem178.Text = "Governo JK";
            this.toolStripMenuItem178.Click += new System.EventHandler(this.toolStripMenuItem178_Click);
            // 
            // toolStripMenuItem179
            // 
            this.toolStripMenuItem179.Name = "toolStripMenuItem179";
            this.toolStripMenuItem179.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem179.Text = "Governo Jânio Quadros";
            this.toolStripMenuItem179.Click += new System.EventHandler(this.toolStripMenuItem179_Click);
            // 
            // toolStripMenuItem180
            // 
            this.toolStripMenuItem180.Name = "toolStripMenuItem180";
            this.toolStripMenuItem180.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem180.Text = "Governo João Goulart";
            this.toolStripMenuItem180.Click += new System.EventHandler(this.toolStripMenuItem180_Click);
            // 
            // toolStripMenuItem181
            // 
            this.toolStripMenuItem181.Name = "toolStripMenuItem181";
            this.toolStripMenuItem181.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem181.Text = "Movimento da Legalidade";
            this.toolStripMenuItem181.Click += new System.EventHandler(this.toolStripMenuItem181_Click);
            // 
            // toolStripMenuItem182
            // 
            this.toolStripMenuItem182.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem183,
            this.toolStripMenuItem185,
            this.toolStripMenuItem186,
            this.toolStripMenuItem187,
            this.toolStripMenuItem188,
            this.toolStripMenuItem189});
            this.toolStripMenuItem182.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem182.Name = "toolStripMenuItem182";
            this.toolStripMenuItem182.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem182.Text = "Regime Militar";
            // 
            // toolStripMenuItem183
            // 
            this.toolStripMenuItem183.Name = "toolStripMenuItem183";
            this.toolStripMenuItem183.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem183.Text = "Golpe de 1964";
            this.toolStripMenuItem183.Click += new System.EventHandler(this.toolStripMenuItem183_Click);
            // 
            // toolStripMenuItem185
            // 
            this.toolStripMenuItem185.Name = "toolStripMenuItem185";
            this.toolStripMenuItem185.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem185.Text = "Governo Castelo Branco";
            this.toolStripMenuItem185.Click += new System.EventHandler(this.toolStripMenuItem185_Click);
            // 
            // toolStripMenuItem186
            // 
            this.toolStripMenuItem186.Name = "toolStripMenuItem186";
            this.toolStripMenuItem186.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem186.Text = "Governo Costa e Silva";
            this.toolStripMenuItem186.Click += new System.EventHandler(this.toolStripMenuItem186_Click);
            // 
            // toolStripMenuItem187
            // 
            this.toolStripMenuItem187.Name = "toolStripMenuItem187";
            this.toolStripMenuItem187.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem187.Text = "Governo Médici";
            this.toolStripMenuItem187.Click += new System.EventHandler(this.toolStripMenuItem187_Click);
            // 
            // toolStripMenuItem188
            // 
            this.toolStripMenuItem188.Name = "toolStripMenuItem188";
            this.toolStripMenuItem188.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem188.Text = "Governo Geisel";
            this.toolStripMenuItem188.Click += new System.EventHandler(this.toolStripMenuItem188_Click);
            // 
            // toolStripMenuItem189
            // 
            this.toolStripMenuItem189.Name = "toolStripMenuItem189";
            this.toolStripMenuItem189.Size = new System.Drawing.Size(256, 26);
            this.toolStripMenuItem189.Text = "Governo Figueiredo";
            // 
            // toolStripMenuItem190
            // 
            this.toolStripMenuItem190.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem190.Name = "toolStripMenuItem190";
            this.toolStripMenuItem190.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem190.Text = "Diretas Já";
            this.toolStripMenuItem190.Click += new System.EventHandler(this.toolStripMenuItem190_Click);
            // 
            // toolStripMenuItem191
            // 
            this.toolStripMenuItem191.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem191.Name = "toolStripMenuItem191";
            this.toolStripMenuItem191.Size = new System.Drawing.Size(491, 26);
            this.toolStripMenuItem191.Text = "A nova Replública";
            this.toolStripMenuItem191.Click += new System.EventHandler(this.toolStripMenuItem191_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(126, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(910, 612);
            this.sfoPlayer.TabIndex = 61;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(126, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(910, 612);
            this.PictureCSharp.TabIndex = 62;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(126, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(910, 612);
            this.panelQuiz.TabIndex = 65;
            // 
            // FrmHist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmHist";
            this.Text = "FrmHist";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.ToolStripMenuItem históriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem históriaDaAméricaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem expansãoMarítimaEComercialEuropeiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aConquistaDaAméricaEOsPovosPréColombianosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colonizaçãoEspanholaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem construçãoDoEstadoNorteAmericanoAIndependênciaDasTrezeColôniasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estaodsUnidosNoSéculoXIXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem criseDe1929ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estadosUnidosPósSegundaGuerraMundialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regimesMilitaresETransiçãoDemocráticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aRevoluçãoCubanaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aRevoluçãoMexicanaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçõesNaAméricaLatinaChileENicaráguaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem independênciaDaAméricaLatinaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estadosNacionaisLatinosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem populismoNaAméricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem américaAtualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem históriaDoBrasilToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aMontagemDoSistemaColonialNoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aAdministraçãoColonialEAExpansãoTerritorialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aCriseDoSistemaColonialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem primeiroReinadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoRegencialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem segundoReinadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aCriseDoSegundoReinadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aReúblicaVelhaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aCriseDaPrimeiraRepúblicaosAnos20ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNovaReplúblicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eraVargasEstadoNovo19371945ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eraVargasGovernoProvisórioEGovernoConstitucionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regimeMilitarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem históriaGeralToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoAoEstudoHistóricoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem antiguidadeClássicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem idadeMédiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aBaixaIdadeMédiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem absolutismoMonárquicoEuropeuEMercantilismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçõesInglesasDoSéculoXVIIEIluminismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoFrancesaEEraNapoleônicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoIndustrialEIdeiasSociaisDoSéculoXIXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imperialismoEPrimeiraGuerraMundialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoEntreGuerrasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem segundaGuerraMundialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guerraFriaEDescolonizaçãoAfroAsiáticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mundoAtualToolStripMenuItem;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem linhaDoTempoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem préHistóriaDefiniçãoEEstudoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mesopotâmiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gréciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem romaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impérioBizantinoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impérioDosFrancosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem civilizaçãoIslâmicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feudalismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cruzadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renascimentoComercialEUrbanoFatoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pesteNegraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem monarquiasNacionaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem igrejaMedievalInquisiçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renascimentoCulturalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reformaProtestanteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem absolutismoEMercantilismoIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem absolutismoEMercantilismoIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expansãoMarítimaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aConquistaDaAméricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iluminismoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem séculoXVIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dinastiaStuartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem absolutismoNaInglaterraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visãoAlémDoAlcanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem economiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anglicanosEPuritanosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reiXParlamentoEAGuerraCivilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem repúblicaPuritanaERevoluçãoGloriosaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoFrancesaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoFrancesaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoNapoleônicoIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoNapoleônicoIiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem primeiraFaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doutrinasDoSéculoXIXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçõesLiberaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem segundaRevoluçãoIndustrialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imperialismoNeocolonialismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem áfricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eurocentrismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem primeiraGuerraMundialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem primeiraGuerraMundialParticipaçãoBrasileiraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tratadoDeVersalhesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoRussaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoRussaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trotskyXStalinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem criseDe1929ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem regimesTotalitáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fascismoItalianoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem históriaNazismoAlemãoIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem históriaNazismoAlemãoIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parteIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoÀGuerraFriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conflitosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oBrasilNaGuerraFriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descolonizaçãoDaÁfricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uRSSESeusEstadistasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quedaDoMuroDeBerlimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoChinesaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guerrasDaCoreiaEVietnãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conflitosNoOrienteMédioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quedaDaURSSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem direitosHumanosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conquistaDaAméricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maiasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aSTECASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colonizaçãoInglesaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoAmericanaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expansãoDosEUAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guerraDeSecessãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estadosUnidosNoSéculoXIXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ditadurasDaAMÉRICALATINAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formaçãoDosEstadosNacionaisIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formaçãoDosEstadosNacionaisIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descobrimentoDoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem préHistóriaNoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoPréColonialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ciclosEconômicosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem capitaniasHereditáriasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governosGeraisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem economiaDoAçúcarColonialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uniãoIbéricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem presençaHolandesaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem economiaMineradoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem escravidãoNoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociedadesQuilombolasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bandeirantismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem criseDoSistemaColonialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inconfidênciaMineiraEConjuraçãoBaianaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inconfidênciaMineiraEConjuraçãoBaianaIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revisãoDoPeríodoColonialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoJoaninoIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoJoaninoIToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem períodoJoaninoIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem independênciaDoBrasilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem primeiroReinadoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem períodoRegencialParteIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoRegencialParteIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaRegenciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem segundoReinadoParteIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem segundoReinadoParteIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guerrasDoPrataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem osPartidosPoliticosNoBrasilImpérioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leisAbolicionistasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oProcessoDeIndependênciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem repúblicaDaEspadaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem repúblicaOligárquicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentosERevoltasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaDaArmadaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaFederalistaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaDeCanudosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaDaVacinaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaDaChibataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaDeJuazeiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoltaContestadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoDe1923ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoOperárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revoluçãoDe1930ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem eraVargasIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eraVargasIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem períodoDemocrático19451964ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem populismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eríodoDemocráticoPopulistaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoDutraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoVargasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aMorteDeVargasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transiçãoDeVargasParaJKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoJKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoJânioQuadrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoJoãoGoulartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoDaLegalidadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem golpeDe1964ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linhaDoTempoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem governoCasteloBrancoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoCostaESilvaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoMédiciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoGeiselToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem governoFigueiredoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diretasJáToolStripMenuItem;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem53;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem58;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem59;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem61;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem62;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem63;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem65;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem70;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem71;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem72;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem73;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem74;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem75;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem76;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem77;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem79;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem80;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem82;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem83;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem84;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem85;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem86;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem87;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem88;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem89;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem90;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem91;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem92;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem93;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem94;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem95;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem98;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem99;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem100;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem101;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem102;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem103;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem104;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem105;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem106;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem109;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem110;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem111;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem112;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem113;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem114;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem115;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem116;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem117;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem118;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem120;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem121;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem122;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem123;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem124;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem125;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem126;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem127;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem128;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem129;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem131;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem132;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem135;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem136;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem137;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem138;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem139;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem141;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem142;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem143;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem145;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem146;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem147;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem148;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem149;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem150;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem152;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem153;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem154;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem155;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem156;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem157;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem158;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem159;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem160;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem161;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem162;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem163;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem164;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem165;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem166;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem169;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem171;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem172;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem174;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem175;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem176;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem178;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem179;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem180;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem181;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem182;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem183;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem185;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem186;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem187;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem188;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem189;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem190;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem191;
    }
}