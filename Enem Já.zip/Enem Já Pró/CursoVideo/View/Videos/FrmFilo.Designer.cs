﻿namespace CursoVideo.View.Videos
{
    partial class FrmFilo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFilo));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fecharMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cursoEmVídeoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filosofiaMoralToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grátisIntroduçãoÀFilosofiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moralÉticaELeiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.éticaMoralEValoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sócratesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.platãoPolíticaDialéticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aTeoriaDasIdeiasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aristótelesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.éticaHelênicaEMoralCristãToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filosofiasHelenísticasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filosofiaMedievalISantoAgostinhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.éticaHelênicaEMoralCristãToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.éticaDeontológicaEConsequencialistaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.éticaContemporâneaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filosofiaPolíticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociedadeEstadoEGovernoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relaçõesDePoderFoucaultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foucaultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relaçõesDePoderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.democraciaELiberdadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDemocraciaGregaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.políticaGregaPlatãoEAristótelesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oSURGIMENTODAPOLÍTICAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maquiavelManutençãoDoPoderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contratoSocialHobbesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contratoSocialLockeERousseauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.johnLockeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iluminismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rousseauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marxismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.karlMarxParteIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.karlMarxParteIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feminismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teoriaDoConhecimentoEpistemologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoTeoriaDoConhecimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.racionalismoEEmpirismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renéDescartesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.francisBaconToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiposDeConhecimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mitoDaCavernaPlatãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oSerOMovimentoEAsVirtudesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.racionalismoModernoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empirismoModernoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.davidHumeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.georgeBerkeleyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kantEOCriticismoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.immanuelKantParteIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.immanuelKantParteIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharMenuItem,
            this.cursoEmVídeoToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(122, 612);
            this.menuStrip1.TabIndex = 37;
            // 
            // fecharMenuItem
            // 
            this.fecharMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.fecharMenuItem.BackColor = System.Drawing.SystemColors.ControlLight;
            this.fecharMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharMenuItem.Image")));
            this.fecharMenuItem.Name = "fecharMenuItem";
            this.fecharMenuItem.Size = new System.Drawing.Size(109, 39);
            this.fecharMenuItem.Text = "FECHAR";
            this.fecharMenuItem.Click += new System.EventHandler(this.fecharMenuItem_Click);
            // 
            // cursoEmVídeoToolStripMenuItem
            // 
            this.cursoEmVídeoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filosofiaMoralToolStripMenuItem,
            this.filosofiaPolíticaToolStripMenuItem,
            this.teoriaDoConhecimentoEpistemologiaToolStripMenuItem});
            this.cursoEmVídeoToolStripMenuItem.Name = "cursoEmVídeoToolStripMenuItem";
            this.cursoEmVídeoToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.cursoEmVídeoToolStripMenuItem.Text = "Filosofia";
            // 
            // filosofiaMoralToolStripMenuItem
            // 
            this.filosofiaMoralToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.grátisIntroduçãoÀFilosofiaToolStripMenuItem,
            this.moralÉticaELeiToolStripMenuItem,
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem,
            this.éticaHelênicaEMoralCristãToolStripMenuItem,
            this.éticaDeontológicaEConsequencialistaToolStripMenuItem,
            this.éticaContemporâneaToolStripMenuItem});
            this.filosofiaMoralToolStripMenuItem.Name = "filosofiaMoralToolStripMenuItem";
            this.filosofiaMoralToolStripMenuItem.Size = new System.Drawing.Size(377, 26);
            this.filosofiaMoralToolStripMenuItem.Text = "Filosofia Moral";
            // 
            // grátisIntroduçãoÀFilosofiaToolStripMenuItem
            // 
            this.grátisIntroduçãoÀFilosofiaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.grátisIntroduçãoÀFilosofiaToolStripMenuItem.Name = "grátisIntroduçãoÀFilosofiaToolStripMenuItem";
            this.grátisIntroduçãoÀFilosofiaToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.grátisIntroduçãoÀFilosofiaToolStripMenuItem.Text = "Introdução à Filosofia";
            this.grátisIntroduçãoÀFilosofiaToolStripMenuItem.Click += new System.EventHandler(this.grátisIntroduçãoÀFilosofiaToolStripMenuItem_Click);
            // 
            // moralÉticaELeiToolStripMenuItem
            // 
            this.moralÉticaELeiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.éticaMoralEValoresToolStripMenuItem});
            this.moralÉticaELeiToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.moralÉticaELeiToolStripMenuItem.Name = "moralÉticaELeiToolStripMenuItem";
            this.moralÉticaELeiToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.moralÉticaELeiToolStripMenuItem.Text = "Moral, Ética e Lei";
            this.moralÉticaELeiToolStripMenuItem.Click += new System.EventHandler(this.moralÉticaELeiToolStripMenuItem_Click);
            // 
            // éticaMoralEValoresToolStripMenuItem
            // 
            this.éticaMoralEValoresToolStripMenuItem.Name = "éticaMoralEValoresToolStripMenuItem";
            this.éticaMoralEValoresToolStripMenuItem.Size = new System.Drawing.Size(235, 26);
            this.éticaMoralEValoresToolStripMenuItem.Text = "Ética, Moral e Valores";
            this.éticaMoralEValoresToolStripMenuItem.Click += new System.EventHandler(this.éticaMoralEValoresToolStripMenuItem_Click);
            // 
            // moralGregaSócratesPlatãoEAristótelesToolStripMenuItem
            // 
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sócratesToolStripMenuItem,
            this.platãoPolíticaDialéticaToolStripMenuItem,
            this.aTeoriaDasIdeiasToolStripMenuItem,
            this.aristótelesToolStripMenuItem});
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem.Name = "moralGregaSócratesPlatãoEAristótelesToolStripMenuItem";
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem.Text = "Moral Grega – Sócrates, Platão e Aristóteles";
            this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem.Click += new System.EventHandler(this.moralGregaSócratesPlatãoEAristótelesToolStripMenuItem_Click);
            // 
            // sócratesToolStripMenuItem
            // 
            this.sócratesToolStripMenuItem.Name = "sócratesToolStripMenuItem";
            this.sócratesToolStripMenuItem.Size = new System.Drawing.Size(254, 26);
            this.sócratesToolStripMenuItem.Text = "Sócrates";
            this.sócratesToolStripMenuItem.Click += new System.EventHandler(this.sócratesToolStripMenuItem_Click);
            // 
            // platãoPolíticaDialéticaToolStripMenuItem
            // 
            this.platãoPolíticaDialéticaToolStripMenuItem.Name = "platãoPolíticaDialéticaToolStripMenuItem";
            this.platãoPolíticaDialéticaToolStripMenuItem.Size = new System.Drawing.Size(254, 26);
            this.platãoPolíticaDialéticaToolStripMenuItem.Text = "Platão: Política/Dialética";
            this.platãoPolíticaDialéticaToolStripMenuItem.Click += new System.EventHandler(this.platãoPolíticaDialéticaToolStripMenuItem_Click);
            // 
            // aTeoriaDasIdeiasToolStripMenuItem
            // 
            this.aTeoriaDasIdeiasToolStripMenuItem.Name = "aTeoriaDasIdeiasToolStripMenuItem";
            this.aTeoriaDasIdeiasToolStripMenuItem.Size = new System.Drawing.Size(254, 26);
            this.aTeoriaDasIdeiasToolStripMenuItem.Text = "A Teoria das Ideias";
            this.aTeoriaDasIdeiasToolStripMenuItem.Click += new System.EventHandler(this.aTeoriaDasIdeiasToolStripMenuItem_Click);
            // 
            // aristótelesToolStripMenuItem
            // 
            this.aristótelesToolStripMenuItem.Name = "aristótelesToolStripMenuItem";
            this.aristótelesToolStripMenuItem.Size = new System.Drawing.Size(254, 26);
            this.aristótelesToolStripMenuItem.Text = "Aristóteles";
            this.aristótelesToolStripMenuItem.Click += new System.EventHandler(this.aristótelesToolStripMenuItem_Click);
            // 
            // éticaHelênicaEMoralCristãToolStripMenuItem
            // 
            this.éticaHelênicaEMoralCristãToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filosofiasHelenísticasToolStripMenuItem,
            this.filosofiaMedievalISantoAgostinhoToolStripMenuItem,
            this.filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem,
            this.éticaHelênicaEMoralCristãToolStripMenuItem1});
            this.éticaHelênicaEMoralCristãToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.éticaHelênicaEMoralCristãToolStripMenuItem.Name = "éticaHelênicaEMoralCristãToolStripMenuItem";
            this.éticaHelênicaEMoralCristãToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.éticaHelênicaEMoralCristãToolStripMenuItem.Text = "Ética Helênica e Moral Cristã";
            this.éticaHelênicaEMoralCristãToolStripMenuItem.Click += new System.EventHandler(this.éticaHelênicaEMoralCristãToolStripMenuItem_Click);
            // 
            // filosofiasHelenísticasToolStripMenuItem
            // 
            this.filosofiasHelenísticasToolStripMenuItem.Name = "filosofiasHelenísticasToolStripMenuItem";
            this.filosofiasHelenísticasToolStripMenuItem.Size = new System.Drawing.Size(391, 26);
            this.filosofiasHelenísticasToolStripMenuItem.Text = "Filosofias Helenísticas";
            this.filosofiasHelenísticasToolStripMenuItem.Click += new System.EventHandler(this.filosofiasHelenísticasToolStripMenuItem_Click);
            // 
            // filosofiaMedievalISantoAgostinhoToolStripMenuItem
            // 
            this.filosofiaMedievalISantoAgostinhoToolStripMenuItem.Name = "filosofiaMedievalISantoAgostinhoToolStripMenuItem";
            this.filosofiaMedievalISantoAgostinhoToolStripMenuItem.Size = new System.Drawing.Size(391, 26);
            this.filosofiaMedievalISantoAgostinhoToolStripMenuItem.Text = "Filosofia Medieval I: Santo Agostinho";
            this.filosofiaMedievalISantoAgostinhoToolStripMenuItem.Click += new System.EventHandler(this.filosofiaMedievalISantoAgostinhoToolStripMenuItem_Click);
            // 
            // filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem
            // 
            this.filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem.Name = "filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem";
            this.filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem.Size = new System.Drawing.Size(391, 26);
            this.filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem.Text = "Filosofia Medieval II: São Tomás de Aquino";
            this.filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem.Click += new System.EventHandler(this.filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem_Click);
            // 
            // éticaHelênicaEMoralCristãToolStripMenuItem1
            // 
            this.éticaHelênicaEMoralCristãToolStripMenuItem1.Name = "éticaHelênicaEMoralCristãToolStripMenuItem1";
            this.éticaHelênicaEMoralCristãToolStripMenuItem1.Size = new System.Drawing.Size(391, 26);
            this.éticaHelênicaEMoralCristãToolStripMenuItem1.Text = "Ética Helênica e Moral Cristã";
            this.éticaHelênicaEMoralCristãToolStripMenuItem1.Click += new System.EventHandler(this.éticaHelênicaEMoralCristãToolStripMenuItem1_Click);
            // 
            // éticaDeontológicaEConsequencialistaToolStripMenuItem
            // 
            this.éticaDeontológicaEConsequencialistaToolStripMenuItem.Name = "éticaDeontológicaEConsequencialistaToolStripMenuItem";
            this.éticaDeontológicaEConsequencialistaToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.éticaDeontológicaEConsequencialistaToolStripMenuItem.Text = "Ética Deontológica e Consequencialista";
            this.éticaDeontológicaEConsequencialistaToolStripMenuItem.Click += new System.EventHandler(this.éticaDeontológicaEConsequencialistaToolStripMenuItem_Click);
            // 
            // éticaContemporâneaToolStripMenuItem
            // 
            this.éticaContemporâneaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.éticaContemporâneaToolStripMenuItem.Name = "éticaContemporâneaToolStripMenuItem";
            this.éticaContemporâneaToolStripMenuItem.Size = new System.Drawing.Size(399, 26);
            this.éticaContemporâneaToolStripMenuItem.Text = "Ética Contemporânea";
            this.éticaContemporâneaToolStripMenuItem.Click += new System.EventHandler(this.éticaContemporâneaToolStripMenuItem_Click);
            // 
            // filosofiaPolíticaToolStripMenuItem
            // 
            this.filosofiaPolíticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sociedadeEstadoEGovernoToolStripMenuItem,
            this.relaçõesDePoderFoucaultToolStripMenuItem,
            this.democraciaELiberdadeToolStripMenuItem,
            this.políticaGregaPlatãoEAristótelesToolStripMenuItem,
            this.maquiavelManutençãoDoPoderToolStripMenuItem,
            this.contratoSocialHobbesToolStripMenuItem,
            this.contratoSocialLockeERousseauToolStripMenuItem,
            this.marxismoToolStripMenuItem,
            this.feminismoToolStripMenuItem});
            this.filosofiaPolíticaToolStripMenuItem.Name = "filosofiaPolíticaToolStripMenuItem";
            this.filosofiaPolíticaToolStripMenuItem.Size = new System.Drawing.Size(377, 26);
            this.filosofiaPolíticaToolStripMenuItem.Text = "Filosofia Política";
            // 
            // sociedadeEstadoEGovernoToolStripMenuItem
            // 
            this.sociedadeEstadoEGovernoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.sociedadeEstadoEGovernoToolStripMenuItem.Name = "sociedadeEstadoEGovernoToolStripMenuItem";
            this.sociedadeEstadoEGovernoToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.sociedadeEstadoEGovernoToolStripMenuItem.Text = "Sociedade, Estado e Governo";
            // 
            // relaçõesDePoderFoucaultToolStripMenuItem
            // 
            this.relaçõesDePoderFoucaultToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.foucaultToolStripMenuItem,
            this.relaçõesDePoderToolStripMenuItem});
            this.relaçõesDePoderFoucaultToolStripMenuItem.Name = "relaçõesDePoderFoucaultToolStripMenuItem";
            this.relaçõesDePoderFoucaultToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.relaçõesDePoderFoucaultToolStripMenuItem.Text = "Relações de Poder - Foucault";
            // 
            // foucaultToolStripMenuItem
            // 
            this.foucaultToolStripMenuItem.Name = "foucaultToolStripMenuItem";
            this.foucaultToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.foucaultToolStripMenuItem.Text = "Foucault";
            this.foucaultToolStripMenuItem.Click += new System.EventHandler(this.foucaultToolStripMenuItem_Click);
            // 
            // relaçõesDePoderToolStripMenuItem
            // 
            this.relaçõesDePoderToolStripMenuItem.Name = "relaçõesDePoderToolStripMenuItem";
            this.relaçõesDePoderToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.relaçõesDePoderToolStripMenuItem.Text = "Relações de Poder";
            this.relaçõesDePoderToolStripMenuItem.Click += new System.EventHandler(this.relaçõesDePoderToolStripMenuItem_Click);
            // 
            // democraciaELiberdadeToolStripMenuItem
            // 
            this.democraciaELiberdadeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDemocraciaGregaToolStripMenuItem});
            this.democraciaELiberdadeToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.democraciaELiberdadeToolStripMenuItem.Name = "democraciaELiberdadeToolStripMenuItem";
            this.democraciaELiberdadeToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.democraciaELiberdadeToolStripMenuItem.Text = "Democracia e Liberdade";
            // 
            // aDemocraciaGregaToolStripMenuItem
            // 
            this.aDemocraciaGregaToolStripMenuItem.Name = "aDemocraciaGregaToolStripMenuItem";
            this.aDemocraciaGregaToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.aDemocraciaGregaToolStripMenuItem.Text = "A Democracia Grega";
            this.aDemocraciaGregaToolStripMenuItem.Click += new System.EventHandler(this.aDemocraciaGregaToolStripMenuItem_Click);
            // 
            // políticaGregaPlatãoEAristótelesToolStripMenuItem
            // 
            this.políticaGregaPlatãoEAristótelesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oSURGIMENTODAPOLÍTICAToolStripMenuItem});
            this.políticaGregaPlatãoEAristótelesToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.políticaGregaPlatãoEAristótelesToolStripMenuItem.Name = "políticaGregaPlatãoEAristótelesToolStripMenuItem";
            this.políticaGregaPlatãoEAristótelesToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.políticaGregaPlatãoEAristótelesToolStripMenuItem.Text = "Política Grega (Platão e Aristóteles)";
            // 
            // oSURGIMENTODAPOLÍTICAToolStripMenuItem
            // 
            this.oSURGIMENTODAPOLÍTICAToolStripMenuItem.Name = "oSURGIMENTODAPOLÍTICAToolStripMenuItem";
            this.oSURGIMENTODAPOLÍTICAToolStripMenuItem.Size = new System.Drawing.Size(260, 26);
            this.oSURGIMENTODAPOLÍTICAToolStripMenuItem.Text = "O Surgimento da Política";
            this.oSURGIMENTODAPOLÍTICAToolStripMenuItem.Click += new System.EventHandler(this.oSURGIMENTODAPOLÍTICAToolStripMenuItem_Click);
            // 
            // maquiavelManutençãoDoPoderToolStripMenuItem
            // 
            this.maquiavelManutençãoDoPoderToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.maquiavelManutençãoDoPoderToolStripMenuItem.Name = "maquiavelManutençãoDoPoderToolStripMenuItem";
            this.maquiavelManutençãoDoPoderToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.maquiavelManutençãoDoPoderToolStripMenuItem.Text = "Maquiavel - Manutenção do Poder";
            this.maquiavelManutençãoDoPoderToolStripMenuItem.Click += new System.EventHandler(this.maquiavelManutençãoDoPoderToolStripMenuItem_Click);
            // 
            // contratoSocialHobbesToolStripMenuItem
            // 
            this.contratoSocialHobbesToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.contratoSocialHobbesToolStripMenuItem.Name = "contratoSocialHobbesToolStripMenuItem";
            this.contratoSocialHobbesToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.contratoSocialHobbesToolStripMenuItem.Text = "Contrato social - Hobbes";
            this.contratoSocialHobbesToolStripMenuItem.Click += new System.EventHandler(this.contratoSocialHobbesToolStripMenuItem_Click);
            // 
            // contratoSocialLockeERousseauToolStripMenuItem
            // 
            this.contratoSocialLockeERousseauToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.johnLockeToolStripMenuItem,
            this.iluminismoToolStripMenuItem,
            this.rousseauToolStripMenuItem});
            this.contratoSocialLockeERousseauToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.contratoSocialLockeERousseauToolStripMenuItem.Name = "contratoSocialLockeERousseauToolStripMenuItem";
            this.contratoSocialLockeERousseauToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.contratoSocialLockeERousseauToolStripMenuItem.Text = "Contrato social - Locke e Rousseau";
            // 
            // johnLockeToolStripMenuItem
            // 
            this.johnLockeToolStripMenuItem.Name = "johnLockeToolStripMenuItem";
            this.johnLockeToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.johnLockeToolStripMenuItem.Text = "John Locke";
            this.johnLockeToolStripMenuItem.Click += new System.EventHandler(this.johnLockeToolStripMenuItem_Click);
            // 
            // iluminismoToolStripMenuItem
            // 
            this.iluminismoToolStripMenuItem.Name = "iluminismoToolStripMenuItem";
            this.iluminismoToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.iluminismoToolStripMenuItem.Text = "Iluminismo";
            this.iluminismoToolStripMenuItem.Click += new System.EventHandler(this.iluminismoToolStripMenuItem_Click);
            // 
            // rousseauToolStripMenuItem
            // 
            this.rousseauToolStripMenuItem.Name = "rousseauToolStripMenuItem";
            this.rousseauToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.rousseauToolStripMenuItem.Text = "Rousseau";
            this.rousseauToolStripMenuItem.Click += new System.EventHandler(this.rousseauToolStripMenuItem_Click);
            // 
            // marxismoToolStripMenuItem
            // 
            this.marxismoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.karlMarxParteIToolStripMenuItem,
            this.karlMarxParteIIToolStripMenuItem});
            this.marxismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.marxismoToolStripMenuItem.Name = "marxismoToolStripMenuItem";
            this.marxismoToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.marxismoToolStripMenuItem.Text = "Marxismo ";
            // 
            // karlMarxParteIToolStripMenuItem
            // 
            this.karlMarxParteIToolStripMenuItem.Name = "karlMarxParteIToolStripMenuItem";
            this.karlMarxParteIToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.karlMarxParteIToolStripMenuItem.Text = "Karl Marx - Parte I";
            this.karlMarxParteIToolStripMenuItem.Click += new System.EventHandler(this.karlMarxParteIToolStripMenuItem_Click);
            // 
            // karlMarxParteIIToolStripMenuItem
            // 
            this.karlMarxParteIIToolStripMenuItem.Name = "karlMarxParteIIToolStripMenuItem";
            this.karlMarxParteIIToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.karlMarxParteIIToolStripMenuItem.Text = "Karl Marx - Parte II";
            this.karlMarxParteIIToolStripMenuItem.Click += new System.EventHandler(this.karlMarxParteIIToolStripMenuItem_Click);
            // 
            // feminismoToolStripMenuItem
            // 
            this.feminismoToolStripMenuItem.Name = "feminismoToolStripMenuItem";
            this.feminismoToolStripMenuItem.Size = new System.Drawing.Size(335, 26);
            this.feminismoToolStripMenuItem.Text = "Feminismo";
            this.feminismoToolStripMenuItem.Click += new System.EventHandler(this.feminismoToolStripMenuItem_Click);
            // 
            // teoriaDoConhecimentoEpistemologiaToolStripMenuItem
            // 
            this.teoriaDoConhecimentoEpistemologiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoTeoriaDoConhecimentoToolStripMenuItem,
            this.racionalismoEEmpirismoToolStripMenuItem,
            this.tiposDeConhecimentoToolStripMenuItem,
            this.mitoDaCavernaPlatãoToolStripMenuItem,
            this.teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem,
            this.racionalismoModernoToolStripMenuItem,
            this.empirismoModernoToolStripMenuItem,
            this.kantEOCriticismoToolStripMenuItem});
            this.teoriaDoConhecimentoEpistemologiaToolStripMenuItem.Name = "teoriaDoConhecimentoEpistemologiaToolStripMenuItem";
            this.teoriaDoConhecimentoEpistemologiaToolStripMenuItem.Size = new System.Drawing.Size(377, 26);
            this.teoriaDoConhecimentoEpistemologiaToolStripMenuItem.Text = "Teoria do Conhecimento - Epistemologia";
            // 
            // introduçãoTeoriaDoConhecimentoToolStripMenuItem
            // 
            this.introduçãoTeoriaDoConhecimentoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.introduçãoTeoriaDoConhecimentoToolStripMenuItem.Name = "introduçãoTeoriaDoConhecimentoToolStripMenuItem";
            this.introduçãoTeoriaDoConhecimentoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.introduçãoTeoriaDoConhecimentoToolStripMenuItem.Text = "Introdução - Teoria do conhecimento";
            this.introduçãoTeoriaDoConhecimentoToolStripMenuItem.Click += new System.EventHandler(this.introduçãoTeoriaDoConhecimentoToolStripMenuItem_Click);
            // 
            // racionalismoEEmpirismoToolStripMenuItem
            // 
            this.racionalismoEEmpirismoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.renéDescartesToolStripMenuItem,
            this.francisBaconToolStripMenuItem});
            this.racionalismoEEmpirismoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.racionalismoEEmpirismoToolStripMenuItem.Name = "racionalismoEEmpirismoToolStripMenuItem";
            this.racionalismoEEmpirismoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.racionalismoEEmpirismoToolStripMenuItem.Text = "Racionalismo e Empirismo";
            // 
            // renéDescartesToolStripMenuItem
            // 
            this.renéDescartesToolStripMenuItem.Name = "renéDescartesToolStripMenuItem";
            this.renéDescartesToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.renéDescartesToolStripMenuItem.Text = "René Descartes";
            this.renéDescartesToolStripMenuItem.Click += new System.EventHandler(this.renéDescartesToolStripMenuItem_Click);
            // 
            // francisBaconToolStripMenuItem
            // 
            this.francisBaconToolStripMenuItem.Name = "francisBaconToolStripMenuItem";
            this.francisBaconToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.francisBaconToolStripMenuItem.Text = "Francis Bacon";
            this.francisBaconToolStripMenuItem.Click += new System.EventHandler(this.francisBaconToolStripMenuItem_Click);
            // 
            // tiposDeConhecimentoToolStripMenuItem
            // 
            this.tiposDeConhecimentoToolStripMenuItem.Name = "tiposDeConhecimentoToolStripMenuItem";
            this.tiposDeConhecimentoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.tiposDeConhecimentoToolStripMenuItem.Text = "Tipos de Conhecimento";
            // 
            // mitoDaCavernaPlatãoToolStripMenuItem
            // 
            this.mitoDaCavernaPlatãoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.mitoDaCavernaPlatãoToolStripMenuItem.Name = "mitoDaCavernaPlatãoToolStripMenuItem";
            this.mitoDaCavernaPlatãoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.mitoDaCavernaPlatãoToolStripMenuItem.Text = "Mito da Caverna - Platão";
            // 
            // teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem
            // 
            this.teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oSerOMovimentoEAsVirtudesToolStripMenuItem});
            this.teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem.Name = "teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem";
            this.teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem.Text = "Teoria das Causas – Empirismo Aristotélico ";
            // 
            // oSerOMovimentoEAsVirtudesToolStripMenuItem
            // 
            this.oSerOMovimentoEAsVirtudesToolStripMenuItem.Name = "oSerOMovimentoEAsVirtudesToolStripMenuItem";
            this.oSerOMovimentoEAsVirtudesToolStripMenuItem.Size = new System.Drawing.Size(320, 26);
            this.oSerOMovimentoEAsVirtudesToolStripMenuItem.Text = "O Ser, o movimento e as virtudes";
            this.oSerOMovimentoEAsVirtudesToolStripMenuItem.Click += new System.EventHandler(this.oSerOMovimentoEAsVirtudesToolStripMenuItem_Click);
            // 
            // racionalismoModernoToolStripMenuItem
            // 
            this.racionalismoModernoToolStripMenuItem.Name = "racionalismoModernoToolStripMenuItem";
            this.racionalismoModernoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.racionalismoModernoToolStripMenuItem.Text = "Racionalismo Moderno";
            this.racionalismoModernoToolStripMenuItem.Click += new System.EventHandler(this.racionalismoModernoToolStripMenuItem_Click);
            // 
            // empirismoModernoToolStripMenuItem
            // 
            this.empirismoModernoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.davidHumeToolStripMenuItem,
            this.georgeBerkeleyToolStripMenuItem});
            this.empirismoModernoToolStripMenuItem.Name = "empirismoModernoToolStripMenuItem";
            this.empirismoModernoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.empirismoModernoToolStripMenuItem.Text = "Empirismo Moderno";
            // 
            // davidHumeToolStripMenuItem
            // 
            this.davidHumeToolStripMenuItem.Name = "davidHumeToolStripMenuItem";
            this.davidHumeToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.davidHumeToolStripMenuItem.Text = "David Hume";
            this.davidHumeToolStripMenuItem.Click += new System.EventHandler(this.davidHumeToolStripMenuItem_Click);
            // 
            // georgeBerkeleyToolStripMenuItem
            // 
            this.georgeBerkeleyToolStripMenuItem.Name = "georgeBerkeleyToolStripMenuItem";
            this.georgeBerkeleyToolStripMenuItem.Size = new System.Drawing.Size(202, 26);
            this.georgeBerkeleyToolStripMenuItem.Text = "George Berkeley";
            this.georgeBerkeleyToolStripMenuItem.Click += new System.EventHandler(this.georgeBerkeleyToolStripMenuItem_Click);
            // 
            // kantEOCriticismoToolStripMenuItem
            // 
            this.kantEOCriticismoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.immanuelKantParteIToolStripMenuItem,
            this.immanuelKantParteIIToolStripMenuItem});
            this.kantEOCriticismoToolStripMenuItem.Name = "kantEOCriticismoToolStripMenuItem";
            this.kantEOCriticismoToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.kantEOCriticismoToolStripMenuItem.Text = "Kant e o Criticismo";
            // 
            // immanuelKantParteIToolStripMenuItem
            // 
            this.immanuelKantParteIToolStripMenuItem.Name = "immanuelKantParteIToolStripMenuItem";
            this.immanuelKantParteIToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.immanuelKantParteIToolStripMenuItem.Text = "Immanuel Kant - Parte I";
            this.immanuelKantParteIToolStripMenuItem.Click += new System.EventHandler(this.immanuelKantParteIToolStripMenuItem_Click);
            // 
            // immanuelKantParteIIToolStripMenuItem
            // 
            this.immanuelKantParteIIToolStripMenuItem.Name = "immanuelKantParteIIToolStripMenuItem";
            this.immanuelKantParteIIToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.immanuelKantParteIIToolStripMenuItem.Text = "Immanuel Kant - Parte II";
            this.immanuelKantParteIIToolStripMenuItem.Click += new System.EventHandler(this.immanuelKantParteIIToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.Tomato;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem18,
            this.toolStripMenuItem37});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(109, 25);
            this.toolStripMenuItem1.Text = "Perguntas";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.toolStripMenuItem6,
            this.toolStripMenuItem11,
            this.toolStripMenuItem16,
            this.toolStripMenuItem17});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(377, 26);
            this.toolStripMenuItem2.Text = "Filosofia Moral";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5});
            this.toolStripMenuItem4.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(399, 26);
            this.toolStripMenuItem4.Text = "Moral, Ética e Lei";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(235, 26);
            this.toolStripMenuItem5.Text = "Ética, Moral e Valores";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10});
            this.toolStripMenuItem6.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(399, 26);
            this.toolStripMenuItem6.Text = "Moral Grega – Sócrates, Platão e Aristóteles";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(254, 26);
            this.toolStripMenuItem7.Text = "Sócrates";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(254, 26);
            this.toolStripMenuItem8.Text = "Platão: Política/Dialética";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(254, 26);
            this.toolStripMenuItem9.Text = "A Teoria das Ideias";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(254, 26);
            this.toolStripMenuItem10.Text = "Aristóteles";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.toolStripMenuItem15});
            this.toolStripMenuItem11.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(399, 26);
            this.toolStripMenuItem11.Text = "Ética Helênica e Moral Cristã";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(391, 26);
            this.toolStripMenuItem12.Text = "Filosofias Helenísticas";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(391, 26);
            this.toolStripMenuItem13.Text = "Filosofia Medieval I: Santo Agostinho";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(391, 26);
            this.toolStripMenuItem14.Text = "Filosofia Medieval II: São Tomás de Aquino";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(391, 26);
            this.toolStripMenuItem15.Text = "Ética Helênica e Moral Cristã";
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(399, 26);
            this.toolStripMenuItem16.Text = "Ética Deontológica e Consequencialista";
            this.toolStripMenuItem16.Click += new System.EventHandler(this.toolStripMenuItem16_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(399, 26);
            this.toolStripMenuItem17.Text = "Ética Contemporânea";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem19,
            this.toolStripMenuItem20,
            this.toolStripMenuItem23,
            this.toolStripMenuItem25,
            this.toolStripMenuItem27,
            this.toolStripMenuItem28,
            this.toolStripMenuItem29,
            this.toolStripMenuItem33,
            this.toolStripMenuItem36});
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(377, 26);
            this.toolStripMenuItem18.Text = "Filosofia Política";
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem19.Text = "Sociedade, Estado e Governo";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem20.Text = "Relações de Poder - Foucault";
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem24});
            this.toolStripMenuItem23.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem23.Text = "Democracia e Liberdade";
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(229, 26);
            this.toolStripMenuItem24.Text = "A Democracia Grega";
            this.toolStripMenuItem24.Click += new System.EventHandler(this.toolStripMenuItem24_Click);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem26});
            this.toolStripMenuItem25.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem25.Text = "Política Grega (Platão e Aristóteles)";
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(260, 26);
            this.toolStripMenuItem26.Text = "O Surgimento da Política";
            this.toolStripMenuItem26.Click += new System.EventHandler(this.toolStripMenuItem26_Click);
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem27.Text = "Maquiavel - Manutenção do Poder";
            this.toolStripMenuItem27.Click += new System.EventHandler(this.toolStripMenuItem27_Click);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem28.Text = "Contrato social - Hobbes";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.toolStripMenuItem28_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem30,
            this.toolStripMenuItem31,
            this.toolStripMenuItem32});
            this.toolStripMenuItem29.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem29.Text = "Contrato social - Locke e Rousseau";
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(161, 26);
            this.toolStripMenuItem30.Text = "John Locke";
            this.toolStripMenuItem30.Click += new System.EventHandler(this.toolStripMenuItem30_Click);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(161, 26);
            this.toolStripMenuItem31.Text = "Iluminismo";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.toolStripMenuItem31_Click);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(161, 26);
            this.toolStripMenuItem32.Text = "Rousseau";
            this.toolStripMenuItem32.Click += new System.EventHandler(this.toolStripMenuItem32_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem34});
            this.toolStripMenuItem33.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem33.Text = "Marxismo ";
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(149, 26);
            this.toolStripMenuItem34.Text = "Karl Marx";
            this.toolStripMenuItem34.Click += new System.EventHandler(this.toolStripMenuItem34_Click);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(335, 26);
            this.toolStripMenuItem36.Text = "Feminismo";
            this.toolStripMenuItem36.Click += new System.EventHandler(this.toolStripMenuItem36_Click);
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem39,
            this.toolStripMenuItem42,
            this.toolStripMenuItem43,
            this.toolStripMenuItem44,
            this.toolStripMenuItem46,
            this.toolStripMenuItem47,
            this.toolStripMenuItem50});
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(377, 26);
            this.toolStripMenuItem37.Text = "Teoria do Conhecimento - Epistemologia";
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem40,
            this.toolStripMenuItem41});
            this.toolStripMenuItem39.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(392, 26);
            this.toolStripMenuItem39.Text = "Racionalismo e Empirismo";
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(192, 26);
            this.toolStripMenuItem40.Text = "René Descartes";
            this.toolStripMenuItem40.Click += new System.EventHandler(this.toolStripMenuItem40_Click);
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(192, 26);
            this.toolStripMenuItem41.Text = "Francis Bacon";
            this.toolStripMenuItem41.Click += new System.EventHandler(this.toolStripMenuItem41_Click);
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(392, 26);
            this.toolStripMenuItem42.Text = "Tipos de Conhecimento";
            this.toolStripMenuItem42.Click += new System.EventHandler(this.toolStripMenuItem42_Click);
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(392, 26);
            this.toolStripMenuItem43.Text = "Mito da Caverna - Platão";
            this.toolStripMenuItem43.Click += new System.EventHandler(this.toolStripMenuItem43_Click);
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem45});
            this.toolStripMenuItem44.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(392, 26);
            this.toolStripMenuItem44.Text = "Teoria das Causas – Empirismo Aristotélico ";
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(320, 26);
            this.toolStripMenuItem45.Text = "O Ser, o movimento e as virtudes";
            this.toolStripMenuItem45.Click += new System.EventHandler(this.toolStripMenuItem45_Click);
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(392, 26);
            this.toolStripMenuItem46.Text = "Racionalismo Moderno";
            this.toolStripMenuItem46.Click += new System.EventHandler(this.toolStripMenuItem46_Click);
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem48,
            this.toolStripMenuItem49});
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(392, 26);
            this.toolStripMenuItem47.Text = "Empirismo Moderno";
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(202, 26);
            this.toolStripMenuItem48.Text = "David Hume";
            this.toolStripMenuItem48.Click += new System.EventHandler(this.toolStripMenuItem48_Click);
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(202, 26);
            this.toolStripMenuItem49.Text = "George Berkeley";
            this.toolStripMenuItem49.Click += new System.EventHandler(this.toolStripMenuItem49_Click);
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem51});
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(392, 26);
            this.toolStripMenuItem50.Text = "Kant e o Criticismo";
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(189, 26);
            this.toolStripMenuItem51.Text = "Immanuel Kant";
            this.toolStripMenuItem51.Click += new System.EventHandler(this.toolStripMenuItem51_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(914, 612);
            this.sfoPlayer.TabIndex = 39;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(914, 612);
            this.PictureCSharp.TabIndex = 40;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(914, 612);
            this.panelQuiz.TabIndex = 64;
            // 
            // FrmFilo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmFilo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmFilo";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fecharMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cursoEmVídeoToolStripMenuItem;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem filosofiaMoralToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grátisIntroduçãoÀFilosofiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moralÉticaELeiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moralGregaSócratesPlatãoEAristótelesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem éticaHelênicaEMoralCristãToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem éticaDeontológicaEConsequencialistaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem éticaContemporâneaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filosofiaPolíticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociedadeEstadoEGovernoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaçõesDePoderFoucaultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem democraciaELiberdadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem políticaGregaPlatãoEAristótelesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maquiavelManutençãoDoPoderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contratoSocialHobbesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contratoSocialLockeERousseauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marxismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feminismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teoriaDoConhecimentoEpistemologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoTeoriaDoConhecimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem racionalismoEEmpirismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tiposDeConhecimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mitoDaCavernaPlatãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teoriaDasCausasEmpirismoAristotélicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem racionalismoModernoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empirismoModernoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kantEOCriticismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem éticaMoralEValoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sócratesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem platãoPolíticaDialéticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aristótelesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aTeoriaDasIdeiasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filosofiasHelenísticasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filosofiaMedievalISantoAgostinhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filosofiaMedievalIISãoTomásDeAquinoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oSURGIMENTODAPOLÍTICAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem johnLockeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rousseauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iluminismoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem karlMarxParteIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem karlMarxParteIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDemocraciaGregaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem éticaHelênicaEMoralCristãToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem foucaultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaçõesDePoderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renéDescartesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem francisBaconToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem immanuelKantParteIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem immanuelKantParteIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oSerOMovimentoEAsVirtudesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem davidHumeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem georgeBerkeleyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.Panel panelQuiz;
    }
}