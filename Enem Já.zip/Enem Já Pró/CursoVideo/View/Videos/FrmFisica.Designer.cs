﻿namespace CursoVideo.View.Videos
{
    partial class FrmFisica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFisica));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fecharMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.físicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.termologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoÀTermologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transferênciaDeCalorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.escalasTermométricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dilataçãoTérmicaIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dilataçãoTérmicaIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cinemáticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.velocidadeMédiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoRetilíneoUniformeMRUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mRUAPLICAÇÕESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.velocidadeRelativaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoDeQuedaLivreMQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lançamentosHorizontaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lançamentosOblíquosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gráficosDaCinemáticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoCircularToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.uniformeMCUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aplicaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deduçãoDaEquaçãoDeTorricelliToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dinâmicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leisDeNewtonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.primeiraLeiDeNewtonINÉRCIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.egundaLeiDeNewtonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.terceiraLeiDeNewtonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leisDeNewtonPoliasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leisDeNewtonAplicaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leisDeNewtonTiposDeForçasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forçaDeAtritoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forçaElásticaLeiDeHookeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impulsoQuantidadeDeMovimentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quantidadeDeMovimentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impulsoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colisõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.energiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.energiaMecânicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eoremaDaEnergiaCinéticaTECToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trabalhoEEnergiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pêndulosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eletrostáticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.processosDeEletrizaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leiDeCoulombToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.campoElétricoIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.campoElétricoIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potencialElétricoIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eletrodinâmicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.correnteElétricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leiDeOhmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fatoresQueInfluenciamNaResistênciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potênciaElétricaEEnergiaElétricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.físicaModernaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.físicaNuclearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.radioatividadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decaimentoRadioativoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circuitosElétricosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.associaçãoDeResistoresIIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.circuitoMistoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.capacitoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geradoresEReceptoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hidrostáticaEGrandezasFísicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.análiseGrandezasErrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pressãoHidrostáticaLeiDeStevinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vasosComunicantesTubosEmUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.máquinasHidráulicasEPrincípioDePascalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empuxoArquimedesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hidrodinâmicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ondasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.introduçãoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.conceitoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.velocidadeDasOndasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ópticaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dispersãoLuminosaECoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.espelhoPlanoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.espelhoEsféricosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lentesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.defeitosDeVisãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dispersãoLuminosaECoresToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem38 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem55 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem56 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem57 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem58 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem59 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem60 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem61 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem62 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem63 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem68 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem69 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem70 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem71 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem72 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem73 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem74 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem75 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem76 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem77 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem79 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem80 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem81 = new System.Windows.Forms.ToolStripMenuItem();
            this.sfoPlayer = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.PictureCSharp = new System.Windows.Forms.PictureBox();
            this.panelQuiz = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(35, 35);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fecharMenuItem,
            this.físicaToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(122, 612);
            this.menuStrip1.TabIndex = 40;
            // 
            // fecharMenuItem
            // 
            this.fecharMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.fecharMenuItem.BackColor = System.Drawing.SystemColors.ControlLight;
            this.fecharMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fecharMenuItem.Image")));
            this.fecharMenuItem.Name = "fecharMenuItem";
            this.fecharMenuItem.Size = new System.Drawing.Size(109, 39);
            this.fecharMenuItem.Text = "FECHAR";
            this.fecharMenuItem.Click += new System.EventHandler(this.fecharMenuItem_Click);
            // 
            // físicaToolStripMenuItem
            // 
            this.físicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.termologiaToolStripMenuItem,
            this.cinemáticaToolStripMenuItem,
            this.dinâmicaToolStripMenuItem,
            this.eletrostáticaToolStripMenuItem,
            this.eletrodinâmicaToolStripMenuItem,
            this.físicaModernaToolStripMenuItem,
            this.circuitosElétricosToolStripMenuItem,
            this.hidrostáticaEGrandezasFísicasToolStripMenuItem,
            this.ondasToolStripMenuItem,
            this.ópticaToolStripMenuItem});
            this.físicaToolStripMenuItem.Name = "físicaToolStripMenuItem";
            this.físicaToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.físicaToolStripMenuItem.Text = "Física";
            // 
            // termologiaToolStripMenuItem
            // 
            this.termologiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoÀTermologiaToolStripMenuItem,
            this.transferênciaDeCalorToolStripMenuItem,
            this.escalasTermométricasToolStripMenuItem,
            this.dilataçãoTérmicaIToolStripMenuItem,
            this.dilataçãoTérmicaIIToolStripMenuItem});
            this.termologiaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.termologiaToolStripMenuItem.Name = "termologiaToolStripMenuItem";
            this.termologiaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.termologiaToolStripMenuItem.Text = "Termologia";
            // 
            // introduçãoÀTermologiaToolStripMenuItem
            // 
            this.introduçãoÀTermologiaToolStripMenuItem.Name = "introduçãoÀTermologiaToolStripMenuItem";
            this.introduçãoÀTermologiaToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.introduçãoÀTermologiaToolStripMenuItem.Text = "Introdução à Termologia";
            this.introduçãoÀTermologiaToolStripMenuItem.Click += new System.EventHandler(this.introduçãoÀTermologiaToolStripMenuItem_Click);
            // 
            // transferênciaDeCalorToolStripMenuItem
            // 
            this.transferênciaDeCalorToolStripMenuItem.Name = "transferênciaDeCalorToolStripMenuItem";
            this.transferênciaDeCalorToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.transferênciaDeCalorToolStripMenuItem.Text = "Transferência de Calor";
            this.transferênciaDeCalorToolStripMenuItem.Click += new System.EventHandler(this.transferênciaDeCalorToolStripMenuItem_Click);
            // 
            // escalasTermométricasToolStripMenuItem
            // 
            this.escalasTermométricasToolStripMenuItem.Name = "escalasTermométricasToolStripMenuItem";
            this.escalasTermométricasToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.escalasTermométricasToolStripMenuItem.Text = "Escalas termométricas";
            this.escalasTermométricasToolStripMenuItem.Click += new System.EventHandler(this.escalasTermométricasToolStripMenuItem_Click);
            // 
            // dilataçãoTérmicaIToolStripMenuItem
            // 
            this.dilataçãoTérmicaIToolStripMenuItem.Name = "dilataçãoTérmicaIToolStripMenuItem";
            this.dilataçãoTérmicaIToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.dilataçãoTérmicaIToolStripMenuItem.Text = "Dilatação Térmica I";
            this.dilataçãoTérmicaIToolStripMenuItem.Click += new System.EventHandler(this.dilataçãoTérmicaIToolStripMenuItem_Click);
            // 
            // dilataçãoTérmicaIIToolStripMenuItem
            // 
            this.dilataçãoTérmicaIIToolStripMenuItem.Name = "dilataçãoTérmicaIIToolStripMenuItem";
            this.dilataçãoTérmicaIIToolStripMenuItem.Size = new System.Drawing.Size(259, 26);
            this.dilataçãoTérmicaIIToolStripMenuItem.Text = "Dilatação Térmica II";
            this.dilataçãoTérmicaIIToolStripMenuItem.Click += new System.EventHandler(this.dilataçãoTérmicaIIToolStripMenuItem_Click);
            // 
            // cinemáticaToolStripMenuItem
            // 
            this.cinemáticaToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.cinemáticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem3,
            this.velocidadeMédiaToolStripMenuItem,
            this.movimentoRetilíneoUniformeMRUToolStripMenuItem,
            this.mRUAPLICAÇÕESToolStripMenuItem,
            this.velocidadeRelativaToolStripMenuItem,
            this.movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem,
            this.movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem,
            this.movimentoDeQuedaLivreMQLToolStripMenuItem,
            this.lançamentosHorizontaisToolStripMenuItem,
            this.lançamentosOblíquosToolStripMenuItem,
            this.gráficosDaCinemáticaToolStripMenuItem,
            this.movimentoCircularToolStripMenuItem,
            this.deduçãoDaEquaçãoDeTorricelliToolStripMenuItem});
            this.cinemáticaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.cinemáticaToolStripMenuItem.Name = "cinemáticaToolStripMenuItem";
            this.cinemáticaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.cinemáticaToolStripMenuItem.Text = "Cinemática Escalar";
            // 
            // introduçãoToolStripMenuItem3
            // 
            this.introduçãoToolStripMenuItem3.Name = "introduçãoToolStripMenuItem3";
            this.introduçãoToolStripMenuItem3.Size = new System.Drawing.Size(477, 26);
            this.introduçãoToolStripMenuItem3.Text = "Introdução";
            this.introduçãoToolStripMenuItem3.Click += new System.EventHandler(this.introduçãoToolStripMenuItem3_Click);
            // 
            // velocidadeMédiaToolStripMenuItem
            // 
            this.velocidadeMédiaToolStripMenuItem.Name = "velocidadeMédiaToolStripMenuItem";
            this.velocidadeMédiaToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.velocidadeMédiaToolStripMenuItem.Text = "Velocidade Média";
            this.velocidadeMédiaToolStripMenuItem.Click += new System.EventHandler(this.velocidadeMédiaToolStripMenuItem_Click);
            // 
            // movimentoRetilíneoUniformeMRUToolStripMenuItem
            // 
            this.movimentoRetilíneoUniformeMRUToolStripMenuItem.Name = "movimentoRetilíneoUniformeMRUToolStripMenuItem";
            this.movimentoRetilíneoUniformeMRUToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.movimentoRetilíneoUniformeMRUToolStripMenuItem.Text = "Movimento Retilíneo Uniforme MRU";
            this.movimentoRetilíneoUniformeMRUToolStripMenuItem.Click += new System.EventHandler(this.movimentoRetilíneoUniformeMRUToolStripMenuItem_Click);
            // 
            // mRUAPLICAÇÕESToolStripMenuItem
            // 
            this.mRUAPLICAÇÕESToolStripMenuItem.Name = "mRUAPLICAÇÕESToolStripMenuItem";
            this.mRUAPLICAÇÕESToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.mRUAPLICAÇÕESToolStripMenuItem.Text = "MRU APLICAÇÕES";
            this.mRUAPLICAÇÕESToolStripMenuItem.Click += new System.EventHandler(this.mRUAPLICAÇÕESToolStripMenuItem_Click);
            // 
            // velocidadeRelativaToolStripMenuItem
            // 
            this.velocidadeRelativaToolStripMenuItem.Name = "velocidadeRelativaToolStripMenuItem";
            this.velocidadeRelativaToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.velocidadeRelativaToolStripMenuItem.Text = "Velocidade Relativa";
            this.velocidadeRelativaToolStripMenuItem.Click += new System.EventHandler(this.velocidadeRelativaToolStripMenuItem_Click);
            // 
            // movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem
            // 
            this.movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem.Name = "movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem";
            this.movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem.Text = "Movimento Retilíneo Uniformemente Variado MRUV";
            this.movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem.Click += new System.EventHandler(this.movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem_Click);
            // 
            // movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem
            // 
            this.movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem.Name = "movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem";
            this.movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem.Text = "Movimento Retilíneo Uniformemente Variado MRUV II";
            this.movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem.Click += new System.EventHandler(this.movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem_Click);
            // 
            // movimentoDeQuedaLivreMQLToolStripMenuItem
            // 
            this.movimentoDeQuedaLivreMQLToolStripMenuItem.Name = "movimentoDeQuedaLivreMQLToolStripMenuItem";
            this.movimentoDeQuedaLivreMQLToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.movimentoDeQuedaLivreMQLToolStripMenuItem.Text = "Movimento de Queda Livre( MQL )";
            this.movimentoDeQuedaLivreMQLToolStripMenuItem.Click += new System.EventHandler(this.movimentoDeQuedaLivreMQLToolStripMenuItem_Click);
            // 
            // lançamentosHorizontaisToolStripMenuItem
            // 
            this.lançamentosHorizontaisToolStripMenuItem.Name = "lançamentosHorizontaisToolStripMenuItem";
            this.lançamentosHorizontaisToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.lançamentosHorizontaisToolStripMenuItem.Text = "Lançamentos horizontais";
            this.lançamentosHorizontaisToolStripMenuItem.Click += new System.EventHandler(this.lançamentosHorizontaisToolStripMenuItem_Click);
            // 
            // lançamentosOblíquosToolStripMenuItem
            // 
            this.lançamentosOblíquosToolStripMenuItem.Name = "lançamentosOblíquosToolStripMenuItem";
            this.lançamentosOblíquosToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.lançamentosOblíquosToolStripMenuItem.Text = "Lançamentos Oblíquos";
            this.lançamentosOblíquosToolStripMenuItem.Click += new System.EventHandler(this.lançamentosOblíquosToolStripMenuItem_Click);
            // 
            // gráficosDaCinemáticaToolStripMenuItem
            // 
            this.gráficosDaCinemáticaToolStripMenuItem.Name = "gráficosDaCinemáticaToolStripMenuItem";
            this.gráficosDaCinemáticaToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.gráficosDaCinemáticaToolStripMenuItem.Text = "Gráficos da Cinemática";
            this.gráficosDaCinemáticaToolStripMenuItem.Click += new System.EventHandler(this.gráficosDaCinemáticaToolStripMenuItem_Click);
            // 
            // movimentoCircularToolStripMenuItem
            // 
            this.movimentoCircularToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem4,
            this.uniformeMCUToolStripMenuItem,
            this.aplicaçõesToolStripMenuItem});
            this.movimentoCircularToolStripMenuItem.Name = "movimentoCircularToolStripMenuItem";
            this.movimentoCircularToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.movimentoCircularToolStripMenuItem.Text = "Movimento Circular";
            // 
            // introduçãoToolStripMenuItem4
            // 
            this.introduçãoToolStripMenuItem4.Name = "introduçãoToolStripMenuItem4";
            this.introduçãoToolStripMenuItem4.Size = new System.Drawing.Size(199, 26);
            this.introduçãoToolStripMenuItem4.Text = "Introdução";
            this.introduçãoToolStripMenuItem4.Click += new System.EventHandler(this.introduçãoToolStripMenuItem4_Click);
            // 
            // uniformeMCUToolStripMenuItem
            // 
            this.uniformeMCUToolStripMenuItem.Name = "uniformeMCUToolStripMenuItem";
            this.uniformeMCUToolStripMenuItem.Size = new System.Drawing.Size(199, 26);
            this.uniformeMCUToolStripMenuItem.Text = "Uniforme (MCU)";
            this.uniformeMCUToolStripMenuItem.Click += new System.EventHandler(this.uniformeMCUToolStripMenuItem_Click);
            // 
            // aplicaçõesToolStripMenuItem
            // 
            this.aplicaçõesToolStripMenuItem.Name = "aplicaçõesToolStripMenuItem";
            this.aplicaçõesToolStripMenuItem.Size = new System.Drawing.Size(199, 26);
            this.aplicaçõesToolStripMenuItem.Text = "Aplicações";
            this.aplicaçõesToolStripMenuItem.Click += new System.EventHandler(this.aplicaçõesToolStripMenuItem_Click);
            // 
            // deduçãoDaEquaçãoDeTorricelliToolStripMenuItem
            // 
            this.deduçãoDaEquaçãoDeTorricelliToolStripMenuItem.Name = "deduçãoDaEquaçãoDeTorricelliToolStripMenuItem";
            this.deduçãoDaEquaçãoDeTorricelliToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.deduçãoDaEquaçãoDeTorricelliToolStripMenuItem.Text = "Dedução da Equação de Torricelli";
            this.deduçãoDaEquaçãoDeTorricelliToolStripMenuItem.Click += new System.EventHandler(this.deduçãoDaEquaçãoDeTorricelliToolStripMenuItem_Click);
            // 
            // dinâmicaToolStripMenuItem
            // 
            this.dinâmicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leisDeNewtonToolStripMenuItem,
            this.forçaDeAtritoToolStripMenuItem,
            this.forçaElásticaLeiDeHookeToolStripMenuItem,
            this.impulsoQuantidadeDeMovimentosToolStripMenuItem,
            this.colisõesToolStripMenuItem,
            this.energiaToolStripMenuItem,
            this.pêndulosToolStripMenuItem});
            this.dinâmicaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.dinâmicaToolStripMenuItem.Name = "dinâmicaToolStripMenuItem";
            this.dinâmicaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.dinâmicaToolStripMenuItem.Text = "Dinâmica";
            // 
            // leisDeNewtonToolStripMenuItem
            // 
            this.leisDeNewtonToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem,
            this.primeiraLeiDeNewtonINÉRCIAToolStripMenuItem,
            this.egundaLeiDeNewtonToolStripMenuItem,
            this.terceiraLeiDeNewtonToolStripMenuItem,
            this.leisDeNewtonPoliasToolStripMenuItem,
            this.leisDeNewtonAplicaçõesToolStripMenuItem,
            this.leisDeNewtonTiposDeForçasToolStripMenuItem});
            this.leisDeNewtonToolStripMenuItem.Name = "leisDeNewtonToolStripMenuItem";
            this.leisDeNewtonToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.leisDeNewtonToolStripMenuItem.Text = "Leis de Newton";
            // 
            // introduçãoToolStripMenuItem
            // 
            this.introduçãoToolStripMenuItem.Name = "introduçãoToolStripMenuItem";
            this.introduçãoToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.introduçãoToolStripMenuItem.Text = "Introdução";
            this.introduçãoToolStripMenuItem.Click += new System.EventHandler(this.introduçãoToolStripMenuItem_Click);
            // 
            // primeiraLeiDeNewtonINÉRCIAToolStripMenuItem
            // 
            this.primeiraLeiDeNewtonINÉRCIAToolStripMenuItem.Name = "primeiraLeiDeNewtonINÉRCIAToolStripMenuItem";
            this.primeiraLeiDeNewtonINÉRCIAToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.primeiraLeiDeNewtonINÉRCIAToolStripMenuItem.Text = "Primeira Lei de Newton INÉRCIA";
            this.primeiraLeiDeNewtonINÉRCIAToolStripMenuItem.Click += new System.EventHandler(this.primeiraLeiDeNewtonINÉRCIAToolStripMenuItem_Click);
            // 
            // egundaLeiDeNewtonToolStripMenuItem
            // 
            this.egundaLeiDeNewtonToolStripMenuItem.Name = "egundaLeiDeNewtonToolStripMenuItem";
            this.egundaLeiDeNewtonToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.egundaLeiDeNewtonToolStripMenuItem.Text = "Segunda Lei de Newton";
            this.egundaLeiDeNewtonToolStripMenuItem.Click += new System.EventHandler(this.egundaLeiDeNewtonToolStripMenuItem_Click);
            // 
            // terceiraLeiDeNewtonToolStripMenuItem
            // 
            this.terceiraLeiDeNewtonToolStripMenuItem.Name = "terceiraLeiDeNewtonToolStripMenuItem";
            this.terceiraLeiDeNewtonToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.terceiraLeiDeNewtonToolStripMenuItem.Text = "Terceira Lei de Newton";
            this.terceiraLeiDeNewtonToolStripMenuItem.Click += new System.EventHandler(this.terceiraLeiDeNewtonToolStripMenuItem_Click);
            // 
            // leisDeNewtonPoliasToolStripMenuItem
            // 
            this.leisDeNewtonPoliasToolStripMenuItem.Name = "leisDeNewtonPoliasToolStripMenuItem";
            this.leisDeNewtonPoliasToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.leisDeNewtonPoliasToolStripMenuItem.Text = "Leis de Newton - Polias";
            this.leisDeNewtonPoliasToolStripMenuItem.Click += new System.EventHandler(this.leisDeNewtonPoliasToolStripMenuItem_Click);
            // 
            // leisDeNewtonAplicaçõesToolStripMenuItem
            // 
            this.leisDeNewtonAplicaçõesToolStripMenuItem.Name = "leisDeNewtonAplicaçõesToolStripMenuItem";
            this.leisDeNewtonAplicaçõesToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.leisDeNewtonAplicaçõesToolStripMenuItem.Text = "Leis de Newton - Aplicações";
            this.leisDeNewtonAplicaçõesToolStripMenuItem.Click += new System.EventHandler(this.leisDeNewtonAplicaçõesToolStripMenuItem_Click);
            // 
            // leisDeNewtonTiposDeForçasToolStripMenuItem
            // 
            this.leisDeNewtonTiposDeForçasToolStripMenuItem.Name = "leisDeNewtonTiposDeForçasToolStripMenuItem";
            this.leisDeNewtonTiposDeForçasToolStripMenuItem.Size = new System.Drawing.Size(321, 26);
            this.leisDeNewtonTiposDeForçasToolStripMenuItem.Text = "Leis de Newton - Tipos de Forças";
            this.leisDeNewtonTiposDeForçasToolStripMenuItem.Click += new System.EventHandler(this.leisDeNewtonTiposDeForçasToolStripMenuItem_Click);
            // 
            // forçaDeAtritoToolStripMenuItem
            // 
            this.forçaDeAtritoToolStripMenuItem.Name = "forçaDeAtritoToolStripMenuItem";
            this.forçaDeAtritoToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.forçaDeAtritoToolStripMenuItem.Text = "Força de Atrito";
            this.forçaDeAtritoToolStripMenuItem.Click += new System.EventHandler(this.forçaDeAtritoToolStripMenuItem_Click);
            // 
            // forçaElásticaLeiDeHookeToolStripMenuItem
            // 
            this.forçaElásticaLeiDeHookeToolStripMenuItem.Name = "forçaElásticaLeiDeHookeToolStripMenuItem";
            this.forçaElásticaLeiDeHookeToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.forçaElásticaLeiDeHookeToolStripMenuItem.Text = "Força Elástica Lei de Hooke";
            this.forçaElásticaLeiDeHookeToolStripMenuItem.Click += new System.EventHandler(this.forçaElásticaLeiDeHookeToolStripMenuItem_Click);
            // 
            // impulsoQuantidadeDeMovimentosToolStripMenuItem
            // 
            this.impulsoQuantidadeDeMovimentosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quantidadeDeMovimentosToolStripMenuItem,
            this.impulsoToolStripMenuItem});
            this.impulsoQuantidadeDeMovimentosToolStripMenuItem.Name = "impulsoQuantidadeDeMovimentosToolStripMenuItem";
            this.impulsoQuantidadeDeMovimentosToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.impulsoQuantidadeDeMovimentosToolStripMenuItem.Text = "Impulso/Quantidade de Movimentos";
            this.impulsoQuantidadeDeMovimentosToolStripMenuItem.Click += new System.EventHandler(this.impulsoQuantidadeDeMovimentosToolStripMenuItem_Click);
            // 
            // quantidadeDeMovimentosToolStripMenuItem
            // 
            this.quantidadeDeMovimentosToolStripMenuItem.Name = "quantidadeDeMovimentosToolStripMenuItem";
            this.quantidadeDeMovimentosToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.quantidadeDeMovimentosToolStripMenuItem.Text = "Quantidade de Movimentos";
            this.quantidadeDeMovimentosToolStripMenuItem.Click += new System.EventHandler(this.quantidadeDeMovimentosToolStripMenuItem_Click);
            // 
            // impulsoToolStripMenuItem
            // 
            this.impulsoToolStripMenuItem.Name = "impulsoToolStripMenuItem";
            this.impulsoToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.impulsoToolStripMenuItem.Text = "Impulso";
            this.impulsoToolStripMenuItem.Click += new System.EventHandler(this.impulsoToolStripMenuItem_Click);
            // 
            // colisõesToolStripMenuItem
            // 
            this.colisõesToolStripMenuItem.Name = "colisõesToolStripMenuItem";
            this.colisõesToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.colisõesToolStripMenuItem.Text = "Colisões";
            this.colisõesToolStripMenuItem.Click += new System.EventHandler(this.colisõesToolStripMenuItem_Click);
            // 
            // energiaToolStripMenuItem
            // 
            this.energiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.energiaMecânicaToolStripMenuItem,
            this.eoremaDaEnergiaCinéticaTECToolStripMenuItem,
            this.trabalhoEEnergiaToolStripMenuItem});
            this.energiaToolStripMenuItem.Name = "energiaToolStripMenuItem";
            this.energiaToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.energiaToolStripMenuItem.Text = "Energia";
            // 
            // energiaMecânicaToolStripMenuItem
            // 
            this.energiaMecânicaToolStripMenuItem.Name = "energiaMecânicaToolStripMenuItem";
            this.energiaMecânicaToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.energiaMecânicaToolStripMenuItem.Text = "Energia Mecânica";
            this.energiaMecânicaToolStripMenuItem.Click += new System.EventHandler(this.energiaMecânicaToolStripMenuItem_Click);
            // 
            // eoremaDaEnergiaCinéticaTECToolStripMenuItem
            // 
            this.eoremaDaEnergiaCinéticaTECToolStripMenuItem.Name = "eoremaDaEnergiaCinéticaTECToolStripMenuItem";
            this.eoremaDaEnergiaCinéticaTECToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.eoremaDaEnergiaCinéticaTECToolStripMenuItem.Text = "Teorema da Energia Cinética (TEC)";
            this.eoremaDaEnergiaCinéticaTECToolStripMenuItem.Click += new System.EventHandler(this.eoremaDaEnergiaCinéticaTECToolStripMenuItem_Click);
            // 
            // trabalhoEEnergiaToolStripMenuItem
            // 
            this.trabalhoEEnergiaToolStripMenuItem.Name = "trabalhoEEnergiaToolStripMenuItem";
            this.trabalhoEEnergiaToolStripMenuItem.Size = new System.Drawing.Size(326, 26);
            this.trabalhoEEnergiaToolStripMenuItem.Text = "Trabalho e Energia";
            this.trabalhoEEnergiaToolStripMenuItem.Click += new System.EventHandler(this.trabalhoEEnergiaToolStripMenuItem_Click);
            // 
            // pêndulosToolStripMenuItem
            // 
            this.pêndulosToolStripMenuItem.Name = "pêndulosToolStripMenuItem";
            this.pêndulosToolStripMenuItem.Size = new System.Drawing.Size(350, 26);
            this.pêndulosToolStripMenuItem.Text = "Pêndulos";
            this.pêndulosToolStripMenuItem.Click += new System.EventHandler(this.pêndulosToolStripMenuItem_Click);
            // 
            // eletrostáticaToolStripMenuItem
            // 
            this.eletrostáticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem1,
            this.processosDeEletrizaçõesToolStripMenuItem,
            this.leiDeCoulombToolStripMenuItem,
            this.campoElétricoIToolStripMenuItem,
            this.campoElétricoIIToolStripMenuItem,
            this.potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem,
            this.potencialElétricoIIToolStripMenuItem,
            this.potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem});
            this.eletrostáticaToolStripMenuItem.Name = "eletrostáticaToolStripMenuItem";
            this.eletrostáticaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.eletrostáticaToolStripMenuItem.Text = "Eletrostática";
            // 
            // introduçãoToolStripMenuItem1
            // 
            this.introduçãoToolStripMenuItem1.Name = "introduçãoToolStripMenuItem1";
            this.introduçãoToolStripMenuItem1.Size = new System.Drawing.Size(444, 26);
            this.introduçãoToolStripMenuItem1.Text = "Introdução";
            this.introduçãoToolStripMenuItem1.Click += new System.EventHandler(this.introduçãoToolStripMenuItem1_Click);
            // 
            // processosDeEletrizaçõesToolStripMenuItem
            // 
            this.processosDeEletrizaçõesToolStripMenuItem.Name = "processosDeEletrizaçõesToolStripMenuItem";
            this.processosDeEletrizaçõesToolStripMenuItem.Size = new System.Drawing.Size(444, 26);
            this.processosDeEletrizaçõesToolStripMenuItem.Text = "Processos de Eletrizações";
            this.processosDeEletrizaçõesToolStripMenuItem.Click += new System.EventHandler(this.processosDeEletrizaçõesToolStripMenuItem_Click);
            // 
            // leiDeCoulombToolStripMenuItem
            // 
            this.leiDeCoulombToolStripMenuItem.Name = "leiDeCoulombToolStripMenuItem";
            this.leiDeCoulombToolStripMenuItem.Size = new System.Drawing.Size(444, 26);
            this.leiDeCoulombToolStripMenuItem.Text = "Lei de Coulomb";
            this.leiDeCoulombToolStripMenuItem.Click += new System.EventHandler(this.leiDeCoulombToolStripMenuItem_Click);
            // 
            // campoElétricoIToolStripMenuItem
            // 
            this.campoElétricoIToolStripMenuItem.Name = "campoElétricoIToolStripMenuItem";
            this.campoElétricoIToolStripMenuItem.Size = new System.Drawing.Size(444, 26);
            this.campoElétricoIToolStripMenuItem.Text = "Campo Elétrico I";
            this.campoElétricoIToolStripMenuItem.Click += new System.EventHandler(this.campoElétricoIToolStripMenuItem_Click);
            // 
            // campoElétricoIIToolStripMenuItem
            // 
            this.campoElétricoIIToolStripMenuItem.Name = "campoElétricoIIToolStripMenuItem";
            this.campoElétricoIIToolStripMenuItem.Size = new System.Drawing.Size(444, 26);
            this.campoElétricoIIToolStripMenuItem.Text = "Campo Elétrico II";
            this.campoElétricoIIToolStripMenuItem.Click += new System.EventHandler(this.campoElétricoIIToolStripMenuItem_Click);
            // 
            // potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem
            // 
            this.potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem.Name = "potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem";
            this.potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem.Size = new System.Drawing.Size(444, 26);
            this.potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem.Text = "Potencial Elétrico e Trabalho de uma Força Elétrica";
            this.potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem.Click += new System.EventHandler(this.potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem_Click);
            // 
            // potencialElétricoIIToolStripMenuItem
            // 
            this.potencialElétricoIIToolStripMenuItem.Name = "potencialElétricoIIToolStripMenuItem";
            this.potencialElétricoIIToolStripMenuItem.Size = new System.Drawing.Size(444, 26);
            this.potencialElétricoIIToolStripMenuItem.Text = "Potencial Elétrico II";
            this.potencialElétricoIIToolStripMenuItem.Click += new System.EventHandler(this.potencialElétricoIIToolStripMenuItem_Click);
            // 
            // potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem
            // 
            this.potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem.Name = "potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem";
            this.potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem.Size = new System.Drawing.Size(444, 26);
            this.potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem.Text = "Potencial Elétrico III - Superfícies equipotenciais";
            this.potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem.Click += new System.EventHandler(this.potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem_Click);
            // 
            // eletrodinâmicaToolStripMenuItem
            // 
            this.eletrodinâmicaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.correnteElétricaToolStripMenuItem,
            this.leiDeOhmToolStripMenuItem,
            this.fatoresQueInfluenciamNaResistênciaToolStripMenuItem,
            this.potênciaElétricaEEnergiaElétricaToolStripMenuItem});
            this.eletrodinâmicaToolStripMenuItem.Name = "eletrodinâmicaToolStripMenuItem";
            this.eletrodinâmicaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.eletrodinâmicaToolStripMenuItem.Text = "Eletrodinâmica";
            // 
            // correnteElétricaToolStripMenuItem
            // 
            this.correnteElétricaToolStripMenuItem.Name = "correnteElétricaToolStripMenuItem";
            this.correnteElétricaToolStripMenuItem.Size = new System.Drawing.Size(359, 26);
            this.correnteElétricaToolStripMenuItem.Text = "Corrente Elétrica";
            this.correnteElétricaToolStripMenuItem.Click += new System.EventHandler(this.correnteElétricaToolStripMenuItem_Click_1);
            // 
            // leiDeOhmToolStripMenuItem
            // 
            this.leiDeOhmToolStripMenuItem.Name = "leiDeOhmToolStripMenuItem";
            this.leiDeOhmToolStripMenuItem.Size = new System.Drawing.Size(359, 26);
            this.leiDeOhmToolStripMenuItem.Text = "Lei de Ohm";
            this.leiDeOhmToolStripMenuItem.Click += new System.EventHandler(this.leiDeOhmToolStripMenuItem_Click);
            // 
            // fatoresQueInfluenciamNaResistênciaToolStripMenuItem
            // 
            this.fatoresQueInfluenciamNaResistênciaToolStripMenuItem.Name = "fatoresQueInfluenciamNaResistênciaToolStripMenuItem";
            this.fatoresQueInfluenciamNaResistênciaToolStripMenuItem.Size = new System.Drawing.Size(359, 26);
            this.fatoresQueInfluenciamNaResistênciaToolStripMenuItem.Text = "Fatores que influenciam na Resistência";
            this.fatoresQueInfluenciamNaResistênciaToolStripMenuItem.Click += new System.EventHandler(this.fatoresQueInfluenciamNaResistênciaToolStripMenuItem_Click);
            // 
            // potênciaElétricaEEnergiaElétricaToolStripMenuItem
            // 
            this.potênciaElétricaEEnergiaElétricaToolStripMenuItem.Name = "potênciaElétricaEEnergiaElétricaToolStripMenuItem";
            this.potênciaElétricaEEnergiaElétricaToolStripMenuItem.Size = new System.Drawing.Size(359, 26);
            this.potênciaElétricaEEnergiaElétricaToolStripMenuItem.Text = "Potência Elétrica e Energia Elétrica";
            this.potênciaElétricaEEnergiaElétricaToolStripMenuItem.Click += new System.EventHandler(this.potênciaElétricaEEnergiaElétricaToolStripMenuItem_Click_1);
            // 
            // físicaModernaToolStripMenuItem
            // 
            this.físicaModernaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.físicaNuclearToolStripMenuItem,
            this.radioatividadeToolStripMenuItem,
            this.decaimentoRadioativoToolStripMenuItem});
            this.físicaModernaToolStripMenuItem.Name = "físicaModernaToolStripMenuItem";
            this.físicaModernaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.físicaModernaToolStripMenuItem.Text = "Física Moderna ";
            // 
            // físicaNuclearToolStripMenuItem
            // 
            this.físicaNuclearToolStripMenuItem.Name = "físicaNuclearToolStripMenuItem";
            this.físicaNuclearToolStripMenuItem.Size = new System.Drawing.Size(250, 26);
            this.físicaNuclearToolStripMenuItem.Text = "Física Nuclear";
            this.físicaNuclearToolStripMenuItem.Click += new System.EventHandler(this.físicaNuclearToolStripMenuItem_Click);
            // 
            // radioatividadeToolStripMenuItem
            // 
            this.radioatividadeToolStripMenuItem.Name = "radioatividadeToolStripMenuItem";
            this.radioatividadeToolStripMenuItem.Size = new System.Drawing.Size(250, 26);
            this.radioatividadeToolStripMenuItem.Text = "Radioatividade";
            this.radioatividadeToolStripMenuItem.Click += new System.EventHandler(this.radioatividadeToolStripMenuItem_Click);
            // 
            // decaimentoRadioativoToolStripMenuItem
            // 
            this.decaimentoRadioativoToolStripMenuItem.Name = "decaimentoRadioativoToolStripMenuItem";
            this.decaimentoRadioativoToolStripMenuItem.Size = new System.Drawing.Size(250, 26);
            this.decaimentoRadioativoToolStripMenuItem.Text = "Decaimento Radioativo";
            this.decaimentoRadioativoToolStripMenuItem.Click += new System.EventHandler(this.decaimentoRadioativoToolStripMenuItem_Click);
            // 
            // circuitosElétricosToolStripMenuItem
            // 
            this.circuitosElétricosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem,
            this.associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem,
            this.associaçãoDeResistoresIIIToolStripMenuItem,
            this.circuitoMistoToolStripMenuItem,
            this.capacitoresToolStripMenuItem,
            this.geradoresEReceptoresToolStripMenuItem});
            this.circuitosElétricosToolStripMenuItem.Name = "circuitosElétricosToolStripMenuItem";
            this.circuitosElétricosToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.circuitosElétricosToolStripMenuItem.Text = "Circuitos Elétricos";
            // 
            // associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem
            // 
            this.associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem.Name = "associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem";
            this.associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem.Size = new System.Drawing.Size(431, 26);
            this.associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem.Text = "Associação de Resistores I : Circuito em Série";
            this.associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem.Click += new System.EventHandler(this.associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem_Click);
            // 
            // associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem
            // 
            this.associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem.Name = "associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem";
            this.associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem.Size = new System.Drawing.Size(431, 26);
            this.associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem.Text = "Associação de Resistores II: Circuito em Paralelo";
            this.associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem.Click += new System.EventHandler(this.associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem_Click);
            // 
            // associaçãoDeResistoresIIIToolStripMenuItem
            // 
            this.associaçãoDeResistoresIIIToolStripMenuItem.Name = "associaçãoDeResistoresIIIToolStripMenuItem";
            this.associaçãoDeResistoresIIIToolStripMenuItem.Size = new System.Drawing.Size(431, 26);
            this.associaçãoDeResistoresIIIToolStripMenuItem.Text = "Associação de Resistores III";
            this.associaçãoDeResistoresIIIToolStripMenuItem.Click += new System.EventHandler(this.associaçãoDeResistoresIIIToolStripMenuItem_Click);
            // 
            // circuitoMistoToolStripMenuItem
            // 
            this.circuitoMistoToolStripMenuItem.Name = "circuitoMistoToolStripMenuItem";
            this.circuitoMistoToolStripMenuItem.Size = new System.Drawing.Size(431, 26);
            this.circuitoMistoToolStripMenuItem.Text = "Circuito Misto";
            this.circuitoMistoToolStripMenuItem.Click += new System.EventHandler(this.circuitoMistoToolStripMenuItem_Click);
            // 
            // capacitoresToolStripMenuItem
            // 
            this.capacitoresToolStripMenuItem.Name = "capacitoresToolStripMenuItem";
            this.capacitoresToolStripMenuItem.Size = new System.Drawing.Size(431, 26);
            this.capacitoresToolStripMenuItem.Text = "Capacitores";
            this.capacitoresToolStripMenuItem.Click += new System.EventHandler(this.capacitoresToolStripMenuItem_Click);
            // 
            // geradoresEReceptoresToolStripMenuItem
            // 
            this.geradoresEReceptoresToolStripMenuItem.Name = "geradoresEReceptoresToolStripMenuItem";
            this.geradoresEReceptoresToolStripMenuItem.Size = new System.Drawing.Size(431, 26);
            this.geradoresEReceptoresToolStripMenuItem.Text = "Geradores e Receptores";
            this.geradoresEReceptoresToolStripMenuItem.Click += new System.EventHandler(this.geradoresEReceptoresToolStripMenuItem_Click);
            // 
            // hidrostáticaEGrandezasFísicasToolStripMenuItem
            // 
            this.hidrostáticaEGrandezasFísicasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.análiseGrandezasErrosToolStripMenuItem,
            this.pressãoHidrostáticaLeiDeStevinToolStripMenuItem,
            this.vasosComunicantesTubosEmUToolStripMenuItem,
            this.máquinasHidráulicasEPrincípioDePascalToolStripMenuItem,
            this.empuxoArquimedesToolStripMenuItem,
            this.hidrodinâmicaToolStripMenuItem});
            this.hidrostáticaEGrandezasFísicasToolStripMenuItem.Name = "hidrostáticaEGrandezasFísicasToolStripMenuItem";
            this.hidrostáticaEGrandezasFísicasToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.hidrostáticaEGrandezasFísicasToolStripMenuItem.Text = "Hidrostática e Fluídos";
            // 
            // análiseGrandezasErrosToolStripMenuItem
            // 
            this.análiseGrandezasErrosToolStripMenuItem.Name = "análiseGrandezasErrosToolStripMenuItem";
            this.análiseGrandezasErrosToolStripMenuItem.Size = new System.Drawing.Size(386, 26);
            this.análiseGrandezasErrosToolStripMenuItem.Text = "Pressão";
            this.análiseGrandezasErrosToolStripMenuItem.Click += new System.EventHandler(this.análiseGrandezasErrosToolStripMenuItem_Click);
            // 
            // pressãoHidrostáticaLeiDeStevinToolStripMenuItem
            // 
            this.pressãoHidrostáticaLeiDeStevinToolStripMenuItem.Name = "pressãoHidrostáticaLeiDeStevinToolStripMenuItem";
            this.pressãoHidrostáticaLeiDeStevinToolStripMenuItem.Size = new System.Drawing.Size(386, 26);
            this.pressãoHidrostáticaLeiDeStevinToolStripMenuItem.Text = "Pressão Hidrostática (Lei de Stevin)";
            this.pressãoHidrostáticaLeiDeStevinToolStripMenuItem.Click += new System.EventHandler(this.pressãoHidrostáticaLeiDeStevinToolStripMenuItem_Click);
            // 
            // vasosComunicantesTubosEmUToolStripMenuItem
            // 
            this.vasosComunicantesTubosEmUToolStripMenuItem.Name = "vasosComunicantesTubosEmUToolStripMenuItem";
            this.vasosComunicantesTubosEmUToolStripMenuItem.Size = new System.Drawing.Size(386, 26);
            this.vasosComunicantesTubosEmUToolStripMenuItem.Text = "Vasos Comunicantes Tubos em U";
            this.vasosComunicantesTubosEmUToolStripMenuItem.Click += new System.EventHandler(this.vasosComunicantesTubosEmUToolStripMenuItem_Click);
            // 
            // máquinasHidráulicasEPrincípioDePascalToolStripMenuItem
            // 
            this.máquinasHidráulicasEPrincípioDePascalToolStripMenuItem.Name = "máquinasHidráulicasEPrincípioDePascalToolStripMenuItem";
            this.máquinasHidráulicasEPrincípioDePascalToolStripMenuItem.Size = new System.Drawing.Size(386, 26);
            this.máquinasHidráulicasEPrincípioDePascalToolStripMenuItem.Text = "Máquinas Hidráulicas e Princípio de Pascal";
            this.máquinasHidráulicasEPrincípioDePascalToolStripMenuItem.Click += new System.EventHandler(this.máquinasHidráulicasEPrincípioDePascalToolStripMenuItem_Click);
            // 
            // empuxoArquimedesToolStripMenuItem
            // 
            this.empuxoArquimedesToolStripMenuItem.Name = "empuxoArquimedesToolStripMenuItem";
            this.empuxoArquimedesToolStripMenuItem.Size = new System.Drawing.Size(386, 26);
            this.empuxoArquimedesToolStripMenuItem.Text = "Empuxo Arquimedes";
            this.empuxoArquimedesToolStripMenuItem.Click += new System.EventHandler(this.empuxoArquimedesToolStripMenuItem_Click);
            // 
            // hidrodinâmicaToolStripMenuItem
            // 
            this.hidrodinâmicaToolStripMenuItem.Name = "hidrodinâmicaToolStripMenuItem";
            this.hidrodinâmicaToolStripMenuItem.Size = new System.Drawing.Size(386, 26);
            this.hidrodinâmicaToolStripMenuItem.Text = "Hidrodinâmica";
            this.hidrodinâmicaToolStripMenuItem.Click += new System.EventHandler(this.hidrodinâmicaToolStripMenuItem_Click);
            // 
            // ondasToolStripMenuItem
            // 
            this.ondasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.introduçãoToolStripMenuItem2,
            this.conceitoToolStripMenuItem,
            this.velocidadeDasOndasToolStripMenuItem});
            this.ondasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.ondasToolStripMenuItem.Name = "ondasToolStripMenuItem";
            this.ondasToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.ondasToolStripMenuItem.Text = "Ondas";
            // 
            // introduçãoToolStripMenuItem2
            // 
            this.introduçãoToolStripMenuItem2.Name = "introduçãoToolStripMenuItem2";
            this.introduçãoToolStripMenuItem2.Size = new System.Drawing.Size(240, 26);
            this.introduçãoToolStripMenuItem2.Text = "Introdução";
            this.introduçãoToolStripMenuItem2.Click += new System.EventHandler(this.introduçãoToolStripMenuItem2_Click);
            // 
            // conceitoToolStripMenuItem
            // 
            this.conceitoToolStripMenuItem.Name = "conceitoToolStripMenuItem";
            this.conceitoToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.conceitoToolStripMenuItem.Text = "Conceito";
            this.conceitoToolStripMenuItem.Click += new System.EventHandler(this.conceitoToolStripMenuItem_Click);
            // 
            // velocidadeDasOndasToolStripMenuItem
            // 
            this.velocidadeDasOndasToolStripMenuItem.Name = "velocidadeDasOndasToolStripMenuItem";
            this.velocidadeDasOndasToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.velocidadeDasOndasToolStripMenuItem.Text = "Velocidade das Ondas";
            this.velocidadeDasOndasToolStripMenuItem.Click += new System.EventHandler(this.velocidadeDasOndasToolStripMenuItem_Click);
            // 
            // ópticaToolStripMenuItem
            // 
            this.ópticaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dispersãoLuminosaECoresToolStripMenuItem,
            this.espelhoPlanoToolStripMenuItem,
            this.espelhoEsféricosToolStripMenuItem,
            this.lentesToolStripMenuItem,
            this.defeitosDeVisãoToolStripMenuItem,
            this.dispersãoLuminosaECoresToolStripMenuItem1});
            this.ópticaToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.ópticaToolStripMenuItem.Name = "ópticaToolStripMenuItem";
            this.ópticaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.ópticaToolStripMenuItem.Text = "Óptica";
            // 
            // dispersãoLuminosaECoresToolStripMenuItem
            // 
            this.dispersãoLuminosaECoresToolStripMenuItem.Name = "dispersãoLuminosaECoresToolStripMenuItem";
            this.dispersãoLuminosaECoresToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.dispersãoLuminosaECoresToolStripMenuItem.Text = "Dispersão Luminosa e Cores";
            this.dispersãoLuminosaECoresToolStripMenuItem.Click += new System.EventHandler(this.dispersãoLuminosaECoresToolStripMenuItem_Click);
            // 
            // espelhoPlanoToolStripMenuItem
            // 
            this.espelhoPlanoToolStripMenuItem.Name = "espelhoPlanoToolStripMenuItem";
            this.espelhoPlanoToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.espelhoPlanoToolStripMenuItem.Text = "Espelho Plano";
            this.espelhoPlanoToolStripMenuItem.Click += new System.EventHandler(this.espelhoPlanoToolStripMenuItem_Click);
            // 
            // espelhoEsféricosToolStripMenuItem
            // 
            this.espelhoEsféricosToolStripMenuItem.Name = "espelhoEsféricosToolStripMenuItem";
            this.espelhoEsféricosToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.espelhoEsféricosToolStripMenuItem.Text = "Espelho Esféricos";
            this.espelhoEsféricosToolStripMenuItem.Click += new System.EventHandler(this.espelhoEsféricosToolStripMenuItem_Click);
            // 
            // lentesToolStripMenuItem
            // 
            this.lentesToolStripMenuItem.Name = "lentesToolStripMenuItem";
            this.lentesToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.lentesToolStripMenuItem.Text = "Lentes";
            this.lentesToolStripMenuItem.Click += new System.EventHandler(this.lentesToolStripMenuItem_Click);
            // 
            // defeitosDeVisãoToolStripMenuItem
            // 
            this.defeitosDeVisãoToolStripMenuItem.Name = "defeitosDeVisãoToolStripMenuItem";
            this.defeitosDeVisãoToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.defeitosDeVisãoToolStripMenuItem.Text = "Defeitos de Visão";
            this.defeitosDeVisãoToolStripMenuItem.Click += new System.EventHandler(this.defeitosDeVisãoToolStripMenuItem_Click);
            // 
            // dispersãoLuminosaECoresToolStripMenuItem1
            // 
            this.dispersãoLuminosaECoresToolStripMenuItem1.Name = "dispersãoLuminosaECoresToolStripMenuItem1";
            this.dispersãoLuminosaECoresToolStripMenuItem1.Size = new System.Drawing.Size(284, 26);
            this.dispersãoLuminosaECoresToolStripMenuItem1.Text = "Dispersão Luminosa e Cores";
            this.dispersãoLuminosaECoresToolStripMenuItem1.Click += new System.EventHandler(this.dispersãoLuminosaECoresToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.Color.Tomato;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem8,
            this.toolStripMenuItem25,
            this.toolStripMenuItem45,
            this.toolStripMenuItem54,
            this.toolStripMenuItem59,
            this.toolStripMenuItem63,
            this.toolStripMenuItem70,
            this.toolStripMenuItem77,
            this.toolStripMenuItem81});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(109, 25);
            this.toolStripMenuItem1.Text = "Perguntas";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem2.Text = "Termologia";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.BackColor = System.Drawing.Color.White;
            this.toolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.toolStripMenuItem16,
            this.toolStripMenuItem17,
            this.toolStripMenuItem18,
            this.toolStripMenuItem19,
            this.toolStripMenuItem20,
            this.toolStripMenuItem24});
            this.toolStripMenuItem8.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem8.Text = "Cinemática Escalar";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem10.Text = "Velocidade Média";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem11.Text = "Movimento Retilíneo Uniforme MRU";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem13.Text = "Velocidade Relativa";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem14.Text = "Movimento Retilíneo Uniformemente Variado MRUV";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem16.Text = "Movimento de Queda Livre( MQL )";
            this.toolStripMenuItem16.Click += new System.EventHandler(this.toolStripMenuItem16_Click);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem17.Text = "Lançamentos horizontais";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem18.Text = "Lançamentos Oblíquos";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem19.Text = "Gráficos da Cinemática";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.toolStripMenuItem19_Click);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem20.Text = "Movimento Circular";
            this.toolStripMenuItem20.Click += new System.EventHandler(this.toolStripMenuItem20_Click);
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(463, 26);
            this.toolStripMenuItem24.Text = "Dedução da Equação de Torricelli";
            this.toolStripMenuItem24.Click += new System.EventHandler(this.toolStripMenuItem24_Click);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem26,
            this.toolStripMenuItem34,
            this.toolStripMenuItem35,
            this.toolStripMenuItem36,
            this.toolStripMenuItem39,
            this.toolStripMenuItem40,
            this.toolStripMenuItem44});
            this.toolStripMenuItem25.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem25.Text = "Dinâmica";
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem28,
            this.toolStripMenuItem29,
            this.toolStripMenuItem30,
            this.toolStripMenuItem31,
            this.toolStripMenuItem33});
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(350, 26);
            this.toolStripMenuItem26.Text = "Leis de Newton";
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(321, 26);
            this.toolStripMenuItem28.Text = "Primeira Lei de Newton INÉRCIA";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.toolStripMenuItem28_Click);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(321, 26);
            this.toolStripMenuItem29.Text = "Segunda Lei de Newton";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.toolStripMenuItem29_Click);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(321, 26);
            this.toolStripMenuItem30.Text = "Terceira Lei de Newton";
            this.toolStripMenuItem30.Click += new System.EventHandler(this.toolStripMenuItem30_Click);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(321, 26);
            this.toolStripMenuItem31.Text = "Leis de Newton - Polias";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.toolStripMenuItem31_Click);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(321, 26);
            this.toolStripMenuItem33.Text = "Leis de Newton - Tipos de Forças";
            this.toolStripMenuItem33.Click += new System.EventHandler(this.toolStripMenuItem33_Click);
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(350, 26);
            this.toolStripMenuItem34.Text = "Força de Atrito";
            this.toolStripMenuItem34.Click += new System.EventHandler(this.toolStripMenuItem34_Click);
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(350, 26);
            this.toolStripMenuItem35.Text = "Força Elástica Lei de Hooke";
            this.toolStripMenuItem35.Click += new System.EventHandler(this.toolStripMenuItem35_Click);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem37,
            this.toolStripMenuItem38});
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(350, 26);
            this.toolStripMenuItem36.Text = "Impulso/Quantidade de Movimentos";
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(284, 26);
            this.toolStripMenuItem37.Text = "Quantidade de Movimentos";
            this.toolStripMenuItem37.Click += new System.EventHandler(this.toolStripMenuItem37_Click);
            // 
            // toolStripMenuItem38
            // 
            this.toolStripMenuItem38.Name = "toolStripMenuItem38";
            this.toolStripMenuItem38.Size = new System.Drawing.Size(284, 26);
            this.toolStripMenuItem38.Text = "Impulso";
            this.toolStripMenuItem38.Click += new System.EventHandler(this.toolStripMenuItem38_Click);
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(350, 26);
            this.toolStripMenuItem39.Text = "Colisões";
            this.toolStripMenuItem39.Click += new System.EventHandler(this.toolStripMenuItem39_Click);
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem41,
            this.toolStripMenuItem42,
            this.toolStripMenuItem43});
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(350, 26);
            this.toolStripMenuItem40.Text = "Energia";
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem41.Text = "Energia Mecânica";
            this.toolStripMenuItem41.Click += new System.EventHandler(this.toolStripMenuItem41_Click);
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem42.Text = "Teorema da Energia Cinética (TEC)";
            this.toolStripMenuItem42.Click += new System.EventHandler(this.toolStripMenuItem42_Click);
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(326, 26);
            this.toolStripMenuItem43.Text = "Trabalho e Energia";
            this.toolStripMenuItem43.Click += new System.EventHandler(this.toolStripMenuItem43_Click);
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(350, 26);
            this.toolStripMenuItem44.Text = "Pêndulos";
            this.toolStripMenuItem44.Click += new System.EventHandler(this.toolStripMenuItem44_Click);
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem47,
            this.toolStripMenuItem48,
            this.toolStripMenuItem49,
            this.toolStripMenuItem51});
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem45.Text = "Eletrostática";
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(444, 26);
            this.toolStripMenuItem47.Text = "Processos de Eletrizações";
            this.toolStripMenuItem47.Click += new System.EventHandler(this.toolStripMenuItem47_Click);
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(444, 26);
            this.toolStripMenuItem48.Text = "Lei de Coulomb";
            this.toolStripMenuItem48.Click += new System.EventHandler(this.toolStripMenuItem48_Click);
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(444, 26);
            this.toolStripMenuItem49.Text = "Campo Elétric";
            this.toolStripMenuItem49.Click += new System.EventHandler(this.toolStripMenuItem49_Click);
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(444, 26);
            this.toolStripMenuItem51.Text = "Potencial Elétrico e Trabalho de uma Força Elétrica";
            this.toolStripMenuItem51.Click += new System.EventHandler(this.toolStripMenuItem51_Click);
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem55,
            this.toolStripMenuItem56,
            this.toolStripMenuItem57,
            this.toolStripMenuItem58});
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem54.Text = "Eletrodinâmica";
            // 
            // toolStripMenuItem55
            // 
            this.toolStripMenuItem55.Name = "toolStripMenuItem55";
            this.toolStripMenuItem55.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem55.Text = "Corrente Elétrica";
            this.toolStripMenuItem55.Click += new System.EventHandler(this.toolStripMenuItem55_Click);
            // 
            // toolStripMenuItem56
            // 
            this.toolStripMenuItem56.Name = "toolStripMenuItem56";
            this.toolStripMenuItem56.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem56.Text = "Lei de Ohm";
            this.toolStripMenuItem56.Click += new System.EventHandler(this.toolStripMenuItem56_Click);
            // 
            // toolStripMenuItem57
            // 
            this.toolStripMenuItem57.Name = "toolStripMenuItem57";
            this.toolStripMenuItem57.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem57.Text = "Fatores que influenciam na Resistência";
            this.toolStripMenuItem57.Click += new System.EventHandler(this.toolStripMenuItem57_Click);
            // 
            // toolStripMenuItem58
            // 
            this.toolStripMenuItem58.Name = "toolStripMenuItem58";
            this.toolStripMenuItem58.Size = new System.Drawing.Size(359, 26);
            this.toolStripMenuItem58.Text = "Potência Elétrica e Energia Elétrica";
            this.toolStripMenuItem58.Click += new System.EventHandler(this.toolStripMenuItem58_Click);
            // 
            // toolStripMenuItem59
            // 
            this.toolStripMenuItem59.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem60,
            this.toolStripMenuItem61,
            this.toolStripMenuItem62});
            this.toolStripMenuItem59.Name = "toolStripMenuItem59";
            this.toolStripMenuItem59.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem59.Text = "Física Moderna ";
            // 
            // toolStripMenuItem60
            // 
            this.toolStripMenuItem60.Name = "toolStripMenuItem60";
            this.toolStripMenuItem60.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem60.Text = "Física Nuclear";
            this.toolStripMenuItem60.Click += new System.EventHandler(this.toolStripMenuItem60_Click);
            // 
            // toolStripMenuItem61
            // 
            this.toolStripMenuItem61.Name = "toolStripMenuItem61";
            this.toolStripMenuItem61.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem61.Text = "Radioatividade";
            this.toolStripMenuItem61.Click += new System.EventHandler(this.toolStripMenuItem61_Click);
            // 
            // toolStripMenuItem62
            // 
            this.toolStripMenuItem62.Name = "toolStripMenuItem62";
            this.toolStripMenuItem62.Size = new System.Drawing.Size(250, 26);
            this.toolStripMenuItem62.Text = "Decaimento Radioativo";
            this.toolStripMenuItem62.Click += new System.EventHandler(this.toolStripMenuItem62_Click);
            // 
            // toolStripMenuItem63
            // 
            this.toolStripMenuItem63.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem64,
            this.toolStripMenuItem67,
            this.toolStripMenuItem68,
            this.toolStripMenuItem69});
            this.toolStripMenuItem63.Name = "toolStripMenuItem63";
            this.toolStripMenuItem63.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem63.Text = "Circuitos Elétricos";
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem64.Text = "Associação de Resistores";
            this.toolStripMenuItem64.Click += new System.EventHandler(this.toolStripMenuItem64_Click);
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem67.Text = "Circuito Misto";
            this.toolStripMenuItem67.Click += new System.EventHandler(this.toolStripMenuItem67_Click);
            // 
            // toolStripMenuItem68
            // 
            this.toolStripMenuItem68.Name = "toolStripMenuItem68";
            this.toolStripMenuItem68.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem68.Text = "Capacitores";
            this.toolStripMenuItem68.Click += new System.EventHandler(this.toolStripMenuItem68_Click);
            // 
            // toolStripMenuItem69
            // 
            this.toolStripMenuItem69.Name = "toolStripMenuItem69";
            this.toolStripMenuItem69.Size = new System.Drawing.Size(263, 26);
            this.toolStripMenuItem69.Text = "Geradores e Receptores";
            this.toolStripMenuItem69.Click += new System.EventHandler(this.toolStripMenuItem69_Click);
            // 
            // toolStripMenuItem70
            // 
            this.toolStripMenuItem70.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem71,
            this.toolStripMenuItem72,
            this.toolStripMenuItem73,
            this.toolStripMenuItem74,
            this.toolStripMenuItem75,
            this.toolStripMenuItem76});
            this.toolStripMenuItem70.Name = "toolStripMenuItem70";
            this.toolStripMenuItem70.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem70.Text = "Hidrostática e Fluídos";
            // 
            // toolStripMenuItem71
            // 
            this.toolStripMenuItem71.Name = "toolStripMenuItem71";
            this.toolStripMenuItem71.Size = new System.Drawing.Size(386, 26);
            this.toolStripMenuItem71.Text = "Pressão";
            this.toolStripMenuItem71.Click += new System.EventHandler(this.toolStripMenuItem71_Click);
            // 
            // toolStripMenuItem72
            // 
            this.toolStripMenuItem72.Name = "toolStripMenuItem72";
            this.toolStripMenuItem72.Size = new System.Drawing.Size(386, 26);
            this.toolStripMenuItem72.Text = "Pressão Hidrostática (Lei de Stevin)";
            this.toolStripMenuItem72.Click += new System.EventHandler(this.toolStripMenuItem72_Click);
            // 
            // toolStripMenuItem73
            // 
            this.toolStripMenuItem73.Name = "toolStripMenuItem73";
            this.toolStripMenuItem73.Size = new System.Drawing.Size(386, 26);
            this.toolStripMenuItem73.Text = "Vasos Comunicantes Tubos em U";
            this.toolStripMenuItem73.Click += new System.EventHandler(this.toolStripMenuItem73_Click);
            // 
            // toolStripMenuItem74
            // 
            this.toolStripMenuItem74.Name = "toolStripMenuItem74";
            this.toolStripMenuItem74.Size = new System.Drawing.Size(386, 26);
            this.toolStripMenuItem74.Text = "Máquinas Hidráulicas e Princípio de Pascal";
            this.toolStripMenuItem74.Click += new System.EventHandler(this.toolStripMenuItem74_Click);
            // 
            // toolStripMenuItem75
            // 
            this.toolStripMenuItem75.Name = "toolStripMenuItem75";
            this.toolStripMenuItem75.Size = new System.Drawing.Size(386, 26);
            this.toolStripMenuItem75.Text = "Empuxo Arquimedes";
            this.toolStripMenuItem75.Click += new System.EventHandler(this.toolStripMenuItem75_Click);
            // 
            // toolStripMenuItem76
            // 
            this.toolStripMenuItem76.Name = "toolStripMenuItem76";
            this.toolStripMenuItem76.Size = new System.Drawing.Size(386, 26);
            this.toolStripMenuItem76.Text = "Hidrodinâmica";
            this.toolStripMenuItem76.Click += new System.EventHandler(this.toolStripMenuItem76_Click);
            // 
            // toolStripMenuItem77
            // 
            this.toolStripMenuItem77.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem79,
            this.toolStripMenuItem80});
            this.toolStripMenuItem77.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem77.Name = "toolStripMenuItem77";
            this.toolStripMenuItem77.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem77.Text = "Ondas";
            // 
            // toolStripMenuItem79
            // 
            this.toolStripMenuItem79.Name = "toolStripMenuItem79";
            this.toolStripMenuItem79.Size = new System.Drawing.Size(240, 26);
            this.toolStripMenuItem79.Text = "Conceito";
            this.toolStripMenuItem79.Click += new System.EventHandler(this.toolStripMenuItem79_Click);
            // 
            // toolStripMenuItem80
            // 
            this.toolStripMenuItem80.Name = "toolStripMenuItem80";
            this.toolStripMenuItem80.Size = new System.Drawing.Size(240, 26);
            this.toolStripMenuItem80.Text = "Velocidade das Ondas";
            this.toolStripMenuItem80.Click += new System.EventHandler(this.toolStripMenuItem80_Click);
            // 
            // toolStripMenuItem81
            // 
            this.toolStripMenuItem81.ForeColor = System.Drawing.Color.Red;
            this.toolStripMenuItem81.Name = "toolStripMenuItem81";
            this.toolStripMenuItem81.Size = new System.Drawing.Size(238, 26);
            this.toolStripMenuItem81.Text = "Óptica";
            this.toolStripMenuItem81.Click += new System.EventHandler(this.toolStripMenuItem81_Click);
            // 
            // sfoPlayer
            // 
            this.sfoPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sfoPlayer.Enabled = true;
            this.sfoPlayer.Location = new System.Drawing.Point(122, 0);
            this.sfoPlayer.Name = "sfoPlayer";
            this.sfoPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("sfoPlayer.OcxState")));
            this.sfoPlayer.Size = new System.Drawing.Size(914, 612);
            this.sfoPlayer.TabIndex = 42;
            // 
            // PictureCSharp
            // 
            this.PictureCSharp.BackgroundImage = global::CursoVideo.Properties.Resources.pequena;
            this.PictureCSharp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PictureCSharp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureCSharp.Location = new System.Drawing.Point(122, 0);
            this.PictureCSharp.Name = "PictureCSharp";
            this.PictureCSharp.Size = new System.Drawing.Size(914, 612);
            this.PictureCSharp.TabIndex = 43;
            this.PictureCSharp.TabStop = false;
            // 
            // panelQuiz
            // 
            this.panelQuiz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelQuiz.Location = new System.Drawing.Point(122, 0);
            this.panelQuiz.Name = "panelQuiz";
            this.panelQuiz.Size = new System.Drawing.Size(914, 612);
            this.panelQuiz.TabIndex = 65;
            // 
            // FrmFisica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.panelQuiz);
            this.Controls.Add(this.PictureCSharp);
            this.Controls.Add(this.sfoPlayer);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmFisica";
            this.Text = "FrmFisica";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sfoPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureCSharp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fecharMenuItem;
        private AxShockwaveFlashObjects.AxShockwaveFlash sfoPlayer;
        private System.Windows.Forms.PictureBox PictureCSharp;
        private System.Windows.Forms.ToolStripMenuItem físicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cinemáticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dinâmicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem energiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leisDeNewtonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colisõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impulsoQuantidadeDeMovimentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eletrostáticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem físicaModernaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem físicaNuclearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem radioatividadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hidrostáticaEGrandezasFísicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem análiseGrandezasErrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ondasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ópticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem termologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem primeiraLeiDeNewtonINÉRCIAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem egundaLeiDeNewtonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem terceiraLeiDeNewtonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leisDeNewtonPoliasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leisDeNewtonAplicaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leisDeNewtonTiposDeForçasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem forçaDeAtritoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem forçaElásticaLeiDeHookeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quantidadeDeMovimentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impulsoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pêndulosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem energiaMecânicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eoremaDaEnergiaCinéticaTECToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trabalhoEEnergiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pressãoHidrostáticaLeiDeStevinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vasosComunicantesTubosEmUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem máquinasHidráulicasEPrincípioDePascalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empuxoArquimedesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hidrodinâmicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eletrodinâmicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem correnteElétricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leiDeOhmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fatoresQueInfluenciamNaResistênciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potênciaElétricaEEnergiaElétricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem processosDeEletrizaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leiDeCoulombToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem campoElétricoIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem campoElétricoIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potencialElétricoIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circuitosElétricosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem associaçãoDeResistoresIIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem circuitoMistoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem capacitoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geradoresEReceptoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dispersãoLuminosaECoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem espelhoPlanoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem espelhoEsféricosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lentesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem defeitosDeVisãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dispersãoLuminosaECoresToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem conceitoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem velocidadeDasOndasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem velocidadeMédiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoRetilíneoUniformeMRUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mRUAPLICAÇÕESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem velocidadeRelativaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoDeQuedaLivreMQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lançamentosHorizontaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lançamentosOblíquosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gráficosDaCinemáticaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoCircularToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem uniformeMCUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aplicaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deduçãoDaEquaçãoDeTorricelliToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decaimentoRadioativoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem introduçãoÀTermologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transferênciaDeCalorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem escalasTermométricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dilataçãoTérmicaIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dilataçãoTérmicaIIToolStripMenuItem;
        private System.Windows.Forms.Panel panelQuiz;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem57;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem58;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem59;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem60;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem61;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem62;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem63;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem68;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem69;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem70;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem71;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem72;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem73;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem74;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem75;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem76;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem77;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem79;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem80;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem81;
    }
}