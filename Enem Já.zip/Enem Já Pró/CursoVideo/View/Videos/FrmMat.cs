﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmMat : Form
    {
        public FrmMat()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }

        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }

        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }

        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Matemática";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void fecharMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
             MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }

        private void expressõesNuméricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qzl93K6_-LY&index=5");
        }

        private void critériosDeDivisibilidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nBYcEu3P6EQ");
        }

        private void númerosPrimosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qYww45PyTEs");
        }

        private void fatoraçãoDeNúmerosInteirosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=74jrzl0yPlI&index=8");
        }

        private void quantidadeDeDivisoresDeUmNúmeroInteiroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=_GmG-b3fpb0");
        }

        private void divisoresDeUmNúmeroInteiroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Jg05vwP-pkY");
        }

        private void mínimoMúltiploComumMMCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TcbtrAPagnw");
        }

        private void máximoDivisorComumMDCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Cy4gAIEM8Dc&index=12");
        }

        private void fraçõesparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=i2GEeGSrZ_E");
        }

        private void fraçõesparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=RbLQCSB4EUY&index=14");
        }

        private void númerosDecimaisparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=lA1lVOBTSlQ&index=15");
        }

        private void númerosDecimaisparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=mKoNPRZ8yn8&index=16");
        }

        private void dízimasPeriódicasdecimaisPeriódicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=d9GBEzzCuRg&index=17");
        }

        private void potenciaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vA8j9nqBlBM&index=18");
        }

        private void potênciaDeDezENotaçãoCientíficaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=IOgeC4ElSlo&index=19");
        }

        private void sistemaDeNumeraçãoDecimalOuBaseDezToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=C812J7_hqTg");
        }

        private void radiciaçãoparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HOc9gSqbJ-8&index=21");
        }

        private void radiciaçãoparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ULydE64exnA&index=22");
        }

        private void produtosNotáveisparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=i48MouWbMCo&index=23");
        }

        private void produtosNotáveisparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7pueb_lKwok");
        }

        private void fatoraçãoDeExpressõesAlgébricasparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gpLUtjncoSo&index=25");
        }

        private void fatoraçãoDeExpressõesAlgébricasparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HQpjjix_aeE&index=26");
        }

        private void fraçõesAlgébricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=_iRc9eMvg_U");
        }

        private void racionalizaçãoDeDenominadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xHQ7cUZnM9g&index=28");
        }

        private void razãoEProporçãoparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wnHd-ofn-os&index=29");
        }

        private void razãoEProporçãoparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8f8BMdUXXV8&index=30");
        }

        private void regraDeTrêsSimplesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=MbVyJfI_Ob4&index=31");
        }

        private void regraDeTrêsCompostaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YnYcf-Vrnl0");
        }

        private void porcentagemparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=J3lwBTutjaw");
        }

        private void porcentagemparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nrQyzCHSrMY");
        }

        private void jurosSimplesparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YHFAeGkBHZI");
        }

        private void jurosSimplesparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=X9xTZ7_QZV4&index=36");
        }

        private void jurosCompostosparte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZxhZpTcNgX8&index=37");
        }

        private void jurosCompostosparte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bqBte86helo&index=38");
        }

        private void sistemaMétricoDecimalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VaxJAPbZMFg");
        }

        private void médiaAritméticaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2sRWaVJh7_o");
        }

        private void médiaPonderadaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=o8fEcLAar0w");
        }

        private void médiaGeométricaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6oVRnFFTu6o");
        }

        private void médiaHarmônicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bamPhPrZk6w&index=43");
        }

        private void equaçãoDo1GrauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0lbhe16At_A&index=44");
        }

        private void equaçãoDo2GrauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ss2VqSeqRQI&index=45");
        }

        private void equaçõesIrracionaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=GvcIM7_DYXA&index=46");
        }

        private void equaçõesBiquadradasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ayC0m_6-SHQ");
        }

        private void princípioFundamentalDaContagemToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=a1FtCh6Snm0");
        }

        private void princípioFundamentalDaContagemENotasDasEscolasDeSambaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=nxFl8hg1OVo");
        }

        private void fatorialEPermutaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4zMFrPhCkbE");
        }

        private void permutaçãoNaVideolocadoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=f-osGM-STDI&index=4");
        }

        private void arranjoECombinaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TE-QGzBM5I0&index=5");
        }

        private void conceitoDeCombinaçãoEArranjoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CDdQq9v7-hM");
        }

        private void análiseCombinatóriaquestãoFácilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1idihALcaio");
        }

        private void comparaçãoDasChancesDeGanharNaLoteriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0S0Z1dTaKxw&index=8");
        }

        private void análiseCombinatóriacomPegadinhaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=RsG9tYUQV30&index=9");
        }

        private void introduçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TC2HcZV3mGo&index=1");
        }

        private void termoGeralToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yfmhfoB0kVA");
        }

        private void termoGeralExercíciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=dzoloHN076c");
        }

        private void notaçõesEspeciaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qoX9HFbYbK4&index=4");
        }

        private void interpolaçãoDeMeiosAritméticosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PGDk9ZHPudg&index=5");
        }

        private void somaDosTermosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vyJGTm6WvdU");
        }

        private void questõesComentadasParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wPB7riMEUbY");
        }

        private void questõesComentadasParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8NqxxLHYr_c");
        }

        private void introduçãoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Jad_XG9bDCE");
        }

        private void termoGeralToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0rRuhofRVuU&index=2");
        }

        private void termoGeralExercíciosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6ShsVLOtGQI&index=3");
        }

        private void notaçõesEspeciaisToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NM9H8__q4gU");
        }

        private void interpolaçãoDeMeiosGeométricosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Hsp10bhYQEs");
        }

        private void somaDosTermosDeUmaPGFinitaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CDZYMkxv2JA");
        }

        private void somaDosTermosDeUmaPGInfinitaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=N_EatIhGANo");
        }

        private void exercíciosDePAEPGSimultaneamenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ANwGhVVhs-s&index=8");
        }

        private void questõesComentadasParte1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=W1c4vhQSoVI&index=9");
        }

        private void questõesComentadasParte2ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=d0EcswGgJdI");
        }

        private void introduçãoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0aUEDxYjZg8&index=1");
        }

        private void subconjuntosEConjuntoDasPartesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Wxm3ugnq9Sw&index=2");
        }

        private void uniãoEIntersecçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=c5a99sX-Sq8");
        }

        private void diferençaEComplementarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=eZfFpnvudR0&index=4");
        }

        private void questõesComentadasConjuntosNívelBásicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wVZYyOuz9GI");
        }

        private void questõesComentadasConjuntosNívelIntermediárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=id8fXOFnoio");
        }

        private void questõesComentadasConjuntosNívelAvançadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6ZZfEs-ccAY&index=7");
        }

        private void númerosNaturaisEInteirosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Y_mYgLkuEl4&index=1");
        }

        private void númerosRacionaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NYAeWhz53NM&index=2");
        }

        private void númerosIrracionaisEReaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=J4vD5RpOqJY&index=3");
        }

        private void intervalosReaisOperaçõesEPropriedadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OPACJhL_mLY");
        }

        private void conjuntosNuméricosNívelBásicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TlsqGpE7Td8&index=5");
        }

        private void questõesComentadasConjuntosNuméricosNívelIntermediárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Bq5XYZKXk-Q&index=6");
        }

        private void questõesComentadasConjuntosNuméricosNívelAvançadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=aVfou0Ad88s&index=7");
        }

        private void noçõesBásicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SPZqQ5qn3P0&index=15");
        }

        private void domínioContradomínioEConjuntoImagemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=G3zjNRYbDv8");
        }

        private void estudoDoDomínioDasFunçõesReaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Y1urlgE0lBU");
        }

        private void noçõesBásicasDePlanoCartesianoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=iC4q1AGeN5A");
        }

        private void construçãoDeGráficosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=K7wtLRXGLJw");
        }

        private void domínioEImagemAtravésDoGráficoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=w13aeOGO3ZI");
        }

        private void reconhecendoUmaFunçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xsIMsYRl46M");
        }

        private void analisandoOGráficoDeFunçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5aLsdGSxCM4");
        }

        private void questõesComentadasAnáliseDeGráficosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8sXnloWAU8s&index=23");
        }

        private void funçãoParEFunçãoÍmparToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HYvlmUiRpGc&index=24");
        }

        private void funçãoInjetoraFunçãoInjetivaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OMvGmAB96do");
        }

        private void funçãoSobrejetoraFunçãoSobrejetivaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=057CkKna7kM");
        }

        private void funçãoBijetoraFunçãoBijetivaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=B8TtvV_vKQc&index=27");
        }

        private void funçãoCompostaComposiçãoDeFunçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=V9yhPL87lGs");
        }

        private void funçãoCompostaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=mytzKEjGM_A&index=29");
        }

        private void funçãoInversaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=k-BPycvaZLA&index=30");
        }

        private void questõesComentadasFunçãoInversaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HXAdRVV_SMc");
        }

        private void conceitosIniciaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=hdMFlAv5GkU");
        }

        private void determinandoAFunçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-EnodYhcQw4&index=33");
        }

        private void exercíciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yTfNuU2xrrc&index=34");
        }

        private void gráficoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2KWDWpmDZwQ&index=35");
        }

        private void coeficienteAngularECoeficienteLinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xDTd2a4NJ40");
        }

        private void exercíciosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Bs2Ylb4x2V8&index=37");
        }

        private void casosParticularesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=567sWGTnf5Q&index=38");
        }

        private void zeroOuRaizDaFunçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PgOLmJ00KPQ");
        }

        private void estudoDoSinalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=5FpSn7-k2sk&index=40");
        }

        private void questõesComentadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BU5XJv7bKB0&index=41");
        }

        private void questõesComentadasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gu_hGWzh_YM");
        }

        private void conceitosIniciaisToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LsX-0I5w9UE&index=43");
        }

        private void inequaçõesSimultâneasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=q1dYyoDKVs4");
        }

        private void inequaçãoProdutoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pxkS0gN0gN0");
        }

        private void inequaçãoQuocienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HBkSpbVoYW4&index=46");
        }

        private void questõesComentadasInequaçãoDoPrimeiroGrauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0SiUrWOSL1U&index=47");
        }

        private void conceitosIniciaisToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Z5aVW_Zgifk&index=48");
        }

        private void zerosRaízesEFórmulaDeBhaskaraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CNqeTO2tCuI");
        }

        private void quantidadeDeRaízesReaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4d48gLFe3F0&index=50");
        }

        private void exercíciosToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oPLsPe94q8Y&index=51");
        }

        private void gráficoParábolaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZnxMdyN4Xp8");
        }

        private void gráficoParábolaIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=U9I1LFFcUkw&index=53");
        }

        private void exercíciosSobreGráficoParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-iMToBhO2i8&index=54");
        }

        private void exercíciosSobreGráficoParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yihH524OkeA&index=55");
        }

        private void estudoDoSinalGráficoParábolaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SggGwu1VV3s&index=56");
        }

        private void questõesComentadasParte1ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6FD8cHk1mI4");
        }

        private void questõesComentadasParte2ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=iMbNrIm2zc4");
        }

        private void inequaçõesSimultâneasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=C50Um6OjmTg");
        }

        private void inequaçãoProdutoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Rh99ZjA2NuU");
        }

        private void inequaçãoQuocienteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=u1zvLoATa-8");
        }

        private void questõesComentadasInequaçãoDoSegundoGrauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jy2hQSveWc8&index=63");
        }

        private void móduloDeUmNúmeroRealToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=sXFdCZXzRT8&index=64");
        }

        private void propriedadesDoMóduloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=WHaqx5VxXVc");
        }

        private void gráficoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=HMEBmYNncuQ");
        }

        private void equaçõesModularesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2fFnD5vgE5Q&index=67");
        }

        private void inequaçõesModularesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jnEskZaPah0");
        }

        private void questõesComentadasFunçãoModularParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=l9fZ1rmGw0Q&index=69");
        }

        private void questõesComentadasFunçãoModularParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=y3DtJRnqPSE&index=70");
        }

        private void revisãoDePotenciaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=n5NRv2cWQIg");
        }

        private void introduçãoToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9FGtZt84w6U&index=72");
        }

        private void gráficoParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SXkjJZHM5UU&index=73");
        }

        private void gráficoParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=31N3orMcdVU&index=74");
        }

        private void equaçõesExponenciaisParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3EXISt9iVqg&index=75");
        }

        private void equaçõesExponenciaisParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NPBry6hE3NA&index=76");
        }

        private void inequaçõesExponenciaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Y7gaJoRnLAY");
        }

        private void questõesComentadasParte1ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=KEzrU0NXm5g&index=78");
        }

        private void questõesComentadasParte2ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CFb6-3bR98M");
        }

        private void noçõesBásicasToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SPZqQ5qn3P0&index=15");
        }

        private void conceitosIniciaisToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=UKgRWYwrzd0");
        }

        private void introduçãoParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=esdFuyG7zGs");
        }

        private void introduçãoParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BzbzlRyaj2U&index=81");
        }

        private void condiçãoDeExistênciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3ennIevODaA");
        }

        private void consequênciasDaDefiniçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cjXN-cs5deo");
        }

        private void propriedadesOperatóriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3gNGS4vzM_o&index=84");
        }

        private void propriedadesOperatóriasExercíciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BkNmuxmnvEc&index=85");
        }

        private void cálculoDeLogaritmosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=E-upQwSS2Vw");
        }

        private void mudançaDeBaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=kZUCI3nFfwk");
        }

        private void logaritmoEAsEquaçõesExponenciaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=y57lgKwsHsk");
        }

        private void aplicaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=IEDBi4x_zQE");
        }

        private void funçãoLogarítmicaEGráficoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=MkgfW2MMnHc&index=90");
        }

        private void equaçõesLogarítmicasParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=sapNhEkx_ZE");
        }

        private void equaçõesLogarítmicasParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LkCvsZdJlD4");
        }

        private void inequaçõesLogarítmicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Fdbc8x0bUT0");
        }

        private void logaritmoQuestõesComentadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LXamhAIIaUg&index=94");
        }

        private void funçãoLogarítmicaQuestõesComentadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=M99eny1lY2M");
        }

        private void equaçõesLogarítmicasQuestõesComentadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2ZZ599-7XMo&index=96");
        }

        private void introduçãoÂngulosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0CnUdzmpO8E");
        }

        private void paralelismoEntreRetasNoPlanoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pyb-5syEWdI");
        }

        private void polígonosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cooNCC78aBI&index=117");
        }

        private void polígonosRegularesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ycFWL3j4qK0");
        }

        private void introduçãoAosTriângulosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TyyTOvjo3D0&index=119");
        }

        private void classificaçãoDosTriângulosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3x920GHyF4g");
        }

        private void pontosNotáveisDoTriânguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=dAZ-mUZbA-A");
        }

        private void áreaDeTriângulosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XlJEpO0K4b0");
        }

        private void semelhançaDeTriângulosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LxFlnxS6iMg");
        }

        private void triânguloRetânguloRelaçõesMétricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=f4JBVvr72MQ");
        }

        private void triânguloRetânguloExercíciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=FpUGVLcIKEo&index=125");
        }

        private void triânguloEquiláteroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OO8NKf_NKJo");
        }

        private void teoremaDeTalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=MQw2524ZZcU");
        }

        private void quadriláterosParalelogramoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=KrFNq-8aP_4");
        }

        private void quadriláterosRetânguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ddfkogMMVEc");
        }

        private void quadriláterosLosangoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BWWaSz-X6nM");
        }

        private void quadriláterosQuadradoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=p6xYxnH6yPs");
        }

        private void quadriláterosTrapézioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2IPnbQmO88Y");
        }

        private void hexágonoRegularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Y5Yq_QJcTEw&index=133");
        }

        private void circunferênciaConceitosIniciaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gojZfbyitrM&index=134");
        }

        private void relaçõesMétricasNaCircunferênciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=kIqcsGBKRq0&index=135");
        }

        private void circunferênciaPotênciaDePontoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qKyE7Q8rr1I&index=136");
        }

        private void ângulosNaCircunferênciaParte1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=NKEPE99XOkQ&index=137");
        }

        private void ângulosNaCircunferênciaParte2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JphuTOv_kE8");
        }

        private void comprimentoDaCircunferênciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Et9z68v5UQ4");
        }

        private void áreaDoCírculoESetorCircularToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oaN_ui6K2w4");
        }

        private void áreaDeSegmentoECoroaCircularesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=MNxLUQQDr18");
        }

        private void áreasSemelhantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gZsfA88Yar0&index=142");
        }

        private void prismasIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0ijHQy-U-VE");
        }

        private void prismasIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=t3Mev6rDKPU");
        }

        private void exercíciosIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=A2eMIbqqW4I&index=47");
        }

        private void pirâmidesIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Pe8pGyaJEqw");
        }

        private void pirâmidesIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oRxRy_l69T8");
        }

        private void exercíciosIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OPbuZnhFs2A");
        }

        private void cilindroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0fWdjhGCsSg&index=51");
        }

        private void coneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9M8gTcQ7KZY");
        }

        private void esferaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=m9TgY5Wywok&index=53");
        }

        private void troncosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OuupqiNyQls&index=54");
        }

        private void exercíciosIIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TtVp4pFBhiI&index=55");
        }

        private void exercíciosIVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-VXm0rCWros&index=56");
        }

        private void exercíciosVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=2Ll5fayWtJA&index=57");
        }

        private void posiçãoEstruturasERelaçãoDeEulerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=j8XzEnzwd9o&index=44");
        }

        private void distânciaEntre2PontosEPontoMédioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oOQxBRfhTGs");
        }

        private void baricentroEÁreaDeTriânguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1iesxv-1Crs&index=11");
        }

        private void exercicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VV7C7tYUAik");
        }

        private void condiçõesDeAlinhamentoDe3PontosEEquaçãoGeralDaRetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=j5ASUmoWZmc&index=13");
        }

        private void estudoDaRetaIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=_7eTtRNHGf8");
        }

        private void estudoDaRetaIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-jqu-KCv7RU&index=15");
        }

        private void exercícioEstudoDaRetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=71cu9gzvVzk");
        }

        private void estudoDaCircunferênciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vnxC_mW-P54");
        }

        private void estudoDaCircunferênciaExercícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=gLAn-7gPgHo");
        }

        private void unidadeImagináriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XSeYp-YHE-s&index=60");
        }

        private void formaAlgébricaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8orf8Pv97Us&index=61");
        }

        private void operaçõesNaFormaAlgébricaIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=0l6SLc6BtAc&index=62");
        }

        private void operaçõesNaFormaAlgébricaIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EX2haZrH3Jc&index=63");
        }

        private void potênciasDaUnidadeImagináriaiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8DjRJUYNaYY");
        }

        private void triânguloRetânguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qkW7bQ5q2XI&index=1");
        }

        private void trigonometriaNoTriânguloRetânguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=_ddOZFdvu3g&index=2");
        }

        private void triânguloQualquerLeiDosSenosECossenosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6ns8Wf15Gh4");
        }

        private void leiDosSenosECossenosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Z_5ZnFIarSc");
        }

        private void cicloTrigonométricoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PjqZMWZ6t9Q&index=5");
        }

        private void exercíciosResolvidosCicloTrigonométricoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6Mxhk3dBdnM");
        }

        private void relaçõesTrigonométricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=sKz-xpZpVj8");
        }

        private void operaçõesComArcosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4XrO1Ls_CR0");
        }

        private void exercíciosResolvidosOperaçõesComArcosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=fgOSKQGlz-I&index=9");
        }

        private void equaçõesTrigonométricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VVLAULiSSYM");
        }

        private void inequaçõesTrigonométricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=FgUwPkCorP4&index=11");
        }

        private void funçãoSenoECossenoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pzcy1a0yqL0");
        }

        private void funçãoTgCotgSecECossecToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jkRtRcLUn90&index=13");
        }

        private void exercíciosResolvidosFunçõesTrigonométricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=T-PoZNSp6lM");
        }

        private void polinômiosIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XySESQb3TWE");
        }

        private void polinômiosIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=uNF6HhKPJ6c");
            
        }

        private void binômioDeNewtonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=C5Vw00yWWzc");
        }

        private void coeficientesBinomiaisETriânguloDePascalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SX8JwHAIfXQ");
        }

        private void parte1ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SLzIbZ-7SBM");
        }

        private void parte2ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TL-igSGXbAQ");
        }

        private void parte3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=q3oaO14Gx78");
        }

        private void parte4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Grd3Td_Qwrk");
        }

        private void parte5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=URSSoml8x5A");
        }

        private void parte6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=T4TxKIh9OGY");
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem4.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem7.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem8.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem9.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem10.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem11.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem12.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem14.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem16.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem17.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem18.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem19.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem20_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem20.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem22_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem22.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem29_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem29.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem25_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem25.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem27_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem27.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem28_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem31_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem31.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem32_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem32.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem33_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem33.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem35_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem35.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem37_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem37.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem39_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem39.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem40_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem40.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem41_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem41.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem42_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem42.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem43_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem43.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem44_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem44.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem45_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem45.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem46_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem46.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem47_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem47.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem49_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem49.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem50_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem50.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem51_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem51.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem52_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem52.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem56_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem56.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem162_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem162.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem163_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem163.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem167_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem167.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem168_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem168.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem169_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem169.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem171_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem171.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem172_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem172.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem173_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem173.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem174_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem174.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem176_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem176.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem177_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem177.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem178_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem178.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem179_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem179.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem180_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem180.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem183_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem183.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem185_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem185.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem190_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem190.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem192_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem192.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem194_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem194.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem196_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem196.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem197_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem197.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem199_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem199.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem200_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem200.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem201_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem201.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem202_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem202.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem205_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem205.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem206_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem206.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem207_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem207.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem210_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem210.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem213_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem213.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem214_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem214.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem215_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem215.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem216_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem216.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem221_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem221.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem222_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem222.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem225_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem225.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem228_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem228.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem232_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem232.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem231_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem231.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem233_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem233.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem235_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem235.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem236_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem236.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem240_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem240.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem241_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem241.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem245_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem245.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem247_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem247.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem252_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem252.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem259_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem259.Text;
            ChamarQuiz();
        }
    }
}
