﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmFisica : Form
    {
        public FrmFisica()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }

        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }

        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }

        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Física";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void introduçãoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vqDXPz-JMuE");
        }

        private void primeiraLeiDeNewtonINÉRCIAToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=WadCT4REbPg");
        }

        private void egundaLeiDeNewtonToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Fw3S1CZUzYs");
        }

        private void terceiraLeiDeNewtonToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Qx0odeYXuPU");
        }

        private void leisDeNewtonPoliasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?time_continue=2&v=3irJhpZ6FeA");
        }

        private void leisDeNewtonAplicaçõesToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ua969fQJD1E");
        }

        private void leisDeNewtonTiposDeForçasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Z9fYAi79vHY");
        }

        private void forçaDeAtritoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LxoAVULkIwc");
        }

        private void forçaElásticaLeiDeHookeToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wRyHFdXDHdA");
        }

        private void quantidadeDeMovimentosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?time_continue=1&v=0NCUrFKuDbI");
        }

        private void impulsoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=KZ3XqgPLoW8");
        }

        private void colisõesToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=u9MNWwzzyTE");
            
        }

        private void pêndulosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PTvsGGqagKA");
        }

        private void impulsoQuantidadeDeMovimentosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("");
        }

        private void energiaMecânicaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=r_ZmEbu2u7E");
        }

        private void trabalhoEEnergiaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Ht-a2_yNuec");
        }

        private void eoremaDaEnergiaCinéticaTECToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JJhkD7E3jP0");
        }

        private void análiseGrandezasErrosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cC7dmPNGWLo");
        }

        private void pressãoHidrostáticaLeiDeStevinToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=sIRpjgBFEEk");
        }

        private void vasosComunicantesTubosEmUToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("");
        }

        private void máquinasHidráulicasEPrincípioDePascalToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Vdr5vC6qXds");
        }

        private void empuxoArquimedesToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TVfOEs_i38g");
        }

        private void hidrodinâmicaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("");
        }

        private void correnteElétricaToolStripMenuItem_Click_1(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=_oCU5-qJrrE");
        }

        private void leiDeOhmToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Ld8lY6WxV-k");
        }

        private void fatoresQueInfluenciamNaResistênciaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=eAkXQxqfISg");
        }

        private void potênciaElétricaEEnergiaElétricaToolStripMenuItem_Click_1(object sender, System.EventArgs e)
        {
            LeitorCodigo("http://aulade.com.br/#videoaulas");
        }

        private void introduçãoToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=QCHdcPV1oj0");
        }

        private void processosDeEletrizaçõesToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yD48T4p2blE");
        }

        private void leiDeCoulombToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=449UV7-R0Gc");
        }

        private void campoElétricoIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3YjNfzEi8EI");
        }

        private void campoElétricoIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ECxrGAGfHz4");
        }

        private void potencialElétricoETrabalhoDeUmaForçaElétricaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pGGcK-_8IDw");
        }

        private void potencialElétricoIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=M4GIP1tbr30");
        }

        private void potencialElétricoIIISuperfíciesEquipotenciaisToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TslYhDW7gs8");
        }

        private void associaçãoDeResistoresICircuitoEmSérieToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=yWIjjUAqRMc");
        }

        private void associaçãoDeResistoresIICircuitoEmParaleloToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OzQkocOXo1Q");
        }

        private void associaçãoDeResistoresIIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bvX0rzGx0So");
        }

        private void circuitoMistoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XFVkX7qu92A");
        }

        private void capacitoresToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=tP_EchgrUr4");
        }

        private void geradoresEReceptoresToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bMSqEn_BjGA");
        }

        private void dispersãoLuminosaECoresToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1yO_wAOLEww");
        }

        private void espelhoPlanoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=hPX7F4eKdtA");
        }

        private void espelhoEsféricosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=-sHSkLAJpM0");
        }

        private void lentesToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?time_continue=1&v=yBLJEEUKg8o");
        }

        private void defeitosDeVisãoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XUKHqp2p_Aw");
        }

        private void dispersãoLuminosaECoresToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1yO_wAOLEww");
        }

        private void introduçãoToolStripMenuItem2_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?time_continue=49&v=dtbnxCWwlAs");
        }

        private void conceitoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=azd53ccObUA");
        }

        private void velocidadeDasOndasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=L4q3qBxhErc");
        }

        private void introduçãoToolStripMenuItem3_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SBWoFOPyGNI"); 
        }

        private void velocidadeMédiaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=aBRAzepTA9E");
        }

        private void movimentoRetilíneoUniformeMRUToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cTE5y7csh4w");
        }

        private void mRUAPLICAÇÕESToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=xq96Dhey_10");
        }

        private void velocidadeRelativaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=njxZQ-pDxdA");
        }

        private void movimentoRetilíneoUniformementeVariadoMRUVToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=vOP8F16DtOI");
        }

        private void movimentoRetilíneoUniformementeVariadoMRUVIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Gvvp7NFwcTo");
        }

        private void movimentoDeQuedaLivreMQLToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Sg5c0YLmPuM");
        }

        private void lançamentosHorizontaisToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=evjA_ZjgAKA");
        }

        private void lançamentosOblíquosToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=eegHMloa670");
        }

        private void gráficosDaCinemáticaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wM_vesmoidQ");
        }

        private void introduçãoToolStripMenuItem4_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=zFH0ziqXYds");
        }

        private void uniformeMCUToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=UIIXHA3PlLA");
        }

        private void aplicaçõesToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=QFWoUXb3Yik");
        }

        private void deduçãoDaEquaçãoDeTorricelliToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JA8zrm0IoDw");
        }

        private void físicaNuclearToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Eb5Atol3H4Q");
        }

        private void radioatividadeToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=dFYvWD4Hgps");
        }

        private void decaimentoRadioativoToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=F9g5m86Mku4");
        }

        private void introduçãoÀTermologiaToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=PE_NTlGyXYc&index=81");
        }

        private void transferênciaDeCalorToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jWqS9OpFjuA&index=82");
        }

        private void escalasTermométricasToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EoY32KVqhyk");
        }

        private void dilataçãoTérmicaIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oi4bOi0ZfUM&index=87");
        }

        private void dilataçãoTérmicaIIToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Pk702TR__kE&index=88&");
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem2.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem10.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem11.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem13.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem14.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem16.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem17.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem18.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem19.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem20_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem20.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem24_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem24.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem28_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem29_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem29.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem30_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem30.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem31_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem31.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem33_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem33.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem34_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem34.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem35_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem35.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem37_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem37.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem38_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem38.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem39_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem39.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem41_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem41.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem42_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem42.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem43_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem43.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem44_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem44.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem47_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem47.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem48_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem48.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem49_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem49.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem51_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem51.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem55_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem55.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem56_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem56.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem57_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem57.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem58_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem58.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem60_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem60.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem61_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem61.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem62_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem62.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem64_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem64.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem67_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem67.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem68_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem68.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem69_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem69.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem71_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem71.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem72_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem72.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem73_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem73.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem74_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem74.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem75_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem75.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem76_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem76.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem79_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem79.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem80_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem80.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem81_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem81.Text;
            ChamarQuiz();
        }

        private void fecharMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
             MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }
    }
}
