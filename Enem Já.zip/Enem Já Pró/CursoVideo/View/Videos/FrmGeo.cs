﻿using CursoVideo.DTO;
using System;
using System.Windows.Forms;

namespace CursoVideo.View.Videos
{
    public partial class FrmGeo : Form
    {
        public FrmGeo()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            panelQuiz.Visible = false;
        }

        private string RetornarURL(string URL)
        {
            /*
             Verificar se exite a string watch?, caso exista irá retornar 1
             */
            if (URL.IndexOf("watch?") > 0)
            {

                URL = URL.Replace("watch?", ""); //Trocar 'watch?' por nada (vázio/string.empty)
                URL = URL.Replace("=", "/"); //Trocar '=' por '/', isto é uma regra do Youtube, estou apenas seguindo
                URL = URL.Replace("index/1", "index=1"); //Troca index/1 por index/1, isto é uma regra do Youtube
                URL = URL.Replace("index/2", "index=2");
                URL = URL.Replace("index/3", "index=3");
                URL = URL.Replace("index/4", "index=4");
                URL = URL.Replace("index/5", "index=5");
                URL = URL.Replace("index/6", "index=6");
                URL = URL.Replace("index/7", "index=7");
                URL = URL.Replace("index/8", "index=8");
                URL = URL.Replace("index/9", "index=9");
                URL = URL.Replace("index/10", "index=10");
                URL = URL.Replace("index/11", "index=11");
                URL = URL.Replace("index/12", "index=12");
                URL = URL.Replace("index/13", "index=13");
                URL = URL.Replace("index/14", "index=14");
                URL = URL.Replace("index/15", "index=15");
                URL = URL.Replace("index/16", "index=16");
                URL = URL.Replace("index/17", "index=17");
                URL = URL.Replace("index/18", "index=18");
                URL = URL.Replace("index/19", "index=19");
                URL = URL.Replace("index/20", "index=20");
                URL = URL.Replace("index/21", "index=21");
                URL = URL.Replace("index/22", "index=22");
                URL = URL.Replace("index/23", "index=23");
                URL = URL.Replace("index/24", "index=24");
                URL = URL.Replace("index/25", "index=25");
                URL = URL.Replace("index/26", "index=26");
                URL = URL + "&autoplay=1"; //Para que o vídeo inicie automaticamente, adiciona '&autoplay=1'.
            }

            return URL;
        }

        private void LeitorCodigo(string URLs)
        {
            PictureCSharp.Visible = false;
            panelQuiz.Visible = false;
            panelQuiz.Enabled = false;

            string URL = "";

            URL = RetornarURL(URLs); //Passamos o valor do txtEndereco para o médodo.

            sfoPlayer.Movie = URL; //Passamos para a pro;priedade o valor da nova URL.
        }

        public void ChamarQuiz()
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YD43j-GxWL4");

            panelQuiz.Enabled = true;
            panelQuiz.Visible = true;
            panelQuiz.Controls.Clear();

            PergDTO.MATERIA = "Geografia";

            FrmQuiz frm = new FrmQuiz();
            frm.TopLevel = false;
            panelQuiz.Controls.Add(frm);
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void orientaçãoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=3TCZfNonZ7Q&index=2");
        }

        private void escalaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=cMoIJamVMD8&index=3");
        }

        private void coordenadasGeográficasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Ttq-KsaK_Rw");
        }

        private void projeçõesCartográficasCilíndricaMercatorEPetersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Wl8HWn_x3yw");
        }

        private void projeçõesCartográficasCônicaEAzimutalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=afgfVFramVc");
        }

        private void fusoHorárioIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=FN2PkvLRn_8");
        }

        private void fusoHorárioIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=z_h_GePOIpk");
        }

        private void fusoHorárioIIIBrasilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=WQHqqGYJTfk");
        }

        private void oQueÉClimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Y8GS1QIAAJA");
            
        }

        private void fatoresClimáticosIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BLKZE9Y0Geo");
        }

        private void circulaçãoGeralDaAtmosferaIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=K6kaRV6gKEM");
        }

        private void circulaçãoGeralDaAtmosferaIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=btWQfFTicZA");

        }

        private void tiposDeChuvaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=kmx33BN_FqY");
        }

        private void dinâmicaDeBrisasEMonçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=AuaHZ4h6QFw");
        }

        private void climasDoBrasilIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Q3bRn1Xpodk");
        }

        private void climasDoBrasilIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=s48mktILziY");
            
        }

        private void elNiñoELaNiñaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jEJ6RyZP0tE");
        }

        private void tempoGeológicoIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=qhxQvc1rdZ0");
        }

        private void tempoGeológicoIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=lCQZFIqx1q4");
        }

        private void estruturaInternaDaTerraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1DbwZTjDaIc");
            
        }

        private void placasTectônicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=zdWXsbsXgQ8");
        }

        private void tiposDeRochaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YQMl7Hov-eQ");
        }

        private void estruturasGeológicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=TuhVdugWtk0");
            
        }

        private void agentesInternosDeFormaçãoDeRelevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=I9GkPcNlSsU");
        }

        private void agentesExternosDeFormaçãoDeRelevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wqCD1r9Iyw0");
        }

        private void planaltoPlanícieEDepressãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=APu5e5O82U4");
        }

        private void relevoBrasileiroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=y6Ut69KfC4U");
            
        }

        private void relevoMarinhoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=jo6EZptI2EU");
        }

        private void formaçãoDeSolosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Gp3Qa1YKMec");
        }

        private void formaçõesVegetaisIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8yCfLKYim_I");
        }

        private void formaçõesVegetaisIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=EFpzBIzmVX0");
        }

        private void formaçõesVegetaisEBiomasBrasileirosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=z_noUzFhNhU");
        }

        private void domíniosMorfoclimáticosIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8Za6oLfQc4U");
        }

        private void domíniosMorfoclimáticosIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=aKuxo3twS4s");

        }

        private void rotaçãoETranslaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LMt7sWQvfZ8");
        }

        private void solstíciosEEquinóciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bpn0Kw9hlpw");
        }

        private void zonasTérmicasEPeriélioEAfélioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=IzxPMwly0-E");
        }

        private void movimentoAparenteDoSolToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=h7cqpluD7hU");
        }

        private void introduçãoAQuestãoAmbientalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JCZ7mtPvd1k");
        }

        private void impactosAmbientaisIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=08zK2Ndz68A");
        }

        private void impactosAmbientaisIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=FZXFk7UYRIQ");
        }

        private void impactosAmbientaisIIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=QvOKBt1ldgI");
        }

        private void impactosAmbientaisIVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=K9BWM0Gdf90");
        }

        private void aspectosPedológicosBásicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=VyQ8GnHnVaY");
           
        }

        private void amazôniaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=8txFEoeVM1g");
        }

        private void teoriasDemográficasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=mvkYBMbu8eE");
        }

        private void fasesDoCrescimentoVegetativoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=9GMAGJCD6P8");
        }

        private void taxasEConceitosParaEstudoDemográficoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SWvWbBXCxmk");
        }

        private void pirâmidesEtáriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=1iFXKzcSaRg");
        }

        private void tiposDeMigraçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=LzSRCNO0Klw");
        }

        private void migraçõesBrasileirasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CiFnuCSb1B8");
        }

        private void estruturaEconômicaDaPopulaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=YRxVPpeBSWo");
            
        }

        private void asRevoluçõesIndustriaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=4d-TyvjIRqM");
        }

        private void aTerceiraRevoluçãoIndustrialMeioTécnicoCientíficoInformacionalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=AqzrokvzgXI");
        }

        private void modosDeProduçãoTaylorismoFordismoEToyotismoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=E4AI7ojUJmM");
        }

        private void conceitosEconômicosCartelTrusteJointVentureEEtcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=7ivheFVS4-A");
        }

        private void aIndustrializaçãoBrasileiraIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=wBQmWe9yrG4");
        }

        private void aIndustrializaçãoBrasileiraIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=oQ81dI6cdCI");
        }

        private void principaisConceitosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=WWQoKjwiEog");
            
        }

        private void transportesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=MAhP7e3fBNY");
        }

        private void regiõesMetropolitanasBrasileirasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=79WCMa85qlg");
        }

        private void conceitoEClassificaçãoDeCidadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=BZdGiHoUNBc");
           
        }

        private void sistemasAgrícolasIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=k3vlrwPokNM");
        }

        private void sistemasAgrícolasIIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=JIhlqy7ngtI");
        }

        private void mecanizaçãoBrasileiraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=pjoagZWJX4A");
        }

        private void noçõesDeCorrentesEconômicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=W7Ccgjsgl0A");
        }

        private void ordensMundiaisIAVelhaORDEMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=XNjJru0cU3I");
        }

        private void ordensMundiaisIIGUERRAFRIAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ZgC5CJXMM1o");
        }

        private void ordensMundiaisIIIANOVAORDEMMUNDIALToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=6N5vYGU9NtU");
        }

        private void globalizaçãoEconômicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=m39xY4n9_sw");
        }

        private void blocosEconômicosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=SfDRSVmb_5A");
        }

        private void recursosRenováveisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Rg6m65RF_1A&index=76");
        }

        private void recursosNãoRenováveisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=_G0V9qqv8eU&index=75");
            
        }

        private void conflitosNoOrienteMédioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=idXlH3O110o");
        }

        private void japãoESuasCaracterísticasFísicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=H8V2lokmwWs&index=53");
            
        }

        private void eUASuperpotênciaGlobalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=CL-caaURuSM");
        }

        private void uniãoEuropeiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=OrhYIZb5mt0&index=51");
        }

        private void bRICToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=ynSEcsnysRY");
        }

        private void bRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=bnRrUuYuwz8&index=5");
        }

        private void disponibilidadeDeÁguaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=myCaHMkxaUQ");
        }

        private void conflitosNaEuropaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=hlxZ9n0s_5Y");
            
        }

        private void conflitosNaMultipolaridadeAméricaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=dKNh4G9heCU");
        }

        private void conflitosNoExtremoOrienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=tH1Y4R2cXRo");
        }

        private void chinaAPotênciaDoSéculoXXIToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LeitorCodigo("https://www.youtube.com/watch?v=Wh-CUs5Z6pE");
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem3.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem4.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem5.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem6.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem7.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem8.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem10.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem13.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem14.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem15.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem16.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem18.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem19.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem20_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem20.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem22_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem22.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem23_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem23.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem24_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem24.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem26_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem26.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem28_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem28.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem30_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem30.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem31_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem31.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem32_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem32.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem33_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem33.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem35_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem35.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem36_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem36.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem37_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem37.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem38_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem38.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem39_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem39.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem40_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem40.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem42_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem42.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem44_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem44.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem45_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem45.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem50_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem50.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem55_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem55.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem57_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem57.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem60_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem60.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem61_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem61.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem62_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem62.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem63_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem63.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem64_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem64.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem65_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem65.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem66_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem66.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem68_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem68.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem69_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem69.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem70_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem70.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem71_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem71.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem72_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem72.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem76_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem76.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem77_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem77.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem78_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem78.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem80_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem80.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem82_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem82.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem84_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem84.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem85_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem85.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem86_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem86.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem87_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem87.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem88_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem88.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem89_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem89.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem91_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem91.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem92_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem92.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem93_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem93.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem95_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem95.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem96_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem96.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem97_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem97.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem98_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem98.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem99_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem99.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem100_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem100.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem101_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem101.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem102_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem102.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem103_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem103.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem104_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem104.Text;
            ChamarQuiz();
        }

        private void toolStripMenuItem105_Click(object sender, EventArgs e)
        {
            PergDTO.TEMA = toolStripMenuItem105.Text;
            ChamarQuiz();
        }

        private void fecharMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa mesmo sair", "Sair",
              MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }
    }
}
