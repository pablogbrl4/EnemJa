﻿namespace CursoVideo.View
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            this.msMenu = new System.Windows.Forms.MenuStrip();
            this.ItemMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AulasMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PhpMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.JavaScriptMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CssMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MySqlMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HtmlMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.JavaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CSharpMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastrarPerguntasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarPerguntasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SobreMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.msMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // msMenu
            // 
            this.msMenu.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.msMenu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msMenu.ImageScalingSize = new System.Drawing.Size(25, 25);
            this.msMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ItemMenu,
            this.jToolStripMenuItem});
            this.msMenu.Location = new System.Drawing.Point(0, 0);
            this.msMenu.Name = "msMenu";
            this.msMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.msMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.msMenu.Size = new System.Drawing.Size(1020, 33);
            this.msMenu.TabIndex = 58;
            // 
            // ItemMenu
            // 
            this.ItemMenu.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ItemMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ItemMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AulasMenuItem,
            this.cadastrarPerguntasToolStripMenuItem,
            this.editarPerguntasToolStripMenuItem});
            this.ItemMenu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemMenu.ForeColor = System.Drawing.SystemColors.Control;
            this.ItemMenu.Image = ((System.Drawing.Image)(resources.GetObject("ItemMenu.Image")));
            this.ItemMenu.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ItemMenu.ImageTransparentColor = System.Drawing.SystemColors.ControlLightLight;
            this.ItemMenu.Name = "ItemMenu";
            this.ItemMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ItemMenu.Size = new System.Drawing.Size(37, 29);
            // 
            // AulasMenuItem
            // 
            this.AulasMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.AulasMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PhpMenuItem,
            this.JavaScriptMenuItem,
            this.CssMenuItem,
            this.MySqlMenuItem,
            this.historiaToolStripMenuItem,
            this.HtmlMenuItem,
            this.sociologiaToolStripMenuItem,
            this.JavaMenuItem,
            this.CSharpMenuItem1});
            this.AulasMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.AulasMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("AulasMenuItem.Image")));
            this.AulasMenuItem.Name = "AulasMenuItem";
            this.AulasMenuItem.Size = new System.Drawing.Size(227, 32);
            this.AulasMenuItem.Text = "Aulas";
            // 
            // PhpMenuItem
            // 
            this.PhpMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.PhpMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.PhpMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("PhpMenuItem.Image")));
            this.PhpMenuItem.Name = "PhpMenuItem";
            this.PhpMenuItem.Size = new System.Drawing.Size(176, 30);
            this.PhpMenuItem.Text = "Biologia";
            this.PhpMenuItem.Click += new System.EventHandler(this.PhpMenuItem_Click);
            // 
            // JavaScriptMenuItem
            // 
            this.JavaScriptMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.JavaScriptMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("JavaScriptMenuItem.Image")));
            this.JavaScriptMenuItem.Name = "JavaScriptMenuItem";
            this.JavaScriptMenuItem.Size = new System.Drawing.Size(176, 30);
            this.JavaScriptMenuItem.Text = "Quimica";
            this.JavaScriptMenuItem.Click += new System.EventHandler(this.JavaScriptMenuItem_Click);
            // 
            // CssMenuItem
            // 
            this.CssMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CssMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("CssMenuItem.Image")));
            this.CssMenuItem.Name = "CssMenuItem";
            this.CssMenuItem.Size = new System.Drawing.Size(176, 30);
            this.CssMenuItem.Text = "Fisica";
            this.CssMenuItem.Click += new System.EventHandler(this.CssMenuItem_Click);
            // 
            // MySqlMenuItem
            // 
            this.MySqlMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.MySqlMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.MySqlMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("MySqlMenuItem.Image")));
            this.MySqlMenuItem.Name = "MySqlMenuItem";
            this.MySqlMenuItem.Size = new System.Drawing.Size(176, 30);
            this.MySqlMenuItem.Text = "Geografia";
            this.MySqlMenuItem.Click += new System.EventHandler(this.MySqlMenuItem_Click);
            // 
            // historiaToolStripMenuItem
            // 
            this.historiaToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.historiaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("historiaToolStripMenuItem.Image")));
            this.historiaToolStripMenuItem.Name = "historiaToolStripMenuItem";
            this.historiaToolStripMenuItem.Size = new System.Drawing.Size(176, 30);
            this.historiaToolStripMenuItem.Text = "História";
            this.historiaToolStripMenuItem.Click += new System.EventHandler(this.historiaToolStripMenuItem_Click);
            // 
            // HtmlMenuItem
            // 
            this.HtmlMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.HtmlMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("HtmlMenuItem.Image")));
            this.HtmlMenuItem.Name = "HtmlMenuItem";
            this.HtmlMenuItem.Size = new System.Drawing.Size(176, 30);
            this.HtmlMenuItem.Text = "Filosofia";
            this.HtmlMenuItem.Click += new System.EventHandler(this.HtmlMenuItem_Click);
            // 
            // sociologiaToolStripMenuItem
            // 
            this.sociologiaToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.sociologiaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sociologiaToolStripMenuItem.Image")));
            this.sociologiaToolStripMenuItem.Name = "sociologiaToolStripMenuItem";
            this.sociologiaToolStripMenuItem.Size = new System.Drawing.Size(176, 30);
            this.sociologiaToolStripMenuItem.Text = "Sociologia";
            this.sociologiaToolStripMenuItem.Click += new System.EventHandler(this.sociologiaToolStripMenuItem_Click);
            // 
            // JavaMenuItem
            // 
            this.JavaMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.JavaMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.JavaMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("JavaMenuItem.Image")));
            this.JavaMenuItem.Name = "JavaMenuItem";
            this.JavaMenuItem.Size = new System.Drawing.Size(176, 30);
            this.JavaMenuItem.Text = "Português";
            this.JavaMenuItem.Click += new System.EventHandler(this.JavaMenuItem_Click);
            // 
            // CSharpMenuItem1
            // 
            this.CSharpMenuItem1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CSharpMenuItem1.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.CSharpMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("CSharpMenuItem1.Image")));
            this.CSharpMenuItem1.Name = "CSharpMenuItem1";
            this.CSharpMenuItem1.Size = new System.Drawing.Size(176, 30);
            this.CSharpMenuItem1.Text = "Matematica";
            this.CSharpMenuItem1.Click += new System.EventHandler(this.CSharpMenuItem1_Click);
            // 
            // cadastrarPerguntasToolStripMenuItem
            // 
            this.cadastrarPerguntasToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.cadastrarPerguntasToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cadastrarPerguntasToolStripMenuItem.Image = global::CursoVideo.Properties.Resources.write_incin;
            this.cadastrarPerguntasToolStripMenuItem.Name = "cadastrarPerguntasToolStripMenuItem";
            this.cadastrarPerguntasToolStripMenuItem.Size = new System.Drawing.Size(227, 32);
            this.cadastrarPerguntasToolStripMenuItem.Text = "Cadastrar Perguntas";
            this.cadastrarPerguntasToolStripMenuItem.Click += new System.EventHandler(this.cadastrarPerguntasToolStripMenuItem_Click);
            // 
            // editarPerguntasToolStripMenuItem
            // 
            this.editarPerguntasToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.editarPerguntasToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.editarPerguntasToolStripMenuItem.Image = global::CursoVideo.Properties.Resources.ic_build_black_18dp;
            this.editarPerguntasToolStripMenuItem.Name = "editarPerguntasToolStripMenuItem";
            this.editarPerguntasToolStripMenuItem.Size = new System.Drawing.Size(227, 32);
            this.editarPerguntasToolStripMenuItem.Text = "Editar Perguntas";
            this.editarPerguntasToolStripMenuItem.Click += new System.EventHandler(this.editarPerguntasToolStripMenuItem_Click);
            // 
            // jToolStripMenuItem
            // 
            this.jToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.jToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SobreMenuItem,
            this.sairToolStripMenuItem});
            this.jToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("jToolStripMenuItem.Image")));
            this.jToolStripMenuItem.Name = "jToolStripMenuItem";
            this.jToolStripMenuItem.Size = new System.Drawing.Size(37, 29);
            // 
            // SobreMenuItem
            // 
            this.SobreMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.SobreMenuItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.SobreMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("SobreMenuItem.Image")));
            this.SobreMenuItem.Name = "SobreMenuItem";
            this.SobreMenuItem.Size = new System.Drawing.Size(120, 32);
            this.SobreMenuItem.Text = "Sobre";
            this.SobreMenuItem.Click += new System.EventHandler(this.SobreMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.sairToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.sairToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sairToolStripMenuItem.Image")));
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(120, 32);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // FrmPrincipal
            // 
            this.AccessibleDescription = "FrmPrincipal";
            this.AccessibleName = "FrmPrincipal";
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1020, 573);
            this.Controls.Add(this.msMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "  MENU";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.msMenu.ResumeLayout(false);
            this.msMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip msMenu;
        private System.Windows.Forms.ToolStripMenuItem ItemMenu;
        private System.Windows.Forms.ToolStripMenuItem AulasMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CSharpMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem JavaMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MySqlMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PhpMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HtmlMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CssMenuItem;
        private System.Windows.Forms.ToolStripMenuItem JavaScriptMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SobreMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastrarPerguntasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarPerguntasToolStripMenuItem;
    }
}