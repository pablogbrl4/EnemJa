﻿using CursoVideo.DTO;
using CursoVideo.Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CursoVideo.View
{
    public partial class FrmQuiz : Form
    {
        public FrmQuiz()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
        }
        int islide = 0;
        int i;

        ModelXML xml = new ModelXML();
        List<PergDTO> dto = new List<PergDTO>();
        PergDTO dtoMateria = new PergDTO();
        List<PergDTO> dtoS = new List<PergDTO>();
        
        public void refresh()
        {
            if (dtoS.Count != 0)
            {
                i = 0;

                DestravarBotoes();
                btnStart.Text = "";

                lblPergunta.Text = dtoS[0].Pergunta[0];

                rbA.Text = dtoS[0].A[0];

                rbB.Text = dtoS[0].B[0];

                rbC.Text = dtoS[0].C[0];

                rbD.Text = dtoS[0].D[0];
            }
            else
            {                          
                travarBotoes();
                btnStart.Enabled = false;
                MessageBox.Show("Este Tema Não Possui Perguntas ");
            }
            
        }
        public void Score()
        {
            DialogResult dialogResult = MessageBox.Show("Você Obteve " + lblPontuacao.Text + " Pontos \nQuer Tentar denovo? ", "Pontuação", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                refresh();
                islide = 0;
            }
            else if (dialogResult == DialogResult.No)
            {
                this.Close();
            }
        }
        private void DestravarBotoes()
        {
            rbA.Enabled = true;
            rbC.Enabled = true;
            rbB.Enabled = true;
            rbD.Enabled = true;

            rbA.BackColor = Color.RoyalBlue;
            rbC.BackColor = Color.RoyalBlue;
            rbB.BackColor = Color.RoyalBlue;
            rbD.BackColor = Color.RoyalBlue;
        }
        private void travarBotoes()
        {
            rbA.Enabled = false;
            rbC.Enabled = false;
            rbB.Enabled = false;
            rbD.Enabled = false;
        }
        private void FrmQuiz_Load(object sender, System.EventArgs e)
             {
                dto = xml.xmlP();

                int contar = dto.Count;

                for (int j = 0; j < contar; j++)
                {
                    var materia = dtoMateria.materia = dto[j].materia;
                    var tem = dtoMateria.materia = dto[j].tema;

                    if (materia == PergDTO.MATERIA && tem == PergDTO.TEMA)
                    {
                        dtoS.Add(dto[j]);
                    }                 
                }

                this.refresh();
        }
        private void rbA_Click(object sender, System.EventArgs e)
        {
            if (rbA.Text == dtoS[i].R[0])
            {
                rbA.BackColor = Color.Green;
                lblPontuacao.Text = Convert.ToString(islide += 1);
            }
            else
            {
                rbA.BackColor = Color.Red;
            }
            btnStart.Text = "Proxima";
            travarBotoes();
            i++;
        }
        private void rbB_Click(object sender, System.EventArgs e)
        {
            if (rbB.Text == dtoS[i].R[0])
            {
                rbB.BackColor = Color.Green;
                lblPontuacao.Text = Convert.ToString(islide += 1);
            }
            else
            {
                rbB.BackColor = Color.Red;
            }
            btnStart.Text = "Proxima";
            travarBotoes();
            i++;
        }
        private void rbC_Click(object sender, System.EventArgs e)
        {
            if (rbC.Text == dtoS[i].R[0])
            {
                rbC.BackColor = Color.Green;
                lblPontuacao.Text = Convert.ToString(islide += 1);
            }
            else
            {
                rbC.BackColor = Color.Red;
            }
            btnStart.Text = "Proxima";
            travarBotoes();
            i++;
        }
        private void rbD_Click(object sender, System.EventArgs e)
        {
            if (rbD.Text == dtoS[i].R[0])
            {
                rbD.BackColor = Color.Green;
                lblPontuacao.Text = Convert.ToString(islide += 1);
            }
            else
            {
                rbD.BackColor = Color.Red;
            }
            btnStart.Text = "Proxima";
            travarBotoes();
            i++;
        }
        private void btnStart_Click(object sender, System.EventArgs e)
        {
            int io = dtoS.Count;
            DestravarBotoes();

            for (; i < io;)
            {
                lblPergunta.Text = dtoS[i].Pergunta[0];

                rbA.Text = dtoS[i].A[0];

                rbB.Text = dtoS[i].B[0];

                rbC.Text = dtoS[i].C[0];

                rbD.Text = dtoS[i].D[0];

                return;
            }

            Score();
        }

     
    }
}
