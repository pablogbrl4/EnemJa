﻿using System;
using System.Windows.Forms;

namespace CursoVideo.View
{
    public partial class FrmSobre : Form
    {
        public FrmSobre()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
