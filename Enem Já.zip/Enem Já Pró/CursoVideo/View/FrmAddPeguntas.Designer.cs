﻿namespace CursoVideo.View
{
    partial class FrmAddPeguntas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbxD = new System.Windows.Forms.CheckBox();
            this.cbxC = new System.Windows.Forms.CheckBox();
            this.cbxB = new System.Windows.Forms.CheckBox();
            this.txtD = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtA = new System.Windows.Forms.TextBox();
            this.cbxA = new System.Windows.Forms.CheckBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxMateria = new System.Windows.Forms.ComboBox();
            this.cbxTema = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Tema = new System.Windows.Forms.Label();
            this.txtPer = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.cbxD);
            this.groupBox1.Controls.Add(this.cbxC);
            this.groupBox1.Controls.Add(this.cbxB);
            this.groupBox1.Controls.Add(this.txtD);
            this.groupBox1.Controls.Add(this.txtC);
            this.groupBox1.Controls.Add(this.txtB);
            this.groupBox1.Controls.Add(this.txtA);
            this.groupBox1.Controls.Add(this.cbxA);
            this.groupBox1.Controls.Add(this.btnStart);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(14, 393);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1004, 193);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // cbxD
            // 
            this.cbxD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxD.AutoSize = true;
            this.cbxD.Location = new System.Drawing.Point(976, 97);
            this.cbxD.Name = "cbxD";
            this.cbxD.Size = new System.Drawing.Size(15, 14);
            this.cbxD.TabIndex = 38;
            this.cbxD.UseVisualStyleBackColor = true;
            this.cbxD.CheckedChanged += new System.EventHandler(this.cbxD_CheckedChanged_1);
            // 
            // cbxC
            // 
            this.cbxC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxC.AutoSize = true;
            this.cbxC.Location = new System.Drawing.Point(976, 14);
            this.cbxC.Name = "cbxC";
            this.cbxC.Size = new System.Drawing.Size(15, 14);
            this.cbxC.TabIndex = 37;
            this.cbxC.UseVisualStyleBackColor = true;
            this.cbxC.CheckedChanged += new System.EventHandler(this.cbxC_CheckedChanged_1);
            // 
            // cbxB
            // 
            this.cbxB.AutoSize = true;
            this.cbxB.Location = new System.Drawing.Point(352, 97);
            this.cbxB.Name = "cbxB";
            this.cbxB.Size = new System.Drawing.Size(15, 14);
            this.cbxB.TabIndex = 36;
            this.cbxB.UseVisualStyleBackColor = true;
            this.cbxB.CheckedChanged += new System.EventHandler(this.cbxB_CheckedChanged_1);
            // 
            // txtD
            // 
            this.txtD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtD.Location = new System.Drawing.Point(635, 119);
            this.txtD.Multiline = true;
            this.txtD.Name = "txtD";
            this.txtD.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtD.Size = new System.Drawing.Size(356, 57);
            this.txtD.TabIndex = 35;
            // 
            // txtC
            // 
            this.txtC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtC.Location = new System.Drawing.Point(635, 34);
            this.txtC.Multiline = true;
            this.txtC.Name = "txtC";
            this.txtC.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtC.Size = new System.Drawing.Size(356, 57);
            this.txtC.TabIndex = 34;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(11, 119);
            this.txtB.Multiline = true;
            this.txtB.Name = "txtB";
            this.txtB.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtB.Size = new System.Drawing.Size(356, 57);
            this.txtB.TabIndex = 33;
            // 
            // txtA
            // 
            this.txtA.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtA.Location = new System.Drawing.Point(11, 34);
            this.txtA.Multiline = true;
            this.txtA.Name = "txtA";
            this.txtA.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtA.Size = new System.Drawing.Size(356, 57);
            this.txtA.TabIndex = 32;
            // 
            // cbxA
            // 
            this.cbxA.AutoSize = true;
            this.cbxA.Checked = true;
            this.cbxA.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxA.Location = new System.Drawing.Point(352, 14);
            this.cbxA.Name = "cbxA";
            this.cbxA.Size = new System.Drawing.Size(15, 14);
            this.cbxA.TabIndex = 31;
            this.cbxA.UseVisualStyleBackColor = true;
            this.cbxA.CheckedChanged += new System.EventHandler(this.cbxA_CheckedChanged_1);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.BackColor = System.Drawing.Color.White;
            this.btnStart.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnStart.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ControlDark;
            this.btnStart.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.Black;
            this.btnStart.Location = new System.Drawing.Point(456, 87);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(98, 31);
            this.btnStart.TabIndex = 30;
            this.btnStart.Text = "Cadastrar";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(276, 286);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 24);
            this.label1.TabIndex = 19;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(14, 130);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1004, 246);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(285, 32);
            this.label2.TabIndex = 23;
            this.label2.Text = "Cadastrar Perguntas";
            // 
            // cbxMateria
            // 
            this.cbxMateria.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxMateria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMateria.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbxMateria.FormattingEnabled = true;
            this.cbxMateria.Location = new System.Drawing.Point(766, 51);
            this.cbxMateria.Name = "cbxMateria";
            this.cbxMateria.Size = new System.Drawing.Size(252, 21);
            this.cbxMateria.TabIndex = 24;
            this.cbxMateria.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cbxTema
            // 
            this.cbxTema.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxTema.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTema.FormattingEnabled = true;
            this.cbxTema.Location = new System.Drawing.Point(766, 82);
            this.cbxTema.Name = "cbxTema";
            this.cbxTema.Size = new System.Drawing.Size(252, 21);
            this.cbxTema.TabIndex = 25;
            this.cbxTema.SelectedIndexChanged += new System.EventHandler(this.cbxTema_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(696, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 19);
            this.label3.TabIndex = 26;
            this.label3.Text = "Materia";
            // 
            // Tema
            // 
            this.Tema.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Tema.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tema.Location = new System.Drawing.Point(710, 84);
            this.Tema.Name = "Tema";
            this.Tema.Size = new System.Drawing.Size(50, 19);
            this.Tema.TabIndex = 27;
            this.Tema.Text = "Tema";
            // 
            // txtPer
            // 
            this.txtPer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPer.Location = new System.Drawing.Point(25, 144);
            this.txtPer.Multiline = true;
            this.txtPer.Name = "txtPer";
            this.txtPer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPer.Size = new System.Drawing.Size(980, 216);
            this.txtPer.TabIndex = 22;
            // 
            // FrmAddPeguntas
            // 
            this.AccessibleDescription = "FrmAddPeguntas";
            this.AccessibleName = "FrmAddPeguntas";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.Tema);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbxTema);
            this.Controls.Add(this.cbxMateria);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPer);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmAddPeguntas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmAddPeguntas";
            this.Load += new System.EventHandler(this.FrmAddPeguntas_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbxMateria;
        private System.Windows.Forms.ComboBox cbxTema;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Tema;
        private System.Windows.Forms.TextBox txtPer;
        private System.Windows.Forms.CheckBox cbxD;
        private System.Windows.Forms.CheckBox cbxC;
        private System.Windows.Forms.CheckBox cbxB;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.CheckBox cbxA;
        private System.Windows.Forms.Button btnStart;
    }
}