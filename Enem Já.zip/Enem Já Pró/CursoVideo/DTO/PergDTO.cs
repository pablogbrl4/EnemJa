﻿using System.Collections.Generic;

namespace CursoVideo.DTO
{
    class PergDTO
    {
        public static string TEMA { get; set; }
        public static string MATERIA { get; set; }

        public string tema { get; set; }
        public string materia { get; set; }
        public string per { get; set; }
        public List<string> Pergunta { get; set; }
        public List<string> A { get; set; }
        public List<string> B { get; set; }
        public List<string> C { get; set; }
        public List<string> D { get; set; }
        public List<string> R { get; set; }
        public string Perguntas { get; set; }
        public string a { get; set; }
        public string b { get; set; }
        public string c { get; set; }
        public string d { get; set; }
        public string r { get; set; }
    }
}
