﻿using System.Collections.Generic;

namespace CursoVideo.DTO
{
    class PergColecao : List<PergDTO> 
    {
    }
}
